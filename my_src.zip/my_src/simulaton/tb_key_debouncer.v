`timescale 1ns/1ps
`include "system_params.vh"
// ============================================================================
// tb_key_debouncer.v — key_debouncer 4路按键消抖模块仿真
// 验证同步打拍、消抖计时、startup_ready 防误触发、单周期脉冲
// ============================================================================
module tb_key_debouncer;
    localparam CLK_HZ = `SYS_CLK_FREQ_HZ;
    localparam CLK_NS = 1000000000 / CLK_HZ;
    localparam DEBOUNCE_TICKS = CLK_HZ / 100;  // 10ms

    reg clk = 1'b0;
    reg rst_n = 1'b0;
    reg [3:0] key_raw = 4'b1111;
    wire [3:0] key_pressed_pulse;
    wire [3:0] key_state;
    always #(CLK_NS/2) clk = ~clk;

    key_debouncer #(.DEBOUNCE_TICKS(DEBOUNCE_TICKS)) dut
        (.clk(clk), .rst_n(rst_n), .key_raw(key_raw),
         .key_pressed_pulse(key_pressed_pulse), .key_state(key_state));

    integer errors = 0;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    initial begin
        repeat(20) @(posedge clk);
        rst_n = 1'b1;

        $display("[场景 1] 上电 50ms 内不应误触发");
        repeat(CLK_HZ/20 + 100) @(posedge clk);
        check(key_pressed_pulse == 0 && key_state == 0, "startup quiet");

        $display("[场景 2] SW1 短毛刺被忽略");
        key_raw[0] = 1'b0;
        repeat(5) @(posedge clk);
        key_raw[0] = 1'b1;
        repeat(DEBOUNCE_TICKS + 100) @(posedge clk);
        check(key_pressed_pulse[0] == 0, "glitch on SW1 ignored");

        $display("[场景 3] SW1 持续按下产生脉冲");
        key_raw[0] = 1'b0;
        repeat(DEBOUNCE_TICKS + 50) @(posedge clk);
        #1;
        check(key_pressed_pulse[0] == 1'b1, "SW1 pressed pulse");
        check(key_state[0] == 1'b1, "SW1 state asserted");
        repeat(5) @(posedge clk);
        check(key_pressed_pulse[0] == 0, "pulse single-cycle");

        $display("[场景 4] SW1 释放，SW2 按下");
        key_raw[0] = 1'b1;
        repeat(DEBOUNCE_TICKS + 50) @(posedge clk);
        check(key_state[0] == 0, "SW1 released");

        key_raw[1] = 1'b0;
        repeat(DEBOUNCE_TICKS + 50) @(posedge clk);
        check(key_pressed_pulse[1] == 1'b1, "SW2 pressed pulse");

        if (errors == 0) $display("\nPASS: key_debouncer 全部通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #50000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule