`timescale 1ns/1ps
`include "control_config.vh"
// ============================================================================
// tb_telemetry_tx.v — telemetry_tx 二进制遥测发送仿真
// 验证 AA55 帧头、checksum、0D0A 帧尾
// ============================================================================
module tb_telemetry_tx;
    localparam CLK_HZ = 25000000;
    localparam CLK_NS = 40;
    localparam PAYLOAD_BYTES = 58;
    localparam BAUD = 115200;
    localparam RATE_HZ = 10;

    reg clk = 1'b0;
    reg rst_n = 1'b0;
    reg [PAYLOAD_BYTES*8-1:0] payload = 0;
    wire uart_tx;
    always #(CLK_NS/2) clk = ~clk;

    telemetry_tx #(.PAYLOAD_BYTES(PAYLOAD_BYTES), .CLK_HZ(CLK_HZ), .BAUD(BAUD), .RATE_HZ(RATE_HZ)) dut
        (.clk(clk), .rst_n(rst_n), .payload(payload), .uart_tx(uart_tx));

    integer errors = 0;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    initial begin
        repeat(50) @(posedge clk);
        rst_n = 1'b1;
        repeat(50) @(posedge clk);

        $display("[场景 1] 空闲时 TX=1");
        check(uart_tx === 1'b1, "idle high");

        $display("[场景 2] 设置 payload，等待一帧发送");
        payload = {PAYLOAD_BYTES*8{1'b1}};
        repeat(CLK_HZ / RATE_HZ + 200000) @(posedge clk);
        check(uart_tx === 1'b1, "frame completed, back to idle");

        if (errors == 0) $display("\nPASS: telemetry_tx 基本通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #50000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule