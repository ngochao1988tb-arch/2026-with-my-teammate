`timescale 1ns/1ps
`include "system_params.vh"
// ============================================================================
// tb_motor_ident_profile.v — motor_ident_profile 电机辨识阶梯仿真
// 验证 7 级阶梯占空比、GAP+PULSE 时序、方向变更复位
// ============================================================================
module tb_motor_ident_profile;
    localparam CLK_HZ = `SYS_CLK_FREQ_HZ;
    localparam CLK_NS = 1000000000 / CLK_HZ;

    reg clk = 1'b0;
    reg rst_n = 1'b0;
    reg request = 1'b0;
    reg [1:0] direction = 2'b00;
    wire [7:0] duty;
    always #(CLK_NS/2) clk = ~clk;

    motor_ident_profile dut(.clk(clk), .rst_n(rst_n), .request(request),
        .direction(direction), .duty(duty));

    integer errors = 0;
    integer i;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    initial begin
        repeat(20) @(negedge clk);
        rst_n = 1'b1;
        repeat(10) @(negedge clk);

        $display("[场景 1] 无请求时 duty=0");
        check(duty == 0, "duty zero without request");

        $display("[场景 2] 启动 CW 辨识: 阶梯 8->12->16->24->32->48->64");
        request = 1'b1;
        direction = 2'b01;  // CW
        // 第一级
        repeat(CLK_HZ*2/5 + CLK_HZ/10) @(negedge clk);  // wait GAP then PULSE
        check(duty >= 8, "step 0: duty >= 8");
        // 第二级
        repeat(CLK_HZ*2/5 + CLK_HZ/10) @(negedge clk);
        check(duty >= 12, "step 1: duty >= 12");

        $display("[场景 3] 方向变更复位");
        direction = 2'b10;  // CCW
        repeat(100) @(negedge clk);
        check(duty == 0, "direction change resets");

        if (errors == 0) $display("\nPASS: motor_ident_profile 全部通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #50000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule