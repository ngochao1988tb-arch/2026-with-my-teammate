`timescale 1ns/1ps
// ============================================================================
// tb_hmi_div_const.v — hmi_div_const 常除法器仿真
// ============================================================================
module tb_hmi_div_const;
    reg clk = 1'b0;
    reg rst_n = 1'b0;
    reg [31:0] value = 32'd0;
    wire [31:0] result;
    always #10 clk = ~clk;

    hmi_div_const #(.DIVISOR(10)) dut(.clk(clk), .rst_n(rst_n), .value(value), .result(result));

    integer errors = 0;
    integer i;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    initial begin
        repeat(20) @(negedge clk);
        rst_n = 1'b1;
        repeat(10) @(negedge clk);

        $display("[场景 1] 基本除法 0/10, 10/10, 100/10");
        value = 32'd0;
        repeat(50) @(negedge clk);
        check(result == 0, "0/10 = 0");

        value = 32'd10;
        repeat(50) @(negedge clk);
        check(result == 1, "10/10 = 1");

        value = 32'd100;
        repeat(50) @(negedge clk);
        check(result == 10, "100/10 = 10");

        $display("[场景 2] 不同除数: 除数为 3");
        defparam dut.DIVISOR = 3;
        value = 32'd9;
        repeat(50) @(negedge clk);
        check(result == 3, "9/3 = 3");

        value = 32'd10;
        repeat(50) @(negedge clk);
        check(result == 3, "10/3 = 3 (truncated)");

        $display("[场景 3] 大数除法");
        defparam dut.DIVISOR = 10;
        value = 32'hFFFFFFFF;
        repeat(50) @(negedge clk);
        check(result == 32'hFFFFFFFF / 10, "max/10");

        if (errors == 0) $display("\nPASS: hmi_div_const 全部通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #10000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule