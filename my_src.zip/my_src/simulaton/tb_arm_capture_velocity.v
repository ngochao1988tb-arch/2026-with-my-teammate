`timescale 1ns/1ps
`include "control_config.vh"
// ============================================================================
// tb_arm_capture_velocity.v — arm_capture_velocity 捕获速度估计仿真
// 验证滑动窗口速度计算、fits 检查、clear
// ============================================================================
module tb_arm_capture_velocity;
    reg clk = 1'b0;
    reg rst_n = 1'b0;
    reg clear = 1'b0;
    reg tick = 1'b0;
    reg fresh = 1'b0;
    reg signed [31:0] angle = 32'd0;
    wire signed [31:0] velocity;
    wire valid;
    always #10 clk = ~clk;

    arm_capture_velocity dut
        (.clk(clk), .rst_n(rst_n), .clear(clear), .tick(tick), .fresh(fresh),
         .angle(angle), .velocity(velocity), .valid(valid));

    integer errors = 0;
    integer i;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    initial begin
        repeat(20) @(negedge clk);
        rst_n = 1'b1;
        repeat(10) @(negedge clk);

        $display("[场景 1] 初始状态 valid=0");
        check(!valid, "velocity not valid initially");

        $display("[场景 2] 填充滑动窗口");
        for(i = 0; i < 50; i = i + 1) begin
            angle = $signed(i * 1000);
            tick = 1; fresh = 1; @(negedge clk); tick = 0; fresh = 0;
            repeat(9) @(negedge clk);
        end
        check(valid, "velocity valid after window fills");

        $display("[场景 3] clear 复位");
        clear = 1;
        @(negedge clk); clear = 0;
        repeat(10) @(negedge clk);
        check(!valid, "clear resets validity");

        if (errors == 0) $display("\nPASS: arm_capture_velocity 基本通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #10000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule