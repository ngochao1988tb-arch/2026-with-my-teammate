`timescale 1ns/1ps
`include "control_config.vh"
// ============================================================================
// tb_fault_snapshot.v — fault_snapshot 故障快照保持模块仿真
// 验证故障进入时锁存现场、两个周期后释放、flag[7]标记
// ============================================================================
module tb_fault_snapshot;
    localparam PAYLOAD_BITS = 464;
    localparam CLK_HZ = 25000000;
    localparam HOLD_CYCLES = 2 * CLK_HZ / 10;  // 简化: 2 个遥测周期
    localparam CLK_NS = 40;

    reg clk = 1'b0;
    reg rst_n = 1'b0;
    reg [2:0] state = 3'd0;
    reg [PAYLOAD_BITS-1:0] live_payload = 0;
    wire [PAYLOAD_BITS-1:0] payload;
    always #(CLK_NS/2) clk = ~clk;

    fault_snapshot #(.PAYLOAD_BITS(PAYLOAD_BITS), .HOLD_CYCLES(HOLD_CYCLES)) dut
        (.clk(clk), .rst_n(rst_n), .state(state), .live_payload(live_payload), .payload(payload));

    integer errors = 0;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    initial begin
        repeat(20) @(negedge clk);
        rst_n = 1'b1;
        repeat(10) @(negedge clk);

        $display("[场景 1] 正常状态 payload = live_payload");
        state = 3'd3;  // balancing
        live_payload = {PAYLOAD_BITS{1'b1}};
        repeat(10) @(negedge clk);
        check(payload == live_payload, "normal state passes live payload");

        $display("[场景 2] 进入 fault (state 3->4)");
        live_payload = {PAYLOAD_BITS{1'b0}};
        @(negedge clk);
        state = 3'd4;  // fault
        repeat(5) @(negedge clk);
        check(payload[PAYLOAD_BITS-25], "flag[7] asserted in event payload");
        check(payload != live_payload, "event payload frozen");

        $display("[场景 3] 保持 HOLD_CYCLES 后恢复 live");
        repeat(HOLD_CYCLES + 10) @(negedge clk);
        check(payload == {PAYLOAD_BITS{1'b0}}, "after hold: live payload restored");

        if (errors == 0) $display("\nPASS: fault_snapshot 全部通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #10000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule