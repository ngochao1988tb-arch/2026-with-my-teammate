`timescale 1ns/1ps
`include "control_config.vh"
// ============================================================================
// tb_swingup_core.v — swingup_core 起摆能量泵核心仿真
// 验证速度估计、频率指令生成、端点处理、approach/restart 模式
// ============================================================================
module tb_swingup_core;
    reg clk = 1'b0;
    reg rst_n = 1'b0;
    reg sample_valid = 1'b0;
    reg enable = 1'b0;
    reg [12:0] ad_value = 13'd2048;
    reg signed [31:0] alpha_meas = 32'd0;
    reg signed [31:0] alpha_c = 32'd0;
    reg signed [31:0] arm_reference_q16 = 32'd0;
    wire signed [31:0] frequency_q8;
    wire signed [31:0] theta_dot_q16;
    wire signed [31:0] u_q16;
    wire velocity_valid;
    wire capture_safe;
    reg approach_valid = 1'b0;
    reg signed [31:0] approach_frequency_q8 = 32'd0;
    reg signed [31:0] approach_arm_velocity = 32'd0;
    wire approach_active;
    reg restart = 1'b0;
    reg signed [31:0] restart_frequency_q8 = 32'd0;
    wire recovery_active;
    wire [2:0] launch_phase;
    always #10 clk = ~clk;

    swingup_core dut
        (.clk(clk), .rst_n(rst_n), .sample_valid(sample_valid), .enable(enable),
         .ad_value(ad_value), .alpha_meas(alpha_meas), .alpha_c(alpha_c),
         .arm_reference_q16(arm_reference_q16),
         .frequency_q8(frequency_q8), .theta_dot_q16(theta_dot_q16), .u_q16(u_q16),
         .velocity_valid(velocity_valid), .capture_safe(capture_safe),
         .approach_valid(approach_valid), .approach_frequency_q8(approach_frequency_q8),
         .approach_arm_velocity(approach_arm_velocity), .approach_active(approach_active),
         .restart(restart), .restart_frequency_q8(restart_frequency_q8),
         .recovery_active(recovery_active), .launch_phase(launch_phase));

    integer errors = 0;
    integer i;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    initial begin
        repeat(20) @(negedge clk);
        rst_n = 1'b1;
        enable = 1'b1;
        repeat(10) @(negedge clk);

        $display("[场景 1] 静止下垂点: ADC 在中间值");
        ad_value = 13'd2048;
        alpha_meas = 32'd0;
        for(i = 0; i < 50; i = i + 1) begin
            sample_valid = 1; @(negedge clk); sample_valid = 0;
            repeat(499) @(negedge clk);
        end
        check(launch_phase <= 4, "swingup state machine running");

        $display("[场景 2] 使能切换: enable=0 复位");
        enable = 1'b0;
        repeat(20) @(negedge clk);
        check(frequency_q8 == 0, "disabled frequency zero");

        if (errors == 0) $display("\nPASS: swingup_core 基本通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #50000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule