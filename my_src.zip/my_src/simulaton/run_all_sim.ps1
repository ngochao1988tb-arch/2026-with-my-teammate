# ============================================================================
# run_all_sim.ps1 — 批量仿真运行脚本（Icarus Verilog / iverilog）
# 用法: pwsh -File run_all_sim.ps1
# 要求: iverilog & vvp 已在 PATH 中。
# ============================================================================

$ErrorActionPreference = "Continue"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$MasterSrc = Join-Path $Root "..\code\j280_balance_master\src"
$MasterSim = Join-Path $Root "..\code\j280_balance_master\sim"
$SlaveSrc  = Join-Path $Root "..\code\j280_balance_slave\src"
$SlaveVer  = Join-Path $Root "..\code\j280_balance_slave\verification"
$OutDir    = Join-Path $Root "build"
$LogDir    = Join-Path $Root "logs"

New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null

# -------- 所有测试用例 (模块名 -> 源文件列表) -----------------------------------
$Tests = @(
    # ---- 简单模块 ----
    @{ Name="tb_key_debounce";           Srcs=@("$MasterSrc\key_debounce.v","$MasterSrc\control_config.vh") },
    @{ Name="tb_serial_rx";              Srcs=@("$MasterSrc\serial_rx.v","$MasterSrc\control_config.vh") },
    @{ Name="tb_serial_tx";              Srcs=@("$MasterSrc\serial_tx.v","$MasterSrc\control_config.vh") },
    @{ Name="tb_uart_rx";                Srcs=@("$MasterSrc\uart_rx.v") },
    @{ Name="tb_uart_tx";                Srcs=@("$MasterSrc\uart_tx.v") },
    @{ Name="tb_square16_pipe";          Srcs=@("$MasterSrc\square16_pipe.v") },
    # ---- 核心模块 ----
    @{ Name="tb_variable_step_dir";      Srcs=@("$MasterSrc\variable_step_dir.v","$MasterSrc\control_config.vh") },
    @{ Name="tb_motor_encoder_link";     Srcs=@("$MasterSrc\motor_encoder_link.v","$MasterSrc\serial_rx.v","$MasterSrc\serial_tx.v","$MasterSrc\control_config.vh") },
    @{ Name="tb_lqr_core";               Srcs=@("$MasterSrc\lqr_core.v","$MasterSrc\lqr_coefficients.vh","$MasterSrc\control_config.vh") },
    @{ Name="tb_swingup_core";           Srcs=@("$MasterSrc\swingup_core.v","$MasterSrc\control_config.vh") },
    # ---- HMI 模块 ----
    @{ Name="tb_hmi_scale";              Srcs=@("$MasterSrc\hmi_scale.v") },
    @{ Name="tb_hmi_div_const";          Srcs=@("$MasterSrc\hmi_div_const.v") },
    @{ Name="tb_hmi_record_ram";         Srcs=@("$MasterSrc\hmi_record_ram.v") },
    @{ Name="tb_hmi_rx";                 Srcs=@("$MasterSrc\hmi_rx.v","$MasterSrc\serial_rx.v","$MasterSrc\control_config.vh") },
    @{ Name="tb_hmi_tx";                 Srcs=@("$MasterSrc\hmi_tx.v","$MasterSrc\serial_tx.v","$MasterSrc\control_config.vh") },
    # ---- 控制模块 ----
    @{ Name="tb_control_supervisor";     Srcs=@("$MasterSrc\control_supervisor.v","$MasterSrc\control_config.vh") },
    @{ Name="tb_control_aux";            Srcs=@("$MasterSrc\control_aux.v","$MasterSrc\control_config.vh") },
    @{ Name="tb_capture_command_guard";  Srcs=@("$MasterSrc\capture_command_guard.v","$MasterSrc\lqr_coefficients.vh","$MasterSrc\control_config.vh") },
    @{ Name="tb_fault_snapshot";         Srcs=@("$MasterSrc\fault_snapshot.v","$MasterSrc\control_config.vh") },
    @{ Name="tb_status_snapshot";        Srcs=@("$MasterSrc\status_snapshot.v","$MasterSrc\lcd_config.vh") },
    # ---- 语音/差旅模块 ----
    @{ Name="tb_voice_command_assembler"; Srcs=@("$MasterSrc\voice_command_assembler.v") },
    @{ Name="tb_voice_dual_coordinator";  Srcs=@("$MasterSrc\voice_dual_coordinator.v") },
    @{ Name="tb_voice_feedback_sequencer"; Srcs=@("$MasterSrc\voice_feedback_sequencer.v") },
    @{ Name="tb_voice_uart_bridge";       Srcs=@("$MasterSrc\voice_uart_bridge.v","$MasterSrc\voice_command_assembler.v","$MasterSrc\uart_rx.v","$MasterSrc\uart_tx.v") },
    # ---- 剩余 Master 模块 ----
    @{ Name="tb_arm_capture_velocity";   Srcs=@("$MasterSrc\arm_capture_velocity.v","$MasterSrc\control_config.vh") },
    @{ Name="tb_arm_travel_guard";       Srcs=@("$MasterSrc\arm_travel_guard.v","$MasterSrc\control_config.vh") },
    @{ Name="tb_telemetry_tx";           Srcs=@("$MasterSrc\telemetry_tx.v","$MasterSrc\serial_tx.v","$MasterSrc\control_config.vh") },
    @{ Name="tb_sine_feedforward";       Srcs=@("$MasterSrc\sine_feedforward.v","$MasterSrc\control_config.vh") },
    @{ Name="tb_run_notch";              Srcs=@("$MasterSrc\run_notch.v","$MasterSrc\control_config.vh") },
    @{ Name="tb_run_target";             Srcs=@("$MasterSrc\run_target.v","$MasterSrc\sine_reference.v","$MasterSrc\control_config.vh") },
    @{ Name="tb_sine_reference";         Srcs=@("$MasterSrc\sine_reference.v","$MasterSrc\control_config.vh") },
    @{ Name="tb_adc_sampler";            Srcs=@("$MasterSrc\adc_sampler.v","$MasterSrc\control_config.vh") },
    # ---- Slave 模块 ----
    @{ Name="tb_key_debouncer";          Srcs=@("$SlaveSrc\key_debouncer.v","$SlaveSrc\system_params.vh") },
    @{ Name="tb_encoder_quad";           Srcs=@("$SlaveSrc\encoder_quad.v","$SlaveSrc\system_params.vh") },
    @{ Name="tb_adc_3pa1030_sync";       Srcs=@("$SlaveSrc\adc_3pa1030_sync.v","$SlaveSrc\system_params.vh") },
    @{ Name="tb_uart_telemetry";         Srcs=@("$SlaveSrc\uart_telemetry.v","$SlaveSrc\system_params.vh") },
    @{ Name="tb_motor_ident_profile";    Srcs=@("$SlaveSrc\motor_ident_profile.v","$SlaveSrc\system_params.vh") },
    @{ Name="tb_motor_tb6612";           Srcs=@("$SlaveSrc\motor_tb6612.v","$SlaveSrc\system_params.vh") },
    @{ Name="tb_lqr_controller";         Srcs=@("$SlaveSrc\lqr_controller.v","$SlaveSrc\system_params.vh") },
    @{ Name="tb_swingup_energy_controller"; Srcs=@("$SlaveSrc\swingup_energy_controller.v","$SlaveSrc\swingup_peak_detector.v","$SlaveSrc\system_params.vh") },
    @{ Name="tb_i2c_register_slave";     Srcs=@("$SlaveSrc\i2c_register_slave.v") },
    @{ Name="tb_control_adaptive_velocity"; Srcs=@("$SlaveSrc\control_adaptive_velocity.v","$SlaveSrc\system_params.vh") },
    @{ Name="tb_control_kalman_velocity";   Srcs=@("$SlaveSrc\control_kalman_velocity.v","$SlaveSrc\system_params.vh") },
    @{ Name="tb_nn_core_q12";            Srcs=@("$SlaveSrc\nn_core_q12.v","$SlaveSrc\nn_weights_q12.vh") },
    @{ Name="tb_nn_safety_filter";       Srcs=@("$SlaveSrc\nn_safety_filter.v") },
    @{ Name="tb_capture_fifo";           Srcs=@("$SlaveSrc\capture_fifo.v") },
    @{ Name="tb_nn_predictor_trial";     Srcs=@("$SlaveSrc\nn_predictor_trial.v","$SlaveSrc\nn_core_q12.v","$SlaveSrc\nn_safety_filter.v","$SlaveSrc\nn_weights_q12.vh","$SlaveSrc\system_params.vh") },
    @{ Name="tb_slave_hmi_adapter";      Srcs=@("$SlaveSrc\slave_hmi_adapter.v","$SlaveSrc\system_params.vh") },
    @{ Name="tb_uart_remote";            Srcs=@("$SlaveSrc\uart_remote.v","$SlaveSrc\capture_fifo.v","$SlaveSrc\system_params.vh") },
    @{ Name="tb_arm_reference_pid";      Srcs=@("$SlaveSrc\arm_reference_pid.v","$SlaveSrc\system_params.vh") }
)

$Passed  = 0
$Failed  = 0
$Skipped = 0

Write-Host "========================================"
Write-Host " J280 FPGA Simulation Test Suite"
Write-Host "========================================"
Write-Host ""

foreach ($Test in $Tests) {
    $Name    = $Test.Name
    $SrcList = $Test.Srcs
    $TbFile  = Join-Path $Root "$Name.v"
    $VvpFile = Join-Path $OutDir "$Name.vvp"
    $LogFile = Join-Path $LogDir "$Name.log"

    if (-not (Test-Path $TbFile)) {
        Write-Host "[SKIP] $Name — tb file not found" -ForegroundColor Yellow
        $Skipped++
        continue
    }

    $AllSources = @($TbFile) + $SrcList
    $SourceArgs = $AllSources -join " "

    Write-Host -NoNewline "[....] $Name " -ForegroundColor Cyan

    # Compile
    $Compile = & iverilog -g2012 -o $VvpFile -I $MasterSrc -I $SlaveSrc -I $MasterSim $SourceArgs 2>&1
    if ($LASTEXITCODE -ne 0) {
        Write-Host " COMPILE FAIL" -ForegroundColor Red
        $Compile | Out-File $LogFile
        $Failed++
        continue
    }

    # Run
    $Result = & vvp $VvpFile 2>&1
    if ($LASTEXITCODE -ne 0) {
        Write-Host " SIM FAIL" -ForegroundColor Red
        $Result | Out-File $LogFile
        $Failed++
        continue
    }

    if (($Result -match "PASS").Count -gt 0) {
        Write-Host " PASS" -ForegroundColor Green
        $Passed++
    } else {
        Write-Host " UNKNOWN" -ForegroundColor Yellow
        $Skipped++
    }
    $Result | Out-File $LogFile
}

Write-Host ""
Write-Host "========================================"
Write-Host " Summary"
Write-Host "   PASSED : $Passed"
Write-Host "   FAILED : $Failed"
Write-Host "   SKIPPED: $Skipped"
Write-Host "   TOTAL  : $($Tests.Count)"
Write-Host "========================================"

if ($Failed -gt 0) {
    exit 1
}