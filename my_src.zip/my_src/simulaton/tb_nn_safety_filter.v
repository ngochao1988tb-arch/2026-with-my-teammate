`timescale 1ns/1ps
`include "system_params.vh"
// ============================================================================
// tb_nn_safety_filter.v — nn_safety_filter 神经网络安全滤波器仿真
// 验证模式切换、warmup、trip_latch、authority_safe、correction 输出
// ============================================================================
module tb_nn_safety_filter;
    localparam CLK_HZ = `SYS_CLK_FREQ_HZ;
    localparam CLK_NS = 1000000000 / CLK_HZ;

    reg clk = 1'b0;
    reg rst_n = 1'b0;
    reg control_tick = 1'b0;
    reg feature_tick = 1'b0;
    reg control_enable = 1'b0;
    reg hard_safe = 1'b0;
    reg authority_safe = 1'b0;
    reg prediction_done = 1'b0;
    reg [7:0] ood_mask = 8'd0;
    reg signed [31:0] delta_q12 = 32'd0;
    reg mode_write = 1'b0;
    reg [7:0] requested_mode = 8'd0;
    reg invert = 1'b0;
    wire [1:0] mode;
    wire trip_latch;
    wire arm_ready;
    wire request_ok;
    wire fresh;
    wire signed [15:0] correction;
    wire signed [15:0] filtered_q8;
    wire [15:0] warmup_ticks;
    wire [15:0] age_frames;
    always #(CLK_NS/2) clk = ~clk;

    nn_safety_filter #(.ALLOW_LIVE(1), .WARMUP_TICKS(10)) dut
        (.clk(clk), .rst_n(rst_n), .control_tick(control_tick),
         .feature_tick(feature_tick), .control_enable(control_enable),
         .hard_safe(hard_safe), .authority_safe(authority_safe),
         .prediction_done(prediction_done), .ood_mask(ood_mask),
         .delta_q12(delta_q12), .mode_write(mode_write),
         .requested_mode(requested_mode), .invert(invert),
         .mode(mode), .trip_latch(trip_latch), .arm_ready(arm_ready),
         .request_ok(request_ok), .fresh(fresh),
         .correction(correction), .filtered_q8(filtered_q8),
         .warmup_ticks(warmup_ticks), .age_frames(age_frames));

    integer errors = 0;
    integer i;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    initial begin
        repeat(20) @(negedge clk);
        rst_n = 1'b1;
        control_enable = 1'b1;
        hard_safe = 1'b1;
        authority_safe = 1'b1;
        repeat(10) @(negedge clk);

        $display("[场景 1] 初始 mode=1 (监测模式)");
        check(mode == 1, "initial mode = monitor");

        $display("[场景 2] 注入预测值");
        prediction_done = 1'b1;
        delta_q12 = 32'd0;
        @(negedge clk); prediction_done = 1'b0;
        repeat(5) @(negedge clk);
        check(fresh, "prediction fresh");

        $display("[场景 3] warmup 完成");
        for(i = 0; i < 30; i = i + 1) begin
            feature_tick = 1; @(negedge clk); feature_tick = 0;
            repeat(3) @(negedge clk);
        end
        check(warmup_ticks == 10, "warmup complete");

        $display("[场景 4] 请求 mode=2 (NN 模式)");
        if(arm_ready) begin
            mode_write = 1'b1;
            requested_mode = 8'd2;
            @(negedge clk); mode_write = 1'b0;
            repeat(10) @(negedge clk);
        end

        if (errors == 0) $display("\nPASS: nn_safety_filter 基本通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #10000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule