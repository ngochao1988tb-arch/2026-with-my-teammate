`timescale 1ns/1ps
`include "control_config.vh"
// ============================================================================
// tb_hmi_rx.v — hmi_rx 上位机/串口屏命令帧解析仿真
// 验证 55 AA 20 帧头、18 字节定长帧、boot 序列
// ============================================================================
module tb_hmi_rx;
    localparam CLK_HZ = 25000000;
    localparam CLK_NS = 40;
    localparam BAUD = 115200;
    localparam BIT_NS = 1000000000 / BAUD;

    reg clk = 1'b0;
    reg rst_n = 1'b0;
    reg rx = 1'b1;
    reg restart = 1'b0;
    wire valid;
    wire [7:0] cmd;
    wire signed [31:0] seq, arg, speed;
    wire boot;
    always #(CLK_NS/2) clk = ~clk;

    hmi_rx #(.CLK_HZ(CLK_HZ), .BAUD(BAUD)) dut
        (.clk(clk), .rst_n(rst_n), .rx(rx), .restart(restart),
         .valid(valid), .cmd(cmd), .seq(seq), .arg(arg), .speed(speed), .boot(boot));

    integer errors = 0;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    task send_byte(input [7:0] byte);
        integer i;
        begin
            rx = 1'b0;
            #(BIT_NS);
            for(i = 0; i < 8; i = i + 1) begin
                rx = byte[i];
                #(BIT_NS);
            end
            rx = 1'b1;
            #(BIT_NS);
        end
    endtask

    task send_frame(input [7:0] c, input [31:0] s, input [31:0] a, input [31:0] v);
        integer i;
        begin
            send_byte(8'h55);
            send_byte(8'hAA);
            send_byte(8'h20);
            send_byte(c);
            for(i = 0; i < 4; i = i + 1) send_byte(s[(i)*8+:8]);
            for(i = 0; i < 4; i = i + 1) send_byte(a[(i)*8+:8]);
            for(i = 0; i < 4; i = i + 1) send_byte(v[(i)*8+:8]);
            send_byte(8'h0D);
            send_byte(8'h0A);
        end
    endtask

    initial begin
        repeat(50) @(posedge clk);
        rst_n = 1'b1;
        repeat(50) @(posedge clk);

        $display("[场景 1] 发送完整帧: cmd=0x10 seq=1 arg=100 speed=50");
        send_frame(8'h10, 32'd1, 32'd100, 32'd50);
        repeat(200) @(posedge clk);
        check(valid && cmd == 8'h10 && seq == 1 && arg == 100 && speed == 50, "valid frame parsed");

        $display("[场景 2] 发送 boot 序列 88 FF FF FF");
        rx = 1'b1;
        repeat(1000) @(posedge clk);
        send_byte(8'h88);
        send_byte(8'hFF);
        send_byte(8'hFF);
        send_byte(8'hFF);
        repeat(50) @(posedge clk);
        check(boot, "boot sequence detected");

        $display("[场景 3] 非法帧头(55 非AA)");
        send_byte(8'h55);
        send_byte(8'hBB);
        send_byte(8'h20);
        send_byte(8'h10);
        send_byte(8'h0D);
        send_byte(8'h0A);
        repeat(200) @(posedge clk);
        check(!valid, "invalid frame ignored");

        if (errors == 0) $display("\nPASS: hmi_rx 全部通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #50000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule