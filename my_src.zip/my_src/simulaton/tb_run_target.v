`timescale 1ns/1ps
`include "control_config.vh"
// ============================================================================
// tb_run_target.v — run_target RUN 参考目标发生器仿真
// 验证速度分档、HMI 目标装载、hold、正负步进
// ============================================================================
module tb_run_target;
    reg clk = 1'b0;
    reg rst_n = 1'b0;
    reg clear = 1'b0;
    reg tick = 1'b0;
    reg run_mode = 1'b0;
    reg feedback_valid = 1'b0;
    reg angle_step = 1'b0;
    reg neg_step = 1'b0;
    reg speed_double = 1'b0;
    reg move = 1'b0;
    reg signed [31:0] alpha_meas = 32'd0;
    wire signed [31:0] goal_q16, reference_q16;
    wire moving;
    wire accepted, rejected;
    wire [1:0] speed_level;
    reg hmi_target_valid = 1'b0;
    reg signed [31:0] hmi_target_q16 = 32'd0;
    reg hmi_speed_valid = 1'b0;
    reg [6:0] hmi_speed_percent = 7'd50;
    reg hmi_hold_valid = 1'b0;
    reg amplitude_step = 1'b0;
    reg hmi_wave_start = 1'b0;
    reg [1:0] hmi_wave_kind = 2'd0;
    reg [31:0] hmi_wave_period_us = 32'd0;
    reg signed [31:0] hmi_wave_amp_q16 = 32'd0;
    reg hmi_wave_stop = 1'b0;
    reg hmi_track_mode = 1'b0;
    reg hmi_point_valid = 1'b0;
    reg signed [31:0] hmi_point_q16 = 32'd0;
    reg capture_hold = 1'b0;
    wire sine_sample_valid, sine_running, sine_ff_active;
    wire [31:0] sine_sample_phase, sine_sample_period;
    wire signed [31:0] sine_sample_amplitude;
    always #20 clk = ~clk;  // 25 MHz

    run_target #(.SINE_DEMO(0), .WAVE_EN(0), .CAPTURE_HOLD(1)) dut
        (.clk(clk), .rst_n(rst_n), .clear(clear), .tick(tick), .run_mode(run_mode),
         .feedback_valid(feedback_valid), .angle_step(angle_step), .neg_step(neg_step),
         .speed_double(speed_double), .move(move), .alpha_meas(alpha_meas),
         .goal_q16(goal_q16), .reference_q16(reference_q16), .moving(moving),
         .accepted(accepted), .rejected(rejected), .speed_level(speed_level),
         .hmi_target_valid(hmi_target_valid), .hmi_target_q16(hmi_target_q16),
         .hmi_speed_valid(hmi_speed_valid), .hmi_speed_percent(hmi_speed_percent),
         .hmi_hold_valid(hmi_hold_valid), .amplitude_step(amplitude_step),
         .hmi_wave_start(hmi_wave_start), .hmi_wave_kind(hmi_wave_kind),
         .hmi_wave_period_us(hmi_wave_period_us), .hmi_wave_amp_q16(hmi_wave_amp_q16),
         .hmi_wave_stop(hmi_wave_stop), .hmi_track_mode(hmi_track_mode),
         .hmi_point_valid(hmi_point_valid), .hmi_point_q16(hmi_point_q16),
         .capture_hold(capture_hold),
         .sine_sample_valid(sine_sample_valid), .sine_running(sine_running),
         .sine_ff_active(sine_ff_active),
         .sine_sample_phase(sine_sample_phase), .sine_sample_period(sine_sample_period),
         .sine_sample_amplitude(sine_sample_amplitude));

    integer errors = 0;
    integer i;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    initial begin
        repeat(20) @(negedge clk);
        rst_n = 1'b1;
        run_mode = 1'b1;
        feedback_valid = 1'b1;
        repeat(10) @(negedge clk);

        $display("[场景 1] 初始 goal=reference=0");
        check(goal_q16 == 0 && reference_q16 == 0, "initial zero");

        $display("[场景 2] HMI 目标装载");
        hmi_target_valid = 1'b1;
        hmi_target_q16 = 32'd30000;
        @(negedge clk); hmi_target_valid = 1'b0;
        repeat(5) @(negedge clk);
        check(accepted, "target accepted");

        $display("[场景 3] HMI hold");
        hmi_hold_valid = 1'b1;
        @(negedge clk); hmi_hold_valid = 1'b0;
        repeat(10) @(negedge clk);

        $display("[场景 4] tick 驱动 slew");
        for(i = 0; i < 20; i = i + 1) begin
            tick = 1; @(negedge clk); tick = 0;
            repeat(9) @(negedge clk);
        end
        check(reference_q16 != 0 || goal_q16 != 0, "reference advancing");

        if (errors == 0) $display("\nPASS: run_target 基本通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #10000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule