`timescale 1ns/1ps
`include "system_params.vh"
// ============================================================================
// tb_swingup_energy_controller.v — swingup_energy_controller 起摆能量控制器仿真
// 验证能量计算、方向切换、kick 助推、cos 查表
// ============================================================================
module tb_swingup_energy_controller;
    localparam CLK_HZ = `SYS_CLK_FREQ_HZ;
    localparam CLK_NS = 1000000000 / CLK_HZ;

    reg clk = 1'b0;
    reg rst_n = 1'b0;
    reg tick = 1'b0;
    reg enable = 1'b0;
    reg [11:0] theta_abs_counts = 12'd1024;
    reg signed [15:0] theta_dot = 16'd0;
    reg [15:0] kick_frames = 16'd0;
    wire [1:0] motor_dir;
    wire [7:0] duty;
    wire kick_done;
    wire signed [15:0] energy_error_mon;
    always #(CLK_NS/2) clk = ~clk;

    swingup_energy_controller dut(.clk(clk), .rst_n(rst_n), .tick(tick),
        .enable(enable), .theta_abs_counts(theta_abs_counts),
        .theta_dot(theta_dot), .kick_frames(kick_frames),
        .motor_dir(motor_dir), .duty(duty), .kick_done(kick_done),
        .energy_error_mon(energy_error_mon));

    integer errors = 0;
    integer i;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    initial begin
        repeat(20) @(negedge clk);
        rst_n = 1'b1;
        enable = 1'b1;
        repeat(10) @(negedge clk);

        $display("[场景 1] 禁止时归零");
        enable = 1'b0;
        tick = 1; @(negedge clk); tick = 0;
        repeat(30) @(negedge clk);
        check(motor_dir == 0 && duty == 0, "disabled: zero duty");

        $display("[场景 2] 下垂点 theta=1024 (pi/2)");
        enable = 1'b1;
        for(i = 0; i < 50; i = i + 1) begin
            tick = 1; @(negedge clk); tick = 0;
            repeat(29) @(negedge clk);
        end
        check(duty > 0, "swingup drives motor");

        $display("[场景 3] 接近直立点 theta=0");
        theta_abs_counts = 12'd0;
        theta_dot = 16'd0;
        for(i = 0; i < 20; i = i + 1) begin
            tick = 1; @(negedge clk); tick = 0;
            repeat(29) @(negedge clk);
        end

        if (errors == 0) $display("\nPASS: swingup_energy_controller 基本通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #10000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule