`timescale 1ns/1ps
// ============================================================================
// tb_hmi_scale.v — hmi_scale 定点缩放器仿真
// 验证 32-cycle 位串乘法、触发模式
// ============================================================================
module tb_hmi_scale;
    reg clk = 1'b0;
    reg rst_n = 1'b0;
    reg trigger = 1'b0;
    reg signed [31:0] value = 32'd0;
    wire signed [31:0] result;
    always #10 clk = ~clk;

    // FACTOR=366693, SHIFT=22: degrees100 conversion (radians Q16 -> centidegrees)
    hmi_scale #(.FACTOR(366693), .SHIFT(22), .TRIGGERED(0)) dut
        (.clk(clk), .rst_n(rst_n), .trigger(trigger), .value(value), .result(result));

    integer errors = 0;
    integer i;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    initial begin
        repeat(20) @(negedge clk);
        rst_n = 1'b1;
        repeat(10) @(negedge clk);

        $display("[场景 1] value=0 输出 0");
        value = 32'd0;
        repeat(60) @(negedge clk);
        check(result == 0, "0 scaled = 0");

        $display("[场景 2] value=65536 (1.0 Q16)");
        value = 32'd65536;
        repeat(60) @(negedge clk);
        // expected: 65536 * 366693 >> 22 = 5730 centidegrees ≈ 57.3°
        check(result > 5700 && result < 5760, "1 rad ~ 57.3 decdeg");

        $display("[场景 3] π/2 radians Q16 = 102944");
        value = 32'd102944;
        repeat(60) @(negedge clk);
        check(result > 8950 && result < 9050, "pi/2 rad ~ 90 decdeg");

        $display("[场景 4] 负数");
        value = -32'sd65536;
        repeat(60) @(negedge clk);
        check(result < 0, "negative value negative result");

        $display("[场景 5] 持续自动转换");
        for(i = 0; i < 5; i = i + 1) begin
            value = $signed(i * 10000);
            repeat(50) @(negedge clk);
            check(result == ($signed(i * 10000) * 64'sd366693) >>> 22, "continuous conversion correct");
        end

        if (errors == 0) $display("\nPASS: hmi_scale 全部通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #10000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule