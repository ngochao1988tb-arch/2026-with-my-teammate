`timescale 1ns/1ps
`include "system_params.vh"
// ============================================================================
// tb_uart_telemetry.v — uart_telemetry 遥测模块仿真
// 验证 Legacy/Debug 模式帧打包、checksum、串口发送
// ============================================================================
module tb_uart_telemetry;
    localparam CLK_HZ = `SYS_CLK_FREQ_HZ;
    localparam CLK_NS = 1000000000 / CLK_HZ;

    reg clk_50m = 1'b0;
    reg rst_n = 1'b0;
    reg tick_3ms = 1'b0;
    reg manual_trig = 1'b0;
    reg [15:0] theta_raw_in = 16'd2048;
    reg [15:0] enc1_pos_in = 16'd1000;
    reg signed [15:0] theta_err_in = 16'd10;
    reg signed [15:0] pwm_duty_signed_in = 16'd50;
    reg [7:0] status_byte_in = 8'd3;
    reg [31:0] frame_number_in = 32'd0;
    reg signed [15:0] theta_dot_in = 16'd100;
    reg signed [15:0] alpha_err_in = 16'd20;
    reg signed [19:0] alpha_dot_q4_in = 20'd500;
    reg signed [15:0] u_unclamped_in = 16'd200;
    reg signed [15:0] requested_pwm_in = 16'd180;
    reg [2:0] fault_cause_in = 3'd0;
    reg [15:0] illegal_count_in = 16'd0;
    wire uart_tx;
    reg uart_rx = 1'b1;
    always #(CLK_NS/2) clk_50m = ~clk_50m;

    uart_telemetry #(.DEBUG_MODE(0)) dut
        (.clk_50m(clk_50m), .rst_n(rst_n), .tick_3ms(tick_3ms), .manual_trig(manual_trig),
         .theta_raw_in(theta_raw_in), .enc1_pos_in(enc1_pos_in),
         .theta_err_in(theta_err_in), .pwm_duty_signed_in(pwm_duty_signed_in),
         .status_byte_in(status_byte_in), .frame_number_in(frame_number_in),
         .theta_dot_in(theta_dot_in), .alpha_err_in(alpha_err_in),
         .alpha_dot_q4_in(alpha_dot_q4_in), .u_unclamped_in(u_unclamped_in),
         .requested_pwm_in(requested_pwm_in),
         .fault_cause_in(fault_cause_in), .illegal_count_in(illegal_count_in),
         .uart_tx(uart_tx), .uart_rx(uart_rx));

    integer errors = 0;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    initial begin
        repeat(50) @(posedge clk_50m);
        rst_n = 1'b1;
        repeat(50) @(posedge clk_50m);

        $display("[场景 1] 空闲 TX=1");
        check(uart_tx === 1'b1, "idle high");

        $display("[场景 2] tick_3ms 触发 legacy 帧发送");
        tick_3ms = 1; @(negedge clk_50m); tick_3ms = 0;
        repeat(50000) @(posedge clk_50m);

        $display("[场景 3] manual_trig 强制发送");
        manual_trig = 1; @(negedge clk_50m); manual_trig = 0;
        repeat(50000) @(posedge clk_50m);

        if (errors == 0) $display("\nPASS: uart_telemetry 基本通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #50000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule