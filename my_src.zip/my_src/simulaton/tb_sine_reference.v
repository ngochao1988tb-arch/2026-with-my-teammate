`timescale 1ns/1ps
`include "control_config.vh"
// ============================================================================
// tb_sine_reference.v — sine_reference 正弦参考振荡器仿真
// 验证正弦输出、周期/幅值参数变更、手写轨迹跟随
// ============================================================================
module tb_sine_reference;
    reg clk = 1'b0;
    reg rst_n = 1'b0;
    reg clear = 1'b0;
    reg tick = 1'b0;
    reg enable = 1'b0;
    reg start = 1'b0;
    reg period_step = 1'b0;
    reg amplitude_step = 1'b0;
    reg signed [31:0] current_reference = 32'd0;
    wire active, valid, accepted, rejected;
    wire signed [31:0] reference_q16;
    wire [31:0] period_us;
    wire signed [31:0] amplitude_q16;
    wire [31:0] sample_phase, sample_period;
    wire signed [31:0] sample_amplitude;
    wire ff_ok;
    reg [1:0] kind = 2'd0;
    reg set_valid = 1'b0;
    reg [31:0] set_period_us = `CFG_SINE_PERIOD_US;
    reg signed [31:0] set_amp_q16 = 32'd50000;
    reg osc_stop = 1'b0;
    reg track_mode = 1'b0;
    reg point_valid = 1'b0;
    reg signed [31:0] point_q16 = 32'd0;
    wire [1:0] kind_active;
    always #20 clk = ~clk;

    sine_reference dut
        (.clk(clk), .rst_n(rst_n), .clear(clear), .tick(tick), .enable(enable),
         .start(start), .period_step(period_step), .amplitude_step(amplitude_step),
         .current_reference(current_reference),
         .active(active), .valid(valid), .accepted(accepted), .rejected(rejected),
         .reference_q16(reference_q16), .period_us(period_us), .amplitude_q16(amplitude_q16),
         .sample_phase(sample_phase), .sample_period(sample_period), .sample_amplitude(sample_amplitude),
         .ff_ok(ff_ok),
         .kind(kind), .set_valid(set_valid), .set_period_us(set_period_us),
         .set_amp_q16(set_amp_q16), .osc_stop(osc_stop),
         .track_mode(track_mode), .point_valid(point_valid), .point_q16(point_q16),
         .kind_active(kind_active));

    integer errors = 0;
    integer i;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    initial begin
        repeat(20) @(negedge clk);
        rst_n = 1'b1;
        enable = 1'b1;
        start = 1'b1;
        @(negedge clk); start = 1'b0;
        repeat(10) @(negedge clk);

        $display("[场景 1] 启动后 active=1, valid 产生");
        for(i = 0; i < 200; i = i + 1) begin
            tick = 1; @(negedge clk); tick = 0;
            repeat(3) @(negedge clk);
        end
        check(active, "oscillator active");
        check(valid, "valid output generated");
        check(kind_active == 2'd0, "sine kind active");

        $display("[场景 2] 输出在封套内");
        check(reference_q16 < 32'h01000000 && reference_q16 > -32'sh01000000, "reference within envelope");

        if (errors == 0) $display("\nPASS: sine_reference 基本通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #10000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule