`timescale 1ns/1ps
`include "control_config.vh"
// ============================================================================
// tb_sine_feedforward.v — sine_feedforward 正弦前馈仿真
// 验证 sin/cos 查表、系数选择、使能/禁止
// ============================================================================
module tb_sine_feedforward;
    reg clk = 1'b0;
    reg rst_n = 1'b0;
    reg clear = 1'b0;
    reg tick = 1'b0;
    reg enable = 1'b0;
    reg active = 1'b0;
    reg sample_valid = 1'b0;
    reg [31:0] sample_phase = 32'd0;
    reg [31:0] sample_period = `CFG_SINE_PERIOD_US;
    reg signed [31:0] sample_amplitude = 32'd1000;
    wire signed [31:0] correction_q16;
    always #20 clk = ~clk;

    sine_feedforward #(.ENABLED(1)) dut
        (.clk(clk), .rst_n(rst_n), .clear(clear), .tick(tick), .enable(enable),
         .active(active), .sample_valid(sample_valid),
         .sample_phase(sample_phase), .sample_period(sample_period),
         .sample_amplitude(sample_amplitude),
         .correction_q16(correction_q16));

    integer errors = 0;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    initial begin
        repeat(20) @(negedge clk);
        rst_n = 1'b1;
        enable = 1'b1;
        active = 1'b1;
        repeat(10) @(negedge clk);

        $display("[场景 1] 启动时 correction 为 0");
        check(correction_q16 == 0, "initial correction zero");

        $display("[场景 2] tick 后开始计算");
        sample_phase = 32'd0;
        sample_amplitude = 32'd65536;  // 1.0 Q16
        sample_period = `CFG_SINE_PERIOD_US;
        repeat(5) begin
            tick = 1; sample_valid = 1; @(negedge clk); tick = 0; sample_valid = 0;
            repeat(50) @(negedge clk);
        end

        $display("[场景 3] enable=0 清零");
        enable = 1'b0;
        clear = 1'b1;
        @(negedge clk); clear = 1'b0;
        repeat(30) @(negedge clk);
        check(correction_q16 == 0, "clear zeros correction");

        if (errors == 0) $display("\nPASS: sine_feedforward 基本通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #10000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule