`timescale 1ns/1ps
`include "system_params.vh"
// ============================================================================
// tb_j280_lqr_top.v — j280_lqr_top 从板顶层集成仿真
// 精简连接测试：时钟、复位、ADC、编码器、电机输出
// ============================================================================
module tb_j280_lqr_top;
    localparam CLK_HZ = `SYS_CLK_FREQ_HZ;
    localparam CLK_NS = 1000000000 / CLK_HZ;

    reg clk_50m = 1'b0;
    reg rst_n = 1'b0;
    reg [3:0] key_sw = 4'hF;
    reg uart_rx = 1'b1;
    wire uart_tx;
    wire adc_clk, adc_oe_n, adc_stby_n;
    reg [9:0] adc_data_in = 10'd512;
    wire PWMA, AN1, AN2, PWMB, BN1, BN2;
    reg enc1_a = 1'b0;
    reg enc1_b = 1'b0;
    reg remote_uart_rx = 1'b1;
    wire remote_uart_tx;
    always #(CLK_NS/2) clk_50m = ~clk_50m;

    j280_lqr_top dut(.clk_50m(clk_50m), .rst_n(rst_n), .key_sw(key_sw),
        .uart_tx(uart_tx), .uart_rx(uart_rx),
        .adc_clk(adc_clk), .adc_oe_n(adc_oe_n), .adc_stby_n(adc_stby_n),
        .adc_data_in(adc_data_in),
        .PWMA(PWMA), .AN1(AN1), .AN2(AN2),
        .PWMB(PWMB), .BN1(BN1), .BN2(BN2),
        .enc1_a(enc1_a), .enc1_b(enc1_b),
        .remote_uart_rx(remote_uart_rx), .remote_uart_tx(remote_uart_tx));

    integer errors = 0;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    initial begin
        repeat(50) @(posedge clk_50m);
        rst_n = 1'b1;
        repeat(100) @(posedge clk_50m);

        $display("[场景 1] 复位后 ADC 时钟产生");
        check(adc_clk !== 1'bz, "adc_clk driven");
        check(adc_oe_n === 1'b0, "adc_oe_n active");

        $display("[场景 2] 所有电机输出已驱动");
        check(PWMA !== 1'bz && AN1 !== 1'bz && AN2 !== 1'bz, "motor A outputs driven");
        check(PWMB !== 1'bz && BN1 !== 1'bz && BN2 !== 1'bz, "motor B outputs driven");

        $display("[场景 3] UART TX 已驱动");
        check(uart_tx !== 1'bz, "uart tx driven");
        check(remote_uart_tx !== 1'bz, "remote uart tx driven");

        $display("[场景 4] 运行时无 X 态");
        repeat(5000) @(posedge clk_50m);

        if (errors == 0) $display("\nPASS: j280_lqr_top 基本通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #500000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule