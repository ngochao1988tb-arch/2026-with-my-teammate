`timescale 1ns/1ps
`include "control_config.vh"
// ============================================================================
// tb_capture_command_guard.v — capture_command_guard 捕获命令预检查仿真
// 验证位串乘法、K*x 预览、command 兼容性判定
// ============================================================================
module tb_capture_command_guard;
    reg clk = 1'b0;
    reg rst_n = 1'b0;
    reg tick = 1'b0;
    reg enable = 1'b0;
    reg signed [31:0] alpha = 32'd0;
    reg signed [31:0] theta = 32'd0;
    reg signed [31:0] alpha_dot = 32'd0;
    reg signed [31:0] theta_dot = 32'd0;
    reg signed [31:0] alpha_c = 32'd0;
    reg signed [31:0] swing_u = 32'd0;
    wire compatible;
    wire signed [31:0] candidate_u;
    wire candidate_valid;
    reg signed [31:0] arm_reference_q16 = 32'd0;
    always #10 clk = ~clk;

    capture_command_guard dut
        (.clk(clk), .rst_n(rst_n), .tick(tick), .enable(enable),
         .alpha(alpha), .theta(theta), .alpha_dot(alpha_dot), .theta_dot(theta_dot),
         .alpha_c(alpha_c), .swing_u(swing_u),
         .compatible(compatible), .candidate_u(candidate_u), .candidate_valid(candidate_valid),
         .arm_reference_q16(arm_reference_q16));

    integer errors = 0;
    integer cycles = 0;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    initial begin
        repeat(20) @(negedge clk);
        rst_n = 1'b1;
        enable = 1'b1;
        repeat(10) @(negedge clk);

        $display("[场景 1] 零状态: 所有角度=0, 应是兼容的");
        tick = 1; @(negedge clk); tick = 0;
        cycles = 0;
        while(!candidate_valid && cycles < 300) begin @(negedge clk); cycles = cycles + 1; end
        check(candidate_valid, "computation completed");
        check(compatible, "zero state compatible");

        $display("[场景 2] enable=0 复位");
        enable = 1'b0;
        repeat(10) @(negedge clk);
        check(!candidate_valid && !compatible, "disabled clears");

        if (errors == 0) $display("\nPASS: capture_command_guard 基本通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #10000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule