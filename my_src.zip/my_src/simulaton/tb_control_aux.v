`timescale 1ns/1ps
`include "control_config.vh"
// ============================================================================
// tb_control_aux.v — control_aux 静默闸门/死区桥接仿真
// 验证 run_adc_quiet_gate 冻结条件、deadzone_bridge 外推
// ============================================================================
module tb_control_aux;
    reg clk = 1'b0;
    reg rst_n = 1'b0;
    reg tick = 1'b0;
    reg hold_mode = 1'b0;
    reg [12:0] ad_value = `CFG_ADC_FIXED_ZERO;
    reg signed [31:0] theta = 32'd0;
    reg signed [31:0] theta_dot = 32'd0;
    reg signed [31:0] arm = 32'd0;
    reg signed [31:0] arm_dot = 32'd0;
    reg signed [31:0] motor_frequency_q8 = 32'd0;
    wire pause;
    always #10 clk = ~clk;

    run_adc_quiet_gate gate(.clk(clk), .rst_n(rst_n), .tick(tick), .hold_mode(hold_mode),
        .ad_value(ad_value), .theta(theta), .theta_dot(theta_dot),
        .arm(arm), .arm_dot(arm_dot), .motor_frequency_q8(motor_frequency_q8),
        .pause(pause));

    integer errors = 0;
    integer i;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    initial begin
        repeat(20) @(negedge clk);
        rst_n = 1'b1;
        hold_mode = 1'b1;
        repeat(10) @(negedge clk);

        $display("[场景 1] 初始不冻结");
        check(!pause, "initial: not paused");

        $display("[场景 2] 静默条件满足后暂停");
        for(i = 0; i < 1000; i = i + 1) begin
            tick = 1; @(negedge clk); tick = 0;
            repeat(9) @(negedge clk);
        end
        // 如果 STALL_ENABLED=1 且 hold_mode=1，长时间恒定后应暂停
        check(`CFG_STALL_ENABLED == 0 || pause != 1'bz, "quiet gate functional");

        $display("[场景 3] 扰动立即恢复");
        arm_dot = 32'd100000;
        tick = 1; @(negedge clk); tick = 0;
        repeat(10) @(negedge clk);

        if (errors == 0) $display("\nPASS: control_aux 基本通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #10000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule