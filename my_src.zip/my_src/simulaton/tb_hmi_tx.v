`timescale 1ns/1ps
`include "control_config.vh"
// ============================================================================
// tb_hmi_tx.v — hmi_tx ASCII 快照上行仿真
// 验证字段输出、十进制转换、串口发送握手
// ============================================================================
module tb_hmi_tx;
    localparam CLK_HZ = 25000000;
    localparam CLK_NS = 40;
    localparam BAUD = 115200;

    reg clk = 1'b0;
    reg rst_n = 1'b0;
    reg [1055:0] values = 0;
    reg ack_valid = 1'b0;
    reg signed [31:0] ack_seq = 32'd0;
    reg signed [31:0] ack_result = 32'd0;
    wire ack_ready;
    wire tx;
    wire snapshot_sent;
    always #(CLK_NS/2) clk = ~clk;

    hmi_tx #(.CLK_HZ(CLK_HZ), .BAUD(BAUD)) dut
        (.clk(clk), .rst_n(rst_n), .values(values),
         .ack_valid(ack_valid), .ack_seq(ack_seq), .ack_result(ack_result),
         .ack_ready(ack_ready), .tx(tx), .snapshot_sent(snapshot_sent));

    integer errors = 0;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    initial begin
        repeat(20) @(posedge clk);
        rst_n = 1'b1;
        repeat(20) @(posedge clk);

        $display("[场景 1] 初始空闲 TX=1, ack_ready=1");
        check(tx === 1'b1 && ack_ready, "idle state");

        $display("[场景 2] 设置 values 字段，等待 100ms 快照周期");
        values[1055:1024] = 32'd1234;  // ghb field
        repeat(CLK_HZ / 10 + 500) @(posedge clk);
        check(snapshot_sent, "snapshot sent after 100ms");

        $display("[场景 3] ack 回复优先级高于周期快照");
        ack_valid = 1'b1;
        ack_seq = 32'd5;
        ack_result = -32'sd100;
        @(negedge clk);
        ack_valid = 1'b0;
        // 等待 ack 帧发出
        repeat(500000) @(posedge clk);

        if (errors == 0) $display("\nPASS: hmi_tx 基本通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #50000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule