`timescale 1ns/1ps
`include "system_params.vh"
// ============================================================================
// tb_arm_reference_pid.v — arm_reference_pid 横臂位置 PID 仿真
// 验证比例/微分项、积分限幅、handoff 斜坡、输出限幅
// ============================================================================
module tb_arm_reference_pid;
    localparam CLK_HZ = `SYS_CLK_FREQ_HZ;
    localparam CLK_NS = 1000000000 / CLK_HZ;

    reg clk_50m = 1'b0;
    reg rst_n = 1'b0;
    reg tick_3ms = 1'b0;
    reg ctrl_enable = 1'b0;
    reg handoff = 1'b0;
    reg [15:0] alpha_target_pos = 16'd10000;
    reg [15:0] alpha_pos = 16'd10000;
    reg signed [19:0] alpha_dot = 20'd0;
    wire signed [15:0] arm_pid_output;
    wire handoff_active;
    always #(CLK_NS/2) clk_50m = ~clk_50m;

    arm_reference_pid dut(.clk_50m(clk_50m), .rst_n(rst_n),
        .tick_3ms(tick_3ms), .ctrl_enable(ctrl_enable), .handoff(handoff),
        .alpha_target_pos(alpha_target_pos), .alpha_pos(alpha_pos),
        .alpha_dot(alpha_dot),
        .arm_pid_output(arm_pid_output), .handoff_active(handoff_active));

    integer errors = 0;
    integer i;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    initial begin
        repeat(20) @(negedge clk_50m);
        rst_n = 1'b1;
        ctrl_enable = 1'b1;
        repeat(10) @(negedge clk_50m);

        $display("[场景 1] 平衡点误差为零: output=0");
        tick_3ms = 1; @(negedge clk_50m); tick_3ms = 0;
        repeat(20) @(negedge clk_50m);
        check(arm_pid_output == 0, "zero at equilibrium");

        $display("[场景 2] 正偏差产生正输出");
        alpha_pos = 16'd10100;  // 100 counts forward
        for(i = 0; i < 10; i = i + 1) begin
            tick_3ms = 1; @(negedge clk_50m); tick_3ms = 0;
            repeat(9) @(negedge clk_50m);
        end
        // P=220, 100 counts error * 220/256 = ~86
        check(arm_pid_output < 0, "negative output for positive error (reverse convention)");

        $display("[场景 3] handoff 斜坡");
        handoff = 1'b1;
        for(i = 0; i < 10; i = i + 1) begin
            tick_3ms = 1; @(negedge clk_50m); tick_3ms = 0;
            repeat(9) @(negedge clk_50m);
        end
        check(handoff_active, "handoff active");

        if (errors == 0) $display("\nPASS: arm_reference_pid 基本通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #10000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule