`timescale 1ns/1ps
// ============================================================================
// tb_uart_rx.v — uart_rx 通用串口接收模块仿真
// 验证标准 8N1 帧接收、过量采样、起始位确认、停止位检测
// ============================================================================
module tb_uart_rx;
    localparam CLK_HZ = 50000000;
    localparam BAUD = 115200;
    localparam CLK_NS = 20;
    localparam BIT_NS = 1000000000 / BAUD;

    reg clk = 1'b0;
    reg rst_n = 1'b0;
    reg rx = 1'b1;
    wire rx_valid;
    wire [7:0] rx_data;
    always #(CLK_NS/2) clk = ~clk;

    uart_rx #(.CLK_HZ(CLK_HZ), .BAUD(BAUD)) dut
        (.clk(clk), .rst_n(rst_n), .rx(rx), .rx_valid(rx_valid), .rx_data(rx_data));

    integer errors = 0;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    task send_byte(input [7:0] byte);
        integer i;
        begin
            rx = 1'b0;  // start
            #(BIT_NS);
            for(i=0;i<8;i=i+1) begin
                rx = byte[i];
                #(BIT_NS);
            end
            rx = 1'b1;  // stop
            #(BIT_NS);
        end
    endtask

    initial begin
        repeat(20) @(posedge clk);
        rst_n = 1'b1;
        repeat(20) @(posedge clk);

        $display("[场景 1] 发送 0xA5，验证接收");
        send_byte(8'hA5);
        repeat(50) @(posedge clk);
        check(rx_valid && rx_data == 8'hA5, "receive 0xA5");

        $display("[场景 2] 发送 0x00");
        send_byte(8'h00);
        repeat(50) @(posedge clk);
        check(rx_valid && rx_data == 8'h00, "receive 0x00");

        $display("[场景 3] 发送 0xFF");
        send_byte(8'hFF);
        repeat(50) @(posedge clk);
        check(rx_valid && rx_data == 8'hFF, "receive 0xFF");

        $display("[场景 4] 发送 0x5A");
        send_byte(8'h5A);
        repeat(50) @(posedge clk);
        check(rx_valid && rx_data == 8'h5A, "receive 0x5A");

        $display("[场景 5] rx_valid 单周期特性");
        send_byte(8'h42);
        repeat(20) @(posedge clk);
        wait(rx_valid);
        @(posedge clk);
        check(!rx_valid, "rx_valid single-cycle");

        if (errors == 0) $display("\nPASS: uart_rx 全部通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #100000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule