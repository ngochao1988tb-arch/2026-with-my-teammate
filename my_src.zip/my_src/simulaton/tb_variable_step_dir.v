`timescale 1ns/1ps
`include "control_config.vh"
// ============================================================================
// tb_variable_step_dir.v — variable_step_dir 变频率脉冲发生器仿真
// 验证正反向脉冲、DIR 建立时间、脉冲宽度、signed_pulses 累加
// ============================================================================
module tb_variable_step_dir;
    localparam CLK_HZ = 25000000;
    reg clk = 1'b0;
    reg rst_n = 1'b0;
    reg run = 1'b0;
    reg signed [31:0] frequency_q8 = 32'd0;
    wire pul;
    wire dir;
    wire ena;
    wire signed [31:0] signed_pulses;
    wire pulse_event;
    always #20 clk = ~clk;  // 25 MHz

    variable_step_dir #(.CLK_HZ(CLK_HZ)) dut
        (.clk(clk), .rst_n(rst_n), .run(run), .frequency_q8(frequency_q8),
         .pul(pul), .dir(dir), .ena(ena), .signed_pulses(signed_pulses), .pulse_event(pulse_event));

    integer errors = 0;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    initial begin
        repeat(20) @(posedge clk);
        rst_n = 1'b1;
        repeat(20) @(posedge clk);

        $display("[场景 1] 停止状态下不输出脉冲");
        run = 1'b0;
        frequency_q8 = 32'd25600;  // 100 Hz
        repeat(10000) @(posedge clk);
        check(!pul && !pulse_event && signed_pulses == 0, "stop: no pulses");

        $display("[场景 2] 正频率产生正向脉冲");
        run = 1'b1;
        frequency_q8 = 32'd256;  // 1 Hz
        repeat(CLK_HZ * 2) @(posedge clk);  // 2 seconds
        check(signed_pulses > 0, "positive step accumulation");
        check(dir === 1'b0, "positive dir = 0");
        check(signed_pulses <= 3, "roughly 1 Hz");

        $display("[场景 3] 零频率=hold, signed_pulses 不变");
        frequency_q8 = 32'd0;
        repeat(500000) @(posedge clk);
        check(!pul && signed_pulses >= 1, "zero frequency: no new pulses, counter held");

        $display("[场景 4] 负频率产生反向脉冲");
        frequency_q8 = -32'sd256;
        repeat(CLK_HZ * 2) @(posedge clk);
        check(dir === 1'b1, "negative dir = 1");
        check(signed_pulses < $signed(1), "reverse clears positive count");

        $display("[场景 5] 停止后复位");
        run = 1'b0;
        repeat(10000) @(posedge clk);
        check(!pul && signed_pulses != 0, "stop preserves counter");

        if (errors == 0) $display("\nPASS: variable_step_dir 全部通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #100000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule