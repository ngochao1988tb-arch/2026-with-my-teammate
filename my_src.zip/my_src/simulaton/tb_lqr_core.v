`timescale 1ns/1ps
`include "control_config.vh"
// ============================================================================
// tb_lqr_core.v — lqr_core LQR 多速率观测器与控制律仿真
// 验证状态预测、Kalman-like 修正、控制量饱和、trim 偏置
// ============================================================================
module tb_lqr_core;
    reg clk = 1'b0;
    reg rst_n = 1'b0;
    reg tick = 1'b0;
    reg clear = 1'b0;
    reg enable = 1'b0;
    reg signed [31:0] alpha_meas = 32'd0;
    reg alpha_update = 1'b0;
    reg signed [31:0] theta_meas = 32'd0;
    reg signed [31:0] alpha_c = 32'd0;
    wire signed [31:0] alpha_hat, theta_hat, alpha_dot_hat, theta_dot_hat;
    wire signed [31:0] u_q16;
    wire saturated, done, numeric_fault;
    reg seed = 1'b0;
    reg signed [31:0] seed_alpha_dot = 32'd0, seed_theta_dot = 32'd0, seed_u = 32'd0;
    wire signed [31:0] trim_u_q16;
    wire [7:0] trim_status;
    reg signed [31:0] arm_reference_q16 = 32'd0;
    reg reference_changing = 1'b0;
    reg signed [31:0] feedforward_q16 = 32'd0;
    reg trim_pause = 1'b0;
    always #10 clk = ~clk;

    lqr_core #(.FEEDFORWARD_EN(0), .PAUSE_TRIM_EN(0)) dut
        (.clk(clk), .rst_n(rst_n), .tick(tick), .clear(clear), .enable(enable),
         .alpha_meas(alpha_meas), .alpha_update(alpha_update), .theta_meas(theta_meas), .alpha_c(alpha_c),
         .alpha_hat(alpha_hat), .theta_hat(theta_hat), .alpha_dot_hat(alpha_dot_hat), .theta_dot_hat(theta_dot_hat),
         .u_q16(u_q16), .saturated(saturated), .done(done), .numeric_fault(numeric_fault),
         .seed(seed), .seed_alpha_dot(seed_alpha_dot), .seed_theta_dot(seed_theta_dot), .seed_u(seed_u),
         .trim_u_q16(trim_u_q16), .trim_status(trim_status),
         .arm_reference_q16(arm_reference_q16), .reference_changing(reference_changing),
         .feedforward_q16(feedforward_q16), .trim_pause(trim_pause));

    integer errors = 0;
    integer cycles = 0;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    task do_frame;
        begin
            tick = 1; @(negedge clk); tick = 0;
            cycles = 0;
            while(!done && cycles < 200) begin @(negedge clk); cycles = cycles + 1; end
            if(!done) $fatal(1, "LQR frame timeout");
            @(negedge clk);
        end
    endtask

    initial begin
        repeat(20) @(negedge clk);
        rst_n = 1'b1;
        enable = 1'b1;
        alpha_update = 1'b1;
        repeat(10) @(negedge clk);

        $display("[场景 1] 直立平衡点：所有状态=0，应输出 0");
        alpha_meas = 32'd0;
        theta_meas = 32'd0;
        alpha_c = 32'd0;
        do_frame;
        check(!numeric_fault && !saturated, "upright equilibrium no fault");
        check(u_q16 == 0 || u_q16 < 1000, "near-zero control at equilibrium");

        $display("[场景 2] 摆杆倾斜(theta_meas=+1000) 应先推后回（非最小相位）");
        theta_meas = 32'd1000;
        do_frame;
        check(!numeric_fault, "tilted no fault");

        $display("[场景 3] 横臂有偏差，trim 应累积偏置");
        alpha_meas = 32'd10000;
        arm_reference_q16 = 32'd5000;
        theta_meas = 32'd0;
        repeat(20) do_frame;
        check(!numeric_fault, "steady state stable");

        $display("[场景 4] disable 后 trim 清零");
        enable = 1'b0;
        repeat(5) @(negedge clk);
        check(trim_u_q16 == 0, "trim zero when disabled");

        if (errors == 0) $display("\nPASS: lqr_core 全部通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #10000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule