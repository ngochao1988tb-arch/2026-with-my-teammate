`timescale 1ns/1ps
`include "system_params.vh"
// ============================================================================
// tb_slave_hmi_adapter.v — slave_hmi_adapter 从板 HMI 协议适配仿真
// 验证除法器、移动目标换算、结果编码
// ============================================================================
module tb_slave_hmi_adapter;
    localparam CLK_HZ = `SYS_CLK_FREQ_HZ;
    localparam CLK_NS = 1000000000 / CLK_HZ;

    reg clk = 1'b0;
    reg rst_n = 1'b0;
    reg control_tick = 1'b0;
    reg command_write = 1'b0;
    reg command_usb = 1'b0;
    reg [7:0] command_op = 8'd0;
    reg [15:0] command_arg = 16'd0;
    reg manual_allowed = 1'b1;
    reg data_valid = 1'b1;
    reg remote_estop = 1'b0;
    reg local_estop = 1'b0;
    reg stopped = 1'b0;
    reg [2:0] state = 3'd2;
    reg restart_pending = 1'b0;
    reg signed [15:0] theta_counts = 16'd0;
    reg signed [15:0] theta_velocity = 16'd0;
    reg signed [15:0] arm_error_counts = 16'd0;
    reg [15:0] arm_position = 16'd10000;
    reg [15:0] arm_center = 16'd10000;
    reg [15:0] final_target = 16'd10000;
    reg [15:0] active_target = 16'd10000;
    wire move_pulse;
    wire [15:0] move_target;
    wire result_pulse, result_usb;
    wire [7:0] command_result;
    wire signed [15:0] theta_reference_counts, theta_reference_cd;
    wire [7:0] speed_percent;
    wire sync_enabled;
    wire [255:0] telemetry_bank;
    always #(CLK_NS/2) clk = ~clk;

    slave_hmi_adapter dut(.clk(clk), .rst_n(rst_n), .control_tick(control_tick),
        .command_write(command_write), .command_usb(command_usb),
        .command_op(command_op), .command_arg(command_arg),
        .manual_allowed(manual_allowed), .data_valid(data_valid),
        .remote_estop(remote_estop), .local_estop(local_estop), .stopped(stopped),
        .state(state), .restart_pending(restart_pending),
        .theta_counts(theta_counts), .theta_velocity(theta_velocity),
        .arm_error_counts(arm_error_counts),
        .arm_position(arm_position), .arm_center(arm_center),
        .final_target(final_target), .active_target(active_target),
        .move_pulse(move_pulse), .move_target(move_target),
        .result_pulse(result_pulse), .result_usb(result_usb),
        .command_result(command_result),
        .theta_reference_counts(theta_reference_counts),
        .theta_reference_cd(theta_reference_cd),
        .speed_percent(speed_percent), .sync_enabled(sync_enabled),
        .telemetry_bank(telemetry_bank));

    integer errors = 0;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    initial begin
        repeat(20) @(negedge clk);
        rst_n = 1'b1;
        repeat(10) @(negedge clk);

        $display("[场景 1] 初始 telemetry_bank 已填充");
        repeat(5) @(negedge clk);

        $display("[场景 2] OP32 相对移动 +300 count");
        command_write = 1'b1;
        command_op = 8'h32;
        command_arg = 16'd300;
        @(negedge clk); command_write = 1'b0;
        repeat(200) @(negedge clk);

        $display("[场景 3] OP34 速度设置 speed=50");
        command_write = 1'b1;
        command_op = 8'h34;
        command_arg = 16'd50;
        @(negedge clk); command_write = 1'b0;
        repeat(200) @(negedge clk);
        check(speed_percent == 50, "speed set to 50");

        if (errors == 0) $display("\nPASS: slave_hmi_adapter 基本通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #50000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule