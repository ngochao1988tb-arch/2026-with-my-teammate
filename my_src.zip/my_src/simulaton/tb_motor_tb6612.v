`timescale 1ns/1ps
`include "system_params.vh"
// ============================================================================
// tb_motor_tb6612.v — motor_tb6612 TB6612 驱动模块仿真
// 验证 10kHz PWM、死区补偿、safe_enable 切断、正反向
// ============================================================================
module tb_motor_tb6612;
    localparam CLK_HZ = `SYS_CLK_FREQ_HZ;
    localparam CLK_NS = 1000000000 / CLK_HZ;

    reg clk_50m = 1'b0;
    reg rst_n = 1'b0;
    reg safe_enable = 1'b0;
    reg [1:0] motor_dir = 2'b00;
    reg [7:0] duty_in = 8'd0;
    reg signed [8:0] deadband_pos = 9'd0;
    reg signed [8:0] deadband_neg = 9'd0;
    reg [7:0] deadzone_thresh = 8'd2;
    reg swingup_mode = 1'b0;
    wire in1, in2, pwm;
    wire signed [15:0] applied_pwm;
    always #(CLK_NS/2) clk_50m = ~clk_50m;

    motor_tb6612 dut(.clk_50m(clk_50m), .rst_n(rst_n), .safe_enable(safe_enable),
        .motor_dir(motor_dir), .duty_in(duty_in),
        .deadband_pos(deadband_pos), .deadband_neg(deadband_neg),
        .deadzone_thresh(deadzone_thresh), .swingup_mode(swingup_mode),
        .in1(in1), .in2(in2), .pwm(pwm), .applied_pwm(applied_pwm));

    integer errors = 0;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    initial begin
        repeat(20) @(negedge clk_50m);
        rst_n = 1'b1;
        repeat(10) @(negedge clk_50m);

        $display("[场景 1] safe_enable=0 切断所有输出");
        safe_enable = 1'b0;
        repeat(50) @(negedge clk_50m);
        check(in1 === 1'b0 && in2 === 1'b0 && pwm === 1'b0, "all outputs cut");

        $display("[场景 2] 正向转动 CW");
        safe_enable = 1'b1;
        motor_dir = 2'b01;  // CW
        duty_in = 8'd128;  // 50%
        repeat(PWM_2500_CYCLES_HINT * 2) @(negedge clk_50m);
        check(in1 === 1'b1 && in2 === 1'b0, "CW: in1=1, in2=0");

        $display("[场景 3] 反向转动 CCW");
        motor_dir = 2'b10;  // CCW
        repeat(PWM_2500_CYCLES_HINT * 2) @(negedge clk_50m);
        check(in1 === 1'b0 && in2 === 1'b1, "CCW: in1=0, in2=1");

        $display("[场景 4] 停止 (dir=00)");
        motor_dir = 2'b00;
        repeat(200) @(negedge clk_50m);
        check(pwm === 1'b0, "stop: pwm low");

        if (errors == 0) $display("\nPASS: motor_tb6612 全部通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    // Dummy parameter for simulation
    localparam PWM_2500_CYCLES_HINT = 3000;

    initial begin #50000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule