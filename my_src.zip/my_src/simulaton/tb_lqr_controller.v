`timescale 1ns/1ps
`include "system_params.vh"
// ============================================================================
// tb_lqr_controller.v — lqr_controller 5 周期流水线 LQR 控制器仿真
// 验证状态误差提取、流水线乘法、控制量饱和、calc_done_pulse
// ============================================================================
module tb_lqr_controller;
    localparam CLK_HZ = `SYS_CLK_FREQ_HZ;
    localparam CLK_NS = 1000000000 / CLK_HZ;

    reg clk_50m = 1'b0;
    reg rst_n = 1'b0;
    reg tick_3ms = 1'b0;
    reg ctrl_enable = 1'b0;
    reg flush_pipeline = 1'b0;
    reg [15:0] calibrated_zero_val = 16'd2048;
    reg [11:0] theta_raw = 12'd2048;
    reg signed [15:0] theta_dot = 16'd0;
    reg [15:0] alpha_pos = 16'd0;
    reg [15:0] alpha_target_pos = 16'd0;
    reg signed [19:0] alpha_dot = 20'd0;
    reg signed [15:0] k_theta = `PARAM_K_THETA;
    reg signed [15:0] k_theta_dot = `PARAM_K_THETA_DOT;
    reg signed [15:0] k_alpha = `PARAM_K_ALPHA;
    reg signed [15:0] k_alpha_dot = `PARAM_K_ALPHA_DOT;
    wire [1:0] motor_dir;
    wire [7:0] duty_out;
    wire calc_done_pulse;
    wire saturated;
    wire signed [15:0] theta_err_mon;
    wire signed [15:0] alpha_err_mon;
    wire signed [15:0] u_scaled_mon;
    always #(CLK_NS/2) clk_50m = ~clk_50m;

    lqr_controller dut(.clk_50m(clk_50m), .rst_n(rst_n), .tick_3ms(tick_3ms),
        .ctrl_enable(ctrl_enable), .flush_pipeline(flush_pipeline),
        .calibrated_zero_val(calibrated_zero_val),
        .theta_raw(theta_raw), .theta_dot(theta_dot),
        .alpha_pos(alpha_pos), .alpha_target_pos(alpha_target_pos),
        .alpha_dot(alpha_dot),
        .k_theta(k_theta), .k_theta_dot(k_theta_dot),
        .k_alpha(k_alpha), .k_alpha_dot(k_alpha_dot),
        .motor_dir(motor_dir), .duty_out(duty_out),
        .calc_done_pulse(calc_done_pulse), .saturated(saturated),
        .theta_err_mon(theta_err_mon), .alpha_err_mon(alpha_err_mon),
        .u_scaled_mon(u_scaled_mon));

    integer errors = 0;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    initial begin
        repeat(20) @(negedge clk_50m);
        rst_n = 1'b1;
        ctrl_enable = 1'b1;
        repeat(10) @(negedge clk_50m);

        $display("[场景 1] 平衡点: theta=0, alpha=0");
        tick_3ms = 1; @(negedge clk_50m); tick_3ms = 0;
        repeat(20) @(negedge clk_50m);
        check(calc_done_pulse, "calculation completed");
        check(duty_out <= 3, "near-zero duty at equilibrium");

        $display("[场景 2] 小角度偏差 theta=2050");
        theta_raw = 12'd2050;
        tick_3ms = 1; @(negedge clk_50m); tick_3ms = 0;
        repeat(20) @(negedge clk_50m);
        check(motor_dir != 2'b00, "corrective direction");

        $display("[场景 3] flush_pipeline 清零");
        flush_pipeline = 1'b1;
        repeat(10) @(negedge clk_50m);
        flush_pipeline = 1'b0;

        $display("[场景 4] ctrl_enable=0 输出停止");
        ctrl_enable = 1'b0;
        tick_3ms = 1; @(negedge clk_50m); tick_3ms = 0;
        repeat(20) @(negedge clk_50m);

        if (errors == 0) $display("\nPASS: lqr_controller 全部通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #10000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule