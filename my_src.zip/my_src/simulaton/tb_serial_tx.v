`timescale 1ns/1ps
// ============================================================================
// tb_serial_tx.v — serial_tx 串口发送模块仿真
// 验证 8N1 帧发送、busy/done 握手、背靠背发送
// ============================================================================
module tb_serial_tx;
    localparam CLK_HZ = 25000000;
    localparam BAUD = 9600;
    localparam CLK_NS = 40;

    reg clk = 1'b0;
    reg rst_n = 1'b0;
    reg start = 1'b0;
    reg [7:0] tx_data = 8'd0;
    wire tx;
    wire busy;
    wire done;
    always #(CLK_NS/2) clk = ~clk;

    serial_tx #(.CLK_HZ(CLK_HZ), .BAUD(BAUD)) dut
        (.clk(clk), .rst_n(rst_n), .start(start), .data(tx_data), .tx(tx), .busy(busy), .done(done));

    integer errors = 0;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    task do_tx(input [7:0] d);
        begin
            @(negedge clk);
            tx_data = d;
            start = 1'b1;
            @(negedge clk);
            start = 1'b0;
        end
    endtask

    initial begin
        repeat(20) @(posedge clk);
        rst_n = 1'b1;
        repeat(20) @(posedge clk);

        $display("[场景 1] 空闲时 TX 为高");
        check(tx === 1'b1 && !busy && !done, "idle state");

        $display("[场景 2] 发送 0x55，检查时序");
        do_tx(8'h55);
        @(negedge clk);
        check(busy, "busy after start");
        wait(done);
        check(!busy, "not busy after done");
        check(done, "done pulsed");
        @(negedge clk);
        check(!done, "done single-cycle");

        $display("[场景 3] 背靠背发送 0xAA, 0x33");
        do_tx(8'hAA);
        wait(!busy);
        repeat(5) @(negedge clk);
        do_tx(8'h33);
        wait(!busy);

        $display("[场景 4] busy 期间不能接受新 start");
        do_tx(8'h12);
        @(negedge clk);
        check(busy, "busy confirmed");
        start = 1'b1;
        @(negedge clk);
        start = 1'b0;
        wait(done);
        // 第二个 start 应该被忽略（busy 期间不锁存新数据）
        repeat(5) @(negedge clk);
        check(tx === 1'b1, "ignored second start while busy");

        if (errors == 0) $display("\nPASS: serial_tx 全部通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #50000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule