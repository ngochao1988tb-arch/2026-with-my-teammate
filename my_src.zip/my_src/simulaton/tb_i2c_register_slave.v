`timescale 1ns/1ps
`include "system_params.vh"
// ============================================================================
// tb_i2c_register_slave.v — i2c_register_slave I2C 寄存器仿真
// 验证 START/STOP、地址匹配、寄存器读写、ack 握手
// ============================================================================
module tb_i2c_register_slave;
    localparam CLK_HZ = `SYS_CLK_FREQ_HZ;
    localparam CLK_NS = 1000000000 / CLK_HZ;
    localparam I2C_ADDRESS = 7'h01;

    reg clk = 1'b0;
    reg rst_n = 1'b0;
    reg scl = 1'b1;
    wire sda;
    reg [255:0] read_bank = 256'h0;
    reg sda_drive = 1'b0;
    reg sda_out = 1'b1;
    wire write_pulse;
    wire [7:0] write_address, write_data;
    assign sda = sda_drive ? sda_out : 1'bz;
    always #(CLK_NS/2) clk = ~clk;

    i2c_register_slave #(.ADDRESS(I2C_ADDRESS)) dut
        (.clk(clk), .rst_n(rst_n), .scl(scl), .sda(sda),
         .read_bank(read_bank), .write_pulse(write_pulse),
         .write_address(write_address), .write_data(write_data));

    integer errors = 0;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    task i2c_start;
        begin
            sda_drive = 1'b1; sda_out = 1'b1;
            repeat(5) @(negedge clk);
            sda_out = 1'b0;  // SDA fall while SCL high
            repeat(5) @(negedge clk);
        end
    endtask

    task i2c_stop;
        begin
            sda_out = 1'b0;
            repeat(5) @(negedge clk);
            scl = 1'b1;
            repeat(5) @(negedge clk);
            sda_out = 1'b1;  // SDA rise while SCL high
            repeat(10) @(negedge clk);
            sda_drive = 1'b0;
        end
    endtask

    task i2c_write_byte(input [7:0] data);
        integer i;
        begin
            for(i = 7; i >= 0; i = i - 1) begin
                sda_out = data[i];
                repeat(5) @(negedge clk);  // setup
                scl = 1'b1;  // SCL rise
                repeat(10) @(negedge clk);
                scl = 1'b0;  // SCL fall
                repeat(5) @(negedge clk);
            end
            // ACK bit: release SDA
            sda_drive = 1'b0;
            repeat(5) @(negedge clk);
            scl = 1'b1;
            repeat(10) @(negedge clk);
            scl = 1'b0;
            sda_drive = 1'b1;
            repeat(5) @(negedge clk);
        end
    endtask

    initial begin
        repeat(50) @(negedge clk);
        rst_n = 1'b1;
        repeat(50) @(negedge clk);

        $display("[场景 1] 写地址 0x00 = 0x42");
        i2c_start;
        i2c_write_byte({I2C_ADDRESS, 1'b0});  // write address
        i2c_write_byte(8'h00);  // register pointer = 0
        i2c_write_byte(8'h42);  // data = 0x42
        i2c_stop;
        repeat(50) @(negedge clk);
        check(write_pulse && write_address == 8'h00 && write_data == 8'h42, "write byte accepted");

        $display("[场景 2] 写地址 0x01 = 0xAB");
        i2c_start;
        i2c_write_byte({I2C_ADDRESS, 1'b0});
        i2c_write_byte(8'h01);
        i2c_write_byte(8'hAB);
        i2c_stop;
        repeat(50) @(negedge clk);
        check(write_pulse && write_address == 8'h01 && write_data == 8'hAB, "second write accepted");

        if (errors == 0) $display("\nPASS: i2c_register_slave 全部通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #10000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule