`timescale 1ns/1ps
`include "system_params.vh"
// ============================================================================
// tb_encoder_quad.v — encoder_quad 正交编码器仿真
// 验证 4x 计数、方向判别、非法跳变检测、速度估计
// ============================================================================
module tb_encoder_quad;
    localparam CLK_HZ = `SYS_CLK_FREQ_HZ;
    localparam CLK_NS = 1000000000 / CLK_HZ;

    reg clk_50m = 1'b0;
    reg rst_n = 1'b0;
    reg tick_3ms = 1'b0;
    reg enc_a = 1'b0;
    reg enc_b = 1'b0;
    wire [15:0] pos;
    wire signed [15:0] vel;
    wire [15:0] illegal_trans_cnt;
    wire [15:0] sampled_pos;
    wire signed [19:0] vel_q4;
    always #(CLK_NS/2) clk_50m = ~clk_50m;

    encoder_quad #(.INIT_POS(0), .FILTER_MODE(1)) dut
        (.clk_50m(clk_50m), .rst_n(rst_n), .tick_3ms(tick_3ms),
         .enc_a(enc_a), .enc_b(enc_b),
         .pos(pos), .vel(vel), .illegal_trans_cnt(illegal_trans_cnt),
         .sampled_pos(sampled_pos), .vel_q4(vel_q4));

    integer errors = 0;
    integer i;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    task enc_step_cw;
        begin
            repeat(3) @(negedge clk_50m);
            enc_a = ~enc_a;  // A first
            repeat(3) @(negedge clk_50m);
            enc_b = ~enc_b;  // B follows
        end
    endtask

    task enc_step_ccw;
        begin
            repeat(3) @(negedge clk_50m);
            enc_b = ~enc_b;  // B first
            repeat(3) @(negedge clk_50m);
            enc_a = ~enc_a;  // A follows
        end
    endtask

    initial begin
        repeat(50) @(posedge clk_50m);
        rst_n = 1'b1;
        repeat(100) @(posedge clk_50m);

        $display("[场景 1] 初始 pos=0");
        check(pos == 0, "initial position zero");

        $display("[场景 2] CW 旋转 10 步 (每步 4 个沿)");
        for(i = 0; i < 10; i = i + 1) enc_step_cw;
        repeat(100) @(posedge clk_50m);
        check(pos == 40, "CW 10 steps * 4 = 40 counts");

        $display("[场景 3] CCW 旋转 5 步");
        for(i = 0; i < 5; i = i + 1) enc_step_ccw;
        repeat(100) @(posedge clk_50m);
        check(pos == 20, "back 5 steps = 20 counts");

        $display("[场景 4] tick_3ms 产生速度估计");
        tick_3ms = 1; @(negedge clk_50m); tick_3ms = 0;
        repeat(100) @(negedge clk_50m);
        check(vel != 0 || vel_q4 != 0, "velocity estimate non-zero");

        if (errors == 0) $display("\nPASS: encoder_quad 全部通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #10000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule