`timescale 1ns/1ps
`include "control_config.vh"
// ============================================================================
// tb_slave_link.v — slave_link 主机到从板 UART v2 链路仿真
// 验证命令编码、应答解析、完成/失败判据
// ============================================================================
module tb_slave_link;
    localparam CLK_HZ = 50000000;
    localparam CLK_NS = 20;
    localparam BAUD = 115200;
    localparam BIT_NS = 1000000000 / BAUD;

    reg clk = 1'b0;
    reg rst_n = 1'b0;
    wire slave_tx;
    reg slave_rx = 1'b1;
    reg cmd_valid = 1'b0;
    reg [2:0] cmd_kind = 3'd0;
    reg [7:0] cmd_arg = 8'd0;
    reg cmd_right = 1'b0;
    reg [7:0] cmd_op = 8'd0;
    reg signed [15:0] cmd_arg16 = 16'd0;
    wire busy, done_pulse, fail_pulse;
    wire [2:0] fail_code;
    wire [7:0] rep_op, rep_result, rep_state, rep_fault, rep_flags;
    wire [15:0] rep_position, rep_final, rep_active;
    always #(CLK_NS/2) clk = ~clk;

    slave_link #(.CLK_HZ(CLK_HZ), .BAUD(BAUD),
        .SLAVE_CENTER(10000), .SLAVE_TRAVEL(2150), .SLAVE_COUNTS_PER_REV(1000),
        .REPLY_TIMEOUT_MS(60), .POLL_PERIOD_MS(20),
        .START_TIMEOUT_MS(1000), .MOVE_TIMEOUT_MS(1000), .SETTLE_TIMEOUT_MS(500),
        .MOVE_TOLERANCE(12), .TELEM_PERIOD_MS(100),
        .TELEM_TIMEOUT_MS(20), .LINK_LOST_MS(500))
        dut(.clk(clk), .rst_n(rst_n), .slave_tx(slave_tx), .slave_rx(slave_rx),
            .cmd_valid(cmd_valid), .cmd_kind(cmd_kind), .cmd_arg(cmd_arg),
            .cmd_right(cmd_right), .cmd_op(cmd_op), .cmd_arg16(cmd_arg16),
            .busy(busy), .done_pulse(done_pulse), .fail_pulse(fail_pulse),
            .fail_code(fail_code), .rep_op(rep_op), .rep_result(rep_result),
            .rep_state(rep_state), .rep_fault(rep_fault), .rep_flags(rep_flags),
            .rep_position(rep_position), .rep_final(rep_final), .rep_active(rep_active));

    integer errors = 0;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    task send_byte(input [7:0] byte);
        integer i;
        begin
            slave_rx = 1'b0;
            #(BIT_NS);
            for(i = 0; i < 8; i = i + 1) begin
                slave_rx = byte[i];
                #(BIT_NS);
            end
            slave_rx = 1'b1;
            #(BIT_NS);
        end
    endtask

    initial begin
        repeat(50) @(posedge clk);
        rst_n = 1'b1;
        repeat(50) @(posedge clk);

        $display("[场景 1] 空闲链路 busy=0");
        check(!busy, "idle: not busy");

        $display("[场景 2] 发送 CMD_POLL 遥测查询 (OP=0x60)");
        cmd_valid = 1'b1;
        cmd_kind = 3'd4;  // CMD_POLL
        cmd_op = 8'h60;
        cmd_arg16 = 16'd0;
        @(negedge clk); cmd_valid = 1'b0;
        repeat(100) @(negedge clk);

        // 模拟从板应答: 5A A5 01 00 00 ... (38 字节)
        send_byte(8'h5A);
        send_byte(8'hA5);
        send_byte(8'h01);
        repeat(35) send_byte(8'd0);

        if (errors == 0) $display("\nPASS: slave_link 基本通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #200000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule