`timescale 1ns/1ps
`include "system_params.vh"
// ============================================================================
// tb_nn_predictor_trial.v — nn_predictor_trial 神经网络预测器仿真
// 验证特征提取、推理触发、安全滤波器集成、debug_bank
// ============================================================================
module tb_nn_predictor_trial;
    localparam CLK_HZ = `SYS_CLK_FREQ_HZ;
    localparam CLK_NS = 1000000000 / CLK_HZ;

    reg clk = 1'b0;
    reg rst_n = 1'b0;
    reg control_tick = 1'b0;
    reg sample_tick = 1'b0;
    reg control_enable = 1'b0;
    reg hard_safe = 1'b0;
    reg authority_safe = 1'b0;
    reg [15:0] position = 16'd10000;
    reg [15:0] active_target = 16'd10000;
    reg [15:0] final_target = 16'd10000;
    reg signed [15:0] theta_error = 16'd0;
    reg signed [15:0] theta_dot = 16'd0;
    reg signed [15:0] base_command = 16'd0;
    reg signed [15:0] applied_pwm = 16'd0;
    reg signed [19:0] arm_velocity_q4 = 20'd0;
    reg mode_write = 1'b0;
    reg [7:0] requested_mode = 8'd1;
    reg invert = 1'b0;
    reg [31:0] frame_number = 32'd0;
    wire signed [15:0] correction;
    wire request_ok;
    wire [1:0] mode;
    wire trip_latch;
    wire [255:0] debug_bank;
    always #(CLK_NS/2) clk = ~clk;

    nn_predictor_trial dut(.clk(clk), .rst_n(rst_n),
        .control_tick(control_tick), .sample_tick(sample_tick),
        .control_enable(control_enable), .hard_safe(hard_safe),
        .authority_safe(authority_safe),
        .position(position), .active_target(active_target),
        .final_target(final_target),
        .theta_error(theta_error), .theta_dot(theta_dot),
        .base_command(base_command), .applied_pwm(applied_pwm),
        .arm_velocity_q4(arm_velocity_q4),
        .mode_write(mode_write), .requested_mode(requested_mode),
        .invert(invert), .frame_number(frame_number),
        .correction(correction), .request_ok(request_ok),
        .mode(mode), .trip_latch(trip_latch), .debug_bank(debug_bank));

    integer errors = 0;
    integer i;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    initial begin
        repeat(20) @(negedge clk);
        rst_n = 1'b1;
        control_enable = 1'b1;
        hard_safe = 1'b1;
        authority_safe = 1'b1;
        repeat(10) @(negedge clk);

        $display("[场景 1] 初始 mode=1 (监视)");
        check(mode == 1, "initial monitor mode");

        $display("[场景 2] 填充历史缓冲区 (10个采样)");
        for(i = 0; i < 20; i = i + 1) begin
            sample_tick = 1; @(negedge clk); sample_tick = 0;
            repeat(9) @(negedge clk);
            control_tick = 1; @(negedge clk); control_tick = 0;
            repeat(9) @(negedge clk);
        end

        $display("[场景 3] 一次推理完成后检查 mode");
        repeat(500) @(negedge clk);
        check(mode != 2'bx, "mode valid");
        check(!trip_latch, "no trip");

        if (errors == 0) $display("\nPASS: nn_predictor_trial 基本通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #20000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule