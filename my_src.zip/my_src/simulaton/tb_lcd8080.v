`timescale 1ns/1ps
`include "lcd_config.vh"
// ============================================================================
// tb_lcd8080.v — lcd8080 8080并口LCD控制器仿真
// 验证总线时序、CS/WR/RD、data_oe、读写完成
// ============================================================================
module tb_lcd8080;
    localparam DW = 16;
    reg clk = 1'b0;
    reg rst_n = 1'b0;
    reg cs = 1'b0;
    reg we = 1'b0;
    reg [7:0] addr = 8'd0;
    reg [31:0] wdata = 32'd0;
    reg [3:0] wstrb = 4'b0;
    wire [31:0] rdata;
    wire done;
    wire lcd_cs_n, lcd_wr_n, lcd_rd_n, lcd_rs, lcd_reset_n;
    wire [DW-1:0] lcd_data_o;
    wire lcd_data_oe;
    reg [DW-1:0] lcd_data_i = 0;
    wire [DW-1:0] lcd_data;
    wire lcd_bl;
    reg touch_miso = 1'b0, touch_pen_n = 1'b1;
    wire touch_cs_n, touch_clk, touch_mosi;
    always #10 clk = ~clk;

    assign lcd_data = lcd_data_oe ? lcd_data_o : {DW{1'bz}};

    lcd8080 #(.DATA_WIDTH(DW)) dut
        (.clk(clk), .rst_n(rst_n), .cs(cs), .we(we), .addr(addr),
         .wdata(wdata), .wstrb(wstrb), .rdata(rdata), .done(done),
         .lcd_cs_n(lcd_cs_n), .lcd_wr_n(lcd_wr_n), .lcd_rd_n(lcd_rd_n),
         .lcd_rs(lcd_rs), .lcd_reset_n(lcd_reset_n),
         .lcd_data_o(lcd_data_o), .lcd_data_oe(lcd_data_oe), .lcd_data_i(lcd_data),
         .lcd_bl(lcd_bl), .touch_miso(touch_miso), .touch_pen_n(touch_pen_n),
         .touch_cs_n(touch_cs_n), .touch_clk(touch_clk), .touch_mosi(touch_mosi));

    integer errors = 0;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    initial begin
        repeat(50) @(negedge clk);
        rst_n = 1'b1;
        repeat(20) @(negedge clk);

        $display("[场景 1] 复位后所有选通为高、data_oe=0");
        check(lcd_cs_n === 1'b1 && lcd_wr_n === 1'b1 && lcd_rd_n === 1'b1, "all strobes high after reset");
        check(lcd_data_oe === 1'b0, "data_oe low (Hi-Z)");

        $display("[场景 2] 写命令 (addr=0x00, RS=0)");
        cs = 1'b1; we = 1'b1; addr = 8'h00; wdata = 32'h00000011; wstrb = 4'hF;
        @(negedge clk); cs = 1'b0; we = 1'b0; wstrb = 4'h0;
        wait(done);
        check(lcd_rs === 1'b0, "RS=0 for command write");
        @(negedge clk);
        check(!done, "done single-cycle");

        $display("[场景 3] 写数据 (addr=0x04, RS=1)");
        cs = 1'b1; we = 1'b1; addr = 8'h04; wdata = 32'h0000FFFF; wstrb = 4'h3;
        @(negedge clk); cs = 1'b0; we = 1'b0; wstrb = 4'h0;
        wait(done);
        check(lcd_rs === 1'b1, "RS=1 for data write");

        $display("[场景 4] 读数据 (addr=0x04)");
        cs = 1'b1; we = 1'b0; addr = 8'h04;
        @(negedge clk); cs = 1'b0;
        wait(done);

        if (errors == 0) $display("\nPASS: lcd8080 基本通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #50000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule