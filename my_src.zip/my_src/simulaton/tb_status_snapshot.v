`timescale 1ns/1ps
`include "lcd_config.vh"
// ============================================================================
// tb_status_snapshot.v — status_snapshot 状态快照模块仿真
// 验证 seqlock 机制: SEQ 递增 → 读字段 → 再读 SEQ 一致
// ============================================================================
module tb_status_snapshot;
    localparam CLK_HZ = 50000000;
    localparam CLK_NS = 20;

    reg clk = 1'b0;
    reg rst_n = 1'b0;
    reg signed [31:0] i_alpha_q16 = 32'd100;
    reg signed [31:0] i_theta_q16 = 32'd200;
    reg signed [31:0] i_arm_ref_q16 = 32'd300;
    reg signed [31:0] i_freq_q8 = 32'd400;
    reg signed [31:0] i_u_q16 = 32'd500;
    reg signed [31:0] i_alpha_dot = 32'd600;
    reg signed [31:0] i_theta_dot = 32'd700;
    reg signed [31:0] i_alpha_c = 32'd800;
    reg [31:0] i_enc_raw = 32'd900;
    reg [31:0] i_enc_age_us = 32'd1000;
    reg [31:0] i_enc_seq = 32'd1100;
    reg [31:0] i_ctrl_count = 32'd1200;
    reg [31:0] i_t_us = 32'd1300;
    reg [12:0] i_ad_value = 13'd1400;
    reg [7:0] i_state = 8'd3;
    reg [7:0] i_fault = 8'd0;
    reg [7:0] i_flags = 8'd1;
    reg [31:0] i_build_tag = 32'h26103101;
    reg i_run = 1'b1;
    reg i_calibrated = 1'b1;
    reg i_saturated = 1'b0;
    reg i_fb_ready = 1'b1;
    reg i_swing_active = 1'b0;
    reg cs = 1'b0;
    reg we = 1'b0;
    reg [7:0] addr = 8'd0;
    reg [31:0] wdata = 32'd0;
    reg [3:0] wstrb = 4'd0;
    wire [31:0] rdata;
    always #(CLK_NS/2) clk = ~clk;

    status_snapshot #(.CLK_HZ(CLK_HZ)) dut
        (.clk(clk), .rst_n(rst_n),
         .i_alpha_q16(i_alpha_q16), .i_theta_q16(i_theta_q16), .i_arm_ref_q16(i_arm_ref_q16),
         .i_freq_q8(i_freq_q8), .i_u_q16(i_u_q16), .i_alpha_dot(i_alpha_dot),
         .i_theta_dot(i_theta_dot), .i_alpha_c(i_alpha_c), .i_enc_raw(i_enc_raw),
         .i_enc_age_us(i_enc_age_us), .i_enc_seq(i_enc_seq), .i_ctrl_count(i_ctrl_count),
         .i_t_us(i_t_us), .i_ad_value(i_ad_value), .i_state(i_state), .i_fault(i_fault),
         .i_flags(i_flags), .i_build_tag(i_build_tag), .i_run(i_run),
         .i_calibrated(i_calibrated), .i_saturated(i_saturated), .i_fb_ready(i_fb_ready),
         .i_swing_active(i_swing_active),
         .cs(cs), .we(we), .addr(addr), .wdata(wdata), .wstrb(wstrb), .rdata(rdata));

    integer errors = 0;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    task read_reg(input [7:0] a, output [31:0] val);
        begin
            @(negedge clk);
            cs = 1'b1; we = 1'b0; addr = a;
            @(negedge clk);
            val = rdata;
            cs = 1'b0;
        end
    endtask

    initial begin
        repeat(30) @(negedge clk);
        rst_n = 1'b1;
        repeat(30) @(negedge clk);

        $display("[场景 1] 读 SEQ (地址 0x00)");
        begin
            reg [31:0] seq1, seq2;
            read_reg(8'h00, seq1);
            read_reg(8'h00, seq2);
            check(seq2 > seq1, "SEQ increments");
        end

        $display("[场景 2] 读状态寄存器 (地址 0x04)");
        begin
            reg [31:0] st;
            read_reg(8'h04, st);
            check(st[7:0] == 8'd3, "state = balancing (3)");
        end

        $display("[场景 3] seqlock 一致性: read seq -> fields -> read seq");
        begin
            reg [31:0] s1, s2, alpha_val;
            read_reg(8'h00, s1);
            read_reg(8'h08, alpha_val);
            read_reg(8'h00, s2);
            check(s2 == s1 || s2 == s1 + 1, "seqlock: no torn read");
        end

        if (errors == 0) $display("\nPASS: status_snapshot 全部通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #100000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule