`timescale 1ns/1ps
// ============================================================================
// tb_square16_pipe.v — square16_pipe 有符号 16 位平方模块仿真
// 验证精确流水线平方、边界值、延迟
// ============================================================================
module tb_square16_pipe;
    reg clk = 1'b0;
    reg signed [15:0] x = 16'd0;
    wire [31:0] y;
    always #10 clk = ~clk;

    square16_pipe dut(.clk(clk), .x(x), .y(y));

    integer i, errors = 0;
    reg signed [31:0] expected [0:6];

    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    initial begin
        for(i=0;i<7;i=i+1) expected[i] = 0;
        repeat(20) @(negedge clk);

        $display("[场景 1] 全量程扫描 -32768 到 32767");
        for(x = -32768; x < 32768; x = x + 1) begin
            @(posedge clk); #1;
            expected[5] = expected[4]; expected[4] = expected[3];
            expected[3] = expected[2]; expected[2] = expected[1];
            expected[1] = expected[0]; expected[0] = $signed(x) * $signed(x);
            if(x >= -32743) begin
                if(y !== expected[5])
                    $fatal(1, "MISMATCH x=%d actual=%h expected=%h", x-6, y, expected[5]);
            end
            @(negedge clk);
        end

        $display("[场景 2] 极值测试");
        x = 16'sh7FFF;  // 32767
        repeat(7) @(negedge clk);
        check(y == 32'd1073676289, "32767^2");
        x = 16'sh8000;  // -32768
        repeat(7) @(negedge clk);
        check(y == 32'd1073741824, "-32768^2");

        $display("[场景 3] 0 平方");
        x = 16'd0;
        repeat(7) @(negedge clk);
        check(y == 32'd0, "0^2");

        if (errors == 0) $display("\nPASS: square16_pipe 全部通过 (全量程65536点)");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #100000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule