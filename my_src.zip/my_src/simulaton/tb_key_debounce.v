`timescale 1ns/1ps
// ============================================================================
// tb_key_debounce.v — key_debounce 按键消抖模块仿真
// ============================================================================
module tb_key_debounce;
    localparam CLK_HZ = 25000000;
    localparam CLK_NS = 1000000000 / CLK_HZ;  // 40 ns
    localparam DEBOUNCE_MS = 20;

    reg clk = 1'b0;
    reg rst_n = 1'b0;
    reg key_n = 1'b1;
    wire pressed;
    always #(CLK_NS/2) clk = ~clk;

    key_debounce #(.CLK_HZ(CLK_HZ), .DEBOUNCE_MS(DEBOUNCE_MS)) dut
        (.clk(clk), .rst_n(rst_n), .key_n(key_n), .pressed(pressed));

    integer errors = 0;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    initial begin
        repeat(10) @(posedge clk);
        rst_n = 1'b1;
        repeat(10) @(posedge clk);

        $display("[场景 1] 上电后未按下，不应有脉冲");
        repeat(1000) @(posedge clk);
        check(!pressed, "no false pulse at startup");

        $display("[场景 2] 短于消抖时间的脉冲不应触发");
        key_n = 1'b0;
        repeat(10) @(posedge clk);
        key_n = 1'b1;
        repeat(500) @(posedge clk);
        check(!pressed, "short glitch ignored");

        $display("[场景 3] 持续按键应产生一个脉冲");
        key_n = 1'b0;
        repeat(CLK_HZ/1000*DEBOUNCE_MS + 10) @(posedge clk);
        #1;
        check(pressed === 1'b1, "pressed pulse after debounce");
        repeat(5) @(posedge clk);
        check(!pressed, "pulse is single-cycle");

        $display("[场景 4] 按键释放后重新按下");
        key_n = 1'b1;
        repeat(CLK_HZ/1000*DEBOUNCE_MS + 10) @(posedge clk);
        key_n = 1'b0;
        repeat(CLK_HZ/1000*DEBOUNCE_MS + 10) @(posedge clk);
        #1;
        check(pressed === 1'b1, "second press detected");

        if (errors == 0) $display("\nPASS: key_debounce 全部通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #10000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule