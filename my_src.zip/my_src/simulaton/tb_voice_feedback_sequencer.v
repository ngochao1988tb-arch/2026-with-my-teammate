`timescale 1ns/1ps
// ============================================================================
// tb_voice_feedback_sequencer.v — voice_feedback_sequencer 播报排序器仿真
// 验证 play_req -> play_done 握手、间隔 GAP、多步播报
// ============================================================================
module tb_voice_feedback_sequencer;
    localparam CLK_HZ = 50000000;
    localparam GAP_MS = 10;  // 缩短仿真时间
    localparam CLK_NS = 20;

    reg clk = 1'b0;
    reg rst_n = 1'b0;
    reg report_valid = 1'b0;
    reg [1:0] report_target_mask = 2'b00;
    reg [7:0] report_action_id = 8'd0;
    reg [2:0] report_result = 3'd0;
    reg prompt_valid = 1'b0;
    reg [7:0] prompt_id = 8'd0;
    reg play_busy = 1'b0;
    reg play_done = 1'b0;
    wire play_req;
    wire [7:0] play_id;
    wire ready;
    wire done_pulse;
    always #(CLK_NS/2) clk = ~clk;

    voice_feedback_sequencer #(.CLK_HZ(CLK_HZ), .GAP_MS(GAP_MS)) dut
        (.clk(clk), .rst_n(rst_n),
         .report_valid(report_valid), .report_target_mask(report_target_mask),
         .report_action_id(report_action_id), .report_result(report_result),
         .prompt_valid(prompt_valid), .prompt_id(prompt_id),
         .play_busy(play_busy), .play_done(play_done),
         .play_req(play_req), .play_id(play_id),
         .ready(ready), .done_pulse(done_pulse));

    integer errors = 0;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    initial begin
        repeat(20) @(negedge clk);
        rst_n = 1'b1;
        repeat(10) @(negedge clk);

        $display("[场景 1] 空闲 ready=1");
        check(ready, "idle ready");

        $display("[场景 2] report_valid 触发播报序列");
        report_valid = 1'b1;
        report_target_mask = 2'b01;  // 主摆
        report_action_id = 8'h40;   // 起摆
        report_result = 3'd0;       // OK
        @(negedge clk); report_valid = 1'b0;
        repeat(5) @(negedge clk);
        check(play_req, "play request issued");

        // 模拟 play_done
        play_busy = 1'b1;
        repeat(100) @(negedge clk);
        play_busy = 1'b0;
        play_done = 1'b1;
        @(negedge clk); play_done = 1'b0;
        repeat(10) @(negedge clk);

        $display("[场景 3] 播报完成后 with GAP 检查 ready 恢复");
        repeat(CLK_HZ/1000*GAP_MS + 100) @(negedge clk);
        check(ready, "ready after gap");

        if (errors == 0) $display("\nPASS: voice_feedback_sequencer 基本通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #50000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule