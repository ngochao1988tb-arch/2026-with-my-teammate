`timescale 1ns/1ps
`include "control_config.vh"
// ============================================================================
// tb_adc_sampler.v — adc_sampler 3PA1030 ADC 双 EMA 采样器仿真
// 验证连续采样、帧同步、双 EMA 滤波、快慢模式切换
// ============================================================================
module tb_adc_sampler;
    localparam CLK_HZ = 25000000;
    localparam CLK_NS = 40;

    reg clk = 1'b0;
    reg rst_n = 1'b0;
    reg [9:0] adc_data_in = 10'd512;
    wire adc_clk, adc_oe_n;
    wire [12:0] ad_value;
    wire sample_valid;
    always #(CLK_NS/2) clk = ~clk;

    adc_sampler dut(.clk(clk), .rst_n(rst_n), .adc_data_in(adc_data_in),
        .adc_clk(adc_clk), .adc_oe_n(adc_oe_n), .ad_value(ad_value), .sample_valid(sample_valid));

    integer errors = 0;
    integer i;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    initial begin
        repeat(50) @(negedge clk);
        rst_n = 1'b1;
        repeat(20) @(negedge clk);

        $display("[场景 1] 时钟产生验证");
        check(adc_clk !== 1'bz, "adc_clk driven");
        check(adc_oe_n === 1'b0, "adc_oe_n low (enabled)");

        $display("[场景 2] 等待采样稳定 (多个 500us 帧)");
        for(i = 0; i < 20; i = i + 1) begin
            wait(sample_valid);
            @(negedge clk);
        end
        check(ad_value >= `CFG_ADC_OUTPUT_OFFSET - 50 &&
              ad_value <= `CFG_ADC_OUTPUT_OFFSET + 50, "ad_value near offset");

        $display("[场景 3] 改变输入验证跟踪");
        adc_data_in = 10'd600;
        repeat(CLK_HZ / 1000000 * `CFG_CONTROL_PERIOD_US * 10) @(negedge clk);
        check(ad_value > `CFG_ADC_OUTPUT_OFFSET + 20, "adc tracks input");

        if (errors == 0) $display("\nPASS: adc_sampler 基本通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #50000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule