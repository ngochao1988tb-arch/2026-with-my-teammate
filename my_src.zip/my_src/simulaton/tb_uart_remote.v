`timescale 1ns/1ps
`include "system_params.vh"
// ============================================================================
// tb_uart_remote.v — uart_remote 远程 UART 协议模块仿真
// 验证 OP20/OP30/OP31 命令解析、应答打包、capture_fifo 集成
// ============================================================================
module tb_uart_remote;
    localparam CLK_HZ = `SYS_CLK_FREQ_HZ;
    localparam CLK_NS = 1000000000 / CLK_HZ;
    localparam BAUD_DIV = `UART_DEBUG_BPS_DIV;
    localparam BIT_NS = CLK_NS * BAUD_DIV;

    reg clk = 1'b0;
    reg rst_n = 1'b0;
    reg rx = 1'b1;
    wire tx;
    reg [255:0] read_bank = 256'd0;
    reg [255:0] debug_bank = 256'd0;
    reg capture_valid = 1'b0;
    reg [255:0] capture_bank = 256'd0;
    wire write_pulse;
    wire [7:0] write_data;
    wire [7:0] write_operation;
    wire [15:0] write_target;
    reg [255:0] telemetry_bank = 256'd0;
    always #(CLK_NS/2) clk = ~clk;

    uart_remote #(.CAPTURE_ENABLE(0), .UNIFORM_REQUESTS(1), .LEGACY_COMPAT(1))
        dut(.clk(clk), .rst_n(rst_n), .rx(rx), .tx(tx),
            .read_bank(read_bank), .debug_bank(debug_bank),
            .capture_valid(capture_valid), .capture_bank(capture_bank),
            .write_pulse(write_pulse), .write_data(write_data),
            .write_operation(write_operation), .write_target(write_target),
            .telemetry_bank(telemetry_bank));

    integer errors = 0;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    task send_byte(input [7:0] byte);
        integer i;
        begin
            rx = 1'b0;
            #(BIT_NS);
            for(i = 0; i < 8; i = i + 1) begin
                rx = byte[i];
                #(BIT_NS);
            end
            rx = 1'b1;
            #(BIT_NS);
        end
    endtask

    initial begin
        repeat(50) @(posedge clk);
        rst_n = 1'b1;
        repeat(50) @(posedge clk);

        $display("[场景 1] O31 保持生效目标 (7 字节)");
        // A5 5A 01 31 00 00 XOR
        send_byte(8'hA5);
        send_byte(8'h5A);
        send_byte(8'h01);
        send_byte(8'h31);
        send_byte(8'h00);
        send_byte(8'h00);
        send_byte(8'h01 ^ 8'h31 ^ 8'h00 ^ 8'h00);
        // 等待处理完成与应答
        repeat(20000) @(negedge clk);

        $display("[场景 2] O20 起摆 (6 字节)");
        send_byte(8'hA5);
        send_byte(8'h5A);
        send_byte(8'h01);
        send_byte(8'h20);
        send_byte(8'h01);
        send_byte(8'h01 ^ 8'h20 ^ 8'h01);
        repeat(20000) @(negedge clk);

        if (errors == 0) $display("\nPASS: uart_remote 基本通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #50000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule