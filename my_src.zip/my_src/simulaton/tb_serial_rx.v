`timescale 1ns/1ps
// ============================================================================
// tb_serial_rx.v — serial_rx 串口接收模块仿真
// 验证 8N1 帧：起始位检测、数据位采样、停止位校验、帧错误
// ============================================================================
module tb_serial_rx;
    localparam CLK_HZ = 25000000;
    localparam BAUD = 9600;
    localparam BIT_CLK = CLK_HZ / BAUD;
    localparam CLK_NS = 40;
    localparam BIT_NS = BIT_CLK * CLK_NS;

    reg clk = 1'b0;
    reg rst_n = 1'b0;
    reg rx = 1'b1;
    wire [7:0] data;
    wire valid;
    wire framing_error;
    always #(CLK_NS/2) clk = ~clk;

    serial_rx #(.CLK_HZ(CLK_HZ), .BAUD(BAUD)) dut
        (.clk(clk), .rst_n(rst_n), .rx(rx), .data(data), .valid(valid), .framing_error(framing_error));

    integer errors = 0;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    task send_byte(input [7:0] byte, input stop_correct);
        integer i;
        begin
            rx = 1'b0;  // start
            #(BIT_NS);
            for(i=0;i<8;i=i+1) begin
                rx = byte[i];
                #(BIT_NS);
            end
            rx = stop_correct ? 1'b1 : 1'b0;  // stop
            #(BIT_NS);
            rx = 1'b1;
        end
    endtask

    initial begin
        repeat(20) @(posedge clk);
        rst_n = 1'b1;
        repeat(20) @(posedge clk);

        $display("[场景 1] 发送 0xAA，检查正确接收");
        send_byte(8'hAA, 1'b1);
        repeat(30) @(posedge clk);
        check(valid && data == 8'hAA && !framing_error, "receive 0xAA");

        $display("[场景 2] 发送 0x55，检查正确接收");
        send_byte(8'h55, 1'b1);
        repeat(30) @(posedge clk);
        check(valid && data == 8'h55 && !framing_error, "receive 0x55");

        $display("[场景 3] 发送 0x00");
        send_byte(8'h00, 1'b1);
        repeat(30) @(posedge clk);
        check(valid && data == 8'h00 && !framing_error, "receive 0x00");

        $display("[场景 4] 发送 0xFF");
        send_byte(8'hFF, 1'b1);
        repeat(30) @(posedge clk);
        check(valid && data == 8'hFF && !framing_error, "receive 0xFF");

        $display("[场景 5] 帧错误（停止位=0）");
        send_byte(8'h33, 1'b0);
        repeat(30) @(posedge clk);
        check(framing_error, "framing error detected");

        $display("[场景 6] 起始位毛刺不应触发完整帧");
        rx = 1'b0;
        #(BIT_NS/4);
        rx = 1'b1;
        #(BIT_NS*12);
        check(!valid, "glitch start bit ignored");

        if (errors == 0) $display("\nPASS: serial_rx 全部通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #50000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule