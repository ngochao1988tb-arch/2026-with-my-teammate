`timescale 1ns/1ps
`include "system_params.vh"
// ============================================================================
// tb_capture_fifo.v — capture_fifo 捕获 FIFO 仿真
// 验证写入、读取、空/满、clear、forward 直通
// ============================================================================
module tb_capture_fifo;
    localparam CLK_HZ = `SYS_CLK_FREQ_HZ;
    localparam CLK_NS = 1000000000 / CLK_HZ;

    reg clk = 1'b0;
    reg rst_n = 1'b0;
    reg clear = 1'b0;
    reg enable = 1'b0;
    reg sample_valid = 1'b0;
    reg [255:0] sample_bank = 256'd0;
    reg pop = 1'b0;
    wire [255:0] head;
    wire empty;
    wire [5:0] count;
    wire [31:0] generated, dropped;
    always #(CLK_NS/2) clk = ~clk;

    capture_fifo #(.ADDR_BITS(5)) dut
        (.clk(clk), .rst_n(rst_n), .clear(clear), .enable(enable),
         .sample_valid(sample_valid), .sample_bank(sample_bank), .pop(pop),
         .head(head), .empty(empty), .count(count),
         .generated(generated), .dropped(dropped));

    integer errors = 0;
    integer i;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    initial begin
        repeat(20) @(negedge clk);
        rst_n = 1'b1;
        enable = 1'b1;
        repeat(10) @(negedge clk);

        $display("[场景 1] 初始空");
        check(empty && count == 0, "initial empty");

        $display("[场景 2] 写入 3 个样本");
        for(i = 0; i < 3; i = i + 1) begin
            sample_bank = {256{$signed(i+1)}};
            sample_valid = 1; @(negedge clk); sample_valid = 0;
            repeat(2) @(negedge clk);
        end
        check(count == 3 && !empty, "count=3 not empty");

        $display("[场景 3] 弹出 1 个");
        pop = 1; @(negedge clk); pop = 0;
        repeat(3) @(negedge clk);
        check(count == 2, "count=2 after pop");

        $display("[场景 4] clear 清空");
        clear = 1; @(negedge clk); clear = 0;
        repeat(5) @(negedge clk);
        check(empty && count == 0, "clear empties FIFO");

        if (errors == 0) $display("\nPASS: capture_fifo 全部通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #10000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule