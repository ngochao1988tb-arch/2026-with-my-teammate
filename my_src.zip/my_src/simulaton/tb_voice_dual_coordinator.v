`timescale 1ns/1ps
// ============================================================================
// tb_voice_dual_coordinator.v — voice_dual_coordinator 双摆协调器仿真
// 验证命令分发、主从板 done/fail 收集、超时报告
// ============================================================================
module tb_voice_dual_coordinator;
    localparam CLK_HZ = 50000000;
    localparam CLK_NS = 20;

    reg clk = 1'b0;
    reg rst_n = 1'b0;
    reg command_valid = 1'b0;
    reg [1:0] command_target_mask = 2'b00;
    reg [3:0] command_action = 4'd0;
    reg [7:0] command_id = 8'd0;
    reg [7:0] command_angle = 8'd0;
    reg command_right = 1'b0;
    reg local_done = 1'b0;
    reg local_fail = 1'b0;
    reg remote_done = 1'b0;
    reg remote_fail = 1'b0;
    wire local_cmd_valid;
    wire [3:0] local_action;
    wire [7:0] local_action_id;
    wire [7:0] local_angle;
    wire local_right;
    wire remote_cmd_valid;
    wire [3:0] remote_action;
    wire [7:0] remote_action_id;
    wire [7:0] remote_angle;
    wire remote_right;
    wire report_valid;
    wire [1:0] report_target_mask;
    wire [7:0] report_action_id;
    wire [2:0] report_result;
    wire ready;
    wire busy;
    always #(CLK_NS/2) clk = ~clk;

    voice_dual_coordinator #(.CLK_HZ(CLK_HZ), .ACTION_TIMEOUT_MS(100)) dut
        (.clk(clk), .rst_n(rst_n),
         .command_valid(command_valid), .command_target_mask(command_target_mask),
         .command_action(command_action), .command_id(command_id),
         .command_angle(command_angle), .command_right(command_right),
         .local_done(local_done), .local_fail(local_fail),
         .remote_done(remote_done), .remote_fail(remote_fail),
         .local_cmd_valid(local_cmd_valid), .local_action(local_action),
         .local_action_id(local_action_id), .local_angle(local_angle), .local_right(local_right),
         .remote_cmd_valid(remote_cmd_valid), .remote_action(remote_action),
         .remote_action_id(remote_action_id), .remote_angle(remote_angle), .remote_right(remote_right),
         .report_valid(report_valid), .report_target_mask(report_target_mask),
         .report_action_id(report_action_id), .report_result(report_result),
         .ready(ready), .busy(busy));

    integer errors = 0;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    initial begin
        repeat(20) @(negedge clk);
        rst_n = 1'b1;
        repeat(10) @(negedge clk);

        $display("[场景 1] 空闲时 ready=1, busy=0");
        check(ready && !busy, "idle state");

        $display("[场景 2] 仅主摆起摆 (target=01)");
        command_target_mask = 2'b01;
        command_action = 4'd1;
        command_id = 8'h01;
        command_valid = 1'b1;
        @(negedge clk); command_valid = 1'b0;
        repeat(5) @(negedge clk);
        check(local_cmd_valid && !remote_cmd_valid, "only local command issued");

        $display("[场景 3] 主摆完成 -> report OK");
        local_done = 1'b1;
        @(negedge clk); local_done = 1'b0;
        repeat(10) @(negedge clk);
        check(report_valid && report_result == 3'd0, "main done ok");

        $display("[场景 4] 双摆目标 (target=11)");
        command_target_mask = 2'b11;
        command_id = 8'h02;
        command_valid = 1'b1;
        @(negedge clk); command_valid = 1'b0;
        repeat(5) @(negedge clk);
        check(local_cmd_valid && remote_cmd_valid, "both local and remote issued");

        // 主摆完成
        local_done = 1'b1;
        @(negedge clk); local_done = 1'b0;
        repeat(5) @(negedge clk);
        check(!report_valid, "not yet complete - waiting remote");

        // 从摆失败
        remote_fail = 1'b1;
        @(negedge clk); remote_fail = 1'b0;
        repeat(10) @(negedge clk);
        check(report_valid && report_result == 3'd2, "both: slave fail reported");

        if (errors == 0) $display("\nPASS: voice_dual_coordinator 全部通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #10000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule