`timescale 1ns/1ps
// ============================================================================
// tb_voice_uart_bridge.v — voice_uart_bridge CI1302 语音 UART 桥仿真
// 验证 AA 55 帧解析、命令词识别、播报字节发送
// ============================================================================
module tb_voice_uart_bridge;
    localparam CLK_HZ = 50000000;
    localparam CLK_NS = 20;
    localparam BAUD = 115200;
    localparam BIT_NS = 1000000000 / BAUD;

    reg clk = 1'b0;
    reg rst_n = 1'b0;
    reg voice_uart_rx_y15 = 1'b1;
    wire voice_uart_tx_y14;
    wire target_changed;
    wire [1:0] target_mask;
    wire target_timeout;
    wire command_valid;
    wire [1:0] command_target_mask;
    wire [3:0] action_code;
    wire [7:0] command_id;
    wire [7:0] move_angle;
    wire move_right;
    wire command_rejected;
    wire [1:0] reject_reason;
    wire raw_frame_valid;
    wire [7:0] raw_func;
    wire [7:0] raw_id;
    wire estop_latched;
    wire safe_to_run;
    reg play_req = 1'b0;
    reg [7:0] play_id = 8'd0;
    wire play_busy;
    wire play_done;
    always #(CLK_NS/2) clk = ~clk;

    voice_uart_bridge #(.CLK_HZ(CLK_HZ), .BAUD(BAUD)) dut
        (.clk(clk), .rst_n(rst_n),
         .voice_uart_rx_y15(voice_uart_rx_y15), .voice_uart_tx_y14(voice_uart_tx_y14),
         .target_changed(target_changed), .target_mask(target_mask),
         .target_timeout(target_timeout),
         .command_valid(command_valid), .command_target_mask(command_target_mask),
         .action_code(action_code), .command_id(command_id),
         .move_angle(move_angle), .move_right(move_right),
         .command_rejected(command_rejected), .reject_reason(reject_reason),
         .raw_frame_valid(raw_frame_valid), .raw_func(raw_func), .raw_id(raw_id),
         .estop_latched(estop_latched), .safe_to_run(safe_to_run),
         .play_req(play_req), .play_id(play_id),
         .play_busy(play_busy), .play_done(play_done));

    integer errors = 0;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    task send_byte(input [7:0] byte);
        integer i;
        begin
            voice_uart_rx_y15 = 1'b0;
            #(BIT_NS);
            for(i = 0; i < 8; i = i + 1) begin
                voice_uart_rx_y15 = byte[i];
                #(BIT_NS);
            end
            voice_uart_rx_y15 = 1'b1;
            #(BIT_NS);
        end
    endtask

    initial begin
        repeat(50) @(posedge clk);
        rst_n = 1'b1;
        repeat(50) @(posedge clk);

        $display("[场景 1] 发送目标选择帧: AA 55 00 B0");
        send_byte(8'hAA);
        send_byte(8'h55);
        send_byte(8'h00);  // FUNC_COMMAND
        send_byte(8'hB0);  // 主摆
        repeat(500) @(posedge clk);
        check(target_mask == 2'b01, "main target mask set");

        $display("[场景 2] 起摆命令: AA 55 00 40");
        send_byte(8'hAA);
        send_byte(8'h55);
        send_byte(8'h00);
        send_byte(8'h40);
        repeat(500) @(posedge clk);
        check(command_valid && action_code == 4'd1, "swing up command detected");

        $display("[场景 3] 播报请求");
        play_req = 1'b1;
        play_id = 8'h70;
        @(negedge clk); play_req = 1'b0;
        repeat(5000) @(posedge clk);
        check(play_busy, "play busy during transmission");

        if (errors == 0) $display("\nPASS: voice_uart_bridge 基本通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #50000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule