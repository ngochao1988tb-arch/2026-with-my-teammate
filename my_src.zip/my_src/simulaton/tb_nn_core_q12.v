`timescale 1ns/1ps
`include "system_params.vh"
// ============================================================================
// tb_nn_core_q12.v — nn_core_q12 神经网络推理核心仿真
// 验证特征归一化、第一层线性、tanh 激活、输出层、OOD 遮罩
// ============================================================================
module tb_nn_core_q12;
    localparam CLK_HZ = `SYS_CLK_FREQ_HZ;
    localparam CLK_NS = 1000000000 / CLK_HZ;

    reg clk = 1'b0;
    reg rst_n = 1'b0;
    reg enable = 1'b0;
    reg start = 1'b0;
    reg [255:0] features_q12 = 256'd0;
    wire busy, done;
    wire signed [31:0] delta_q12, future_error_q12;
    wire [7:0] ood_mask;
    always #(CLK_NS/2) clk = ~clk;

    nn_core_q12 dut(.clk(clk), .rst_n(rst_n), .enable(enable), .start(start),
        .features_q12(features_q12), .busy(busy), .done(done),
        .delta_q12(delta_q12), .future_error_q12(future_error_q12),
        .ood_mask(ood_mask));

    integer errors = 0;
    integer i;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    initial begin
        repeat(20) @(negedge clk);
        rst_n = 1'b1;
        enable = 1'b1;
        repeat(10) @(negedge clk);

        $display("[场景 1] 开始推理");
        for(i = 0; i < 8; i = i + 1) begin
            features_q12[i*32+:32] = $signed(32'd100 * i);
        end
        start = 1; @(negedge clk); start = 0;

        $display("[场景 2] 等待推理完成");
        wait(done);
        check(!busy && done, "inference complete");
        check(ood_mask == 0 || ood_mask != 8'hFF, "OOD mask valid");

        $display("[场景 3] disable 清零");
        enable = 1'b0;
        repeat(10) @(negedge clk);
        check(!busy && !done, "disable clears");

        if (errors == 0) $display("\nPASS: nn_core_q12 基本通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #5000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule