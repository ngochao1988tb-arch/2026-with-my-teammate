`timescale 1ns/1ps
`include "control_config.vh"
// ============================================================================
// tb_run_notch.v — run_notch 三级陷波滤波器仿真
// 验证 IIR 递推、系数加载、输出饱和、disable 归零
// ============================================================================
module tb_run_notch;
    reg clk = 1'b0;
    reg rst_n = 1'b0;
    reg tick = 1'b0;
    reg enable = 1'b0;
    reg signed [31:0] u = 32'd0;
    wire signed [31:0] y;
    wire done;
    always #10 clk = ~clk;  // 50 MHz

    run_notch dut(.clk(clk), .rst_n(rst_n), .tick(tick), .enable(enable), .u(u), .y(y), .done(done));

    integer errors = 0;
    integer i, cycles;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    task notch_sample(input signed [31:0] val);
        begin
            u = val;
            tick = 1; @(negedge clk); tick = 0;
            cycles = 0;
            while(!done && cycles < 200) begin @(negedge clk); cycles = cycles + 1; end
            if(!done) $fatal(1, "notch result timeout");
            @(negedge clk);
        end
    endtask

    initial begin
        repeat(20) @(negedge clk);
        rst_n = 1'b1;
        enable = 1'b1;
        repeat(10) @(negedge clk);

        $display("[场景 1] 零输入零输出");
        notch_sample(0);
        check(y == 0, "zero input -> zero output");

        $display("[场景 2] 阶跃响应收敛");
        for(i = 0; i < 50; i = i + 1) notch_sample(32'd100000);
        check(y >= 0 || y <= 100000, "notch bounded");

        $display("[场景 3] 负值阶跃");
        for(i = 0; i < 10; i = i + 1) notch_sample(-32'sd100000);

        $display("[场景 4] disable 清零");
        enable = 1'b0;
        repeat(5) @(negedge clk);
        check(y == 0 && !done, "disable zeros output");

        if (errors == 0) $display("\nPASS: run_notch 基本通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #10000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule