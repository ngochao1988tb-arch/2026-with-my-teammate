`timescale 1ns/1ps
// ============================================================================
// tb_hmi_record_ram.v — hmi_record_ram 双端口记录 RAM 仿真
// 验证 1024x672 双端口读写
// ============================================================================
module tb_hmi_record_ram;
    localparam DEPTH = 1024;
    localparam AW = $clog2(DEPTH);
    localparam WIDTH = 672;

    reg clk = 1'b0;
    reg write_enable = 1'b0;
    reg [AW-1:0] write_address = 0;
    reg [AW-1:0] read_address = 0;
    reg [WIDTH-1:0] write_data = 0;
    wire [WIDTH-1:0] read_data;
    always #10 clk = ~clk;

    hmi_record_ram #(.DEPTH(DEPTH)) dut
        (.clk(clk), .write_enable(write_enable),
         .write_address(write_address), .read_address(read_address),
         .write_data(write_data), .read_data(read_data));

    integer errors = 0;
    integer i;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    initial begin
        repeat(20) @(negedge clk);

        $display("[场景 1] 写入并回读地址 0");
        write_enable = 1'b1;
        write_address = 0;
        write_data = {672{1'b1}};
        read_address = 0;
        @(negedge clk);
        write_enable = 1'b0;
        repeat(2) @(negedge clk);
        check(read_data === {672{1'b1}}, "write all-ones readback");

        $display("[场景 2] 地址 1 写入 0");
        write_enable = 1'b1;
        write_address = 1;
        write_data = 0;
        read_address = 1;
        @(negedge clk);
        write_enable = 1'b0;
        repeat(2) @(negedge clk);
        check(read_data == 0, "address 1 all-zeros");

        $display("[场景 3] 地址 0 仍为 all-ones");
        read_address = 0;
        repeat(2) @(negedge clk);
        check(read_data === {672{1'b1}}, "addr0 still holds ones");

        $display("[场景 4] 环形写入测试");
        for(i = 0; i < 10; i = i + 1) begin
            write_enable = 1'b1;
            write_address = i;
            write_data = i;
            @(negedge clk);
        end
        write_enable = 1'b0;
        for(i = 0; i < 10; i = i + 1) begin
            read_address = i;
            repeat(2) @(negedge clk);
            check(read_data == i, "sequential write/read");
        end

        if (errors == 0) $display("\nPASS: hmi_record_ram 全部通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #10000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule