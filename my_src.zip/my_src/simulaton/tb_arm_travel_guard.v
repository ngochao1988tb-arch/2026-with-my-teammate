`timescale 1ns/1ps
`include "control_config.vh"
// ============================================================================
// tb_arm_travel_guard.v — arm_travel_guard 行程保护差分封套仿真
// 验证正/负限速封套、lookahead、无效速度时加 margin
// ============================================================================
module tb_arm_travel_guard;
    reg clk = 1'b0;
    reg rst_n = 1'b0;
    reg signed [31:0] alpha_meas = 32'd0;
    reg signed [31:0] alpha_c = 32'd0;
    reg signed [31:0] arm_reference_q16 = 32'd0;
    reg signed [31:0] arm_velocity = 32'd0;
    reg velocity_valid = 1'b0;
    wire signed [31:0] positive_limit_q8;
    wire signed [31:0] negative_limit_q8;
    always #10 clk = ~clk;

    arm_travel_guard dut
        (.clk(clk), .rst_n(rst_n),
         .alpha_meas(alpha_meas), .alpha_c(alpha_c), .arm_reference_q16(arm_reference_q16),
         .arm_velocity(arm_velocity), .velocity_valid(velocity_valid),
         .positive_limit_q8(positive_limit_q8), .negative_limit_q8(negative_limit_q8));

    integer errors = 0;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    initial begin
        repeat(20) @(negedge clk);
        rst_n = 1'b1;
        repeat(10) @(negedge clk);

        $display("[场景 1] 中心位置正负限速对称");
        alpha_meas = 32'd0;
        alpha_c = 32'd0;
        velocity_valid = 1'b1;
        arm_velocity = 32'd0;
        repeat(5) @(negedge clk);
        check(positive_limit_q8 > 0, "positive limit set");
        check(negative_limit_q8 < 0, "negative limit set");
        check(positive_limit_q8 == -negative_limit_q8, "symmetric at center");

        $display("[场景 2] 靠近正向硬限，正限速应减小");
        alpha_meas = 32'h00300000;  // ~3 rad
        alpha_c = 32'h00300000;
        repeat(5) @(negedge clk);
        check(positive_limit_q8 < 256*`CFG_CONTROL_MAX_FREQUENCY_HZ, "positive limit reduced near boundary");

        $display("[场景 3] 负向速度靠近负边界");
        alpha_meas = -32'sh00300000;
        alpha_c = -32'sh00300000;
        arm_velocity = -32'sd500000;
        repeat(5) @(negedge clk);
        check(negative_limit_q8 > -256*`CFG_CONTROL_MAX_FREQUENCY_HZ, "negative limit near boundary");

        $display("[场景 4] velocity_valid=0 加 margin");
        velocity_valid = 1'b0;
        repeat(5) @(negedge clk);
        check(positive_limit_q8 < 256*50, "invalid velocity reduces positive limit conservatively");

        if (errors == 0) $display("\nPASS: arm_travel_guard 基本通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #5000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule