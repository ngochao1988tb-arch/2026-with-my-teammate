`timescale 1ns/1ps
// ============================================================================
// tb_voice_command_assembler.v — voice_command_assembler 仿真
// 验证命令词到目标/动作的解码
// ============================================================================
module tb_voice_command_assembler;
    reg clk = 1'b0;
    reg rst_n = 1'b0;
    reg command_word_valid = 1'b0;
    reg [7:0] command_word_id = 8'd0;
    wire target_changed;
    wire [1:0] target_mask;
    wire target_timeout;
    wire command_valid;
    wire [1:0] command_target_mask;
    wire [3:0] command_action;
    wire [7:0] command_id;
    wire [7:0] command_angle;
    wire command_right;
    wire command_rejected;
    wire [1:0] reject_reason;
    always #10 clk = ~clk;

    voice_command_assembler dut
        (.clk(clk), .rst_n(rst_n),
         .command_word_valid(command_word_valid), .command_word_id(command_word_id),
         .target_changed(target_changed), .target_mask(target_mask),
         .target_timeout(target_timeout), .command_valid(command_valid),
         .command_target_mask(command_target_mask), .command_action(command_action),
         .command_id(command_id), .command_angle(command_angle),
         .command_right(command_right), .command_rejected(command_rejected),
         .reject_reason(reject_reason));

    integer errors = 0;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    initial begin
        repeat(20) @(negedge clk);
        rst_n = 1'b1;
        repeat(10) @(negedge clk);

        $display("[场景 1] 发送目标选择: B0=主摆");
        command_word_valid = 1'b1;
        command_word_id = 8'hB0;
        @(negedge clk); command_word_valid = 1'b0;
        repeat(10) @(negedge clk);
        check(target_changed && target_mask == 2'b01, "target main selected");

        $display("[场景 2] 起摆命令 (0x40)");
        command_word_valid = 1'b1;
        command_word_id = 8'h40;
        @(negedge clk); command_word_valid = 1'b0;
        repeat(10) @(negedge clk);
        check(command_valid && command_action == 4'd1, "swing up action decoded");

        $display("[场景 3] 急停命令");
        command_word_valid = 1'b1;
        command_word_id = 8'h42;
        @(negedge clk); command_word_valid = 1'b0;
        repeat(10) @(negedge clk);
        check(!command_rejected, "estop accepted");

        $display("[场景 4] 未选择目标时的动作应被拒绝");
        // 复位后 target 未知，新的动作不应触发
        command_word_valid = 1'b1;
        command_word_id = 8'h40;
        @(negedge clk); command_word_valid = 1'b0;
        repeat(10) @(negedge clk);

        if (errors == 0) $display("\nPASS: voice_command_assembler 基本通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #10000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule