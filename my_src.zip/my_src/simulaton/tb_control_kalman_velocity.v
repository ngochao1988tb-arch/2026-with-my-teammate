`timescale 1ns/1ps
`include "system_params.vh"
// ============================================================================
// tb_control_kalman_velocity.v — control_kalman_velocity 稳态 Kalman 观测器仿真
// 验证预测-修正环、模域位置处理、增益收敛、clear
// ============================================================================
module tb_control_kalman_velocity;
    localparam CLK_HZ = `SYS_CLK_FREQ_HZ;
    localparam CLK_NS = 1000000000 / CLK_HZ;

    reg clk_50m = 1'b0;
    reg rst_n = 1'b0;
    reg clear_filter = 1'b0;
    reg sample_tick = 1'b0;
    reg [11:0] theta_position = 12'd2048;
    reg [15:0] alpha_position = 16'd10000;
    wire signed [15:0] theta_velocity;
    wire signed [19:0] alpha_velocity_q4;
    wire velocity_valid;
    always #(CLK_NS/2) clk_50m = ~clk_50m;

    control_kalman_velocity dut(.clk_50m(clk_50m), .rst_n(rst_n),
        .clear_filter(clear_filter), .sample_tick(sample_tick),
        .theta_position(theta_position), .alpha_position(alpha_position),
        .theta_velocity(theta_velocity), .alpha_velocity_q4(alpha_velocity_q4),
        .velocity_valid(velocity_valid));

    integer errors = 0;
    integer i;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    initial begin
        repeat(20) @(negedge clk_50m);
        rst_n = 1'b1;
        repeat(10) @(negedge clk_50m);

        $display("[场景 1] 初始未初始化");
        check(!velocity_valid, "not valid initially");

        $display("[场景 2] 模拟恒定速度运动");
        for(i = 0; i < 30; i = i + 1) begin
            theta_position = theta_position + 12'd5;
            alpha_position = alpha_position + 16'd10;
            sample_tick = 1; @(negedge clk_50m); sample_tick = 0;
            repeat(9) @(negedge clk_50m);
        end
        repeat(30) @(negedge clk_50m);
        check(velocity_valid, "velocity_valid asserted");
        check(theta_velocity > 0, "positive theta velocity estimated");

        $display("[场景 3] 停止运动，速度收敛到零");
        for(i = 0; i < 30; i = i + 1) begin
            sample_tick = 1; @(negedge clk_50m); sample_tick = 0;
            repeat(9) @(negedge clk_50m);
        end
        repeat(30) @(negedge clk_50m);
        check(theta_velocity < 5 && theta_velocity > -5, "velocity converges near zero");

        if (errors == 0) $display("\nPASS: control_kalman_velocity 基本通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #10000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule