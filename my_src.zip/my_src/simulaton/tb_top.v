`timescale 1ns/1ps
`include "control_config.vh"
`include "lcd_config.vh"
// ============================================================================
// tb_top.v — top 顶层集成仿真
// 精简连接测试：时钟、复位、按键、LCD
// ============================================================================
module tb_top;
    localparam CLK_NS = 20;
    localparam LCD_DW = 16;

    reg clk_50m = 1'b0;
    reg rst_n = 1'b0;
    reg [3:0] key_sw = 4'hF;
    wire pul_out, dir_out, ena_out;
    reg motor_rx = 1'b1;
    wire motor_tx;
    wire telemetry_tx;
    wire adc_clk, adc_oe_n;
    reg [9:0] adc_data_in = 10'd466;
    reg hmi_rx = 1'b1;
    wire hmi_tx;
    reg screen_rx = 1'b1;
    wire screen_tx;
    reg slave_rx = 1'b1;
    wire slave_tx;
    reg voice_rx = 1'b1;
    wire voice_tx;
    wire lcd_cs_n, lcd_wr_n, lcd_rd_n, lcd_rs, lcd_reset_n;
    wire [LCD_DW-1:0] lcd_data;
    wire lcd_bl;
    reg touch_miso = 1'b0, touch_pen_n = 1'b1;
    wire touch_cs_n, touch_clk, touch_mosi;
    always #(CLK_NS/2) clk_50m = ~clk_50m;

    top #(.LCD_DW(LCD_DW), .ENABLE_TELEMETRY(0), .PC_DEBUG_EN(0)) dut
        (.clk_50m(clk_50m), .rst_n(rst_n), .key_sw(key_sw),
         .pul_out(pul_out), .dir_out(dir_out), .ena_out(ena_out),
         .motor_rx(motor_rx), .motor_tx(motor_tx),
         .telemetry_tx(telemetry_tx),
         .adc_clk(adc_clk), .adc_oe_n(adc_oe_n), .adc_data_in(adc_data_in),
         .hmi_rx(hmi_rx), .hmi_tx(hmi_tx),
         .screen_rx(screen_rx), .screen_tx(screen_tx),
         .slave_rx(slave_rx), .slave_tx(slave_tx),
         .voice_rx(voice_rx), .voice_tx(voice_tx),
         .lcd_cs_n(lcd_cs_n), .lcd_wr_n(lcd_wr_n), .lcd_rd_n(lcd_rd_n),
         .lcd_rs(lcd_rs), .lcd_reset_n(lcd_reset_n), .lcd_data(lcd_data),
         .lcd_bl(lcd_bl), .touch_miso(touch_miso), .touch_pen_n(touch_pen_n),
         .touch_cs_n(touch_cs_n), .touch_clk(touch_clk), .touch_mosi(touch_mosi));

    integer errors = 0;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    initial begin
        repeat(50) @(posedge clk_50m);
        rst_n = 1'b1;
        repeat(200) @(posedge clk_50m);

        $display("[场景 1] 复位后 clk_sys PLL 产生 25MHz");
        // 验证 ADC 时钟产生
        check(adc_clk !== 1'bz, "adc_clk driven after reset");

        $display("[场景 2] 所有输出已赋值");
        check(pul_out !== 1'bz && ena_out !== 1'bz, "motor outputs driven");
        check(lcd_cs_n !== 1'bz && lcd_reset_n !== 1'bz, "LCD signals driven");

        $display("[场景 3] 运行时无 X 态");
        repeat(5000) @(posedge clk_50m);

        if (errors == 0) $display("\nPASS: top 基本通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #500000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule