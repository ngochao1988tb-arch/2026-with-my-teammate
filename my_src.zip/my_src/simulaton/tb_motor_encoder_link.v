`timescale 1ns/1ps
`include "control_config.vh"
// ============================================================================
// tb_motor_encoder_link.v — motor_encoder_link 电机编码器串口链路仿真
// 精简验证轮询、响应解析、超时处理
// ============================================================================
module tb_motor_encoder_link;
    localparam CLK_HZ = 25000000;
    localparam CLK_NS = 40;
    localparam BAUD = 9600;
    localparam BIT_NS = 1000000000 / BAUD;

    reg clk = 1'b0;
    reg rst_n = 1'b0;
    reg motor_rx = 1'b1;
    wire motor_tx;
    reg clear_request = 1'b0;
    wire [15:0] encoder_raw;
    wire encoder_valid;
    wire encoder_update;
    wire clear_done;
    wire [7:0] clear_status;
    wire [31:0] timeout_count;
    always #(CLK_NS/2) clk = ~clk;

    motor_encoder_link #(.CLK_HZ(CLK_HZ), .BAUD(BAUD), .POLL_MS(2), .TIMEOUT_MS(10), .BYTE_TIMEOUT_MS(5))
        dut(.clk(clk), .rst_n(rst_n), .motor_rx(motor_rx), .motor_tx(motor_tx),
            .clear_request(clear_request), .encoder_raw(encoder_raw), .encoder_valid(encoder_valid),
            .encoder_update(encoder_update), .clear_done(clear_done), .clear_status(clear_status),
            .timeout_count(timeout_count));

    integer errors = 0;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    task send_byte(input [7:0] byte);
        integer i;
        begin
            motor_rx = 1'b0;
            #(BIT_NS);
            for(i = 0; i < 8; i = i + 1) begin
                motor_rx = byte[i];
                #(BIT_NS);
            end
            motor_rx = 1'b1;
            #(BIT_NS);
        end
    endtask

    initial begin
        repeat(20) @(posedge clk);
        rst_n = 1'b1;
        repeat(20) @(posedge clk);

        $display("[场景 1] 等待模块启动轮询");
        repeat(CLK_HZ / 1000 * 5) @(posedge clk);  // 等 5 ms
        // 此时应该有发送请求发出

        $display("[场景 2] 模拟编码器应答: 地址 0x01 + 数据 0x12 0x34 + 校验 0x6b");
        // 模块发送 0x01 0x31 0x6b 后等待回答
        // 应答格式 (假设 8 字节: 地址 数据H 数据L 校验)
        repeat(CLK_HZ / 1000 * 8) @(posedge clk);
        send_byte(8'h01);  // 地址
        send_byte(8'h12);  // 高字节
        send_byte(8'h34);  // 低字节
        send_byte(8'h6b);  // 校验
        repeat(5000) @(posedge clk);
        check(encoder_valid, "encoder valid after response");

        $display("[场景 3] 超时计数验证");
        check(timeout_count < 10, "timeout_count bounded");

        if (errors == 0) $display("\nPASS: motor_encoder_link 基本通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #500000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule