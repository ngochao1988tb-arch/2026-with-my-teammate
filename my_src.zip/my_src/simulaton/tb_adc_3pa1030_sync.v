`timescale 1ns/1ps
`include "system_params.vh"
// ============================================================================
// tb_adc_3pa1030_sync.v — adc_3pa1030_sync ADC 同步采集仿真
// 验证 12.5MHz 时钟生成、总线锁存、坏点抑制、中值滤波
// ============================================================================
module tb_adc_3pa1030_sync;
    localparam CLK_HZ = `SYS_CLK_FREQ_HZ;
    localparam CLK_NS = 1000000000 / CLK_HZ;

    reg clk_50m = 1'b0;
    reg rst_n = 1'b0;
    wire adc_clk, adc_oe_n, adc_stby_n;
    reg [9:0] adc_data_in = 10'd512;
    wire adc_valid_3ms;
    wire [11:0] theta_raw_12b;
    wire signed [15:0] theta_dot_raw;
    always #(CLK_NS/2) clk_50m = ~clk_50m;

    adc_3pa1030_sync dut(.clk_50m(clk_50m), .rst_n(rst_n),
        .adc_clk(adc_clk), .adc_oe_n(adc_oe_n), .adc_stby_n(adc_stby_n),
        .adc_data_in(adc_data_in),
        .adc_valid_3ms(adc_valid_3ms), .theta_raw_12b(theta_raw_12b), .theta_dot_raw(theta_dot_raw));

    integer errors = 0;
    integer i;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    initial begin
        repeat(50) @(posedge clk_50m);
        rst_n = 1'b1;
        repeat(100) @(posedge clk_50m);

        $display("[场景 1] ADC 时钟 12.5MHz 产生");
        check(adc_oe_n === 1'b0, "adc_oe_n low");
        check(adc_stby_n === 1'b0, "adc_stby_n low (active)");

        $display("[场景 2] 等待 adc_valid_3ms 脉冲");
        repeat(CLK_HZ / 10000 + 200) @(posedge clk_50m);  // wait for first frame
        check(theta_raw_12b != 12'h000, "theta data present");

        $display("[场景 3] 改变 ADC 输入验证跟踪");
        adc_data_in = 10'd600;
        repeat(CLK_HZ / 5000) @(posedge clk_50m);
        check(theta_raw_12b > 12'd0, "tracking changing input");

        if (errors == 0) $display("\nPASS: adc_3pa1030_sync 基本通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #50000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule