`timescale 1ns/1ps
// ============================================================================
// tb_uart_tx.v — uart_tx 通用串口发送模块仿真
// ============================================================================
module tb_uart_tx;
    localparam CLK_HZ = 50000000;
    localparam BAUD = 115200;
    localparam CLK_NS = 20;

    reg clk = 1'b0;
    reg rst_n = 1'b0;
    reg start = 1'b0;
    reg [7:0] data = 8'd0;
    wire tx;
    wire busy;
    wire done;
    always #(CLK_NS/2) clk = ~clk;

    uart_tx #(.CLK_HZ(CLK_HZ), .BAUD(BAUD)) dut
        (.clk(clk), .rst_n(rst_n), .start(start), .data(data), .tx(tx), .busy(busy), .done(done));

    integer errors = 0;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    task do_tx(input [7:0] d);
        begin
            @(negedge clk);
            data = d;
            start = 1'b1;
            @(negedge clk);
            start = 1'b0;
        end
    endtask

    initial begin
        repeat(20) @(posedge clk);
        rst_n = 1'b1;
        repeat(20) @(posedge clk);

        $display("[场景 1] 空闲验证");
        check(tx === 1'b1 && !busy && !done, "idle state");

        $display("[场景 2] 发送 0xA5");
        do_tx(8'hA5);
        @(negedge clk);
        check(busy, "busy asserted");
        wait(done);
        check(!busy && done, "done after transmission");

        $display("[场景 3] 背靠背发送");
        do_tx(8'h55);
        wait(!busy);
        repeat(10) @(negedge clk);
        do_tx(8'hAA);
        wait(!busy);
        check(!busy, "back-to-back complete");

        $display("[场景 4] done 单周期脉冲");
        do_tx(8'h12);
        wait(done);
        @(posedge clk);
        check(!done, "done single-cycle");

        if (errors == 0) $display("\nPASS: uart_tx 全部通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #100000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule