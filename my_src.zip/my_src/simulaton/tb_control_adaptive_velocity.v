`timescale 1ns/1ps
`include "system_params.vh"
// ============================================================================
// tb_control_adaptive_velocity.v — control_adaptive_velocity 自适应速度估计仿真
// 验证二阶 IIR 滤波、慢速/快速自适应切换、Q16 分数状态
// ============================================================================
module tb_control_adaptive_velocity;
    localparam CLK_HZ = `SYS_CLK_FREQ_HZ;
    localparam CLK_NS = 1000000000 / CLK_HZ;

    reg clk_50m = 1'b0;
    reg rst_n = 1'b0;
    reg clear_filter = 1'b0;
    reg sample_tick = 1'b0;
    reg [11:0] theta_position = 12'd2048;
    reg [15:0] alpha_position = 16'd10000;
    wire signed [15:0] theta_velocity;
    wire signed [19:0] alpha_velocity_q4;
    wire velocity_valid;
    always #(CLK_NS/2) clk_50m = ~clk_50m;

    control_adaptive_velocity dut(.clk_50m(clk_50m), .rst_n(rst_n),
        .clear_filter(clear_filter), .sample_tick(sample_tick),
        .theta_position(theta_position), .alpha_position(alpha_position),
        .theta_velocity(theta_velocity), .alpha_velocity_q4(alpha_velocity_q4),
        .velocity_valid(velocity_valid));

    integer errors = 0;
    integer i;
    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    initial begin
        repeat(20) @(negedge clk_50m);
        rst_n = 1'b1;
        repeat(10) @(negedge clk_50m);

        $display("[场景 1] 初始无运动，速度=0");
        sample_tick = 1; @(negedge clk_50m); sample_tick = 0;
        repeat(50) @(negedge clk_50m);
        check(theta_velocity == 0 && alpha_velocity_q4 == 0, "initial zero velocity");

        $display("[场景 2] 模拟运动: theta_position 递增");
        for(i = 0; i < 20; i = i + 1) begin
            theta_position = theta_position + 12'd10;
            alpha_position = alpha_position + 16'd50;
            sample_tick = 1; @(negedge clk_50m); sample_tick = 0;
            repeat(9) @(negedge clk_50m);
        end
        repeat(30) @(negedge clk_50m);
        check(velocity_valid, "velocity valid after convergence");
        check(theta_velocity > 0, "positive theta velocity");

        $display("[场景 3] clear_filter 复位");
        clear_filter = 1'b1; @(negedge clk_50m); clear_filter = 1'b0;
        repeat(20) @(negedge clk_50m);
        check(!velocity_valid, "clear resets valid");

        if (errors == 0) $display("\nPASS: control_adaptive_velocity 基本通过");
        else $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin #10000000; $fatal(1, "FAIL: simulation timeout"); end
endmodule