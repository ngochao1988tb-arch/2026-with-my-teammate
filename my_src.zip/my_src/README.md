# J280 旋转倒立摆控制系统（双 FPGA 主从架构）

基于 **高云 GW2A-55C** (GW2A-LV55PG484C8/I7) FPGA 的旋转倒立摆实时控制系统。系统由两块 FPGA 板协同工作：**主控板**（`j280_balance_master`）负责全部控制律、人机交互（串口屏 + 本地触摸屏 + RISC-V 软核）与语音交互；**从控板**（`j280_balance_slave`）负责 LQR 平衡、起摆、电机驱动与神经网络安全滤波的执行。

## 硬件平台

| 项目 | 说明 |
|------|------|
| FPGA | 高云 GW2A-LV55PG484C8/I7（GW2A-55C，两片） |
| 开发环境 | Gowin IDE（工程 `.gprj` 已随源码提供） |
| 主时钟 | 板载 50 MHz 晶振（M19），内部二分频为 **25 MHz 系统时钟** |
| 摆角传感器 | 3PEAK 3PA1030 10-bit 并口 ADC（12.5 MHz 采样时钟） |
| 摆杆电机 | TB6612FNG 双通道并联（XH1 / XH2），10 kHz PWM |
| 横臂电机 | 步进电机（STP/DIR，主控板） |
| 编码器 | 正交编码器（4 倍频解码） |
| 屏幕 | ST7789（16-bit 8080 并口，320x240 横屏，主控板本地触摸）|
| 串口屏 | TJC（主控板，与上位机共用命令集）|
| 语音模块 | CI1302（主控板） |
| 辅助 MCU | PicoRV32 RISC-V 软核（主控板，本地 HMI）|

## 系统架构

```
                        ┌─────────────────────────────────────────────┐
                        │              主控板  project_01             │
                        │  lqr_system（LQR_sine_move 内核）           │
                        │   │ 起摆 swingup_core ├ LQR lqr_core        │
                        │   │ RUN 参考 run_target ├ 陷波 run_notch    │
                        │   │ 行程保护 arm_travel_guard               │
                        │  rv32_soc（PicoRV32 + ST7789 + HR2046 触摸）│
                        │  hmi_rx/hmi_tx/hmi_control（上位机/串口屏） │
                        │  voice_*（CI1302 语音链路与双摆协调）       │
                        │  slave_link（UART v2 从板链路）             │
                        └───────┬──────────────────────────┬─────────┘
                                │ UART v2 (V8/V9 ⭢ W7/W8) │
                                ▼                          ▼
               ┌─────────────────────────────┐   ┌─────────────────────────────┐
               │   从控板  j280_lqr_hardware  │   │  上位机 / TJC串口屏 / 语音   │
               │  j280_lqr_top               │   │  CH340N(UART) | TJC | CI1302 │
               │  lqr_controller（5级流水线）│   └─────────────────────────────┘
               │  swingup_energy_controller  │
               │  motor_tb6612（A/B 并联）   │
               │  nn_predictor_trial（NN 安全│
               │    滤波，Q12 定点推理）      │
               │  uart_remote / slave_hmi    │
               └─────────────────────────────┘
```

- **主控板**：控制律全在 `lqr_system` 内，对外提供移动/轨迹/波形/语音命令解析与四路串口 + 本地触摸界面；通过 `slave_link` 以 UART v2 协议驱动从板。
- **从控板**：独立执行平衡/起摆/急停，内置神经网络（Q12 定点）安全滤波，对主控板命令做最终的门控与仲裁。

## 目录结构

```
my_src/
├── code/
│   ├── j280_balance_master/          # 主控板工程
│   │   ├── project_01.gprj           # Gowin 工程文件
│   │   ├── build.tcl / build.bat     # 命令行综合脚本
│   │   ├── src/                      # RTL 源码 + 约束（.cst/.sdc）
│   │   │   ├── top.v                 # 集成顶层
│   │   │   ├── lqr_system.v          # 控制内核集成
│   │   │   ├── lqr_core.v            # 多速率 LQR 观测器
│   │   │   ├── swingup_core.v        # 起摆能量泵
│   │   │   ├── rv32/                 # PicoRV32 软核
│   │   │   └── ...                   # 其余外设模块
│   │   ├── sw/                       # RISC-V 固件（C + 汇编）
│   │   ├── sim/                      # 既有仿真 testbench
│   │   └── tools/                    # 固件/头文件生成脚本
│   ├── j280_balance_slave/           # 从控板工程
│   │   ├── j280_lqr_hardware.gprj    # Gowin 工程文件
│   │   ├── src/                      # RTL 源码 + system_params.vh
│   │   ├── cst/                      # 管脚 + 时序约束
│   │   └── verification/             # 既有仿真 testbench（.sv）
│   └── ...
├── simulaton/                        # 补充生成的仿真 testbench（54 个）
│   └── run_all_sim.ps1               # 批量仿真运行脚本（Icarus Verilog）
└── 设计文档（本文档同目录）
```

## 功能清单

### 主控板
- **直立平衡**：多速率 LQR（预测 + 扩张状态观测器 + 有界回零偏置 + 正弦前馈），三级串联陷波（8.3 / 12.5 / 9.77 Hz）
- **起摆**：非线性能量泵 + 单次助推 + approach 局部反馈 + 捕获量化检查
- **运动控制**：RUN 目标参考（速度分档/倍速/波形/手写轨迹）
- **保护**：行程封套、跌倒检测、饱和监控、数值故障、编码器/ADC 超时
- **人机交互**：上位机（CH340N）、TJC 串口屏（同一命令集）、本地触摸屏（RISC-V 软核）
- **语音**：CI1302 命令词识别、播报、双摆协调
- **遥测**：82 字节二进制 v3 遥测（参数开关，默认关闭）

### 从控板
- **直立平衡**：25 MHz 5 级流水线 LQR（5 周期 / 200 ns 极速计算）
- **起摆**：能量整形控制 + cos 查表 + 峰值触反转
- **速度估计**：稳态 Kalman 观测器（独立 θ / α 通道）
- **神经网络安全滤波**：Q12 定点 MLP 推理，OOD 检测，模式切换（监视/介入），trip 闭锁
- **驾驶保护**：硬件安全使能切断、死区补偿、行程/超速故障
- **遥测**：Debug 模式 32 字节帧 / Legacy 模式 10 字节帧

## 协议速览

### 主从板 UART v2（115200 8N1）
- 命令：`A5 5A 01 OP [DATA...] XOR`（OP20 起摆 / OP20-02 急停 / OP30 绝对目标 / OP31 保持 / OP60 遥测查询）
- 应答：`5A A5 01 OP RESULT BANK[0..31] XOR`

### 上位机/串口屏（115200 8N1）
- 命令帧：`55 AA 20 CMD SEQ[4] ARG[4] SPEED[4] 0D 0A`（18 字节）
- 快照帧：ASCII `字段名=值` 序列（33 字段 + `ghb` 结束标记）

### 语音 CI1302（115200 8N1）
- 命令帧：`AA 55 00 ID`（目标选择 0xB0/B1/B2，动作 0x40 起摆 / 0x42 急停 / 0x43 复位等）

## 构建方法

### 主控板（Gowin IDE）
```powershell
# 直接打开工程综合，或命令行：
cd code\j280_balance_master
.\build.bat        # 或 gowin_sh build.tcl
```
固件（RISC-V）：
```powershell
cd code\j280_balance_master\sw
.\build_hmi.ps1    # 需要 zig + python，生成 fw.bin → imem.hex/dmem.hex
```

### 从控板（Gowin IDE）
直接打开 `code\j280_balance_slave\j280_lqr_hardware.gprj` 综合即可。

### 仿真（Icarus Verilog）
```powershell
cd simulaton
.\run_all_sim.ps1   # 批量编译 + 运行 54 个 testbench
```

## 说明

- 所有控制律定点运算按 Q16 / Q20 / Q12 表示，综合时由 `control_config.vh` / `system_params.vh` 展开，不含运行时浮点。
- 本工程约束文件 `project.cst` 需保持纯 ASCII（工具以 ANSI/GBK 解析，UTF-8 中文注释会导致 CT2000 语法错误）。
- 与外部接口相关的关键管脚定义见 `src/project.cst`（主控）与 `cst/j280_pins.cst`（从控）。