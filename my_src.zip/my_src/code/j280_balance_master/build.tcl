cd [file dirname [file normalize [info script]]]
open_project project_01.gprj
set_option -output_base_name project_01
set_option -top_module top
set_option -include_path {src}
# route_option 2 is required: the alpha_meas -> arm_capture_velocity/product
# constant multiply chain has almost no slack at 50 MHz.
set_option -place_option 2
set_option -route_option 2
set_option -replicate_resources 1
# SW4 sits on the SSPI dedicated pin T20; without this it cannot be a button.
set_option -use_sspi_as_gpio 1
run syn
run pnr
run close
