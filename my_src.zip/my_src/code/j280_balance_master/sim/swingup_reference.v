`timescale 1ns/1ps
`include "control_config.vh"
// Nonlinear energy pumping for a velocity-command motor. All runtime arithmetic
// is integer. The linear LQR observer must not be used at hanging-down angles.
module swingup_reference #(
    parameter THETA_INVERT=`CFG_HARDWARE_THETA_INVERT,
    parameter MAX_FREQ_HZ=`CFG_CONTROL_MAX_FREQUENCY_HZ,
    parameter UPDATE_CLOCKS=5
)(
    input clk, input rst_n, input sample_valid, input enable,
    input [12:0] ad_value,
    input signed [31:0] alpha_meas, alpha_c,
    input signed [31:0] arm_reference_q16,
    output reg signed [31:0] frequency_q8,
    output signed [31:0] theta_dot_q16,
    output signed [31:0] u_q16,
    output velocity_valid,
    output capture_safe,
    input approach_valid,
    input signed [31:0] approach_frequency_q8, approach_arm_velocity,
    output reg approach_active,
    input restart,
    input signed [31:0] restart_frequency_q8,
    output reg recovery_active
);
    localparam integer PI_COUNTS=`CFG_ADC_THETA_COUNTS_PER_PI;
    localparam integer VELOCITY_SCALE=$rtoi(3.141592653589793*256.0*1000000.0/PI_COUNTS/`CFG_CONTROL_PERIOD_US+0.5);
    localparam integer SOFT_ARM=$rtoi(`CFG_SWINGUP_SOFT_ARM_DEG/180.0*3.141592653589793*65536.0);
    localparam integer LIMIT_HZ=(`CFG_SWINGUP_MAX_FREQUENCY_HZ<MAX_FREQ_HZ) ? `CFG_SWINGUP_MAX_FREQUENCY_HZ : MAX_FREQ_HZ;
    localparam integer LIMIT_Q8=LIMIT_HZ*256;
    localparam integer RESTART_LIMIT_Q8=MAX_FREQ_HZ*256;
    localparam integer STEP_Q8=(`CFG_SWINGUP_ACCEL_HZ_PER_S*64'sd256*`CFG_CONTROL_PERIOD_US)/1000000;
    localparam integer RECOVERY_STEP_Q8=(`CFG_SWINGUP_RECOVERY_ACCEL_HZ_PER_S*64'sd256*`CFG_CONTROL_PERIOD_US)/1000000;
    localparam integer KICK_FRAMES=(`CFG_SWINGUP_KICK_US+`CFG_CONTROL_PERIOD_US-1)/`CFG_CONTROL_PERIOD_US;
    localparam integer ENDPOINT_KICK_FRAMES=(`CFG_SWINGUP_ENDPOINT_KICK_US+`CFG_CONTROL_PERIOD_US-1)/`CFG_CONTROL_PERIOD_US;
    localparam integer ENDPOINT_LIMIT_HZ=(`CFG_SWINGUP_ENDPOINT_MAX_FREQUENCY_HZ<LIMIT_HZ) ? `CFG_SWINGUP_ENDPOINT_MAX_FREQUENCY_HZ : LIMIT_HZ;
    localparam integer MAX_VALID_DELTA=$rtoi(`CFG_SWINGUP_MAX_VALID_SPEED_RAD_S*PI_COUNTS*`CFG_CONTROL_PERIOD_US/(3.141592653589793*1000000.0));
    localparam integer RECOVERY_FRAMES=`CFG_SWINGUP_VELOCITY_RECOVERY_FRAMES;
    reg [$clog2(RECOVERY_FRAMES+1)-1:0] good_velocity_pairs;
    reg step_valid, endpoint_trial_started;
    reg [12:0] previous_ad;
    reg velocity_seen, previous_endpoint;
    reg [1:0] endpoint_pair_pipe;
    wire endpoint=`CFG_SWINGUP_ENDPOINT_ESCAPE_ENABLED &&
        (ad_value<`CFG_ADC_RAIL_MIN || ad_value>`CFG_ADC_RAIL_MAX);
    reg signed [15:0] speed_q8;
    reg [31:0] kick_frames;
    reg kick_negative;
    wire signed [15:0] raw_delta=THETA_INVERT ? $signed({3'd0,previous_ad})-$signed({3'd0,ad_value}) :
                                                           $signed({3'd0,ad_value})-$signed({3'd0,previous_ad});
    // Unwrap a full turn at the potentiometer endpoint; do not interpret it as velocity.
    wire signed [15:0] delta_next=(raw_delta>PI_COUNTS) ? raw_delta-2*PI_COUNTS :
                             (raw_delta< -PI_COUNTS) ? raw_delta+2*PI_COUNTS : raw_delta;
    // A dead-zone crossing is not a measured full-turn displacement. Reject
    // discontinuities, including plausible-looking intermediate averaged ADs.
    wire delta_plausible=(raw_delta<=MAX_VALID_DELTA && raw_delta>= -MAX_VALID_DELTA);
    reg signed [15:0] delta;
    reg signed [31:0] instant_speed;
    reg [UPDATE_CLOCKS-1:0] sample_pipe;
    wire signed [31:0] filtered_speed=($signed(speed_q8)*3+instant_speed)>>>2;
    wire signed [15:0] angle_counts=THETA_INVERT ? `CFG_ADC_FIXED_ZERO-$signed({3'd0,ad_value}) :
                                                                $signed({3'd0,ad_value})-`CFG_ADC_FIXED_ZERO;
    localparam signed [31:0] CAPTURE_INSTANT_Q8=$rtoi(`CFG_SWINGUP_CAPTURE_INSTANT_SPEED_RAD_S*256.0);
    localparam signed [31:0] CAPTURE_PROJECTED_COUNTS=$rtoi(`CFG_SWINGUP_CAPTURE_PROJECTED_ANGLE_DEG*PI_COUNTS/180.0);
    wire signed [31:0] projected_counts=$signed(angle_counts)+$signed(delta)*`CFG_SWINGUP_CAPTURE_LOOKAHEAD_FRAMES;
    assign capture_safe=!recovery_active && velocity_valid && step_valid &&
        instant_speed<=CAPTURE_INSTANT_Q8 && instant_speed>=-CAPTURE_INSTANT_Q8 &&
        projected_counts<=CAPTURE_PROJECTED_COUNTS && projected_counts>=-CAPTURE_PROJECTED_COUNTS;
    reg [15:0] abs_angle;
    // cos(k*pi/16), Q10; 11.25 degree bins. Energy is an approximate switching
    // criterion, not a full identified nonlinear model of the real mechanism.
    function signed [15:0] cosine;
        input [15:0] a;
        reg [4:0] k;
        begin
            // Balanced constant comparisons avoid a combinational divider.
            if(a<PI_COUNTS*8/16) begin
                if(a<PI_COUNTS*4/16) begin
                    if(a<PI_COUNTS*2/16) k=(a<PI_COUNTS/16) ? 0 : 1;
                    else k=(a<PI_COUNTS*3/16) ? 2 : 3;
                end else begin
                    if(a<PI_COUNTS*6/16) k=(a<PI_COUNTS*5/16) ? 4 : 5;
                    else k=(a<PI_COUNTS*7/16) ? 6 : 7;
                end
            end else begin
                if(a<PI_COUNTS*12/16) begin
                    if(a<PI_COUNTS*10/16) k=(a<PI_COUNTS*9/16) ? 8 : 9;
                    else k=(a<PI_COUNTS*11/16) ? 10 : 11;
                end else begin
                    if(a<PI_COUNTS*14/16) k=(a<PI_COUNTS*13/16) ? 12 : 13;
                    else k=(a<PI_COUNTS*15/16) ? 14 : (a<PI_COUNTS ? 15 : 16);
                end
            end
            case(k)
                0:cosine=1024; 1:cosine=1004; 2:cosine=946; 3:cosine=851;
                4:cosine=724; 5:cosine=569; 6:cosine=392; 7:cosine=200;
                8:cosine=0; 9:cosine=-200; 10:cosine=-392; 11:cosine=-569;
                12:cosine=-724; 13:cosine=-851; 14:cosine=-946; 15:cosine=-1004;
                default:cosine=-1024;
            endcase
        end
    endfunction
    // sqrt(2*h/b*(1-cos(theta)))*256 for the same Q10 cosine bins.
    // This is equivalent to the former speed_q8^2 energy comparison but
    // avoids a 16x16 combinational square when all DSP blocks are occupied.
    // Regenerate these constants if CFG_SWINGUP_H_OVER_B changes.
    function signed [15:0] energy_speed_limit;
        input signed [15:0] c;
        begin
            case(c)
                16'sd1024:energy_speed_limit=16'sd0;
                16'sd1004:energy_speed_limit=16'sd585;
                16'sd946:energy_speed_limit=16'sd1154;
                16'sd851:energy_speed_limit=16'sd1719;
                16'sd724:energy_speed_limit=16'sd2263;
                16'sd569:energy_speed_limit=16'sd2787;
                16'sd392:energy_speed_limit=16'sd3284;
                16'sd200:energy_speed_limit=16'sd3750;
                16'sd0:energy_speed_limit=16'sd4180;
                -16'sd200:energy_speed_limit=16'sd4570;
                -16'sd392:energy_speed_limit=16'sd4916;
                -16'sd569:energy_speed_limit=16'sd5214;
                -16'sd724:energy_speed_limit=16'sd5462;
                -16'sd851:energy_speed_limit=16'sd5657;
                -16'sd946:energy_speed_limit=16'sd5798;
                -16'sd1004:energy_speed_limit=16'sd5883;
                default:energy_speed_limit=16'sd5912;
            endcase
        end
    endfunction
    reg signed [15:0] cos_q10;
    wire signed [15:0] speed_mag_q8=speed_q8[15] ? -speed_q8 : speed_q8;
    wire needs_energy=speed_mag_q8<energy_speed_limit(cos_q10);
    // theta_ddot = g*sin(theta) - coupling*cos(theta)*arm_ddot.
    // Below target, choose arm acceleration opposite to theta_dot*cos(theta).
    wire pump_negative=(speed_q8[15]^cos_q10[15]) ^ needs_energy;
    wire slow=(speed_q8<16'sd51 && speed_q8> -16'sd51);
    assign velocity_valid=(good_velocity_pairs>=RECOVERY_FRAMES) && !endpoint;
    wire blind=endpoint || !velocity_valid;
    localparam integer APPROACH_ENTRY=$rtoi(`CFG_SWINGUP_APPROACH_ENTRY_DEG*PI_COUNTS/180.0);
    localparam integer APPROACH_EXIT=$rtoi(`CFG_SWINGUP_APPROACH_EXIT_DEG*PI_COUNTS/180.0);
    localparam integer APPROACH_SPEED=$rtoi(`CFG_SWINGUP_APPROACH_SPEED_RAD_S*256.0);
    localparam integer APPROACH_RAW=$rtoi(`CFG_SWINGUP_APPROACH_INSTANT_RAD_S*256.0);
    localparam integer APPROACH_ARM_SPEED=$rtoi(`CFG_SWINGUP_APPROACH_ARM_SPEED_RAD_S*65536.0);
    localparam integer APPROACH_TRACKING=$rtoi(`CFG_SWINGUP_CAPTURE_TRACKING_DEG*3.141592653589793*65536.0/180.0);
    localparam integer APPROACH_LIMIT_HZ=(`CFG_SWINGUP_APPROACH_MAX_FREQUENCY_HZ<LIMIT_HZ) ? `CFG_SWINGUP_APPROACH_MAX_FREQUENCY_HZ : LIMIT_HZ;
    localparam integer APPROACH_STEP=(`CFG_SWINGUP_APPROACH_ACCEL_HZ_PER_S*64'sd256*`CFG_CONTROL_PERIOD_US)/1000000;
    localparam integer APPROACH_QUAL_FRAMES=`CFG_SWINGUP_APPROACH_QUAL_FRAMES;
    wire signed [31:0] relative_alpha=alpha_meas-arm_reference_q16;
    wire signed [31:0] relative_command=alpha_c-arm_reference_q16;
    wire signed [32:0] tracking=$signed({relative_alpha[31],relative_alpha})-$signed({relative_command[31],relative_command});
    wire approach_request=approach_valid && velocity_valid && step_valid && !endpoint &&
        angle_counts<=(approach_active ? APPROACH_EXIT : APPROACH_ENTRY) &&
        angle_counts>=-(approach_active ? APPROACH_EXIT : APPROACH_ENTRY) &&
        speed_q8<=APPROACH_SPEED && speed_q8>=-APPROACH_SPEED &&
        instant_speed<=APPROACH_RAW && instant_speed>=-APPROACH_RAW &&
        approach_arm_velocity<=APPROACH_ARM_SPEED && approach_arm_velocity>=-APPROACH_ARM_SPEED &&
        tracking<=APPROACH_TRACKING && tracking>=-APPROACH_TRACKING &&
        relative_alpha<=SOFT_ARM && relative_alpha>=-SOFT_ARM && relative_command<=SOFT_ARM && relative_command>=-SOFT_ARM;
    reg signed [31:0] approach_target;
    reg negative_acceleration;
    reg acceleration_pipe, approach_request_pipe;
    reg signed [31:0] approach_target_pipe;
    reg signed [31:0] next_frequency;
    reg [$clog2(APPROACH_QUAL_FRAMES+1)-1:0] approach_good_frames;
    reg [$clog2(APPROACH_QUAL_FRAMES+1)-1:0] approach_bad_frames;
    wire signed [31:0] active_limit_q8=blind ? ENDPOINT_LIMIT_HZ*256 : LIMIT_Q8;
    always @* begin
        // Endpoint speed is unavailable: use a bounded alternating trial rather
        // than the stale energy estimate. Lower speed permits reversal in budget.
        negative_acceleration=(blind || slow) ? kick_negative : pump_negative;
        if(relative_alpha>SOFT_ARM || relative_command>SOFT_ARM) negative_acceleration=1;
        else if(relative_alpha< -SOFT_ARM || relative_command< -SOFT_ARM) negative_acceleration=0;
        approach_target=approach_frequency_q8;
        if(approach_target>APPROACH_LIMIT_HZ*256) approach_target=APPROACH_LIMIT_HZ*256;
        if(approach_target< -APPROACH_LIMIT_HZ*256) approach_target=-APPROACH_LIMIT_HZ*256;
        next_frequency=frequency_q8+(acceleration_pipe ? -STEP_Q8 : STEP_Q8);
        if(approach_request_pipe) begin
            if(approach_target_pipe>frequency_q8+APPROACH_STEP) next_frequency=frequency_q8+APPROACH_STEP;
            else if(approach_target_pipe<frequency_q8-APPROACH_STEP) next_frequency=frequency_q8-APPROACH_STEP;
            else next_frequency=approach_target_pipe;
        end
        if(next_frequency>active_limit_q8) next_frequency=active_limit_q8;
        if(next_frequency< -active_limit_q8) next_frequency=-active_limit_q8;
    end
    reg signed [63:0] velocity_product;
    assign u_q16=velocity_product>>>24;
    assign theta_dot_q16=$signed(speed_q8)*32'sd256;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            previous_ad<=0; velocity_seen<=0; previous_endpoint<=1; endpoint_pair_pipe<=0; speed_q8<=0;
            good_velocity_pairs<=0; step_valid<=0; endpoint_trial_started<=0;
            frequency_q8<=0; kick_frames<=0; kick_negative<=0; approach_active<=0; recovery_active<=0;
            delta<=0; instant_speed<=0; sample_pipe<=0; abs_angle<=0;
            acceleration_pipe<=0; approach_request_pipe<=0; approach_target_pipe<=0;
            approach_good_frames<=0; approach_bad_frames<=0;
            cos_q10<=1024; velocity_product<=0;
        end else begin
            // Break the energy-comparison / command-adder path at 50MHz.
            acceleration_pipe<=negative_acceleration;
            approach_request_pipe<=approach_request;
            approach_target_pipe<=approach_target;
            // Top waits 220 clocks for this frame's serial preview and conversion.
            // Standalone energy-only tests retain the original five-clock schedule.
            sample_pipe<={sample_pipe[UPDATE_CLOCKS-2:0],sample_valid};
            // Latch the angle difference at the sample edge; previous_ad changes
            // there too, so a free-running difference must not feed the pipeline.
            instant_speed<=delta*VELOCITY_SCALE;
            // Endpoint angle and speed are unavailable. Use bottom cosine for pumping,
            // discard speed history across the gap. Recovery needs consecutive
            // plausible pairs before energy control or capture can use velocity.
            abs_angle<=endpoint ? PI_COUNTS : (angle_counts[15] ? -angle_counts : angle_counts);
            endpoint_pair_pipe<={endpoint_pair_pipe[0],(sample_valid && (endpoint || previous_endpoint))};
            cos_q10<=cosine(abs_angle);
            velocity_product<=$signed(frequency_q8)*`CFG_PULSE_RAD_Q32;
            if(sample_valid) begin
                previous_ad<=ad_value; previous_endpoint<=endpoint;
                delta<=delta_next; step_valid<=delta_plausible;
            end
            if(sample_pipe[1]) begin
                velocity_seen<=1;
                if(!velocity_seen || endpoint_pair_pipe[1] || !step_valid) begin
                    speed_q8<=0; good_velocity_pairs<=0;
                end else begin
                    speed_q8<=filtered_speed;
                    if(good_velocity_pairs<RECOVERY_FRAMES) good_velocity_pairs<=good_velocity_pairs+1'b1;
                end
            end
            if(!enable) begin
                frequency_q8<=0; kick_frames<=0; kick_negative<=0; approach_active<=0;
                approach_good_frames<=0; approach_bad_frames<=0;
                endpoint_trial_started<=0; recovery_active<=0;
            end
            else if(restart) begin
                // Preserve the last applied RUN command (bounded by the motor
                // limit), then ramp toward zero before resuming energy pumping.
                // Applying the lower swing limit immediately would add a step.
                if(restart_frequency_q8>RESTART_LIMIT_Q8) frequency_q8<=RESTART_LIMIT_Q8;
                else if(restart_frequency_q8< -RESTART_LIMIT_Q8) frequency_q8<=-RESTART_LIMIT_Q8;
                else frequency_q8<=restart_frequency_q8;
                kick_frames<=0; kick_negative<=restart_frequency_q8[31];
                approach_active<=0;
                approach_good_frames<=0; approach_bad_frames<=0;
                endpoint_trial_started<=0; recovery_active<=1;
            end else if(recovery_active && sample_pipe[UPDATE_CLOCKS-1]) begin
                approach_active<=0;
                approach_good_frames<=0; approach_bad_frames<=0;
                if(frequency_q8>RECOVERY_STEP_Q8) frequency_q8<=frequency_q8-RECOVERY_STEP_Q8;
                else if(frequency_q8< -RECOVERY_STEP_Q8) frequency_q8<=frequency_q8+RECOVERY_STEP_Q8;
                else begin frequency_q8<=0; recovery_active<=0; end
            end
            else if(sample_pipe[UPDATE_CLOCKS-1]) begin
                frequency_q8<=next_frequency;
                if(approach_active) begin
                    approach_good_frames<=0;
                    if(approach_request_pipe) approach_bad_frames<=0;
                    else if(approach_bad_frames>=APPROACH_QUAL_FRAMES-1) begin
                        approach_active<=0; approach_bad_frames<=0;
                    end else approach_bad_frames<=approach_bad_frames+1'b1;
                end else begin
                    approach_bad_frames<=0;
                    if(approach_request_pipe) begin
                        if(approach_good_frames>=APPROACH_QUAL_FRAMES-1) begin
                            approach_active<=1; approach_good_frames<=0;
                        end else approach_good_frames<=approach_good_frames+1'b1;
                    end else approach_good_frames<=0;
                end
                if(!blind) endpoint_trial_started<=0;
                if(kick_frames>=(blind ? (endpoint_trial_started ? 2*ENDPOINT_KICK_FRAMES : ENDPOINT_KICK_FRAMES) : KICK_FRAMES)-1) begin
                    kick_frames<=0; kick_negative<=!kick_negative;
                    if(blind) endpoint_trial_started<=1;
                end
                else kick_frames<=kick_frames+1'b1;
            end
        end
    end
endmodule
