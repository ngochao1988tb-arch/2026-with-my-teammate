`timescale 1ns/1ps
`include "control_config.vh"
// ============================================================================
// tb_hmi_dual_cmd.v — HMI 2.1 双摆扩展命令译码回归
// ----------------------------------------------------------------------------
// 直接驱动 hmi_control 的 rx_valid 接口（不经过 UART），逐个检查：
//   0x16/0x63 主摆横臂参考、0x50~0x56 从摆命令、0x60~0x62 双摆协同，
//   以及越界帧（0x50 arg=700）必须回 1 且不下发从板命令。
// ============================================================================
module tb_hmi_dual_cmd;
    reg clk = 0, rst_n = 0;
    always #10 clk = ~clk;              // 50 MHz 仿真时钟

    reg us_tick = 0, sample_valid = 0, rx_valid = 0;
    reg [7:0] cmd = 0;
    reg signed [31:0] seq = 0, arg = 0, speed = 0;
    reg screen_boot = 0, rx_source = 1, source_rv = 0;
    reg ack_ready = 1, snapshot_sent = 0;
    wire ack_valid, remote_start, remote_reset, stop_control, manual_run;
    wire signed [31:0] ack_seq, ack_result, manual_frequency_q8, arm_target_q16;
    wire [1:0] ack_source;
    wire arm_target_valid, arm_speed_valid, arm_hold_valid;
    wire [6:0] arm_speed_percent;
    wire [671:0] values;
    wire wave_set, wave_stop, track_request, point_valid;
    wire [1:0] wave_kind;
    wire [31:0] wave_period_us;
    wire signed [31:0] wave_amp_q16, point_q16;
    wire slave_req_valid, sync_enable;
    wire [7:0] slave_req_op;
    wire signed [15:0] slave_req_arg;

    hmi_control #(.RELATIVE_MANUAL(1)) dut (
        .clk(clk), .rst_n(rst_n), .us_tick(us_tick), .sample_valid(sample_valid),
        .rx_valid(rx_valid), .cmd(cmd), .seq(seq), .arg(arg), .speed(speed),
        .screen_boot(screen_boot), .rx_source(rx_source), .source_rv(source_rv),
        .state(3'd2), .fault(8'd0), .calibrated(1'b1), .feedback_ok(1'b1), .rail(1'b0),
        .buttons(3'b000),
        .arm_q16(32'sd0), .theta_q16(32'sd0), .command_q16(32'sd0),
        .theta_velocity_q16(32'sd0), .frequency_q8(32'sd0),
        .ack_ready(ack_ready), .snapshot_sent(snapshot_sent),
        .ack_valid(ack_valid), .ack_seq(ack_seq), .ack_result(ack_result), .ack_source(ack_source),
        .remote_start(remote_start), .remote_reset(remote_reset), .stop_control(stop_control),
        .manual_run(manual_run), .manual_frequency_q8(manual_frequency_q8),
        .arm_target_valid(arm_target_valid), .arm_target_q16(arm_target_q16),
        .arm_speed_valid(arm_speed_valid), .arm_speed_percent(arm_speed_percent),
        .arm_hold_valid(arm_hold_valid), .values(values),
        .signed_pulses(32'sd0), .reference_q16(32'sd0),
        .wave_set(wave_set), .wave_kind(wave_kind), .wave_period_us(wave_period_us),
        .wave_amp_q16(wave_amp_q16), .wave_stop(wave_stop), .track_request(track_request),
        .point_valid(point_valid), .point_q16(point_q16),
        .slave_req_valid(slave_req_valid), .slave_req_op(slave_req_op),
        .slave_req_arg(slave_req_arg), .sync_enable(sync_enable)
    );

    // 1 µs 节拍（每 50 拍），用于 hmi_control 内部 ms 计时
    integer us_div = 0;
    always @(posedge clk) begin
        if (us_div == 49) begin us_div <= 0; us_tick <= 1'b1; end
        else begin us_div <= us_div + 1; us_tick <= 1'b0; end
    end

    integer errors = 0;
    integer req_count = 0;
    reg [7:0] req_op = 0;
    reg signed [15:0] req_arg = 0;

    // 抓 slave_req 脉冲（每帧命令只应出现一次）
    always @(posedge clk) if (slave_req_valid) begin
        req_op  <= slave_req_op;
        req_arg <= slave_req_arg;
        req_count = req_count + 1;
    end

    task send_cmd;
        input [7:0] c;
        input signed [31:0] a;
        input signed [31:0] v;
        begin
            @(negedge clk);
            seq = seq + 1; cmd = c; arg = a; speed = v; rx_valid = 1;
            @(negedge clk);
            rx_valid = 0;
            repeat (40) @(negedge clk);
        end
    endtask

    task expect_req;
        input [7:0] op;
        input signed [15:0] a;
        input [127:0] tag;
        begin
            if (req_op !== op || req_arg !== a) begin
                $display("FAIL %0s: op=%02x arg=%0d (期望 %02x/%0d)", tag, req_op, req_arg, op, a);
                errors = errors + 1;
            end else if (ack_result !== 32'sd0) begin
                $display("FAIL %0s: ack=%0d", tag, ack_result);
                errors = errors + 1;
            end else
                $display("  [OK] %0s → OP %02x arg %0d", tag, op, a);
        end
    endtask

    initial begin
        repeat (20) @(negedge clk);
        rst_n = 1;
        repeat (200) @(negedge clk);

        // ---- 从摆摆角目标：-123 → 0.01° 域 -1230 ----
        req_count = 0;
        send_cmd(8'h50, -32'sd123, 32'sd30);
        if (req_count != 1) begin $display("FAIL 0x50 req_count=%0d", req_count); errors = errors + 1; end
        expect_req(8'h32, -16'sd1230, "0x50 从摆摆角目标 -12.3°");

        // ---- 从摆速度 ----
        req_count = 0;
        send_cmd(8'h51, 32'sd55, 32'sd30);
        expect_req(8'h34, 16'sd55, "0x51 从摆速度 55%");

        // ---- 回零 / 起摆 / 停止 / 复位 ----
        req_count = 0;
        send_cmd(8'h52, 32'sd0, 32'sd30);
        expect_req(8'h35, 16'sd0, "0x52 从摆回零");
        req_count = 0;
        send_cmd(8'h53, 32'sd0, 32'sd30);
        expect_req(8'h20, 16'sd1, "0x53 从摆起摆");
        req_count = 0;
        send_cmd(8'h54, 32'sd0, 32'sd30);
        expect_req(8'h20, 16'sd2, "0x54 从摆停止");

        // 0x55 复位后再发 0x53 让主摆保持可起摆：这里只查译码
        req_count = 0;
        send_cmd(8'h55, 32'sd0, 32'sd30);
        expect_req(8'h20, 16'sd5, "0x55 从摆复位");

        // ---- 横臂目标：60.0° → 6000 (0.01°) ----
        req_count = 0;
        send_cmd(8'h56, 32'sd600, 32'sd30);
        expect_req(8'h33, 16'sd6000, "0x56 从摆横臂 +60°");

        // ---- 双摆同步起摆（主摆也起摆）----
        req_count = 0;
        send_cmd(8'h60, 32'sd0, 32'sd30);
        expect_req(8'h20, 16'sd1, "0x60 双摆同步起摆");

        // ---- 双摆同步停止 ----
        req_count = 0;
        send_cmd(8'h61, 32'sd0, 32'sd30);
        expect_req(8'h20, 16'sd2, "0x61 双摆同步停止");

        // ---- 位置协同开 ----
        req_count = 0;
        send_cmd(8'h62, 32'sd1, 32'sd30);
        expect_req(8'h38, 16'sd1, "0x62 位置协同开");
        if (sync_enable !== 1'b1) begin $display("FAIL sync_enable=%0b", sync_enable); errors = errors + 1; end

        // ---- 双摆横臂目标：-60.0° ----
        req_count = 0;
        send_cmd(8'h63, -32'sd600, 32'sd30);
        expect_req(8'h33, -16'sd6000, "0x63 双摆横臂 -60°");

        // ---- 0x16 主摆横臂：只改主摆参考，不下发从板 ----
        req_count = 0;
        send_cmd(8'h16, 32'sd300, 32'sd30);
        if (req_count != 0) begin
            $display("FAIL 0x16 不该下发从板命令 (req_count=%0d)", req_count);
            errors = errors + 1;
        end else if (ack_result !== 32'sd0) begin
            $display("FAIL 0x16 ack=%0d", ack_result); errors = errors + 1;
        end else $display("  [OK] 0x16 主摆横臂 +30°（不改从板）");

        // ---- 越界：0x50 arg=700 必须回 1 且不下发 ----
        req_count = 0;
        send_cmd(8'h50, 32'sd700, 32'sd30);
        if (req_count != 0) begin
            $display("FAIL 0x50 越界仍下发 (req_count=%0d)", req_count); errors = errors + 1;
        end else if (ack_result !== 32'sd1) begin
            $display("FAIL 0x50 越界 ack=%0d (期望 1)", ack_result); errors = errors + 1;
        end else $display("  [OK] 0x50 越界被拒（ack=1，无下发）");

        // ---- 越界：0x62 arg=2 ----
        req_count = 0;
        send_cmd(8'h62, 32'sd2, 32'sd30);
        if (req_count != 0 || ack_result !== 32'sd1) begin
            $display("FAIL 0x62 非法参数 ack=%0d req=%0d", ack_result, req_count);
            errors = errors + 1;
        end else $display("  [OK] 0x62 非法参数被拒");

        if (errors == 0) $display("PASS dual-pendulum HMI command decode: 12 cases");
        else             $display("FAIL dual-pendulum HMI command decode: %0d errors", errors);
        $finish;
    end
endmodule
