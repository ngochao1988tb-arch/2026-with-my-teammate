`timescale 1ns/1ps
// ============================================================================
// tb_lqr_smoke.v —— lqr_system 整链冒烟测试
// ----------------------------------------------------------------------------
// 目的不是验控制律（那要上板），而是确认替换后的整条链在仿真里能干净启动：
//   · 复位后 state/fault/motor_frequency_q8 不是 X
//   · 编码器链路超时会进入故障，而不是把 X 传进 LQR/陷波
//   · 停止状态下没有任何脉冲输出
// ============================================================================
module tb_lqr_smoke;
    reg clk=0,rst_n=0;
    always #20 clk=~clk;                 // 25 MHz

    wire pul,dir,ena,tel,hm_tx,scr_tx,slv_tx,vox_tx,adc_clk,adc_oe_n;
    wire [31:0] st_alpha,st_theta,st_ref,st_freq,st_u,st_adot,st_tdot,st_ac;
    wire [31:0] st_enc,st_age,st_seq,st_cnt,st_t,st_tag;
    wire [12:0] st_ad;
    wire [7:0]  st_state,st_fault,st_flags;
    wire st_run,st_cal,st_sat,st_fb,st_swing;
    wire rv_ack;wire [31:0] rv_ack_seq,rv_ack_result;wire hmi_req;

    lqr_system dut(
        .clk_sys(clk),.rst_n(rst_n),.key_sw(4'hf),
        .pul_out(pul),.dir_out(dir),.ena_out(ena),
        .motor_rx(1'b1),.motor_tx(),
        .telemetry_tx(tel),
        .adc_clk(adc_clk),.adc_oe_n(adc_oe_n),.adc_data_in(10'd390),
        .hmi_rx(1'b1),.hmi_tx(hm_tx),
        .screen_rx(1'b1),.screen_tx(scr_tx),
        .slave_rx(1'b1),.slave_tx(slv_tx),
        .voice_rx(1'b1),.voice_tx(vox_tx),
        .st_alpha_q16(st_alpha),.st_theta_q16(st_theta),.st_arm_ref_q16(st_ref),
        .st_freq_q8(st_freq),.st_u_q16(st_u),.st_alpha_dot(st_adot),.st_theta_dot(st_tdot),
        .st_alpha_c(st_ac),.st_enc_raw(st_enc),.st_enc_age_us(st_age),.st_enc_seq(st_seq),
        .st_ctrl_count(st_cnt),.st_t_us(st_t),.st_ad_value(st_ad),
        .st_state(st_state),.st_fault(st_fault),.st_flags(st_flags),.st_build_tag(st_tag),
        .st_run(st_run),.st_calibrated(st_cal),.st_saturated(st_sat),
        .st_fb_ready(st_fb),.st_swing_active(st_swing),
        .rv_req(1'b0),.rv_cmd(8'd0),.rv_seq(32'd0),.rv_arg(32'd0),.rv_speed(32'd0),
        .rv_ack(rv_ack),.rv_ack_seq(rv_ack_seq),.rv_ack_result(rv_ack_result),
        .hmi_req_pulse(hmi_req));

    reg prev_pul=0;
    integer pulses=0;
    always @(posedge clk) begin
        if(pul===1'b1 && prev_pul!==1'b1) pulses<=pulses+1;
        prev_pul<=pul;
    end

    integer errors=0;
    task chk(input integer cond,input [255:0] msg);
        begin
            if(!cond) begin errors=errors+1; $display("FAIL: %0s",msg); end
            else $display("ok  : %0s",msg);
        end
    endtask

    initial begin
        repeat(10) @(posedge clk);
        rst_n=1;
        repeat(10) @(posedge clk);
        chk(st_state!==8'hxx,"复位后 state 不是 X");
        chk(st_fault!==8'hxx,"复位后 fault 不是 X");
        chk(st_freq===32'sd0,"复位后频率指令为 0");
        chk(pul===1'b0 || pul===1'b1,"脉冲输出是确定值");

        // 编码器一直不回帧 → 30 ms 内必须报故障并停机
        repeat(800000) @(posedge clk);       // 32 ms @25MHz
        chk(st_state!==8'hxx,"长跑后 state 不是 X");
        chk(st_fault!==8'hxx,"长跑后 fault 不是 X");
        // 没有收到任何启动命令时，控制器必须停在 IDLE：不报故障、不发脉冲。
        // 与替换前工程的行为逐位一致（用同一测试对比过旧 src）。
        chk(st_state===8'd0,"未启动时停在 IDLE(state=0)");
        chk(st_fault===8'd0,"未启动时不报故障");
        chk(st_run===1'b0,"未启动时 run=0");
        chk(st_freq===32'sd0,"未启动时频率指令为 0");
        chk(st_u===32'sd0,"未启动时 LQR 输出为 0");
        chk(pulses==0,"未启动时没有任何脉冲");

        if(errors==0) $display("\n=== SMOKE PASS ===");
        else $display("\n=== %0d FAIL ===",errors);
        $finish;
    end
endmodule
