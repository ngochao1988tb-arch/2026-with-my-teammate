`timescale 1ns/1ps
`include "control_config.vh"
// 上位机波形/轨迹协议（0x20~0x26）验证：
//   0x20/0x21/0x22 一帧下发 波类型+周期+幅值 -> run_target 参考按波形运动
//   0x23 停止输出；0x25/0x24/0x26 手写轨迹跟随；gtarget 在 RUN 上报真实 LQR 参考。
module tb_hmi_wave;
 reg clk=0;always #5 clk=~clk;
 reg rst_n=0,valid=0;reg [7:0] cmd=0;reg signed [31:0] seq=0,arg=0,speed=0;
 reg [2:0] state=3;reg [7:0] fault=0;reg calibrated=1,feedback=1,rail=0;reg [2:0] buttons=0;
 reg signed [31:0] arm=0,theta=0,command_angle=0,velocity=0,frequency=0;
 reg tick=0,run_mode=1,clear=0;
 wire ack,start,reset,stop,manual,target_valid,speed_valid,hold_valid;
 wire signed [31:0] aseq,result,mfreq,target_q16;
 wire [6:0] speed_percent;
 wire [671:0] values;
 wire wave_set,wave_stop,track_request,point_valid;
 wire [1:0] wave_kind;
 wire [31:0] wave_period_us;
 wire signed [31:0] wave_amp_q16,point_q16;
 wire signed [31:0] goal,reference;
 wire moving,accepted,rejected;wire [1:0] level;
 wire signed [31:0] gtarget_report=values[543:512];

 hmi_control #(.CLK_HZ(1000000),.RECORD_DEPTH(4)) hmi(
  .clk(clk),.rst_n(rst_n),.us_tick(1'b1),.sample_valid(1'b1),
  .rx_valid(valid),.cmd(cmd),.seq(seq),.arg(arg),.speed(speed),.screen_boot(1'b0),.rx_source(1'b1),.source_rv(1'b0),
  .state(state),.fault(fault),.calibrated(calibrated),.feedback_ok(feedback),.rail(rail),
  .buttons(buttons),.arm_q16(arm),.theta_q16(theta),.command_q16(command_angle),
  .theta_velocity_q16(velocity),.frequency_q8(frequency),
  .ack_ready(1'b1),.snapshot_sent(1'b0),.ack_valid(ack),.ack_seq(aseq),.ack_result(result),.ack_source(),
  .remote_start(start),.remote_reset(reset),.stop_control(stop),.manual_run(manual),
  .manual_frequency_q8(mfreq),.arm_target_valid(target_valid),.arm_target_q16(target_q16),
  .arm_speed_valid(speed_valid),.arm_speed_percent(speed_percent),.arm_hold_valid(hold_valid),
  .values(values),.signed_pulses(32'sd0),.reference_q16(reference),
  .wave_set(wave_set),.wave_kind(wave_kind),.wave_period_us(wave_period_us),
  .wave_amp_q16(wave_amp_q16),.wave_stop(wave_stop),.track_request(track_request),
  .point_valid(point_valid),.point_q16(point_q16));

 run_target #(.SINE_DEMO(1)) tgt(.clk(clk),.rst_n(rst_n),.clear(clear),.tick(tick),
  .run_mode(run_mode),.feedback_valid(feedback),.angle_step(1'b0),.neg_step(1'b0),
  .speed_double(1'b0),.move(1'b0),.alpha_meas(arm),
  .goal_q16(goal),.reference_q16(reference),.moving(moving),.accepted(accepted),.rejected(rejected),
  .speed_level(level),.hmi_target_valid(target_valid),.hmi_target_q16(target_q16),
  .hmi_speed_valid(speed_valid),.hmi_speed_percent(speed_percent),.hmi_hold_valid(hold_valid),
  .amplitude_step(1'b0),.hmi_wave_start(wave_set),.hmi_wave_kind(wave_kind),
  .hmi_wave_period_us(wave_period_us),.hmi_wave_amp_q16(wave_amp_q16),.hmi_wave_stop(wave_stop),
  .hmi_track_mode(track_request),.hmi_point_valid(point_valid),.hmi_point_q16(point_q16));

 integer n,saved,transitions,maximum,minimum,last_ref;
 real expected,error,max_error;

 task send;input [7:0] c;input signed [31:0] a;input signed [31:0] v;begin
  @(negedge clk);seq=seq+1;cmd=c;arg=a;speed=v;valid=1;
  @(negedge clk);valid=0;
  repeat(200) @(negedge clk);          // 等 0.1°->Q16 串行转换与参数装载完成
 end endtask

 task frame;begin
  @(negedge clk);tick=1;@(negedge clk);tick=0;repeat(10) @(negedge clk);
 end endtask

 task expect_reject;input [7:0] c;input signed [31:0] a;input signed [31:0] v;begin
  @(negedge clk);seq=seq+1;cmd=c;arg=a;speed=v;valid=1;
  @(posedge clk);#1;
  if(result==0) $fatal(1,"cmd %h arg %0d should be rejected",c,a);
  @(negedge clk);valid=0;repeat(20) @(negedge clk);
 end endtask

 initial begin
  repeat(4) @(negedge clk);rst_n=1;repeat(4) @(negedge clk);

  // ---------- 1) 正弦：周期 2000 ms，幅值 ±20.0° ----------
  send(8'h20,2000,200);
  if(result!=0) $fatal(1,"sine params rejected");
  if(wave_period_us!=2000000 || wave_kind!=2'd0) $fatal(1,"framing: period %0d kind %0d",wave_period_us,wave_kind);
  if(!tgt.u_sine.active) $fatal(1,"sine did not start after parameter frame");
  max_error=0;maximum=-2147483647;minimum=2147483647;
  // 每帧相位步进 = 控制周期 / 波形周期。控制周期随 CFG_CONTROL_PERIOD_US 变化，
  // 帧数要足够覆盖至少一个完整波形周期：2000ms / CFG_CONTROL_PERIOD_US。
  for(n=0;n<2000000/`CFG_CONTROL_PERIOD_US+100;n=n+1) begin
   frame;
   expected=22878.0*$sin(6.283185307179586*n*($itor(`CFG_CONTROL_PERIOD_US)/1.0e6)/2.0);
   error=reference-expected;if(error<0) error=-error;if(error>max_error) max_error=error;
   if(error>40) $fatal(1,"sine shape frame=%0d actual=%0d expected=%f",n,reference,expected);
   if(reference>maximum) maximum=reference;
   if(reference<minimum) minimum=reference;
  end
  if(maximum<22850 || minimum> -22850) $fatal(1,"sine amplitude max=%0d min=%0d",maximum,minimum);

  // ---------- 2) 方波：周期 500 ms，幅值 ±10.0° ----------
  send(8'h21,500,100);
  if(wave_kind!=2'd1) $fatal(1,"square kind");
  frame;frame;                        // 让上一轮的管道排空
  transitions=0;last_ref=reference;
  maximum=-2147483647;minimum=2147483647;
  // 覆盖至少 3 个周期（1500ms）才有足够边沿；帧数随控制周期缩放。
  for(n=0;n<1500000/`CFG_CONTROL_PERIOD_US;n=n+1) begin
   frame;
   if(reference>maximum) maximum=reference;
   if(reference<minimum) minimum=reference;
   if((reference-last_ref)>3000 || (last_ref-reference)>3000) transitions=transitions+1;
   if(reference>11500 || reference< -11500) $fatal(1,"square out of range %0d",reference);
   last_ref=reference;
  end
  if(maximum<11400 || minimum> -11400) $fatal(1,"square must reach both rails max=%0d min=%0d",maximum,minimum);
  if(transitions<5) $fatal(1,"square edges missing: %0d",transitions);

  // ---------- 3) 三角波：周期 1000 ms，幅值 ±30.0° ----------
  send(8'h22,1000,300);
  if(wave_kind!=2'd2) $fatal(1,"triangle kind");
  // 在线换幅值不会跳变：包络按 15 deg/s 从 10°升到 30°（需 20°/15deg/s≈1.33s），先等它稳定。
  for(n=0;n<1400000/`CFG_CONTROL_PERIOD_US;n=n+1) frame;
  if(tgt.u_sine.applied_amplitude_q16<34300) $fatal(1,"envelope did not reach 30deg: %0d",tgt.u_sine.applied_amplitude_q16);
  maximum=-2147483647;minimum=2147483647;
  // 覆盖至少 1 个完整周期（1000ms）。
  for(n=0;n<1100000/`CFG_CONTROL_PERIOD_US;n=n+1) begin
   frame;
   if(reference>maximum) maximum=reference;
   if(reference<minimum) minimum=reference;
  end
  if(maximum<34000 || minimum> -34000) $fatal(1,"triangle amplitude max=%0d min=%0d",maximum,minimum);

  // ---------- 4) 0x23 停止输出 ----------
  send(8'h23,0,0);
  if(tgt.u_sine.active) $fatal(1,"stop frame did not deactivate");
  saved=reference;repeat(20) frame;
  if(reference!=saved) $fatal(1,"reference moved after stop");

  // ---------- 5) 手写轨迹：0x25 + 0x24 + 0x26 ----------
  send(8'h25,100,10);
  if(!track_request) $fatal(1,"track begin not latched");
  saved=reference;
  send(8'h24,300,10);                 // +30.0°
  if(point_q16<34315 || point_q16>34322) $fatal(1,"point scaling %0d",point_q16);
  last_ref=reference;
  // 轨迹限速 120 deg/s，每帧步进 = 120*控制周期；收敛 30° 所需帧数随控制周期缩放。
  for(n=0;n<30000/(120*`CFG_CONTROL_PERIOD_US/1000)+50;n=n+1) begin
   frame;
   if((reference-last_ref)>600) $fatal(1,"track slew exceeded limit");
   last_ref=reference;
  end
  if(reference<33800 || reference>34322) $fatal(1,"track did not converge to +30deg, got %0d",reference);
  send(8'h24,-300,10);                // -30.0°
  for(n=0;n<60000/(120*`CFG_CONTROL_PERIOD_US/1000)+50;n=n+1) frame;
  if(reference> -33800 || reference< -34322) $fatal(1,"track did not converge to -30deg, got %0d",reference);
  send(8'h26,0,0);
  if(track_request) $fatal(1,"track end not cleared");
  saved=reference;repeat(20) frame;
  if(reference-saved>2 || saved-reference>2) $fatal(1,"reference must hold after track end");

  // ---------- 6) RUN 状态 gtarget 上报真实参考 ----------
  send(8'h20,4000,150);
  // 跑足 600ms，保证正弦在 4s 周期里推进了可观的相位。
  for(n=0;n<600000/`CFG_CONTROL_PERIOD_US;n=n+1) frame;
  // gtarget 为 values[543:512]，参考值换成 0.01°：q16*0.087426
  if(gtarget_report==0) $fatal(1,"gtarget not reported in RUN");
  if(!((gtarget_report-reference*0.087426)<400 && (reference*0.087426-gtarget_report)<400))
   $fatal(1,"gtarget %0d does not follow reference %0d",gtarget_report,reference);

  // ---------- 7) 非 RUN 下发参数：先存着，进入 RUN 后自动开始一次 ----------
  send(8'h23,0,0);
  run_mode=0;repeat(10) @(negedge clk);
  send(8'h20,3000,100);               // READY 下下发 3 s / ±10.0°
  if(tgt.u_sine.active) $fatal(1,"wave must not run outside RUN");
  saved=reference;
  run_mode=1;repeat(60) @(negedge clk);
  if(!tgt.u_sine.active) $fatal(1,"armed wave did not auto-start on RUN entry");
  for(n=0;n<600000/`CFG_CONTROL_PERIOD_US;n=n+1) frame;
  if(reference-saved<2000 && saved-reference<2000) $fatal(1,"armed wave produced no motion");

  // ---------- 8) 参数越界必须被拒绝 ----------
  expect_reject(8'h20,10,200);          // 周期 < 50ms
  expect_reject(8'h20,2000,9500);       // 幅值 > 900.0°
  expect_reject(8'h24,2000,10);         // 位置 > ±180.0°
  expect_reject(8'h25,0,10);            // 点数 < 1

  $display("PASS HMI wave: sine/square/triangle framing, stop, track follow, gtarget reporting, range rejects");
  $finish;
 end
 initial begin #20000000;$fatal(1,"wave test timeout");end
endmodule
