`timescale 1ns/1ps
module tb_control_sync;
 reg clk=0;always #10 clk=~clk;
 reg rst=0;
 // Integration: test the actual motor command chain in lqr_system.
 wire pul,ena;
 lqr_system d(.clk_50m(clk),.rst_n(rst),.key_sw(4'hf),.pul_out(pul),.ena_out(ena),
 .motor_rx(1'b1),.hmi_rx(1'b1),.adc_data_in(10'd466),.rv_req(1'b0),
 .rv_cmd(8'd0),.rv_seq(32'd0),.rv_arg(32'd0),.rv_speed(32'd0));
 // Filter: independent fixed-point recurrence, including positive/negative rails.
 reg nt=0,ne=0;reg signed [31:0] nu=0;wire signed [31:0] ny;wire nd;
 run_notch n(clk,rst,nt,ne,nu,ny,nd);
 reg signed [31:0] x1=0,x2=0,y1=0,y2=0,expected;
 reg signed [67:0] acc;
 integer i,cycles;
 task notch_sample(input signed [31:0] val,input first);
 begin
  nu=val;
  if(first)expected=val;
  else begin
   acc=$signed(val)*68'sd8423-$signed(x1)*68'sd16576+$signed(x2)*68'sd8423+$signed(y1)*68'sd15316-$signed(y2)*68'sd7394;
   acc=acc>>>13;
   expected=acc>68'sd2147483647 ? 32'sh7fffffff : acc< -68'sd2147483648 ? 32'sh80000000 : acc[31:0];
  end
  nt=1;@(negedge clk);nt=0;cycles=0;
  while(!nd && cycles<110)begin @(negedge clk);cycles=cycles+1;end
  if(!nd || ny!==expected)$fatal(1,"notch recurrence mismatch sample=%d got=%d expected=%d cycles=%d",i,ny,expected,cycles);
  if(first)begin x1=val;x2=val;y1=val;y2=val;end
  else begin x2=x1;x1=val;y2=y1;y1=ny;end
  @(negedge clk);
 end endtask
 // Reference ramp: use the imported source module with the screen interface.
 reg tick=0,speedvalid=0,targetvalid=0,hold=0;
 reg [6:0] percent=0;reg signed [31:0] goal=100000;
 wire signed [31:0] refangle;
 run_target r(.clk(clk),.rst_n(rst),.clear(1'b0),.tick(tick),.run_mode(1'b1),.feedback_valid(1'b1),
 .angle_step(1'b0),.neg_step(1'b0),.speed_double(1'b0),.move(1'b0),.alpha_meas(32'sd0),
 .reference_q16(refangle),.hmi_target_valid(targetvalid),.hmi_target_q16(goal),
 .hmi_speed_valid(speedvalid),.hmi_speed_percent(percent),.hmi_hold_valid(hold),
 .amplitude_step(1'b0),.hmi_wave_start(1'b0),.hmi_wave_kind(2'd0),.hmi_wave_period_us(32'd0),
 .hmi_wave_amp_q16(32'sd0),.hmi_wave_stop(1'b0),.hmi_track_mode(1'b0),.hmi_point_valid(1'b0),.hmi_point_q16(32'sd0));
 integer before_ref,step;
 task ramp_sample(input [6:0] pct,input integer exp_step);
 begin
  percent=pct;speedvalid=1;@(negedge clk);speedvalid=0;
  before_ref=refangle;tick=1;@(negedge clk);tick=0;
  if(refangle-before_ref!=exp_step)$fatal(1,"speed band %d got=%d expected=%d",pct,refangle-before_ref,exp_step);
 end endtask
 // Integral: inject an existing bias then issue a one-clock target event.
 reg lt=0,change=0,le=1;wire ld;wire signed [31:0] trim;
 lqr_core l(.clk(clk),.rst_n(rst),.tick(lt),.clear(1'b0),.enable(le),
 .alpha_meas(32'sd0),.alpha_update(1'b1),.theta_meas(32'sd0),.alpha_c(32'sd0),
 .seed(1'b0),.seed_alpha_dot(32'sd0),.seed_theta_dot(32'sd0),.seed_u(32'sd0),
 .trim_u_q16(trim),.done(ld),.arm_reference_q16(32'sd0),.reference_changing(change));
 reg signed [63:0] oldtrim;
 task lqr_frame;
 begin
  lt=1;@(negedge clk);lt=0;cycles=0;
  while(!ld && cycles<150)begin @(negedge clk);cycles=cycles+1;end
  if(!ld)$fatal(1,"LQR result timeout");
  @(negedge clk);
 end endtask
 task result_pulse;
 begin force d.done=1;@(negedge clk);force d.done=0;repeat(120)@(negedge clk);end
 endtask
 integer prev_rate;
 initial begin
  repeat(8)@(negedge clk);rst=1;repeat(8)@(negedge clk);
  ne=1;
  notch_sample(0,1);
  for(i=0;i<120;i=i+1)notch_sample((i%2)?(i*523-31000):(65000-i*781),0);
  notch_sample(32'sh7fffffff,0);notch_sample(32'sh80000000,0);
  ne=0;repeat(2)@(negedge clk);if(ny!=0 || nd)$fatal(1,"notch disable");
  ne=1;notch_sample(-123456,1);
  $display("PASS: notch 124 fixed-point recurrence/startup/disable samples, bounded output, result latency <110 clocks.");
  targetvalid=1;@(negedge clk);targetvalid=0;
  step=r.STEP_E1;
  ramp_sample(0,0);ramp_sample(1,step);ramp_sample(25,step);
  ramp_sample(26,step*2);ramp_sample(50,step*2);ramp_sample(51,step*3);
  ramp_sample(75,step*3);ramp_sample(76,step*4);ramp_sample(100,step*4);
  hold=1;@(negedge clk);hold=0;ramp_sample(100,0);
  $display("PASS: source reference speed bands 0/25/50/75/100 boundaries, hold, Q16 steps=%d/%d/%d/%d.",step,step*2,step*3,step*4);
  l.trim_q36=64'sd1000000000;change=1;@(negedge clk);change=0;
  if(!l.trim_return_pending)$fatal(1,"short reference event not latched");
  for(i=0;i<5;i=i+1)begin
   oldtrim=l.trim_q36;lqr_frame;
   if(l.trim_q36!=((oldtrim>l.TRIM_RETURN_STEP_Q36)?oldtrim-l.TRIM_RETURN_STEP_Q36:0))$fatal(1,"trim slew mismatch");
  end
  if(l.trim_q36!=0 || l.trim_return_pending)$fatal(1,"trim did not finish returning");
  le=0;@(negedge clk);if(trim!=0)$fatal(1,"disabled trim");
  $display("PASS: short target event latched; integral bias returns in bounded steps across subsequent frames; disable clears bias.");
  force d.run=1;force d.state=3;force d.manual_run=0;
  force d.travel_positive_limit_q8=1024000;force d.travel_negative_limit_q8=1024000;
  force d.u_q16=1000000;force d.done=0;
  repeat(130)@(negedge clk);
  for(i=0;i<5;i=i+1)begin
   prev_rate=d.run_rate_frequency_q8;result_pulse;
   if(d.run_rate_frequency_q8-prev_rate!=30720)$fatal(1,"RUN slew positive: %d",d.run_rate_frequency_q8-prev_rate);
  end
  force d.u_q16=-1000000;
  for(i=0;i<10;i=i+1)begin
   prev_rate=d.run_rate_frequency_q8;result_pulse;
   if(d.run_rate_frequency_q8-prev_rate>30720 || d.run_rate_frequency_q8-prev_rate< -30720)$fatal(1,"RUN slew bound");
  end
  prev_rate=d.run_rate_frequency_q8;repeat(150)@(negedge clk);
  if(d.run_rate_frequency_q8!=prev_rate)$fatal(1,"slew changed without a result");
  force d.run=0;@(negedge clk);
  if(d.run_rate_frequency_q8!=0 || d.u_motor.run!==0)$fatal(1,"stop failed rate=%d run=%b",d.run_rate_frequency_q8,d.u_motor.run);
  prev_rate=d.signed_pulses;repeat(1000)@(negedge clk);
  if(d.signed_pulses!=prev_rate || pul || ena!==1)$fatal(1,"stop emitted a new step or changed source holding-enable behavior");
  $display("PASS: actual integrated notch-result pipeline, RUN <=120Hz/result, hold between results, direct stop gate emits no new steps (driver holding-enable retained, same as source).");
  $finish;
 end
 initial begin #10000000;$fatal(1,"timeout");end
endmodule
