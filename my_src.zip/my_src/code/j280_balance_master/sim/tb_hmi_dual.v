`timescale 1ns/1ps
`include "control_config.vh"
// 双路 HMI：上位机(L20/K20) + 串口屏(K22/L22) 共存验证。
//   1) 两个口的命令都能被解析执行；
//   2) 两台主机的 seq 各自独立计数，源切换后不会被对方的 last_seq 判成重复帧；
//   3) 同一源的重复/过期帧仍然被挡住（回 4，且不改变动作）；
//   4) 上行快照同时出现在 hmi_tx 与 screen_tx，字节数一致。
module tb_hmi_dual;
 localparam TB_RX_CLK_HZ=1152000;   // 10 拍/bit，配合 100MHz 测试时钟
 reg clk=0,rst_n=0;always #5 clk=~clk;
 reg rx_pc=1,rx_scr=1;
 wire pul,dir,ena,mtx,aclk,oe,tx_pc,tx_scr;
 // PORT_ALL 的 top 还带从板(V8/V9)和语音(Y14/Y15)两路串口；
 // 这两路在本用例里保持 idle（rx=1），只验证 HMI 两路。
 top #(.PC_DEBUG_EN(0)) dut(.clk_50m(clk),.rst_n(rst_n),.key_sw(4'b1111),.pul_out(pul),.dir_out(dir),.ena_out(ena),
  .motor_rx(1'b1),.motor_tx(mtx),.adc_clk(aclk),.adc_oe_n(oe),.adc_data_in(10'd466),
  .hmi_rx(rx_pc),.hmi_tx(tx_pc),.screen_rx(rx_scr),.screen_tx(tx_scr),
  .slave_rx(1'b1),.slave_tx(),.voice_rx(1'b1),.voice_tx(),.telemetry_tx());
 // 接收与发送都按 1.152MHz 计时钟，测试时钟 100MHz → 10 拍/bit，仿真快 100 倍且功能等价。
 defparam dut.u_lqr.u_hmi_rx_pc.CLK_HZ=TB_RX_CLK_HZ;
 defparam dut.u_lqr.u_hmi_rx_screen.CLK_HZ=TB_RX_CLK_HZ;
 defparam dut.u_lqr.u_hmi_tx_pc.CLK_HZ=TB_RX_CLK_HZ;
 defparam dut.u_lqr.u_hmi_tx_screen.CLK_HZ=TB_RX_CLK_HZ;

 wire b_pc,b_scr,fe1,fe2;wire [7:0] byte_pc,byte_scr;
 serial_rx #(.CLK_HZ(TB_RX_CLK_HZ),.BAUD(115200)) mon_pc(clk,rst_n,tx_pc,byte_pc,b_pc,fe1);
 serial_rx #(.CLK_HZ(TB_RX_CLK_HZ),.BAUD(115200)) mon_scr(clk,rst_n,tx_scr,byte_scr,b_scr,fe2);
 integer n_pc=0,n_scr=0;
 // 抓最近一次回执：拒绝码只在 ack_result 上出现一拍，last_result 不更新
 integer ack_count=0;reg signed [31:0] ack_val=0;
 always @(posedge clk) if(dut.u_lqr.u_hmi_control.ack_valid) begin
  ack_val<=dut.u_lqr.u_hmi_control.ack_result;ack_count<=ack_count+1;
 end
 // 回执定向验证：pc_ack/screen_ack 各自只对属于本源的回执拉高。
 reg [1:0] ack_dir_err=0;
 always @(posedge clk) begin
  if(dut.u_lqr.u_hmi_control.ack_valid) begin
   if(dut.u_lqr.u_hmi_control.ack_source==2'd1 && !dut.u_lqr.pc_ack) ack_dir_err[0]=1'b1;
   if(dut.u_lqr.u_hmi_control.ack_source==2'd0 && !dut.u_lqr.screen_ack) ack_dir_err[0]=1'b1;
   if(dut.u_lqr.u_hmi_control.ack_source==2'd1 &&  dut.u_lqr.screen_ack) ack_dir_err[1]=1'b1;
   if(dut.u_lqr.u_hmi_control.ack_source==2'd0 &&  dut.u_lqr.pc_ack) ack_dir_err[1]=1'b1;
  end
 end
 always @(posedge clk) begin if(b_pc) n_pc=n_pc+1; if(b_scr) n_scr=n_scr+1; end

 integer bitn;
 // ch=0 走上位机口，ch=1 走串口屏口
 task byte_out;input integer ch;input [7:0] d;begin
  @(negedge clk);
  if(ch==0) rx_pc=0;else rx_scr=0;
  repeat(10) @(negedge clk);
  for(bitn=0;bitn<8;bitn=bitn+1) begin
   if(ch==0) rx_pc=d[bitn];else rx_scr=d[bitn];
   repeat(10) @(negedge clk);
  end
  if(ch==0) rx_pc=1;else rx_scr=1;
  repeat(10) @(negedge clk);
 end endtask

 task frame;input integer ch;input [7:0] c;input signed [31:0] s,a,v;begin
  byte_out(ch,8'h55);byte_out(ch,8'haa);byte_out(ch,8'h20);byte_out(ch,c);
  byte_out(ch,s[7:0]);byte_out(ch,s[15:8]);byte_out(ch,s[23:16]);byte_out(ch,s[31:24]);
  byte_out(ch,a[7:0]);byte_out(ch,a[15:8]);byte_out(ch,a[23:16]);byte_out(ch,a[31:24]);
  byte_out(ch,v[7:0]);byte_out(ch,v[15:8]);byte_out(ch,v[23:16]);byte_out(ch,v[31:24]);
  byte_out(ch,8'h0d);byte_out(ch,8'h0a);
  repeat(40) @(negedge clk);
 end endtask

 task expect_speed;input [6:0] want;input [255:0] tag;begin
  repeat(60) @(negedge clk);
  if(dut.u_lqr.u_hmi_control.speed_limit!=want)
   $fatal(1,"%0s: speed_limit=%0d expected %0d",tag,dut.u_lqr.u_hmi_control.speed_limit,want);
 end endtask

 integer k;
 initial begin
  repeat(6) @(negedge clk);rst_n=1;repeat(40) @(negedge clk);

  // 1) 上位机先发，seq 从 100 开始
  frame(0,8'h11,100,57,30);
  expect_speed(57,"pc seq=100");

  // 2) 串口屏发 seq=2（比 100 小）：换源后必须照样执行
  frame(1,8'h11,2,33,30);
  expect_speed(33,"screen seq=2 after pc seq=100");

  // 3) 切回上位机 seq=101
  frame(0,8'h11,101,44,30);
  expect_speed(44,"pc seq=101");

  // 4) 串口屏 seq=3
  frame(1,8'h11,3,66,30);
  expect_speed(66,"screen seq=3");

  // 5) 同源过期帧（seq=3 改参数重发）：必须被挡住，动作不变，回 4
  frame(1,8'h11,3,99,30);
  repeat(60) @(negedge clk);
  if(dut.u_lqr.u_hmi_control.speed_limit!=66)
   $fatal(1,"stale frame changed the action: speed_limit=%0d",dut.u_lqr.u_hmi_control.speed_limit);
  if(ack_val!=4)
   $fatal(1,"stale frame not flagged, ack_result=%0d",ack_val);

  // 6) 上行快照广播到两个脚 + 回执按来源定向
  for(k=0;k<800000 && n_pc<400;k=k+1) @(negedge clk);
  repeat(4000) @(negedge clk);
  if(n_pc<400 || n_scr<400) $fatal(1,"snapshot not broadcast: pc=%0d scr=%0d",n_pc,n_scr);
  // 回执已定向，两端口总字节数（快照+各自回执）允许差异；但必须验证定向正确。
  if(ack_dir_err!=2'b0) $fatal(1,"ack direction wrong: err=%b (pc=%0d scr=%0d)",ack_dir_err,n_pc,n_scr);
  if(ack_count<5) $fatal(1,"expected >=5 acks across both sources, got %0d",ack_count);
  $display("PASS dual HMI: pc+screen per-source seq, stale blocked, snapshot broadcast (pc=%0d scr=%0d), ack routed by source",n_pc,n_scr);
  $finish;
 end
 initial begin #40000000;$fatal(1,"dual hmi timeout");end
endmodule
