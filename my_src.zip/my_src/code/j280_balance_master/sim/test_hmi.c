#define HMI_HOST
#include "../sw/hmi.c"
#include "../sw/font8x16.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define CHECK(x) do{if(!(x)){fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#x);exit(1);}}while(0)
static uint16_t fb[240][320];
static int x0,y0,x1,y1,cx,cy;
static unsigned writes,cmd_count;
static struct {unsigned cmd,t;int arg;unsigned speed;} sent[1000];
static lqr_status_t source;
int host_cmd(unsigned c,int a,unsigned s){CHECK(cmd_count<1000);sent[cmd_count].cmd=c;sent[cmd_count].arg=a;sent[cmd_count].speed=s;sent[cmd_count++].t=host_ms;last_result=0;return 1;}
int lqr_read_status(lqr_status_t *s){*s=source;return 0;}
int32_t q16_to_deg10(int32_t v){return (v*573)>>16;}
const char *lqr_state_name(uint8_t v){return v==3?"RUN  ":"READY";}
void lcd_set_window(uint16_t x,uint16_t y,uint16_t xx,uint16_t yy){CHECK(x<=xx&&y<=yy&&xx<320&&yy<240);x0=cx=x;y0=cy=y;x1=xx;y1=yy;}
void lcd_write_data(uint16_t c){fb[cy][cx]=c;writes++;if(++cx>x1){cx=x0;if(++cy>y1)cy=y0;}}
void lcd_fill_rect(uint16_t x,uint16_t y,uint16_t w,uint16_t h,uint16_t c){if(x>=320||y>=240||!w||!h)return;for(unsigned j=y;j<y+h&&j<240;j++)for(unsigned i=x;i<x+w&&i<320;i++)fb[j][i]=c;}
void lcd_draw_pixel(uint16_t x,uint16_t y,uint16_t c){CHECK(x<320&&y<240);fb[y][x]=c;}
void lcd_hline(uint16_t x,uint16_t y,uint16_t w,uint16_t c){lcd_fill_rect(x,y,w,1,c);}
void lcd_vline(uint16_t x,uint16_t y,uint16_t h,uint16_t c){lcd_fill_rect(x,y,1,h,c);}
void lcd_rect(uint16_t x,uint16_t y,uint16_t w,uint16_t h,uint16_t c){lcd_hline(x,y,w,c);lcd_hline(x,y+h-1,w,c);lcd_vline(x,y,h,c);lcd_vline(x+w-1,y,h,c);}
void lcd_draw_char(uint16_t x,uint16_t y,char c,uint16_t fg,uint16_t bg){CHECK(x+8<=320&&y+16<=240);if(c<32||c>126)c='?';for(unsigned j=0;j<16;j++)for(unsigned i=0;i<8;i++)fb[y+j][x+i]=font8x16[c-32][j]&(128>>i)?fg:bg;}
void lcd_draw_text(uint16_t x,uint16_t y,const char *s,uint16_t fg,uint16_t bg){while(*s){lcd_draw_char(x,y,*s++,fg,bg);x+=8;}}
static void dump(const char *s){FILE *f=fopen(s,"wb");CHECK(f);fprintf(f,"P6\n320 240\n255\n");for(unsigned y=0;y<240;y++)for(unsigned x=0;x<320;x++){uint16_t c=fb[y][x];unsigned char p[3]={(c>>11)*255/31,((c>>5)&63)*255/63,(c&31)*255/31};fwrite(p,1,3,f);}fclose(f);}
static void refresh(unsigned t){host_ms=t;source.epoch++;read_snapshot();}
int main(void)
{
 source.state=3;source.mode=0x12;source.alpha_q16=1000;source.theta_q16=-500;source.alpha_dot=3000;source.freq_q8=128000;source.enc_raw=12345;source.ad_value=2048;
 refresh(100);draw_page();
 CHECK(values[0]==8&&values[1]==-5&&values[2]==26&&values[3]==125);
 for(unsigned i=0;i<N;i++){refresh(100+i*50);values[0]=(int)i-116;values[1]=wave_at(i,0,N,200);values[2]=(int)i*2-232;values[3]=wave_at(i,2,N,600);sample_plot();}
 status_ui();dump("scope.ppm");
 action(20,80);CHECK(selected==1&&enabled==2u);   /* tapping PEND shows PEND alone */
 action(20,165);CHECK(selected==3&&enabled==8u);  /* tapping SPD switches the single curve */
 action(20,165);CHECK(enabled==15u);               /* same card again -> four-curve overview */
 action(20,165);CHECK(enabled==8u);               /* and back to solo */
 action(20,165);CHECK(enabled==15u);
 action(130,195);CHECK(!(range_auto&8));CHECK(hi[3]==ranges[range_idx[3]]);
 action(175,195);CHECK(range_auto&8);unsigned old=count;action(230,195);sample_plot();CHECK(paused&&count==old);action(230,195);CHECK(!paused);
 action(90,225);CHECK(window_idx==2&&count==0); /* T- : 10 s -> 5 s, history restarts */
 action(124,225);CHECK(window_idx==3&&count==0); /* T+ : back to 10 s */
 for(unsigned i=0;i<20;i++)action(124,225);CHECK(window_idx==NWIN-1); /* clamp at 120 s */
 for(unsigned i=0;i<20;i++)action(90,225);CHECK(window_idx==0&&count==0); /* clamp at 1 s */
 draw_page(); /* time readout must stay on-panel at both extremes */
 window_idx=3;clear_history();dirty=1;draw_page();
 action(285,195);CHECK(cursor==0);
 for(unsigned k=0;k<4;k++){selected=k;for(unsigned j=0;j<20;j++)range_change(-1);CHECK(hi[k]==10);for(unsigned j=0;j<20;j++)range_change(1);CHECK(hi[k]==3600);}
 action(100,10);CHECK(page==PAD);draw_page();stroke(80,100,1);stroke(150,55,0);stroke(230,140,0);stroke(307,90,0);while(pad_draw_col<N)pad_render_tick();status_ui();dump("pad.ppm");
 CHECK(pad_has);int tail=pad_points[N-1];action(280,175);CHECK(pad_points[N-1]==-tail);action(94,175);CHECK(pad_points[N-1]==tail);
 action(100,225);CHECK(playing==1);CHECK(play_points[N-1]==tail);
 pad_points[N-1]=0;CHECK(play_points[N-1]==tail); /* Editing never mutates active playback. */
 refresh(play_origin+play_duration/2);playback_tick();CHECK(sent[cmd_count-1].cmd==0x24);CHECK(abs_i(sent[cmd_count-1].arg)<=1800);
 refresh(play_origin+play_duration);playback_tick();CHECK(!playing&&sent[cmd_count-1].arg==tail);
 action(180,10);CHECK(page==WAVE);draw_page();dump("wave.ppm");
 CHECK(wave_at(0,0,4000,100)==0);CHECK(wave_at(1000,0,4000,100)==100);CHECK(wave_at(3000,0,4000,100)==-100);
 CHECK(wave_at(0,1,4000,100)==100&&wave_at(2000,1,4000,100)==-100);
 CHECK(wave_at(1000,2,4000,100)==100&&wave_at(3000,2,4000,100)==-100);
 for(unsigned kind=0;kind<3;kind++)for(unsigned i=0;i<10000;i++)CHECK(abs_i(wave_at(i,kind,500,1800))<=1800);
 refresh(30000);action(100,225);CHECK(playing==2);playback_tick();unsigned before=cmd_count;
 refresh(33000);playback_tick();CHECK(cmd_count==before+1);CHECK(sent[cmd_count-1].t==33000); /* no overdue point burst */
 source.fault=1;refresh(33020);playback_tick();CHECK(!playing&&stop_pending==0x23);playback_tick();CHECK(sent[cmd_count-1].cmd==0x23);source.fault=0;
 refresh(40000);begin_play(2);CHECK(playing);host_ms=40201;playback_tick();CHECK(!playing);playback_tick();
 refresh(41000);source.state=2;refresh(41001);begin_play(2);CHECK(!playing&&last_result==2);
 source.state=3;refresh(42000);begin_play(2);action(20,220);CHECK(!playing&&stop_pending==0x0f);playback_tick();CHECK(sent[cmd_count-1].cmd==0x0f);
 action(260,10);CHECK(page==CONTROL);draw_page();status_ui();dump("control.ppm");
 action(240,40);playback_tick();CHECK(sent[cmd_count-1].cmd==2);action(90,85);playback_tick();CHECK(sent[cmd_count-1].cmd==4);
 /* Rendering extreme register values and state changes must stay on-panel.
  * The LCD mock checks every pixel/window, including the packed UI fonts. */
 unsigned render_commands=cmd_count;
 values[0]=-174865;values[1]=174865;values[2]=-349730;values[3]=-1000;
 source.enc_raw=(-2147483647-1);source.ad_value=8191;source.arm_ref_q16=-2000000;source.freq_q8=-1024000;
 for(unsigned pg=0;pg<4;pg++){page=pg;dirty=1;draw_page();if(pg==PAD)while(pad_draw_col<N)pad_render_tick();}
 CHECK(cmd_count==render_commands);
 page=MONITOR;dirty=1;draw_page();uint16_t released=fb[190][82];
 ui_down=1;ui_x=90;ui_y=195;page_controls();CHECK(fb[190][82]!=released);
 dump("scope_pressed.ppm");ui_down=0;page_controls();CHECK(fb[190][82]==released);
 source.fault=1;source.state=4;page=CONTROL;dirty=1;draw_page();status_ui();dump("fault.ppm");
 CHECK(cmd_count==render_commands);host_ms+=201;status_ui();
 printf("PASS: actual UI rendering; four channels, units/scaling, range bounds, time/pause/clear; handwriting interpolation/edit/undo; sine/square/triangle bounds; elapsed-time playback; stale/fault/RUN interlocks; stop/E-stop/reset mailbox. commands=%u\n",cmd_count);
 puts("PASS: compact-font/window bounds on all pages with extreme signed values; visual press/release feedback; fault/stale rendering sends no control commands.");
 return 0;
}
