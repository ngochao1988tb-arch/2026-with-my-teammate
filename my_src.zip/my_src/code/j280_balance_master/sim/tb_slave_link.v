`timescale 1ns/1ps
// ============================================================================
// tb_slave_link.v — 从板链路端到端仿真
// ============================================================================
// 用一个行为级「假从板」回应答，验证：
//   1) 命令帧字节与协议文档一致（A5 5A 01 <OP> <DATA> <CHECK>）；
//   2) 38 字节应答的帧头搜索、XOR 校验、字段提取；
//   3) OP00 轮询直到「起摆进 RUN / 位置到达 / 急停接受」才判完成；
//   4) 校验错误的应答被判为失败。
// 运行：iverilog -g2005 -I ../src -o tb_slave_link.vvp tb_slave_link.v ../src/*.v
//       vvp tb_slave_link.vvp
// ============================================================================
module tb_slave_link;

    localparam CLK_PERIOD = 20;          // 50 MHz
    // 仿真用 1Mbps 代替 115200：收发时序关系与逻辑完全相同，
    // 只是把一位从 8680ns 缩到 1000ns，仿真时间缩短近 9 倍。
    localparam TB_BAUD    = 1000000;
    localparam BIT_NS     = 1000;
    localparam CPB        = 50;          // 一位对应的时钟数 = 50MHz / 1Mbps

    reg clk = 1'b0;
    reg rst_n = 1'b0;
    always #(CLK_PERIOD/2) clk = ~clk;

    // ---------------- DUT ----------------
    wire       slave_tx;
    reg        slave_rx = 1'b1;
    reg        cmd_valid = 1'b0;
    reg  [2:0] cmd_kind  = 3'd0;
    reg  [7:0] cmd_arg   = 8'd0;
    reg        cmd_right = 1'b0;
    wire       busy, done_pulse, fail_pulse;
    wire [2:0] fail_code;
    wire [7:0] rep_op, rep_result, rep_state, rep_fault, rep_flags;
    wire [15:0] rep_position, rep_final, rep_active, target_shadow;
    wire [3:0] fsm_state;

    slave_link #(
        .CLK_HZ(50000000),
        .BAUD(TB_BAUD),
        .SLAVE_CENTER(10000),
        .SLAVE_TRAVEL(2150),
        .SLAVE_COUNTS_PER_REV(1000),
        .POLL_PERIOD_MS(2),
        .REPLY_TIMEOUT_MS(20),
        .START_TIMEOUT_MS(500),
        .MOVE_TIMEOUT_MS(500),
        .SETTLE_TIMEOUT_MS(200),
        .MOVE_TOLERANCE(12)
    ) dut (
        .clk(clk), .rst_n(rst_n),
        .slave_tx(slave_tx), .slave_rx(slave_rx),
        .cmd_valid(cmd_valid), .cmd_kind(cmd_kind),
        .cmd_arg(cmd_arg), .cmd_right(cmd_right),
        .busy(busy), .done_pulse(done_pulse), .fail_pulse(fail_pulse),
        .fail_code(fail_code),
        .rep_op(rep_op), .rep_result(rep_result), .rep_state(rep_state),
        .rep_fault(rep_fault), .rep_flags(rep_flags),
        .rep_position(rep_position), .rep_final(rep_final), .rep_active(rep_active),
        .target_shadow(target_shadow), .fsm_state(fsm_state)
    );

    // ---------------- 假从板：请求接收 ----------------
    reg  [7:0]  req [0:15];
    integer     req_len = 0;
    integer     req_count = 0;
    // done/fail 是单周期脉冲，可能在本测试进程进入等待之前就打完了，
    // 因此用粘滞标志记录，避免漏掉。
    reg         saw_done = 1'b0;
    reg         saw_fail = 1'b0;

    // 用工程自带的 serial_rx 收 DUT 发出的请求字节，避免手写采样时序出错。
    wire       req_valid;
    wire [7:0] req_data;
    serial_rx #(.CLK_HZ(50000000), .BAUD(TB_BAUD)) u_req_rx (
        .clk(clk), .rst_n(rst_n), .rx(slave_tx),
        .data(req_data), .valid(req_valid), .framing_error()
    );

    // serial_rx 的 data 与 valid 同拍更新，必须延一拍再取值，否则会读到上一字节。
    reg req_valid_d;
    always @(posedge clk) begin
        req_valid_d <= req_valid;
        if (req_valid_d) begin
            req[req_len] = req_data;
            req_len      = req_len + 1;
            req_count    = req_count + 1;
        end
    end

    // ---------------- 假从板：应答发送 ----------------
    // 由测试流程在 reply_state 等变量里设定，然后调用 send_reply
    reg [7:0]  rp_state = 8'd0;
    reg [7:0]  rp_fault = 8'd0;
    reg [7:0]  rp_flags = 8'd0;
    reg [7:0]  rp_result = 8'd0;
    reg [15:0] rp_pos = 16'd0;
    reg [15:0] rp_final = 16'd0;
    reg [15:0] rp_active = 16'd0;
    reg        rp_bad_check = 1'b0;

    task uart_send_byte(input [7:0] b);
        integer k;
        begin
            slave_rx = 1'b0;
            #(BIT_NS);
            for (k = 0; k < 8; k = k + 1) begin
                slave_rx = b[k];
                #(BIT_NS);
            end
            slave_rx = 1'b1;
            #(BIT_NS);
        end
    endtask

    task send_reply(input [7:0] op);
        reg [7:0] f [0:37];
        reg [7:0] x;
        integer i;
        begin
            for (i = 0; i < 38; i = i + 1) f[i] = 8'h00;
            f[0] = 8'h5A; f[1] = 8'hA5; f[2] = 8'h01;
            f[3] = op;  f[4] = rp_result;
            f[5] = 8'h4A; f[6] = 8'h02;
            f[7] = rp_state; f[8] = rp_fault; f[9] = rp_flags;
            f[10] = 8'h00; f[11] = rp_result; f[12] = 8'h07;
            f[13] = 8'h00; f[14] = 8'h00;
            f[15] = 8'h00; f[16] = 8'h00;
            f[17] = 8'h00; f[18] = 8'h00;
            f[19] = rp_pos[7:0];    f[20] = rp_pos[15:8];
            f[21] = 8'h00; f[22] = 8'h00;
            f[23] = rp_final[7:0];  f[24] = rp_final[15:8];
            f[25] = rp_active[7:0]; f[26] = rp_active[15:8];
            f[27] = 8'h00; f[28] = 8'h00;
            f[29] = 8'h00; f[30] = 8'h00; f[31] = 8'h00; f[32] = 8'h00;
            f[33] = 8'h10; f[34] = 8'h27;   // center 10000 = 0x2710
            f[35] = 8'h66; f[36] = 8'h08;   // travel 2150  = 0x0866
            x = 8'h00;
            for (i = 2; i <= 36; i = i + 1) x = x ^ f[i];
            f[37] = rp_bad_check ? ~x : x;
            for (i = 0; i < 38; i = i + 1) uart_send_byte(f[i]);
        end
    endtask

    // ---------------- 检查工具 ----------------
    integer errors = 0;
    task expect8(input [7:0] got, input [7:0] want, input [127:0] tag);
        begin
            if (got !== want) begin
                $display("  FAIL %0s: got %02h want %02h", tag, got, want);
                errors = errors + 1;
            end else begin
                $display("  ok   %0s = %02h", tag, got);
            end
        end
    endtask

    // 等待 DUT 发完一帧（req_len 增长到 frame_len）
    task wait_frame(input integer n);
        integer guard;
        begin
            guard = 0;
            while (req_len < n && guard < 2000000) begin
                @(posedge clk);
                guard = guard + 1;
            end
            if (req_len < n) begin
                $display("  FAIL 等待请求帧超时");
                errors = errors + 1;
            end
        end
    endtask

    task clear_frame;
        begin
            req_len = 0;
        end
    endtask

    // 等待 done/fail
    task wait_result(output integer is_done, output integer is_fail);
        integer guard;
        begin
            is_done = 0; is_fail = 0;
            guard = 0;
            while (!saw_done && !saw_fail && guard < 40000000) begin
                @(posedge clk);
                guard = guard + 1;
            end
            is_done = saw_done;
            is_fail = saw_fail;
            if (!is_done && !is_fail) $display("  FAIL 等待 done/fail 超时");
        end
    endtask

    // done/fail 粘滞标志（声明见上方）
    always @(posedge clk) begin
        if (done_pulse) saw_done <= 1'b1;
        if (fail_pulse) saw_fail <= 1'b1;
    end

    // 在时钟下降沿驱动命令，保证 DUT 在下一个上升沿能稳定采到
    task issue_cmd(input [2:0] kind, input [7:0] arg, input right);
        begin
            @(negedge clk);
            saw_done  = 1'b0;
            saw_fail  = 1'b0;
            cmd_kind  = kind;
            cmd_arg   = arg;
            cmd_right = right;
            cmd_valid = 1'b1;
            @(negedge clk);
            cmd_valid = 1'b0;
        end
    endtask

    // ---------------- 测试流程 ----------------
    integer t_done, t_fail;

    initial begin
        rst_n = 1'b0;
        repeat (20) @(posedge clk);
        rst_n = 1'b1;
        repeat (20) @(posedge clk);

        // ============ 场景 1：起摆 OP20/01，先待机后进 RUN ============
        $display("[场景 1] CMD_START -> OP20/01");
        clear_frame;
        rp_state = 8'd1; rp_fault = 8'd0; rp_result = 8'd0;
        rp_pos = 16'd10000; rp_final = 16'd10000; rp_active = 16'd10000;
        issue_cmd(3'd1, 8'd0, 1'b0);

        wait_frame(6);
        expect8(req[0], 8'hA5, "frame0");
        expect8(req[1], 8'h5A, "frame1");
        expect8(req[2], 8'h01, "frame2");
        expect8(req[3], 8'h20, "OP20");
        expect8(req[4], 8'h01, "DATA01");
        expect8(req[5], 8'h20, "CHECK");
        send_reply(8'h20);

        // 第二次应答改为 RUN，DUT 应判完成
        clear_frame;
        wait_frame(6);
        expect8(req[3], 8'h00, "poll OP00");
        rp_state = 8'd3;
        send_reply(8'h00);
        repeat (200) @(posedge clk);
        $display("  观察: fsm=%0d rep_op=%02h rep_state=%0d rep_result=%02h",
                 fsm_state, rep_op, rep_state, rep_result);

        wait_result(t_done, t_fail);
        if (!t_done) begin $display("  FAIL 起摆未判完成"); errors = errors + 1; end
        else              $display("  ok   起摆进 RUN 判完成");
        repeat (100) @(posedge clk);

        // ============ 场景 2：右移 30° -> OP30 绝对目标 ============
        // 30° @1000计数/圈 = 83 计数；影子目标 10000 -> 10083
        $display("[场景 2] CMD_MOVE 30deg right -> OP30");
        clear_frame;
        rp_state = 8'd3; rp_fault = 8'd0; rp_result = 8'd0;
        rp_final  = 16'd10083;
        rp_active = 16'd10083;
        rp_pos    = 16'd10000;
        issue_cmd(3'd4, 8'd30, 1'b1);

        wait_frame(7);
        expect8(req[0], 8'hA5, "frame0");
        expect8(req[3], 8'h30, "OP30");
        expect8(req[4], 16'd10083 & 8'hFF, "TGT_LO");
        expect8(req[5], (16'd10083 >> 8) & 8'hFF, "TGT_HI");
        expect8(req[6], 8'h01 ^ 8'h30 ^ (16'd10083 & 8'hFF) ^ ((16'd10083 >> 8) & 8'hFF), "TGT_CHECK");
        send_reply(8'h30);

        // 轮询：位置未到，继续轮询
        clear_frame;
        wait_frame(6);
        expect8(req[3], 8'h00, "poll OP00");
        rp_pos = 16'd10070;
        send_reply(8'h00);

        // 再轮询：位置到位
        clear_frame;
        wait_frame(6);
        rp_pos = 16'd10083;
        send_reply(8'h00);

        wait_result(t_done, t_fail);
        if (!t_done) begin $display("  FAIL 位置到达未判完成"); errors = errors + 1; end
        else              $display("  ok   位置到达判完成");
        repeat (100) @(posedge clk);

        // ============ 场景 3：校验错误的应答必须判失败 ============
        $display("[场景 3] 坏校验应答 -> 应失败");
        clear_frame;
        rp_state = 8'd3; rp_result = 8'd0; rp_bad_check = 1'b1;
        issue_cmd(3'd2, 8'd0, 1'b0);   // ESTOP
        wait_frame(6);
        send_reply(8'h20);
        // 重发一次（DUT 允许无效应答重发一次）
        clear_frame;
        wait_frame(6);
        send_reply(8'h20);
        wait_result(t_done, t_fail);
        if (t_fail) $display("  ok   坏校验判失败, code=%0d", fail_code);
        else begin $display("  FAIL 坏校验未判失败"); errors = errors + 1; end
        rp_bad_check = 1'b0;

        repeat (100) @(posedge clk);

        // ============ 结果 ============
        if (errors == 0) $display("\nPASS: slave_link 帧编码 / 应答解析 / 轮询完成判定 全部通过");
        else             $display("\nFAIL: %0d 处错误", errors);
        $finish;
    end

    // 全局超时
    initial begin
        #500_000_000;
        $display("FAIL: 全局超时");
        $finish;
    end

endmodule
