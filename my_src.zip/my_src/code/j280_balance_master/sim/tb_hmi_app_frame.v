`timescale 1ns/1ps
`include "control_config.vh"
// 端到端：把上位机（D:/FPGA/debug_app）真实产生的 18 字节帧，
// 按 115200 8N1 逐位灌进 hmi_rx -> hmi_control -> run_target，检查参考输出。
module tb_hmi_app_frame;
 localparam CLK_HZ=100000000, BIT_CYCLES=868;   // 100MHz / 115200
 localparam BYTES=162;
 reg [7:0] ROM_DATA[0:BYTES-1];
 initial begin
  ROM_DATA[0]=8'h55;
  ROM_DATA[1]=8'hAA;
  ROM_DATA[2]=8'h20;
  ROM_DATA[3]=8'h20;
  ROM_DATA[4]=8'h01;
  ROM_DATA[5]=8'h00;
  ROM_DATA[6]=8'h00;
  ROM_DATA[7]=8'h00;
  ROM_DATA[8]=8'hD0;
  ROM_DATA[9]=8'h07;
  ROM_DATA[10]=8'h00;
  ROM_DATA[11]=8'h00;
  ROM_DATA[12]=8'hC8;
  ROM_DATA[13]=8'h00;
  ROM_DATA[14]=8'h00;
  ROM_DATA[15]=8'h00;
  ROM_DATA[16]=8'h0D;
  ROM_DATA[17]=8'h0A;
  ROM_DATA[18]=8'h55;
  ROM_DATA[19]=8'hAA;
  ROM_DATA[20]=8'h20;
  ROM_DATA[21]=8'h25;
  ROM_DATA[22]=8'h02;
  ROM_DATA[23]=8'h00;
  ROM_DATA[24]=8'h00;
  ROM_DATA[25]=8'h00;
  ROM_DATA[26]=8'h06;
  ROM_DATA[27]=8'h00;
  ROM_DATA[28]=8'h00;
  ROM_DATA[29]=8'h00;
  ROM_DATA[30]=8'h0A;
  ROM_DATA[31]=8'h00;
  ROM_DATA[32]=8'h00;
  ROM_DATA[33]=8'h00;
  ROM_DATA[34]=8'h0D;
  ROM_DATA[35]=8'h0A;
  ROM_DATA[36]=8'h55;
  ROM_DATA[37]=8'hAA;
  ROM_DATA[38]=8'h20;
  ROM_DATA[39]=8'h24;
  ROM_DATA[40]=8'h03;
  ROM_DATA[41]=8'h00;
  ROM_DATA[42]=8'h00;
  ROM_DATA[43]=8'h00;
  ROM_DATA[44]=8'h00;
  ROM_DATA[45]=8'h00;
  ROM_DATA[46]=8'h00;
  ROM_DATA[47]=8'h00;
  ROM_DATA[48]=8'h0A;
  ROM_DATA[49]=8'h00;
  ROM_DATA[50]=8'h00;
  ROM_DATA[51]=8'h00;
  ROM_DATA[52]=8'h0D;
  ROM_DATA[53]=8'h0A;
  ROM_DATA[54]=8'h55;
  ROM_DATA[55]=8'hAA;
  ROM_DATA[56]=8'h20;
  ROM_DATA[57]=8'h24;
  ROM_DATA[58]=8'h04;
  ROM_DATA[59]=8'h00;
  ROM_DATA[60]=8'h00;
  ROM_DATA[61]=8'h00;
  ROM_DATA[62]=8'h64;
  ROM_DATA[63]=8'h00;
  ROM_DATA[64]=8'h00;
  ROM_DATA[65]=8'h00;
  ROM_DATA[66]=8'h0A;
  ROM_DATA[67]=8'h00;
  ROM_DATA[68]=8'h00;
  ROM_DATA[69]=8'h00;
  ROM_DATA[70]=8'h0D;
  ROM_DATA[71]=8'h0A;
  ROM_DATA[72]=8'h55;
  ROM_DATA[73]=8'hAA;
  ROM_DATA[74]=8'h20;
  ROM_DATA[75]=8'h24;
  ROM_DATA[76]=8'h05;
  ROM_DATA[77]=8'h00;
  ROM_DATA[78]=8'h00;
  ROM_DATA[79]=8'h00;
  ROM_DATA[80]=8'hC8;
  ROM_DATA[81]=8'h00;
  ROM_DATA[82]=8'h00;
  ROM_DATA[83]=8'h00;
  ROM_DATA[84]=8'h0A;
  ROM_DATA[85]=8'h00;
  ROM_DATA[86]=8'h00;
  ROM_DATA[87]=8'h00;
  ROM_DATA[88]=8'h0D;
  ROM_DATA[89]=8'h0A;
  ROM_DATA[90]=8'h55;
  ROM_DATA[91]=8'hAA;
  ROM_DATA[92]=8'h20;
  ROM_DATA[93]=8'h24;
  ROM_DATA[94]=8'h06;
  ROM_DATA[95]=8'h00;
  ROM_DATA[96]=8'h00;
  ROM_DATA[97]=8'h00;
  ROM_DATA[98]=8'h2C;
  ROM_DATA[99]=8'h01;
  ROM_DATA[100]=8'h00;
  ROM_DATA[101]=8'h00;
  ROM_DATA[102]=8'h0A;
  ROM_DATA[103]=8'h00;
  ROM_DATA[104]=8'h00;
  ROM_DATA[105]=8'h00;
  ROM_DATA[106]=8'h0D;
  ROM_DATA[107]=8'h0A;
  ROM_DATA[108]=8'h55;
  ROM_DATA[109]=8'hAA;
  ROM_DATA[110]=8'h20;
  ROM_DATA[111]=8'h24;
  ROM_DATA[112]=8'h07;
  ROM_DATA[113]=8'h00;
  ROM_DATA[114]=8'h00;
  ROM_DATA[115]=8'h00;
  ROM_DATA[116]=8'hC8;
  ROM_DATA[117]=8'h00;
  ROM_DATA[118]=8'h00;
  ROM_DATA[119]=8'h00;
  ROM_DATA[120]=8'h0A;
  ROM_DATA[121]=8'h00;
  ROM_DATA[122]=8'h00;
  ROM_DATA[123]=8'h00;
  ROM_DATA[124]=8'h0D;
  ROM_DATA[125]=8'h0A;
  ROM_DATA[126]=8'h55;
  ROM_DATA[127]=8'hAA;
  ROM_DATA[128]=8'h20;
  ROM_DATA[129]=8'h24;
  ROM_DATA[130]=8'h08;
  ROM_DATA[131]=8'h00;
  ROM_DATA[132]=8'h00;
  ROM_DATA[133]=8'h00;
  ROM_DATA[134]=8'h64;
  ROM_DATA[135]=8'h00;
  ROM_DATA[136]=8'h00;
  ROM_DATA[137]=8'h00;
  ROM_DATA[138]=8'h0A;
  ROM_DATA[139]=8'h00;
  ROM_DATA[140]=8'h00;
  ROM_DATA[141]=8'h00;
  ROM_DATA[142]=8'h0D;
  ROM_DATA[143]=8'h0A;
  ROM_DATA[144]=8'h55;
  ROM_DATA[145]=8'hAA;
  ROM_DATA[146]=8'h20;
  ROM_DATA[147]=8'h26;
  ROM_DATA[148]=8'h09;
  ROM_DATA[149]=8'h00;
  ROM_DATA[150]=8'h00;
  ROM_DATA[151]=8'h00;
  ROM_DATA[152]=8'h00;
  ROM_DATA[153]=8'h00;
  ROM_DATA[154]=8'h00;
  ROM_DATA[155]=8'h00;
  ROM_DATA[156]=8'h00;
  ROM_DATA[157]=8'h00;
  ROM_DATA[158]=8'h00;
  ROM_DATA[159]=8'h00;
  ROM_DATA[160]=8'h0D;
  ROM_DATA[161]=8'h0A;
 end
 reg clk=0;always #5 clk=~clk;
 reg rst_n=0,rx=1;
 integer idx,bitn;

 wire hmi_valid;wire [7:0] hmi_cmd;wire signed [31:0] hmi_seq,hmi_arg,hmi_speed;wire hmi_boot;
 hmi_rx #(.CLK_HZ(CLK_HZ)) u_rx(.clk(clk),.rst_n(rst_n),.rx(rx),.restart(1'b0),
   .valid(hmi_valid),.cmd(hmi_cmd),.seq(hmi_seq),.arg(hmi_arg),.speed(hmi_speed),.boot(hmi_boot));

 reg [2:0] state=3;reg [7:0] fault=0;reg calibrated=1,feedback=1,rail=0;reg [2:0] buttons=0;
 reg signed [31:0] arm=0,theta=0,command_angle=0,velocity=0,frequency=0;
 wire ack,start,reset,stop,manual,target_valid,speed_valid,hold_valid;
 wire signed [31:0] aseq,result,mfreq,target_q16;
 wire [6:0] speed_percent;wire [671:0] values;
 wire wave_set,wave_stop,track_request,point_valid;
 wire [1:0] wave_kind;wire [31:0] wave_period_us;
 wire signed [31:0] wave_amp_q16,point_q16;
 wire signed [31:0] goal,reference;
 wire moving,accepted,rejected;wire [1:0] level;
 reg tick=0,run_mode=1;

 hmi_control #(.CLK_HZ(1000000),.RECORD_DEPTH(4)) hmi(
  .clk(clk),.rst_n(rst_n),.us_tick(1'b1),.sample_valid(1'b1),
  .rx_valid(hmi_valid),.cmd(hmi_cmd),.seq(hmi_seq),.arg(hmi_arg),.speed(hmi_speed),.screen_boot(hmi_boot),.rx_source(1'b1),.source_rv(1'b0),
  .state(state),.fault(fault),.calibrated(calibrated),.feedback_ok(feedback),.rail(rail),
  .buttons(buttons),.arm_q16(arm),.theta_q16(theta),.command_q16(command_angle),
  .theta_velocity_q16(velocity),.frequency_q8(frequency),
  .ack_ready(1'b1),.snapshot_sent(1'b0),.ack_valid(ack),.ack_seq(aseq),.ack_result(result),.ack_source(),
  .remote_start(start),.remote_reset(reset),.stop_control(stop),.manual_run(manual),
  .manual_frequency_q8(mfreq),.arm_target_valid(target_valid),.arm_target_q16(target_q16),
  .arm_speed_valid(speed_valid),.arm_speed_percent(speed_percent),.arm_hold_valid(hold_valid),
  .values(values),.signed_pulses(32'sd0),.reference_q16(reference),
  .wave_set(wave_set),.wave_kind(wave_kind),.wave_period_us(wave_period_us),
  .wave_amp_q16(wave_amp_q16),.wave_stop(wave_stop),.track_request(track_request),
  .point_valid(point_valid),.point_q16(point_q16));

 run_target #(.SINE_DEMO(1)) tgt(.clk(clk),.rst_n(rst_n),.clear(1'b0),.tick(tick),
  .run_mode(run_mode),.feedback_valid(feedback),.angle_step(1'b0),.neg_step(1'b0),
  .speed_double(1'b0),.move(1'b0),.alpha_meas(arm),
  .goal_q16(goal),.reference_q16(reference),.moving(moving),.accepted(accepted),.rejected(rejected),
  .speed_level(level),.hmi_target_valid(target_valid),.hmi_target_q16(target_q16),
  .hmi_speed_valid(speed_valid),.hmi_speed_percent(speed_percent),.hmi_hold_valid(hold_valid),
  .amplitude_step(1'b0),.hmi_wave_start(wave_set),.hmi_wave_kind(wave_kind),
  .hmi_wave_period_us(wave_period_us),.hmi_wave_amp_q16(wave_amp_q16),.hmi_wave_stop(wave_stop),
  .hmi_track_mode(track_request),.hmi_point_valid(point_valid),.hmi_point_q16(point_q16));

 task frame;begin @(negedge clk);tick=1;@(negedge clk);tick=0;repeat(10) @(negedge clk);end endtask
 task send_byte;input [7:0] d;begin
  @(negedge clk);rx=0;repeat(BIT_CYCLES) @(negedge clk);
  for(bitn=0;bitn<8;bitn=bitn+1) begin rx=d[bitn];repeat(BIT_CYCLES) @(negedge clk);end
  rx=1;repeat(BIT_CYCLES) @(negedge clk);
 end endtask

 integer i,n,maximum;
 initial begin
  repeat(4) @(negedge clk);rst_n=1;repeat(20) @(negedge clk);

  // 1) 正弦参数帧
  for(i=0;i<18;i=i+1) send_byte(ROM_DATA[i]);
  repeat(400) @(negedge clk);
  if(!tgt.u_sine.active) $fatal(1,"app sine frame did not start the oscillator");
  if(tgt.u_sine.period_us!=2000000) $fatal(1,"period from app frame = %0d",tgt.u_sine.period_us);
  if(tgt.u_sine.kind_active!=2'd0) $fatal(1,"kind from app frame = %0d",tgt.u_sine.kind_active);

  // 2) 轨迹帧：0x25 -> 6 个 0x24 -> 0x26，按上位机真实节奏（约 10ms 一个点）插入控制拍
  for(i=18;i<36;i=i+1) send_byte(ROM_DATA[i]);      // 0x25 轨迹开始
  repeat(50) @(negedge clk);
  if(!track_request) $fatal(1,"0x25 did not enter track mode");
  maximum=-2147483647;
  // 每个轨迹点之间给足控制拍：限速 120 deg/s，控制周期缩短后单点移动量变小，
  // 这里按「约 10ms 一个点」的时间跨度 = 10000us/控制周期 帧数。
  for(n=0;n<6;n=n+1) begin
   for(i=0;i<18;i=i+1) send_byte(ROM_DATA[36+18*n+i]);   // 一个轨迹点
   for(i=0;i<10000/`CFG_CONTROL_PERIOD_US;i=i+1) frame;
   if(reference>maximum) maximum=reference;
  end
  for(i=144;i<162;i=i+1) send_byte(ROM_DATA[i]);     // 0x26 轨迹结束
  repeat(50) @(negedge clk);
  for(n=0;n<10000/`CFG_CONTROL_PERIOD_US;n=n+1) begin frame; if(reference>maximum) maximum=reference; end
  if(track_request) $fatal(1,"0x26 did not leave track mode");
  // 6 个点只给了 18 个控制拍，参考受 120deg/s 限速，能到 ~6deg 即可证明通路正确；
  // 真正的判据是最后一个点(10.0deg)被正确解析并锁存为跟随目标。
  if(tgt.u_sine.track_target<11400 || tgt.u_sine.track_target>11480)
   $fatal(1,"last app point not latched: %0d",tgt.u_sine.track_target);
  if(maximum<5000) $fatal(1,"track points from app frames did not move reference, max=%0d",maximum);

  $display("PASS app frame end-to-end: 9 frames/162B from the PC tool drive period %0d, kind %0d, track peak %0d",
           tgt.u_sine.period_us,tgt.u_sine.kind_active,maximum);
  $finish;
 end
 initial begin #50000000;$fatal(1,"app frame timeout");end
endmodule
