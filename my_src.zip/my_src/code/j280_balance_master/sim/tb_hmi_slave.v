`timescale 1ns/1ps
// ============================================================================
// tb_hmi_slave.v — 双摆从摆链路回归
// ----------------------------------------------------------------------------
// 1) CMD_RAW 透传：HMI 命令 → A5 5A 01 OP AL AH CHK 是否逐字节正确
// 2) 后台轮询：空闲时是否按周期发 A5 5A 01 60 00 00 61
// 3) 遥测解析：OP60 应答的从摆数据是否落进 ts_* 与 RTT
// 4) 语音路径不受影响：done/fail 只在语音命令上产生
// ============================================================================
module tb_hmi_slave;
    localparam integer CLK_HZ  = 25000000;
    localparam integer BAUD    = 115200;
    localparam integer PERIOD  = 10;   // 测试用轮询周期 ms

    reg clk = 0, rst_n = 0;
    always #20 clk = ~clk;              // 25 MHz

    // ---------------- DUT ----------------
    wire        slave_tx_line;
    wire        slave_rx_line;   // 由从板模型的 serial_tx 驱动
    reg         cmd_valid = 0;
    reg  [2:0]  cmd_kind  = 3'd0;
    reg  [7:0]  cmd_arg   = 8'd0;
    reg         cmd_right = 1'b1;
    reg  [7:0]  cmd_op    = 8'd0;
    reg  signed [15:0] cmd_arg16 = 16'sd0;
    wire        busy, done_pulse, fail_pulse;
    wire [2:0]  fail_code_ignored;
    wire signed [15:0] ts_theta, ts_wdot, ts_target, ts_armerr, ts_angerr, ts_refang;
    wire [7:0]  ts_state, ts_flags;
    wire [15:0] ts_rtt_us;
    wire        ts_valid, ts_fresh;

    slave_link #(
        .CLK_HZ(CLK_HZ), .BAUD(BAUD),
        .TELEM_PERIOD_MS(PERIOD), .TELEM_TIMEOUT_MS(6)
    ) dut (
        .clk(clk), .rst_n(rst_n),
        .slave_tx(slave_tx_line), .slave_rx(slave_rx_line),
        .cmd_valid(cmd_valid), .cmd_kind(cmd_kind), .cmd_arg(cmd_arg), .cmd_right(cmd_right),
        .cmd_op(cmd_op), .cmd_arg16(cmd_arg16),
        .busy(busy), .done_pulse(done_pulse), .fail_pulse(fail_pulse), .fail_code(fail_code_ignored),
        .rep_op(), .rep_result(), .rep_state(), .rep_fault(), .rep_flags(),
        .rep_position(), .rep_final(), .rep_active(), .target_shadow(), .fsm_state(),
        .ts_theta(ts_theta), .ts_wdot(ts_wdot), .ts_target(ts_target),
        .ts_armerr(ts_armerr), .ts_angerr(ts_angerr), .ts_refang(ts_refang),
        .ts_state(ts_state), .ts_flags(ts_flags),
        .ts_rtt_us(ts_rtt_us), .ts_valid(ts_valid), .ts_fresh(ts_fresh)
    );

    // ---------------- 从板模型：收 DUT 的命令，回 38 字节应答 ----------------
    wire       m_valid;
    wire [7:0] m_data;
    serial_rx #(.CLK_HZ(CLK_HZ), .BAUD(BAUD)) m_rx (
        .clk(clk), .rst_n(rst_n), .rx(slave_tx_line),
        .data(m_data), .valid(m_valid), .framing_error());

    reg        rtx_start = 0;
    reg  [7:0] rtx_data  = 8'd0;
    wire       rtx_busy, rtx_done;
    serial_tx #(.CLK_HZ(CLK_HZ), .BAUD(BAUD)) m_tx (
        .clk(clk), .rst_n(rst_n), .start(rtx_start), .data(rtx_data),
        .tx(slave_rx_line), .busy(rtx_busy), .done(rtx_done));

    // 收到的帧缓存（最多 8 字节）
    reg [7:0] rxbuf [0:7];
    reg [3:0] rxcnt = 0;
    reg [15:0] gap_timer = 0;          // 字节间隔计时（µs 级：40 个时钟）
    reg [7:0] cur_op = 0;
    reg [7:0] op_hold = 0;
    reg       have_frame = 0;

    // 遥测测试值
    localparam signed [15:0] T_TH  = 16'sd1234;
    localparam signed [15:0] T_WD  = -16'sd56;
    localparam signed [15:0] T_TG  = 16'sd200;
    localparam signed [15:0] T_AE  = -16'sd15;
    localparam signed [15:0] T_GE  = 16'sd7;
    localparam signed [15:0] T_RF  = 16'sd1800;

    integer k;
    reg [15:0] rtt_seen;
    reg        got_op32 = 0, got_poll = 0, got_op38 = 0;
    reg [7:0]  op32_bytes [0:6];
    reg [7:0]  op38_bytes [0:6];

    // 应答发送状态
    reg [5:0]  tx_idx = 0;
    reg        replying = 0;
    reg [7:0]  rep_mem [0:37];
    reg [7:0]  rep_op  = 0;
    reg [7:0]  chk_acc;
    integer    j;

    // 收到完整帧 → 填 38 字节应答表并算校验
    task build_reply;
        input [7:0] op;
        begin
            for (j = 0; j < 38; j = j + 1) rep_mem[j] = 8'h00;
            rep_mem[0] = 8'h5A;
            rep_mem[1] = 8'hA5;
            rep_mem[2] = 8'h01;
            rep_mem[3] = op;
            rep_mem[4] = 8'h00;              // RESULT
            rep_mem[5] = 8'd2;               // state = 稳定保持
            rep_mem[6] = 8'd3;               // flags: bit0 有效 / bit1 允许手动
            rep_mem[7]  = T_TH[7:0];   rep_mem[8]  = T_TH[15:8];
            rep_mem[9]  = T_WD[7:0];   rep_mem[10] = T_WD[15:8];
            rep_mem[11] = T_TG[7:0];   rep_mem[12] = T_TG[15:8];
            rep_mem[13] = T_AE[7:0];   rep_mem[14] = T_AE[15:8];
            rep_mem[15] = T_GE[7:0];   rep_mem[16] = T_GE[15:8];
            rep_mem[17] = T_RF[7:0];   rep_mem[18] = T_RF[15:8];
            rep_mem[19] = 8'h10;       rep_mem[20] = 8'h27;   // position = 10000
            rep_mem[23] = 8'h10;       rep_mem[24] = 8'h27;   // final    = 10000
            rep_mem[25] = 8'h10;       rep_mem[26] = 8'h27;   // active   = 10000
            chk_acc = 8'h00;
            for (j = 2; j <= 36; j = j + 1) chk_acc = chk_acc ^ rep_mem[j];
            rep_mem[37] = chk_acc;
        end
    endtask

    // 收到字节 → 组帧
    always @(posedge clk) if (m_valid) begin
        if (rxcnt < 8) rxbuf[rxcnt] <= m_data;
        rxcnt     <= rxcnt + 1'b1;
        gap_timer <= 0;
    end else if (rxcnt > 0) begin
        if (gap_timer < 16'd4000) gap_timer <= gap_timer + 1'b1;
        else have_frame <= 1;               // 500 个时钟（20 µs）无字节＝帧结束
    end

    // 帧判定 + 准备应答
    always @(posedge clk) begin
        if (!rst_n) begin
            rxcnt <= 0; gap_timer <= 0; have_frame <= 0; replying <= 0; tx_idx <= 0;
        end else begin
            rtx_start <= 1'b0;
            if (have_frame) begin
                have_frame <= 0;
                rxcnt      <= 0;
                if (rxbuf[0] == 8'hA5 && rxbuf[1] == 8'h5A && rxbuf[2] == 8'h01) begin
                    if (rxbuf[3] == 8'h32) begin
                        for (k = 0; k < 7; k = k + 1) op32_bytes[k] <= rxbuf[k];
                        got_op32 <= 1;
                    end
                    if (rxbuf[3] == 8'h38) begin
                        for (k = 0; k < 7; k = k + 1) op38_bytes[k] <= rxbuf[k];
                        got_op38 <= 1;
                    end
                    if (rxbuf[3] == 8'h60) got_poll <= 1;
                    build_reply(rxbuf[3]);
                    tx_idx   <= 6'd0;
                    replying <= 1'b1;
                end
            end

            if (replying) begin
                if (rtx_done) begin
                    if (tx_idx == 6'd37) replying <= 1'b0;
                    else                 tx_idx   <= tx_idx + 1'b1;
                end else if (!rtx_busy && !rtx_start) begin
                    rtx_data  <= rep_mem[tx_idx];
                    rtx_start <= 1'b1;
                end
            end
        end
    end

    // ---------------- 激励 ----------------
    integer errors = 0;
    task issue_raw;
        input [7:0] op;
        input signed [15:0] a;
        begin
            @(posedge clk);
            cmd_op    <= op;
            cmd_arg16 <= a;
            cmd_kind  <= 3'd6;
            cmd_valid <= 1'b1;
            @(posedge clk);
            cmd_valid <= 1'b0;
        end
    endtask

    initial begin
        $display("  [0] start, clk=%0d Hz", CLK_HZ);
        rst_n = 0;
        repeat (20) @(posedge clk);
        rst_n = 1;
        repeat (200) @(posedge clk);

        // --- 1) 透传 0x32（摆角目标 24.56° = 2456）---
        issue_raw(8'h32, 16'sd2456);
        wait (got_op32);
        repeat (10) @(posedge clk);
        if (op32_bytes[0] !== 8'hA5 || op32_bytes[1] !== 8'h5A || op32_bytes[2] !== 8'h01) begin
            $display("FAIL raw frame prefix: %02x %02x %02x", op32_bytes[0], op32_bytes[1], op32_bytes[2]);
            errors = errors + 1;
        end
        if (op32_bytes[3] !== 8'h32 || op32_bytes[4] !== 8'h98 || op32_bytes[5] !== 8'h09) begin
            $display("FAIL raw frame payload: op=%02x al=%02x ah=%02x",
                     op32_bytes[3], op32_bytes[4], op32_bytes[5]);
            errors = errors + 1;
        end
        if (op32_bytes[6] !== (8'h01 ^ 8'h32 ^ 8'h98 ^ 8'h09)) begin
            $display("FAIL raw frame check: %02x", op32_bytes[6]);
            errors = errors + 1;
        end else $display("  [1] raw op32 frame OK: A5 5A 01 32 %02x %02x %02x",
                          op32_bytes[4], op32_bytes[5], op32_bytes[6]);

        // --- 2) 等后台轮询，检查遥测解析 ---
        wait (ts_valid);
        repeat (100) @(posedge clk);
        if (!got_poll) begin $display("FAIL no OP60 poll seen"); errors = errors + 1; end
        else $display("  [2] background poll OP60 sent");

        if (ts_theta !== T_TH)  begin $display("FAIL ts_theta=%0d", ts_theta); errors = errors + 1; end
        if (ts_wdot  !== T_WD)  begin $display("FAIL ts_wdot=%0d", ts_wdot);   errors = errors + 1; end
        if (ts_target!== T_TG)  begin $display("FAIL ts_target=%0d", ts_target); errors = errors + 1; end
        if (ts_armerr!== T_AE)  begin $display("FAIL ts_armerr=%0d", ts_armerr); errors = errors + 1; end
        if (ts_angerr!== T_GE)  begin $display("FAIL ts_angerr=%0d", ts_angerr); errors = errors + 1; end
        if (ts_refang!== T_RF)  begin $display("FAIL ts_refang=%0d", ts_refang); errors = errors + 1; end
        if (ts_state !== 8'd2 || ts_flags !== 8'd3) begin
            $display("FAIL ts_state/flags = %0d/%0d", ts_state, ts_flags); errors = errors + 1;
        end
        if (ts_rtt_us == 0) begin $display("FAIL ts_rtt_us = 0"); errors = errors + 1; end
        else $display("  [3] telemetry parsed: theta=%0d wdot=%0d target=%0d armerr=%0d angerr=%0d ref=%0d rtt=%0dus",
                      ts_theta, ts_wdot, ts_target, ts_armerr, ts_angerr, ts_refang, ts_rtt_us);

        // --- 3) 位置协同 0x38 arg=1 ---
        issue_raw(8'h38, 16'sd1);
        wait (got_op38);
        repeat (10) @(posedge clk);
        if (op38_bytes[3] !== 8'h38 || op38_bytes[4] !== 8'h01 || op38_bytes[6] !== (8'h01 ^ 8'h38 ^ 8'h01))
            begin $display("FAIL sync frame: %02x %02x %02x", op38_bytes[4], op38_bytes[5], op38_bytes[6]); errors = errors + 1; end
        else $display("  [4] sync op38 frame OK");

        // --- 4) 透传命令不得产生语音侧的 done/fail 脉冲 ---
        //      （上面 0x32/0x38 都没有脉冲，这里只做一次确认）
        repeat (2000) @(posedge clk);

        if (errors == 0) $display("PASS dual-pendulum slave link: pass-through frames, poll, telemetry, RTT");
        else             $display("FAIL dual-pendulum slave link: %0d errors", errors);
        $finish;
    end

    // 任何时刻 CMD_RAW/CMD_POLL 都不应给出 done/fail 脉冲
    always @(posedge clk) if (rst_n && (done_pulse || fail_pulse) && cmd_kind == 3'd6) begin
        $display("FAIL CMD_RAW produced done/fail pulse");
        errors = errors + 1;
    end

    // 看门狗：仿真卡住时也要出结果
    initial begin
        #60_000_000;
        $display("FAIL timeout: got_op32=%0b got_poll=%0b ts_valid=%0b busy=%0b rxcnt=%0d",
                  got_op32, got_poll, ts_valid, busy, rxcnt);
        $finish;
    end
endmodule
