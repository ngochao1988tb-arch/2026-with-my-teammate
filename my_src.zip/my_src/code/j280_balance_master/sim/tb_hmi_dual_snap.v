`timescale 1ns/1ps
`include "control_config.vh"
// ============================================================================
// tb_hmi_dual_snap.v — 从摆遥测进 ASCII 快照的端到端验证
// ----------------------------------------------------------------------------
// top（真实 lqr_system + hmi_tx）→ 串口屏口 K22/L22 输出 ASCII 快照；
// 从板口 V8/V9 接一个从板模型，回答 OP60 遥测。
// 断言：快照里必须出现 gsttheta/gstangerr/gstarmerr/gsttarget/gstwt/gsstate/
//       gsvalid/gspermit/glinkh/grttus/gsync/gsrefang，且数值等于模型给的数。
// 时钟统一按 1.152 MHz 计（测试时钟 100 MHz → 10 拍/bit），仿真快 25 倍。
// ============================================================================
module tb_hmi_dual_snap;
    localparam TB_CLK_HZ = 1152000;
    reg clk = 0, rst_n = 0;
    always #5 clk = ~clk;                       // 100 MHz

    reg rx_pc = 1, rx_scr = 1;
    wire pul, dir, ena, mtx, aclk, oe, tx_pc, tx_scr, slave_tx_line;
    wire slave_rx_line;

    top #(.PC_DEBUG_EN(0)) dut (
        .clk_50m(clk), .rst_n(rst_n), .key_sw(4'b1111),
        .pul_out(pul), .dir_out(dir), .ena_out(ena),
        .motor_rx(1'b1), .motor_tx(mtx), .adc_clk(aclk), .adc_oe_n(oe), .adc_data_in(10'd466),
        .hmi_rx(rx_pc), .hmi_tx(tx_pc), .screen_rx(rx_scr), .screen_tx(tx_scr),
        .slave_rx(slave_rx_line), .slave_tx(slave_tx_line),
        .voice_rx(1'b1), .voice_tx(), .telemetry_tx());

    defparam dut.u_lqr.u_hmi_rx_pc.CLK_HZ     = TB_CLK_HZ;
    defparam dut.u_lqr.u_hmi_rx_screen.CLK_HZ = TB_CLK_HZ;
    defparam dut.u_lqr.u_hmi_tx_pc.CLK_HZ     = TB_CLK_HZ;
    defparam dut.u_lqr.u_hmi_tx_screen.CLK_HZ = TB_CLK_HZ;
    defparam dut.u_lqr.u_slave_link.CLK_HZ    = TB_CLK_HZ;

    // ---------------- 从板模型 ----------------
    localparam signed [15:0] T_TH = 16'sd1234;      // 12.34°
    localparam signed [15:0] T_WD = -16'sd56;       // -5.6 °/s
    localparam signed [15:0] T_TG = 16'sd200;       // 2.00°
    localparam signed [15:0] T_AE = -16'sd15;       // -0.15°
    localparam signed [15:0] T_GE = 16'sd7;         // 0.07°
    localparam signed [15:0] T_RF = 16'sd1800;      // 18.00°

    wire       m_valid;
    wire [7:0] m_data;
    serial_rx #(.CLK_HZ(TB_CLK_HZ), .BAUD(115200)) m_rx (
        .clk(clk), .rst_n(rst_n), .rx(slave_tx_line),
        .data(m_data), .valid(m_valid), .framing_error());

    reg        rtx_start = 0;
    reg  [7:0] rtx_data  = 0;
    wire       rtx_busy, rtx_done;
    serial_tx #(.CLK_HZ(TB_CLK_HZ), .BAUD(115200)) m_tx (
        .clk(clk), .rst_n(rst_n), .start(rtx_start), .data(rtx_data),
        .tx(slave_rx_line), .busy(rtx_busy), .done(rtx_done));

    reg  [7:0]  rxbuf [0:7];
    reg  [3:0]  rxcnt = 0;
    reg  [15:0] gap_timer = 0;
    reg         have_frame = 0;
    reg  [7:0]  rep_mem [0:37];
    reg  [5:0]  tx_idx = 0;
    reg         replying = 0;
    reg  [7:0]  chk_acc;
    integer     j;
    integer     poll_count = 0;

    task build_reply;
        input [7:0] op;
        begin
            for (j = 0; j < 38; j = j + 1) rep_mem[j] = 8'h00;
            rep_mem[0] = 8'h5A; rep_mem[1] = 8'hA5; rep_mem[2] = 8'h01; rep_mem[3] = op;
            rep_mem[4] = 8'h00;              // RESULT
            rep_mem[5] = 8'd2;               // state = 稳定保持
            rep_mem[6] = 8'd3;               // flags: 有效 + 允许手动
            rep_mem[7]  = T_TH[7:0];   rep_mem[8]  = T_TH[15:8];
            rep_mem[9]  = T_WD[7:0];   rep_mem[10] = T_WD[15:8];
            rep_mem[11] = T_TG[7:0];   rep_mem[12] = T_TG[15:8];
            rep_mem[13] = T_AE[7:0];   rep_mem[14] = T_AE[15:8];
            rep_mem[15] = T_GE[7:0];   rep_mem[16] = T_GE[15:8];
            rep_mem[17] = T_RF[7:0];   rep_mem[18] = T_RF[15:8];
            rep_mem[19] = 8'h10; rep_mem[20] = 8'h27;
            rep_mem[23] = 8'h10; rep_mem[24] = 8'h27;
            rep_mem[25] = 8'h10; rep_mem[26] = 8'h27;
            chk_acc = 8'h00;
            for (j = 2; j <= 36; j = j + 1) chk_acc = chk_acc ^ rep_mem[j];
            rep_mem[37] = chk_acc;
        end
    endtask

    always @(posedge clk) if (m_valid) begin
        if (rxcnt < 8) rxbuf[rxcnt] <= m_data;
        rxcnt     <= rxcnt + 1'b1;
        gap_timer <= 0;
    end else if (rxcnt > 0) begin
        if (gap_timer < 16'd4000) gap_timer <= gap_timer + 1'b1;
        else have_frame <= 1;
    end

    always @(posedge clk) begin
        if (!rst_n) begin
            rxcnt <= 0; gap_timer <= 0; have_frame <= 0; replying <= 0; tx_idx <= 0;
        end else begin
            rtx_start <= 1'b0;
            if (have_frame) begin
                have_frame <= 0;
                rxcnt      <= 0;
                if (rxbuf[0] == 8'hA5 && rxbuf[1] == 8'h5A && rxbuf[2] == 8'h01) begin
                    if (rxbuf[3] == 8'h60) poll_count = poll_count + 1;
                    build_reply(rxbuf[3]);
                    tx_idx   <= 6'd0;
                    replying <= 1'b1;
                end
            end
            if (replying) begin
                if (rtx_done) begin
                    if (tx_idx == 6'd37) replying <= 1'b0;
                    else                 tx_idx   <= tx_idx + 1'b1;
                end else if (!rtx_busy && !rtx_start) begin
                    rtx_data  <= rep_mem[tx_idx];
                    rtx_start <= 1'b1;
                end
            end
        end
    end

    // ---------------- 抓串口屏口的 ASCII 快照 ----------------
    wire       b_scr;
    wire [7:0] byte_scr;
    serial_rx #(.CLK_HZ(TB_CLK_HZ), .BAUD(115200)) mon_scr (
        .clk(clk), .rst_n(rst_n), .rx(tx_scr), .data(byte_scr), .valid(b_scr), .framing_error());

    reg [7:0] cap [0:4095];
    integer   cap_n = 0;
    integer   ghb_count = 0;
    reg [47:0] win = 0;
    always @(posedge clk) if (b_scr) begin
        // 每帧快照都以 gtheta= 开头：一见到就从头记录，缓冲区永远只有最近一帧
        if ({win[39:0], byte_scr} == "gtheta") cap_n = 0;
        if ({win[23:0], byte_scr} == "ghb=")   ghb_count = ghb_count + 1;
        win <= {win[39:0], byte_scr};
        if (cap_n < 4096) begin
            cap[cap_n] = byte_scr;
            cap_n = cap_n + 1;
        end
    end

    // 在捕获缓冲里找 "名字="，回读其后的十进制（有符号）
    function integer find_field;
        input [119:0] nm;         // 最多 15 字符名字
        input integer nlen;
        integer i, k2;
        reg hit;
        reg neg;
        integer val;
        begin
            find_field = -99999;
            for (i = 0; i + nlen < cap_n; i = i + 1) begin
                hit = 1;
                for (k2 = 0; k2 < nlen; k2 = k2 + 1)
                    if (cap[i + k2] !== nm[(nlen-1-k2)*8 +: 8]) hit = 0;
                if (hit && cap[i + nlen] == 8'h3d) begin
                    k2 = i + nlen + 1;
                    neg = 0;
                    if (cap[k2] == 8'h2d) begin neg = 1; k2 = k2 + 1; end
                    val = 0;
                    while (cap[k2] >= 8'h30 && cap[k2] <= 8'h39) begin
                        val = val * 10 + (cap[k2] - 8'h30);
                        k2 = k2 + 1;
                    end
                    find_field = neg ? -val : val;
                    i = cap_n;         // 只取第一处
                end
            end
        end
    endfunction

    integer errors = 0;
    task check;
        input [119:0] nm;
        input integer nlen;
        input integer want;
        input [255:0] tag;
        integer got;
        begin
            got = find_field(nm, nlen);
            if (got !== want) begin
                $display("FAIL %0s: got %0d want %0d", tag, got, want);
                errors = errors + 1;
            end else
                $display("  [OK] %0s = %0d", tag, got);
        end
    endtask

    initial begin
        rst_n = 0;
        repeat (20) @(negedge clk);
        rst_n = 1;
        // 让从板链路握手、轮询几轮，再收满 3 帧完整快照
        wait (ghb_count >= 3);
        #1000;
        $display("  slave poll frames seen: %0d, snapshot bytes in window: %0d", poll_count, cap_n);
        if (poll_count == 0) begin $display("FAIL 从板口没有 OP60 轮询"); errors = errors + 1; end
        if (cap_n < 300)     begin $display("FAIL 快照太短，hmi_tx 可能没跑"); errors = errors + 1; end

        check("gsttheta",  8, 1234, "gsttheta (12.34°)");
        check("gstangerr", 9, 7,    "gstangerr (0.07°)");
        check("gstarmerr", 9, -15,  "gstarmerr (-0.15°)");
        check("gsttarget", 9, 200,  "gsttarget (2.00°)");
        check("gstwt",     5, -56,  "gstwt (-5.6 °/s)");
        check("gsstate",   7, 2,    "gsstate (稳定保持)");
        check("gsvalid",   7, 1,    "gsvalid");
        check("gspermit",  8, 1,    "gspermit");
        check("glinkh",    6, 1,    "glinkh (板间链路正常)");
        check("gsync",     5, 0,    "gsync");
        check("gsrefang",  8, 1800, "gsrefang (18.00°)");
        // 主摆字段必须还在（顺序没被破坏）
        check("gstate",    6, 0,    "gstate (主摆)");
        check("ghb",       3, find_field("ghb", 3), "ghb 存在");
        if (find_field("grttus", 6) <= 0) begin
            $display("FAIL grttus 未上报 (%0d)", find_field("grttus", 6));
            errors = errors + 1;
        end else $display("  [OK] grttus = %0d us", find_field("grttus", 6));

        if (errors == 0) $display("PASS dual-pendulum telemetry in ASCII snapshot");
        else             $display("FAIL dual-pendulum telemetry: %0d errors", errors);
        $finish;
    end

    initial begin
        #20_000_000;
        $display("FAIL timeout: polls=%0d bytes=%0d", poll_count, cap_n);
        $finish;
    end
endmodule
