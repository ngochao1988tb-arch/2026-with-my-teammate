// =============================================================================
// lcd_model.v  --  8080 并口控制器行为模型（用于仿真验证）
//
// 作用：
//   1) 按 8080 时序在 WR 上升沿锁存数据（与真实控制器的采样点一致）
//   2) 实现最小命令集：0x01 SWRESET / 0x11 SLPOUT / 0x3A COLMOD /
//      0x36 MADCTL / 0x2A CASET / 0x2B RASET / 0x2C RAMWR
//   3) 把像素写进内部帧存，结束时 dump 成 RGB565 小端裸数据，供 Python 出图
//   4) 检查 tAS / tPW / tDS / tDH / tIDLE，统计违例次数
//
// 这不是某个具体型号的完整模型：只覆盖本项目用到的命令，其余命令按"记录参数"
// 处理。它的价值是"验证时序和像素流"，不是"验证某颗控制器的寄存器语义"。
// =============================================================================
`timescale 1ns/1ps

module lcd_model #(
    parameter integer DW        = 16,
    parameter integer PANEL_W   = 320,
    parameter integer PANEL_H   = 240,
    parameter integer EXP_TAS   = 2,     // 期望的最小建立时间（周期）
    parameter integer EXP_TDS   = 2,
    parameter integer EXP_TPW   = 4,
    parameter integer EXP_TDH   = 2,
    parameter integer EXP_TIDLE = 2,
    parameter integer CLK_NS    = 20,
    parameter         DUMP_FILE = "fb.bin"
)(
    input  wire              clk,
    input  wire              rst_n,
    input  wire              cs_n,
    input  wire              wr_n,
    input  wire              rd_n,
    input  wire              rs,
    inout  wire [DW-1:0]     data
);

    // ------------------------------------------------------------------
    // 帧存
    // ------------------------------------------------------------------
    reg [15:0] fb [0:PANEL_W*PANEL_H-1];
    integer    fb_writes;

    integer xs, xe, ys, ye;      // 当前窗口
    integer cx, cy;              // 写指针
    integer win_x0, win_y0;      // RAMWR 起始
    reg     in_ramwr;

    integer cmd;                 // 当前命令
    integer param_idx;
    integer params [0:7];
    reg [7:0] byte_hi;           // 8 位模式下拼接像素
    integer pix_lo;              // 8 位模式下低字节标志

    // 时序测量
    time t_cs_fall, t_wr_fall, t_wr_rise, t_data_change, t_rs_change, t_cs_rise;
    time min_as, min_pw, min_ds, min_dh, min_idle;
    integer err_as, err_pw, err_ds, err_dh, err_idle;
    integer n_writes, n_reads;
    integer k;
    reg     wr_seen;

    // 读时序：RD 低时由"面板"驱动数据总线
    reg [DW-1:0] rd_val;
    assign data = (cs_n == 1'b0 && rd_n == 1'b0) ? rd_val : {DW{1'bz}};

    localparam time NS = 1;

    initial begin
        xs = 0; xe = PANEL_W-1; ys = 0; ye = PANEL_H-1;
        cx = 0; cy = 0; in_ramwr = 0;
        cmd = -1; param_idx = 0;
        fb_writes = 0;
        pix_lo = 0; byte_hi = 0;
        t_cs_fall = 0; t_wr_fall = 0; t_wr_rise = 0;
        t_data_change = 0; t_rs_change = 0; t_cs_rise = 0;
        min_as = 1000000; min_pw = 1000000; min_ds = 1000000;
        min_dh = 1000000; min_idle = 1000000;
        err_as = 0; err_pw = 0; err_ds = 0; err_dh = 0; err_idle = 0;
        n_writes = 0; n_reads = 0;
        rd_val = 16'h5AA5;
        wr_seen = 0;
        $timeformat(-9, 0, " ns", 8);
        for (k = 0; k < PANEL_W*PANEL_H; k = k + 1) fb[k] = 16'h0000;
    end

    // 数据/RS 变化时间戳（用于测建立/保持）
    always @(data) begin
        t_data_change = $time;
    end
    always @(rs) begin
        t_rs_change = $time;
    end

    // ------------------------------------------------------------------
    // 写时序检查与数据锁存
    // ------------------------------------------------------------------
    always @(negedge cs_n) begin
        t_cs_fall = $time;
        wr_seen   = 0;
        if (t_cs_rise != 0 && (($time - t_cs_rise) < EXP_TIDLE * CLK_NS)) begin
            err_idle = err_idle + 1;
            $display("[LCD_MODEL] %0t ns: tIDLE violation (%0d ns < %0d ns)",
                     $time, $time - t_cs_rise, EXP_TIDLE * CLK_NS);
        end
    end

    always @(posedge cs_n) begin
        t_cs_rise = $time;
        if (wr_seen && (($time - t_wr_rise) < EXP_TDH * CLK_NS)) begin
            err_dh = err_dh + 1;
            $display("[LCD_MODEL] %0t ns: tDH violation (%0d ns < %0d ns)",
                     $time, $time - t_wr_rise, EXP_TDH * CLK_NS);
        end
    end

    always @(negedge wr_n) begin
        t_wr_fall = $time;
        if (cs_n == 1'b0) wr_seen = 1;
        if (($time - t_cs_fall) < EXP_TAS * CLK_NS) begin
            err_as = err_as + 1;
            $display("[LCD_MODEL] %0t ns: tAS violation (%0d ns < %0d ns)",
                     $time, $time - t_cs_fall, EXP_TAS * CLK_NS);
        end
        if (($time - t_data_change) < EXP_TDS * CLK_NS) begin
            err_ds = err_ds + 1;
            $display("[LCD_MODEL] %0t ns: tDS violation (%0d ns < %0d ns)",
                     $time, $time - t_data_change, EXP_TDS * CLK_NS);
        end
        if (($time - t_cs_fall) < min_as) min_as = $time - t_cs_fall;
        if (($time - t_data_change) < min_ds) min_ds = $time - t_data_change;
    end

    // 8080: 控制器在 WR 上升沿采样数据
    always @(posedge wr_n) begin
        t_wr_rise = $time;
        if (cs_n == 1'b0) begin
            n_writes = n_writes + 1;
            if (($time - t_wr_fall) < EXP_TPW * CLK_NS) begin
                err_pw = err_pw + 1;
                $display("[LCD_MODEL] %0t ns: tPW violation (%0d ns < %0d ns)",
                         $time, $time - t_wr_fall, EXP_TPW * CLK_NS);
            end
            if (($time - t_wr_fall) < min_pw) min_pw = $time - t_wr_fall;
            take_word(rs, data);
        end
    end

    always @(posedge rd_n) begin
        if (cs_n == 1'b0) n_reads = n_reads + 1;
    end

    // ------------------------------------------------------------------
    // 命令解析
    // ------------------------------------------------------------------
    task take_word;
        input       rs_bit;
        input [DW-1:0] d;
        integer v;
        begin
            v = d;
            if (rs_bit == 1'b0) begin
                cmd       = v;
                param_idx = 0;
                in_ramwr  = (v == 8'h2C);
                if (v == 8'h2C) begin
                    cx = win_x0;
                    cy = win_y0;
                end
                if (v == 8'h01) begin
                    xs = 0; xe = PANEL_W-1; ys = 0; ye = PANEL_H-1;
                    in_ramwr = 0;
                end
            end else begin
                if (in_ramwr) begin
                    // 像素数据
                    if (DW == 16) begin
                        put_pixel(v[15:0]);
                    end else begin
                        if (pix_lo == 0) begin
                            byte_hi = v[7:0];
                            pix_lo  = 1;
                        end else begin
                            put_pixel({byte_hi, v[7:0]});
                            pix_lo = 0;
                        end
                    end
                end else begin
                    if (param_idx < 8) params[param_idx] = v;
                    case (cmd)
                        8'h2A: begin
                            if (param_idx == 3) begin
                                xs = (params[0] << 8) | params[1];
                                xe = (params[2] << 8) | params[3];
                                win_x0 = xs;
                            end
                        end
                        8'h2B: begin
                            if (param_idx == 3) begin
                                ys = (params[0] << 8) | params[1];
                                ye = (params[2] << 8) | params[3];
                                win_y0 = ys;
                            end
                        end
                        default: ;
                    endcase
                    param_idx = param_idx + 1;
                end
            end
        end
    endtask

    task put_pixel;
        input [15:0] p;
        begin
            if (cx >= 0 && cx < PANEL_W && cy >= 0 && cy < PANEL_H) begin
                fb[cy*PANEL_W + cx] = p;
                fb_writes = fb_writes + 1;
            end
            cx = cx + 1;
            if (cx > xe) begin
                cx = xs;
                cy = cy + 1;
                if (cy > ye) cy = ys;   // 循环回卷（不关心，正常流不会触发）
            end
        end
    endtask

    // ------------------------------------------------------------------
    // 统计与导出
    // ------------------------------------------------------------------
    task report;
        begin
            $display("[LCD_MODEL] writes=%0d reads=%0d pixels=%0d", n_writes, n_reads, fb_writes);
            $display("[LCD_MODEL] min tAS=%0d ns  tDS=%0d ns  tPW=%0d ns (period %0d ns)",
                     min_as, min_ds, min_pw, CLK_NS);
            $display("[LCD_MODEL] violations: tAS=%0d tDS=%0d tPW=%0d tDH=%0d tIDLE=%0d",
                     err_as, err_ds, err_pw, err_dh, err_idle);
            if (err_as + err_ds + err_pw + err_dh + err_idle != 0)
                $display("[LCD_MODEL] *** TIMING CHECK FAILED ***");
        end
    endtask

    task dump_fb;
        integer f, i;
        begin
            f = $fopen(DUMP_FILE, "wb");
            if (f == 0) begin
                $display("[LCD_MODEL] cannot open %s", DUMP_FILE);
            end else begin
                for (i = 0; i < PANEL_W*PANEL_H; i = i + 1) begin
                    $fwrite(f, "%c", fb[i][7:0]);
                    $fwrite(f, "%c", fb[i][15:8]);
                end
                $fclose(f);
                $display("[LCD_MODEL] dumped %0d pixels to %s", PANEL_W*PANEL_H, DUMP_FILE);
            end
        end
    endtask

endmodule
