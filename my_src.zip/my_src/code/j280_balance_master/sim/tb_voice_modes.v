`timescale 1ns/1ps
// Actual UART frames -> persistent mode -> coordinator local/remote dispatch.
module tb_voice_modes;
    reg clk=0, rst_n=0, rx=1;
    always #5 clk=~clk;
    // 10 clocks/bit; simulated clock frequency is scaled for fast long waits.
    localparam CLK_HZ=100000, BAUD=10000, BIT_NS=100;
    wire tx, cmd_valid, rejected, latched, timeout_pulse;
    wire [1:0] mode, mask, reason;
    wire [3:0] action;
    wire [7:0] id, angle;
    wire right, lv, rv, ready;
    reg ld=0, rd=0;
    integer local_count=0, remote_count=0, errors=0;
    reg [3:0] last_local_action, last_remote_action;
    reg [7:0] last_local_angle, last_remote_angle;
    wire [3:0] la, ra;
    wire [7:0] lang, rang;
    voice_uart_bridge #(.CLK_HZ(CLK_HZ), .BAUD(BAUD),
        .TARGET_TIMEOUT_MS(3)) bridge (
        .clk(clk), .rst_n(rst_n), .voice_uart_rx_y15(rx), .voice_uart_tx_y14(tx),
        .target_mask(mode), .target_timeout(timeout_pulse),
        .command_valid(cmd_valid), .command_target_mask(mask), .action_code(action),
        .command_id(id), .move_angle(angle), .move_right(right),
        .command_rejected(rejected), .reject_reason(reason), .estop_latched(latched),
        .play_req(1'b0), .play_id(8'd0)
    );
    voice_dual_coordinator #(.CLK_HZ(CLK_HZ), .ACTION_TIMEOUT_MS(10000)) coord (
        .clk(clk), .rst_n(rst_n), .command_valid(cmd_valid),
        .command_target_mask(mask), .command_action(action), .command_id(id),
        .command_angle(angle), .command_right(right),
        .local_done(ld), .local_fail(1'b0), .remote_done(rd), .remote_fail(1'b0),
        .local_cmd_valid(lv), .remote_cmd_valid(rv), .local_action(la),
        .remote_action(ra), .local_angle(lang), .remote_angle(rang), .ready(ready)
    );
    reg saw_reject=0, saw_timeout=0;
    always @(posedge clk) begin
        if (lv) begin
            local_count <= local_count+1;
            last_local_action <= la; last_local_angle <= lang;
        end
        if (rv) begin
            remote_count <= remote_count+1;
            last_remote_action <= ra; last_remote_angle <= rang;
        end
        if (rejected) saw_reject<=1;
        if (timeout_pulse) saw_timeout<=1;
    end
    task check(input cond, input [639:0] msg);
        begin
            if (cond !== 1'b1) begin $display("FAIL: %0s",msg); errors=errors+1; end
            else $display("ok: %0s",msg);
        end
    endtask
    task byte_tx(input [7:0] data);
        integer i;
        begin
            rx=0; #(BIT_NS);
            for(i=0;i<8;i=i+1) begin rx=data[i]; #(BIT_NS); end
            rx=1; #(BIT_NS);
        end
    endtask
    task word_tx(input [7:0] data);
        begin
            @(negedge clk);
            byte_tx(8'hAA); byte_tx(8'h55); byte_tx(8'h00);
            byte_tx(data); byte_tx(8'hFB);
            repeat(12) @(negedge clk);
        end
    endtask
    task finish_action;
        begin
            @(negedge clk); ld=1; rd=1;
            @(negedge clk); ld=0; rd=0;
            repeat(4) @(negedge clk);
            check(ready,"coordinator ready after completion");
        end
    endtask
    initial begin
        repeat(4) @(negedge clk); rst_n=1;
        word_tx(8'hB3);
        check(saw_reject && local_count==0 && remote_count==0,"no mode rejects motion");
        word_tx(8'hB0);
        check(mode==1 && local_count==0 && remote_count==0,"B0 selects main without moving");
        // 400000 clocks at CLK_HZ=100000 represent 4000ms, exceeding
        // both the configured legacy 3ms window and the old production 3s.
        repeat(400000) @(negedge clk);
        check(mode==1 && !saw_timeout,"mode persists beyond old 3s timeout");
        word_tx(8'hB3);
        check(local_count==1 && remote_count==0 && last_local_action==1,"main swing dispatch");
        check(mode==1,"action preserves selected mode"); finish_action;
        word_tx(8'hC6);
        check(local_count==2 && remote_count==0 && last_local_action==6 && last_local_angle==30,
            "second action without reselection: main right 30"); finish_action;
        word_tx(8'hB1);
        check(mode==2,"B1 replaces main, does not OR into both");
        word_tx(8'h86);
        check(local_count==2 && remote_count==1 && last_remote_action==5 && last_remote_angle==30,
            "slave left 30 dispatch"); finish_action;
        word_tx(8'hB2); check(mode==3,"B2 selects both");
        word_tx(8'h40);
        check(local_count==3 && remote_count==2,"both swing dispatch");
        // Switch while busy: must not retarget the action already in flight.
        word_tx(8'hB0); check(mode==1,"mode switch while action in flight");
        check(coord.target_latched==3,"in-flight action keeps original both target"); finish_action;
        word_tx(8'h43);
        check(local_count==4 && remote_count==2,"next balance action uses new main mode"); finish_action;
        word_tx(8'hFF); check(mode==1,"unknown word preserves mode");
        // Stop must bypass busy and mode, and remain latched until reset.
        word_tx(8'hB3);
        word_tx(8'h41);
        check(local_count==6 && remote_count==3 && latched && mode==1,
            "stop preempts busy action on both, retaining mode");
        word_tx(8'hC6);
        check(local_count==6 && remote_count==3,"latched stop blocks motion");
        word_tx(8'h42);
        check(!latched && mode==1 && local_count==7 && remote_count==3,"voice reset retains main mode");
        finish_action;
        @(negedge clk); rst_n=0;
        repeat(4) @(negedge clk); rst_n=1;
        check(mode==0,"hardware reset clears selected mode");
        word_tx(8'h41);
        check(local_count==8 && remote_count==4 && latched,"stop works even without mode");
        if(errors) $fatal(1,"voice modes: %0d failures",errors);
        $display("PASS: UART persistent modes and dispatch"); $finish;
    end
    initial begin #20000000; $fatal(1,"simulation timeout"); end
endmodule
