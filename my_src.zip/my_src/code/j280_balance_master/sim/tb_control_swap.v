`timescale 1ns/1ps
// ============================================================================
// tb_control_swap.v —— 控制内核替换后的定点回归（iverilog）
// ----------------------------------------------------------------------------
// 只测本次手工合并/新增的部分，不依赖 ADC 与编码器链：
//   1) run_target + sine_reference：上位机波形装载 → 纯正弦 → 前馈采样有效
//   2) 手写轨迹模式：前馈必须失效（sample_amplitude=0 / ff_active=0）
//   3) CAPTURE_HOLD：捕获脉冲把 goal/reference 就地锁存到 alpha_meas
//   4) sine_feedforward：拿到采样后 correction_q16 非零且被限幅
// 运行：iverilog -g2005-sv -I../src -o tb_control_swap.vvp tb_control_swap.v && vvp tb_control_swap.vvp
// ============================================================================
module tb_control_swap;
    reg clk=0,rst_n=0;
    always #20 clk=~clk;              // 25 MHz

    localparam integer TICK_CYCLES=50;
    integer cyc=0;
    reg tick=0;

    // ---------------- run_target + sine_reference ----------------
    reg  wave_start=0,wave_stop=0,track=0,point_valid=0,capture_hold=0;
    reg  [1:0] kind=2'd0;
    reg  [31:0] set_period=32'd10000000;
    reg  signed [31:0] set_amp=32'sd68650;      // ~60 deg in Q16
    reg  signed [31:0] point_q16=32'sd0;
    reg  signed [31:0] alpha_meas=32'sd1000;
    reg  clear=0;
    wire signed [31:0] goal,refangle;
    wire moving,accepted,rejected;
    wire [1:0] speed_level;
    wire sine_sample_valid,sine_running,sine_ff_active;
    wire [31:0] sine_sample_phase,sine_sample_period;
    wire signed [31:0] sine_sample_amplitude,sine_ff_q16;

    run_target #(.SINE_DEMO(0),.WAVE_EN(1),.CAPTURE_HOLD(1)) dut(
        .clk(clk),.rst_n(rst_n),.clear(clear),.tick(tick),.run_mode(1'b1),.feedback_valid(1'b1),
        .angle_step(1'b0),.neg_step(1'b0),.speed_double(1'b0),.move(1'b0),
        .alpha_meas(alpha_meas),.goal_q16(goal),.reference_q16(refangle),.moving(moving),
        .accepted(accepted),.rejected(rejected),.speed_level(speed_level),
        .hmi_target_valid(1'b0),.hmi_target_q16(32'sd0),
        .hmi_speed_valid(1'b0),.hmi_speed_percent(7'd0),.hmi_hold_valid(1'b0),
        .amplitude_step(1'b0),
        .hmi_wave_start(wave_start),.hmi_wave_kind(kind),
        .hmi_wave_period_us(set_period),.hmi_wave_amp_q16(set_amp),
        .hmi_wave_stop(wave_stop),.hmi_track_mode(track),
        .hmi_point_valid(point_valid),.hmi_point_q16(point_q16),
        .capture_hold(capture_hold),
        .sine_sample_valid(sine_sample_valid),.sine_running(sine_running),
        .sine_ff_active(sine_ff_active),
        .sine_sample_phase(sine_sample_phase),.sine_sample_period(sine_sample_period),
        .sine_sample_amplitude(sine_sample_amplitude));

    sine_feedforward ff(.clk(clk),.rst_n(rst_n),.clear(clear),.tick(tick),.enable(1'b1),
        .active(sine_ff_active),.sample_valid(sine_sample_valid),
        .sample_phase(sine_sample_phase),.sample_period(sine_sample_period),
        .sample_amplitude(sine_sample_amplitude),.correction_q16(sine_ff_q16));

    // ---------------- 时钟/节拍 ----------------
    always @(posedge clk) begin
        cyc<=cyc+1;
        tick<=(cyc%TICK_CYCLES==TICK_CYCLES-1);
    end

    integer samples=0;
    always @(posedge clk) if(sine_sample_valid) samples<=samples+1;

    integer errors=0;
    task chk(input integer cond,input [255:0] msg);
        begin
            if(!cond) begin
                errors=errors+1;
                $display("FAIL: %0s  (t=%0t)",msg,$time);
            end else $display("ok  : %0s",msg);
        end
    endtask

    initial begin
        repeat(20) @(posedge clk);
        rst_n=1;
        repeat(20) @(posedge clk);

        // --- 1) 上位机下发正弦参数并启动 ---
        wave_start=1; @(posedge clk); wave_start=0;
        repeat(400) @(posedge clk);      // 8 个控制节拍
        chk(sine_running===1'b1,"正弦通道运行");
        chk(sine_ff_active===1'b1,"纯正弦时前馈使能");
        chk(samples>2,"前馈采样持续输出");
        chk(sine_sample_amplitude>0,"前馈采样幅值非零");
        chk(sine_sample_period==32'd10000000,"前馈采样周期=装载值");

        // --- 2) 手写轨迹模式：前馈必须失效 ---
        track=1;
        repeat(400) @(posedge clk);
        chk(sine_ff_active===1'b0,"轨迹模式关闭前馈");
        chk(sine_sample_amplitude==0,"轨迹模式采样幅值为 0");
        chk(sine_ff_q16==0,"轨迹模式下修正量回零");
        track=0;
        repeat(200) @(posedge clk);

        // --- 3) 捕获保持：目标就地锁存到当前横臂角 ---
        alpha_meas=32'sd123456;
        capture_hold=1; @(posedge clk); capture_hold=0;
        @(posedge clk);
        chk(goal==32'sd123456,"捕获后 goal 锁存到 alpha_meas");
        chk(refangle==32'sd123456,"捕获后 reference 锁存到 alpha_meas");
        chk(accepted===1'b1,"捕获被记为 accepted");

        // --- 4) 恢复正弦后前馈重新建立且被限幅 ---
        alpha_meas=32'sd0;
        wave_start=1; @(posedge clk); wave_start=0;
        repeat(2000) @(posedge clk);
        chk(sine_ff_active===1'b1,"重新起振后前馈恢复");
        chk(sine_ff_q16<=32'sd51471,"前馈修正不超过限幅 0.785 rad/s");

        if(errors==0) $display("\n=== ALL PASS ===");
        else $display("\n=== %0d FAIL ===",errors);
        $finish;
    end
endmodule
