`timescale 1ns/1ps
// 验证语音「急停后再起摆」能通过 estop_latched 的封锁。
// 原有设计：estop_latched 锁存后，移动被阻止（安全）；但起摆/平衡应能解除锁存重新运行。
module tb_voice_estop_restart;
    reg clk=0, rst_n=0, rx=1;
    always #5 clk=~clk;
    localparam CLK_HZ=100000, BAUD=10000, BIT_NS=100;
    wire tx, cmd_valid, rejected, latched;
    wire [1:0] mode, mask, reason;
    wire [3:0] action;
    wire [7:0] id, angle;
    wire right, lv, rv, ready;
    reg ld=0, rd=0;
    integer local_count=0, errors=0;
    reg [3:0] last_local_action;
    wire [3:0] la;

    voice_uart_bridge #(.CLK_HZ(CLK_HZ), .BAUD(BAUD), .TARGET_TIMEOUT_MS(3)) bridge (
        .clk(clk), .rst_n(rst_n), .voice_uart_rx_y15(rx), .voice_uart_tx_y14(tx),
        .target_mask(mode), .target_timeout(), .command_valid(cmd_valid),
        .command_target_mask(mask), .action_code(action), .command_id(id),
        .move_angle(angle), .move_right(right), .command_rejected(rejected),
        .reject_reason(reason), .estop_latched(latched), .play_req(1'b0), .play_id(8'd0)
    );
    voice_dual_coordinator #(.CLK_HZ(CLK_HZ), .ACTION_TIMEOUT_MS(10000)) coord (
        .clk(clk), .rst_n(rst_n), .command_valid(cmd_valid),
        .command_target_mask(mask), .command_action(action), .command_id(id),
        .command_angle(angle), .command_right(right), .local_done(ld), .local_fail(1'b0),
        .remote_done(rd), .remote_fail(1'b0), .local_cmd_valid(lv), .remote_cmd_valid(rv),
        .local_action(la), .remote_action(), .local_angle(), .remote_angle(), .ready(ready)
    );
    always @(posedge clk) if(lv) begin local_count<=local_count+1; last_local_action<=la; end

    task check(input cond, input [639:0] msg);
        begin if(cond!==1'b1) begin $display("FAIL: %0s",msg); errors=errors+1; end
        else $display("ok: %0s",msg); end
    endtask
    task byte_tx(input [7:0] data); integer i;
        begin rx=0; #(BIT_NS); for(i=0;i<8;i=i+1) begin rx=data[i]; #(BIT_NS); end rx=1; #(BIT_NS); end
    endtask
    task word_tx(input [7:0] data);
        begin @(negedge clk); byte_tx(8'hAA); byte_tx(8'h55); byte_tx(8'h00); byte_tx(data); byte_tx(8'hFB); repeat(30) @(negedge clk); end
    endtask
    task finish_action; begin @(negedge clk); ld=1; rd=1; @(negedge clk); ld=0; rd=0; repeat(4) @(negedge clk); end endtask

    initial begin
        repeat(4) @(negedge clk); rst_n=1;
        word_tx(8'hB0);          // 选主摆
        word_tx(8'h41);          // 急停
        check(latched,"estop latched");
        // 关键：急停后发起摆(0x40=起摆) 必须能通过，不被 estop_latched 永久封锁
        word_tx(8'h40);
        check(!latched, "swing-up clears estop latch");
        check(last_local_action==1, "swing-up dispatched after estop");
        finish_action;
        // 再次急停，再试「开始平衡(0x43)」
        word_tx(8'h41); check(latched,"estop latched again");
        word_tx(8'h43);
        check(!latched, "balance clears estop latch");
        check(last_local_action==4, "balance dispatched after estop");
        finish_action;
        if(errors) $fatal(1,"voice estop-restart: %0d failures",errors);
        $display("PASS: voice estop -> swing-up / balance restart works"); $finish;
    end
    initial begin #3000000; $fatal(1,"timeout"); end
endmodule
