`timescale 1ns/1ps
`include "control_config.vh"
// Supervisor contract: raw travel requests clamp first; only sustained loss of
// authority with an outward-falling pendulum may request another swing-up.
module tb_run_travel_recovery;
    reg clk=0,rst_n=0,sample_valid=0;
    always #20 clk=~clk;
    reg request=0,saturated=0,numeric_fault=0,external_stop=0,remote_start=0;
    reg feedback_good=1,hard_limit=0;
    reg signed [31:0] angle_counts=0,theta_speed=0;
    wire [2:0] state;
    wire [7:0] fault,reason;
    wire [15:0] exits;
    wire run,qualified;
    localparam integer FRAMES=(`CFG_RUN_TRAVEL_RECOVERY_US+`CFG_CONTROL_PERIOD_US-1)/`CFG_CONTROL_PERIOD_US;
    localparam integer ANGLE30=$rtoi(30.0/180.0*`CFG_ADC_THETA_COUNTS_PER_PI);
    control_supervisor dut(
        .clk(clk),.rst_n(rst_n),.us_tick(1'b0),.sample_valid(sample_valid),
        .buttons(3'd0),.ad_value(13'd1585),.encoder_raw(16'd0),
        .encoder_update(1'b0),.encoder_valid(1'b1),.signed_pulses(32'sd0),.pul(1'b0),
        .alpha_dot(32'sd0),.theta_dot(theta_speed),.saturated(saturated),.numeric_fault(numeric_fault),
        .state(state),.fault(fault),.run(run),.remote_start(remote_start),.remote_reset(1'b0),
        .external_stop(external_stop),.swing_velocity_valid(1'b0),.travel_recovery_request(request),
        .arm_reference_q16(32'sd0),.travel_recovery_qualified(qualified),
        .run_exit_reason(reason),.run_exit_count(exits));
    task check(input integer ok,input [639:0] message);
        if(!ok) $fatal(1,"%0s: state=%0d fault=%0d reason=%0d ticks=%0d",message,state,fault,reason,dut.travel_limited_ticks);
    endtask
    task enter_run;
        begin
            @(negedge clk);rst_n=0;sample_valid=0;request=0;saturated=0;
            numeric_fault=0;external_stop=0;remote_start=0;feedback_good=1;hard_limit=0;
            angle_counts=0;theta_speed=0;
            repeat(4) @(negedge clk);
            rst_n=1;
            @(negedge clk);dut.state=3;dut.calibrated=1;
            repeat(3) @(negedge clk);
            check(state==3 && run,"enter RUN");
        end
    endtask
    task frame;
        begin
            @(negedge clk);sample_valid=1;
            @(negedge clk);sample_valid=0;
            repeat(2) @(negedge clk);
        end
    endtask
    integer i;
    initial begin
        force dut.feedback_ok=feedback_good;
        force dut.encoder_seen=1'b1;
        force dut.arm_limit=hard_limit;
        force dut.ad_relative_q=angle_counts;
        enter_run();request=1;angle_counts=ANGLE30;theta_speed=65536;
        frame();repeat(100) @(negedge clk);
        check(state==3 && !qualified,"one limited frame does not exit or count FPGA clocks");
        for(i=1;i<FRAMES-1;i=i+1) frame();
        check(state==3,"outward fall waits for full dwell");
        frame();
        check(state==5 && reason==2 && exits==1,"positive sustained constraint and worsening exits");
        repeat(12) @(negedge clk);check(exits==1,"exit counted once");

        enter_run();request=1;angle_counts=-ANGLE30;theta_speed=-65536;
        repeat(FRAMES) frame();
        check(state==5 && reason==2,"negative sustained constraint and worsening exits");

        enter_run();request=1;angle_counts=100;theta_speed=65536;
        repeat(FRAMES+20) frame();check(state==3,"small pendulum angle stays RUN during long limitation");
        angle_counts=ANGLE30;theta_speed=-65536;
        repeat(20) frame();check(state==3,"positive angle returning upright stays RUN");
        angle_counts=-ANGLE30;theta_speed=65536;
        repeat(20) frame();check(state==3,"negative angle returning upright stays RUN");
        theta_speed=0;repeat(20) frame();check(state==3,"large but non-growing angle stays RUN");

        enter_run();request=1;angle_counts=ANGLE30;theta_speed=65536;
        repeat(FRAMES-1) frame();request=0;repeat(3) @(negedge clk);
        check(dut.travel_limited_ticks==0,"gap resets consecutive limitation dwell");
        request=1;repeat(FRAMES-1) frame();check(state==3,"old dwell cannot leak across gap");
        frame();check(state==5 && reason==2,"new full dwell exits");

        enter_run();angle_counts=`CFG_FALLEN_COUNTS+1;
        repeat(3) @(negedge clk);check(state==5 && reason==1,"positive fall protection remains immediate");
        enter_run();angle_counts=-`CFG_FALLEN_COUNTS-1;
        repeat(3) @(negedge clk);check(state==5 && reason==1,"negative fall protection remains immediate");
        enter_run();feedback_good=0;repeat(3) @(negedge clk);
        check(state==4 && fault==2 && reason==4 && !run,"feedback fault stops immediately");
        enter_run();numeric_fault=1;repeat(3) @(negedge clk);
        check(state==4 && fault==5 && reason==5 && !run,"numeric fault stops immediately");
        enter_run();hard_limit=1;repeat(3) @(negedge clk);
        check(state==4 && fault==7 && reason==6 && !run,"hard travel fault stops immediately");
        enter_run();external_stop=1;repeat(3) @(negedge clk);
        check(state==2 && reason==7 && exits==1 && !run,"stop still immediate and counted once");
        enter_run();remote_start=1;@(negedge clk);remote_start=0;
        repeat(2) @(negedge clk);check(state==2 && reason==8,"restart has distinct exit reason");
        enter_run();saturated=1;
        repeat(`CFG_SATURATION_FRAMES-1) frame();check(state==3,"saturation dwell preserved");
        frame();check(state==5 && reason==3,"continuous saturation retains recovery");
        $display("PASS: travel recovery dwell, both directions, returning/quiet states, gaps and all exit causes");
        $finish;
    end
    initial begin #20000000;$fatal(1,"timeout");end
endmodule
