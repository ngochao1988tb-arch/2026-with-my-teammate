param([string]$Zig='zig',[string]$Iverilog='iverilog',[string]$Vvp='vvp',[switch]$FullUi)
$ErrorActionPreference='Stop'
function Run([string]$Program,[string[]]$Parameters){
 & $Program @Parameters
 if($LASTEXITCODE -ne 0){throw "Check failed: $Program"}
}
Push-Location (Split-Path $PSScriptRoot)
try {
 Run $Zig @('cc','-O1','-g','-I','sw','sim/test_hmi.c','sw/font8x16.c','-o','sim/test_hmi.exe')
 Run './sim/test_hmi.exe' @()
 Run $Iverilog @('-g2012','-I','src','-s','tb_math','-o','sim/math.vvp','src/square16_pipe.v','src/swingup_core.v','sim/swingup_reference.v','sim/tb_math.v')
 Run $Vvp @('sim/math.vvp')
 Run $Iverilog @('-g2012','-I','src','-s','tb_mailbox','-o','sim/mailbox.vvp','src/rv32/picorv32.v','src/status_snapshot.v','src/lcd8080.v','src/rv32_soc.v','src/hmi_scale.v','src/hmi_div_const.v','src/hmi_record_ram.v','src/hmi_control.v','sim/tb_mailbox.v')
 Run $Vvp @('sim/mailbox.vvp')
 $rtl=([xml](Get-Content 'ST7789_HMI_control.gprj' -Raw)).Project.FileList.File | Where-Object { $_.path -like '*.v' } | ForEach-Object { [string]$_.path }
 Run $Iverilog (@('-g2012','-I','src','-s','tb_control_sync','-o','sim/control_sync.vvp')+@($rtl)+@('sim/tb_control_sync.v'))
 Run $Vvp @('sim/control_sync.vvp')
 if($FullUi){
  Run $Iverilog @('-g2012','-I','src','-s','tb_ui_boot','-o','sim/ui_boot.vvp','src/rv32/picorv32.v','src/status_snapshot.v','src/lcd8080.v','src/rv32_soc.v','sim/lcd_model.v','sim/tb_ui_boot.v')
  Run $Vvp @('sim/ui_boot.vvp')
 }
} finally {Pop-Location}
