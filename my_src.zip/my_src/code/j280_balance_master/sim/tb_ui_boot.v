`timescale 1ns/1ps
module tb_ui_boot;
 reg clk=0,rst_n=0;always #10 clk=~clk;
 wire cs,wr,rd,rs,lrst,bl,oe;wire[15:0] data,data_o;
 assign data=oe?data_o:16'hzzzz;
 rv32_soc #(.IMEM_INIT("imem_sim.hex"),.ENABLE_CMD(1),.ENABLE_TOUCH(1)) dut(
 .clk(clk),.rst_n(rst_n),.st_alpha_q16(32'd1000),.st_theta_q16(-32'sd500),.st_arm_ref_q16(0),.st_freq_q8(32'd128000),.st_u_q16(0),
 .st_alpha_dot(32'd3000),.st_theta_dot(0),.st_alpha_c(0),.st_enc_raw(32'd12345),.st_enc_age_us(0),.st_enc_seq(32'd4),.st_ctrl_count(32'd7),.st_t_us(0),.st_ad_value(13'd2048),
 .st_state(8'd3),.st_fault(8'd0),.st_flags(8'd0),.st_build_tag(32'h26103101),.st_run(1'b1),.st_calibrated(1'b1),.st_saturated(1'b0),.st_fb_ready(1'b1),.st_swing_active(1'b0),
 .lcd_cs_n(cs),.lcd_wr_n(wr),.lcd_rd_n(rd),.lcd_rs(rs),.lcd_reset_n(lrst),.lcd_bl(bl),.lcd_data_oe(oe),.lcd_data_o(data_o),.lcd_data_i(data),
 .touch_miso(1'b1),.touch_pen_n(1'b1),.hmi_req_active(1'b0),.rv_ack(1'b0),.rv_ack_seq(0),.rv_ack_result(0));
 lcd_model #(.DUMP_FILE("sim/ui_boot_rgb565.bin")) panel(clk,rst_n,cs,wr,rd,rs,data);
 integer cycles=0,mad=-1,pixel=-1,command=-1;
 always @(posedge wr)if(rst_n&&!cs)begin if(!rs)command=data;else if(command=='h36)mad=data;else if(command=='h3a)pixel=data;end
 always @(posedge clk)begin
  cycles<=cycles+1;
  if(dut.cpu_trap||dut.bus_err_none||dut.bus_err_imem)$fatal(1,"CPU/bus error");
  if(cycles>15000000)$fatal(1,"timeout scratch=%h",dut.scratch);
 end
 initial begin
  repeat(10)@(negedge clk);rst_n=1;
  wait(dut.scratch==32'h484d0000);repeat(100)@(negedge clk);
  if(!bl||mad!='h60||pixel!='h05)$fatal(1,"panel config");
  if(panel.err_as+panel.err_pw+panel.err_ds+panel.err_dh+panel.err_idle!=0)$fatal(1,"LCD timing");
  // Check the real CPU's new theme, chart field, and selected channel card.
  if(panel.fb[100*320+76]!==16'h0883)$fatal(1,"background pixel %h",panel.fb[100*320+76]);
  if(panel.fb[49*320+81]!==16'h08a4)$fatal(1,"plot pixel %h",panel.fb[49*320+81]);
  if(panel.fb[45*320+70]!==16'h19a8)$fatal(1,"selected card pixel %h",panel.fb[45*320+70]);
  panel.dump_fb();panel.report();
  $display("PASS: complete UI firmware boot through real RV32/32KB ROM/MMIO/LCD8080, ST7789 init, pixels and bus timing. cycles=%0d",cycles);$finish;
 end
endmodule
