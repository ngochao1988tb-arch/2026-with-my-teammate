`timescale 1ns/1ps
module tb_mailbox;
 reg clk=0;always #10 clk=~clk;
 reg rst_n=0;reg busy_gate=0,uart_valid=0;reg [31:0] uart_seq=1;
 wire req;wire [7:0] cmd;wire [31:0] seq,arg,speed;wire ack;wire [31:0] ackseq,result;
 wire target_valid,hold_valid;wire signed [31:0] target;
 reg [2:0] state=3;reg fault=0,feedback=1,rail=0;
 rv32_soc #(.IMEM_INIT("imem_bus_test.hex"),.DMEM_INIT("dmem_bus_test.hex"),.ENABLE_CMD(1),.ENABLE_TOUCH(1)) dut(
 .clk(clk),.rst_n(rst_n),.st_alpha_q16(32'd65536),.st_theta_q16(-32'sd32768),.st_arm_ref_q16(32'd32768),.st_freq_q8(32'd128000),.st_u_q16(0),
 .st_alpha_dot(32'd16384),.st_theta_dot(0),.st_alpha_c(0),.st_enc_raw(32'd12345),.st_enc_age_us(0),.st_enc_seq(32'd4),.st_ctrl_count(32'd7),.st_t_us(0),.st_ad_value(13'd2048),
 .st_state(8'd3),.st_fault(8'd0),.st_flags(8'd0),.st_build_tag(32'h26103101),.st_run(1'b1),.st_calibrated(1'b1),.st_saturated(1'b0),.st_fb_ready(1'b1),.st_swing_active(1'b0),
 .lcd_data_i(16'd0),.touch_miso(1'b1),.touch_pen_n(1'b1),.hmi_req_active(busy_gate|uart_valid),.rv_req(req),.rv_cmd(cmd),.rv_seq(seq),.rv_arg(arg),.rv_speed(speed),.rv_ack(ack),.rv_ack_seq(ackseq),.rv_ack_result(result));
 wire [7:0] hc=req?cmd:8'h11;wire [31:0] hs=req?seq:uart_seq,ha=req?arg:32'd30,hsp=req?speed:32'd30;
 hmi_control h(.clk(clk),.rst_n(rst_n),.us_tick(1'b0),.sample_valid(1'b0),.rx_valid(req|uart_valid),.source_rv(req),.cmd(hc),.seq(hs),.arg(ha),.speed(hsp),.screen_boot(1'b0),
 .state(state),.fault({7'd0,fault}),.calibrated(1'b1),.feedback_ok(feedback),.rail(rail),.buttons(3'd0),.arm_q16(0),.theta_q16(0),.command_q16(0),.theta_velocity_q16(0),.frequency_q8(0),
 .ack_ready(1'b1),.snapshot_sent(1'b0),.ack_valid(ack),.ack_seq(ackseq),.ack_result(result),.arm_target_valid(target_valid),.arm_target_q16(target),.arm_hold_valid(hold_valid));
 integer requests=0,targets=0;
 always @(posedge clk)begin
  if(req)begin requests=requests+1;if($signed(seq)<=0)$fatal(1,"negative sequence");end
  if(target_valid)begin targets=targets+1;if(target> -14050 || target< -14090)$fatal(1,"wrong signed target %d",target);end
  if(dut.cpu_trap)$fatal(1,"CPU trap");
  if(dut.bus_err_none || dut.bus_err_imem)$fatal(1,"CPU bus error");
 end
 task uart_send;begin
  @(negedge clk);uart_valid=1;@(negedge clk);uart_valid=0;
  #1;if(!ack||ackseq!==uart_seq||result!==0)$fatal(1,"UART/RV source sequence collision");uart_seq=uart_seq+1;
 end endtask
 reg bus_cs=0;reg [31:0] bus_addr=0,bus_data=0;reg [3:0] bus_strb=0;
 task write_sys(input [6:0] off,input [31:0] data);begin
  @(negedge clk);bus_addr=32'h30000080+off;bus_data=data;bus_strb=15;bus_cs=1;
  @(negedge clk);bus_cs=0;bus_strb=0;repeat(3)@(negedge clk);
 end endtask
 reg [31:0] savedseq;
 initial begin
  repeat(5)@(negedge clk);rst_n=1;
  wait(requests==1);repeat(30)@(negedge clk);uart_send();
  wait(dut.scratch==32'h484d50ff || dut.scratch[31:16]==16'hdead);
  if(dut.scratch!==32'h484d50ff)$fatal(1,"firmware selftest %h",dut.scratch);
  if(requests!=6||targets!=1)$fatal(1,"request/target counts %d %d",requests,targets);
  uart_send();
  // Exercise queued payload immutability independently of CPU instruction timing.
  force dut.cpu_resetn=0;
  force dut.cs_sys=bus_cs;force dut.mem_addr=bus_addr;force dut.mem_wdata=bus_data;force dut.mem_wstrb=bus_strb;
  busy_gate=1;write_sys('h10,'h24);write_sys('h14,-123);write_sys('h18,100);write_sys('h1c,1);
  repeat(10)@(negedge clk);if(!dut.cmd_busy||!dut.rv_pending)$fatal(1,"not queued");
  savedseq=seq;write_sys('h10,2);write_sys('h14,0);write_sys('h18,0);
  if(cmd!==8'h24||arg!==-32'sd123||speed!==100||seq!==savedseq)$fatal(1,"queued payload mutated");
  busy_gate=0;repeat(120)@(negedge clk);
  if(dut.cmd_busy||!dut.cmd_done||dut.ack_res_lat!==0)$fatal(1,"mailbox ack mismatch");
  state=2;write_sys('h10,'h24);write_sys('h14,0);write_sys('h18,100);write_sys('h1c,1);repeat(20)@(negedge clk);
  if(dut.ack_res_lat!==2)$fatal(1,"READY accepted trajectory");
  state=3;fault=1;write_sys('h1c,1);repeat(20)@(negedge clk);if(dut.ack_res_lat!==2)$fatal(1,"FAULT accepted trajectory");
  fault=0;rail=1;write_sys('h1c,1);repeat(20)@(negedge clk);if(dut.ack_res_lat!==2)$fatal(1,"rail accepted trajectory");
  $display("PASS: real RV32 firmware/MMIO snapshot/scaling; signed point, bounds, stop, E-stop, reset; UART and CPU sequence banks; frozen queued payload and matching acknowledgement; READY/fault/rail reject.");$finish;
 end
 initial begin #100000000;$fatal(1,"timeout scratch=%h requests=%d",dut.scratch,requests);end
endmodule
