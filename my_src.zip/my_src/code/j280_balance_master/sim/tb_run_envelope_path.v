`timescale 1ns/1ps
module tb_run_envelope_path;
    reg clk=0,rst_n=0;
    always #20 clk=~clk;
    reg signed [31:0] requested=0,positive_limit=4000*256,negative_limit=4000*256;
    reg ready=0;
    wire [2:0] ready_pipe={ready,2'b00};
    lqr_system #(.PC_DEBUG_EN(0)) dut(
        .clk_sys(clk),.rst_n(rst_n),.key_sw(4'hf),.motor_rx(1'b1),.adc_data_in(10'd390),
        .hmi_rx(1'b1),.screen_rx(1'b1),.slave_rx(1'b1),.voice_rx(1'b1),
        .rv_req(1'b0),.rv_cmd(8'd0),.rv_seq(32'd0),.rv_arg(32'd0),.rv_speed(32'd0));
    task update_command;
        begin
            @(negedge clk);ready=1;
            @(negedge clk);ready=0;
            repeat(3) @(negedge clk);
        end
    endtask
    task check(input integer ok,input [639:0] message);
        if(!ok) $fatal(1,"%0s: rate=%0d motor=%0d",message,dut.run_rate_frequency_q8,dut.motor_frequency_q8);
    endtask
    initial begin
        repeat(5) @(negedge clk);rst_n=1;repeat(8) @(negedge clk);
        force dut.u_supervisor.state=3;
        force dut.u_supervisor.feedback_ok=1;
        force dut.u_supervisor.arm_limit=0;
        force dut.run=1;
        force dut.sample_valid=0;
        force dut.stall_release=0;
        force dut.manual_run=0;
        force dut.frequency_q8=requested;
        force dut.travel_positive_limit_q8=positive_limit;
        force dut.travel_negative_limit_q8=negative_limit;
        force dut.run_command_ready_pipe=ready_pipe;
        @(negedge clk);dut.run_rate_frequency_q8=0;requested=1000*256;
        update_command();check(dut.run_rate_frequency_q8==20*256,"ordinary RUN slew remains 20 Hz/frame");
        @(negedge clk);positive_limit=600*256;requested=3000*256;dut.run_rate_frequency_q8=3000*256;
        update_command();check(dut.run_rate_frequency_q8==600*256,"positive internal slew tracks envelope");
        check(dut.motor_frequency_q8<=600*256,"positive actual command clamped");
        check(dut.u_lqr.trim_pause===1'b1,"constrained command pauses bias integration");
        @(negedge clk);positive_limit=0;
        update_command();check(dut.run_rate_frequency_q8==0 && dut.motor_frequency_q8==0,"outward stop tracks zero");
        @(negedge clk);requested=-1000*256;
        update_command();check(dut.run_rate_frequency_q8==-20*256,"inward command responds on first frame");
        @(negedge clk);positive_limit=4000*256;negative_limit=600*256;requested=-3000*256;dut.run_rate_frequency_q8=-3000*256;
        update_command();check(dut.run_rate_frequency_q8==-600*256,"negative internal slew tracks envelope");
        check(dut.motor_frequency_q8>=-600*256,"negative actual command clamped");
        @(negedge clk);negative_limit=0;
        update_command();check(dut.run_rate_frequency_q8==0,"negative outward stop tracks zero");
        @(negedge clk);requested=1000*256;
        update_command();check(dut.run_rate_frequency_q8==20*256,"positive inward recovery is retained");
        $display("PASS: directional motor clamp, slew tracking, prompt reversal and trim pause");
        $finish;
    end
    initial begin #1000000;$fatal(1,"timeout");end
endmodule
