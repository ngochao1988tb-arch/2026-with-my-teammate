`timescale 1ns/1ps
module tb_pc_debug;
    reg clk=0,rst_n=0,pc_rx=1,screen_rx=1;
    always #20 clk=~clk;
    wire tx,pul,tel;
    lqr_system #(.PC_DEBUG_EN(1)) dut(
        .clk_sys(clk),.rst_n(rst_n),.key_sw(4'hf),.motor_rx(1'b1),.adc_data_in(10'd390),
        .hmi_rx(pc_rx),.hmi_tx(tx),.screen_rx(screen_rx),.slave_rx(1'b1),.voice_rx(1'b1),
        .pul_out(pul),.telemetry_tx(tel),
        .rv_req(1'b0),.rv_cmd(8'd0),.rv_seq(32'd0),.rv_arg(32'd0),.rv_speed(32'd0));
    defparam dut.u_hmi_rx_pc.CLK_HZ=1152000;
    defparam dut.u_hmi_rx_screen.CLK_HZ=1152000;
    defparam dut.g_pc_debug.u_debug_tx.CLK_HZ=2304000;
    defparam dut.g_pc_debug.u_debug_tx.RATE_HZ=1000;
    wire [7:0] rx_data;
    wire rx_valid,framing_error;
    serial_rx #(.CLK_HZ(2304000),.BAUD(230400)) monitor(
        .clk(clk),.rst_n(rst_n),.rx(tx),.data(rx_data),.valid(rx_valid),.framing_error(framing_error));
    reg [7:0] packet[0:131];
    integer index=0,frames=0,event_frames=0,pc_commands=0,screen_commands=0,sum=0,k;
    integer capture_file=0;
    reg [2047:0] capture_path;
    initial if($value$plusargs("CAPTURE_FILE=%s",capture_path)) begin
        capture_file=$fopen(capture_path,"wb");
        if(!capture_file) $fatal(1,"cannot open UART capture file");
    end
    always @(negedge clk) if(rst_n) begin
        if(dut.pc_valid) pc_commands=pc_commands+1;
        if(dut.scr_valid) screen_commands=screen_commands+1;
        if(framing_error) $fatal(1,"debug UART framing error");
        if(pul) $fatal(1,"debug traffic generated a motor pulse while IDLE");
        if(rx_valid) begin
            if(capture_file) $fwrite(capture_file,"%c",rx_data);
            packet[index]=rx_data;
            if(index==131) begin
                if(packet[0]!=8'haa || packet[1]!=8'h55 || packet[2]!=4 || packet[130]!=13 || packet[131]!=10)
                    $fatal(1,"bad debug framing / version");
                sum=0;for(k=2;k<128;k=k+1) sum=sum+packet[k];
                if({packet[128],packet[129]}!=(sum & 65535)) $fatal(1,"bad debug checksum");
                if({packet[80],packet[81],packet[82],packet[83]}!=32'h26110306) $fatal(1,"bad build tag / field offset");
                if(packet[100]==2 && {packet[101],packet[102]}==1) begin
                    if({packet[108],packet[109],packet[110],packet[111]}!=12345) $fatal(1,"exit angle lost");
                    if({packet[112],packet[113],packet[114],packet[115]}!=3500*256) $fatal(1,"exit request lost");
                    if({packet[116],packet[117],packet[118],packet[119]}!=1400*256) $fatal(1,"exit applied command lost");
                    if({packet[120],packet[121],packet[122],packet[123]}!=1400*256) $fatal(1,"exit positive envelope lost");
                    if({packet[124],packet[125],packet[126],packet[127]}!=4000*256) $fatal(1,"exit negative envelope lost");
                    event_frames=event_frames+1;
                end
                frames=frames+1;index=0;
            end else index=index+1;
        end
    end
    task send_byte(input integer channel,input [7:0] value);
        integer b;
        begin
            @(negedge clk);if(channel==0) pc_rx=0;else screen_rx=0;
            repeat(10) @(negedge clk);
            for(b=0;b<8;b=b+1) begin
                if(channel==0) pc_rx=value[b];else screen_rx=value[b];
                repeat(10) @(negedge clk);
            end
            if(channel==0) pc_rx=1;else screen_rx=1;
            repeat(10) @(negedge clk);
        end
    endtask
    task send_command(input integer channel,input [7:0] command);
        integer b;
        begin
            send_byte(channel,8'h55);send_byte(channel,8'haa);send_byte(channel,8'h20);send_byte(channel,command);
            send_byte(channel,8'd1);for(b=0;b<11;b=b+1) send_byte(channel,8'd0);
            send_byte(channel,8'h0d);send_byte(channel,8'h0a);
            repeat(30) @(negedge clk);
        end
    endtask
    initial begin
        repeat(8) @(negedge clk);rst_n=1;repeat(8) @(negedge clk);
        if(tel!==1'bz) $fatal(1,"debug mode unexpectedly enabled A14");
        send_command(0,8'h01);
        if(pc_commands!=0 || dut.state!=0) $fatal(1,"L20 accepted PC command in debug mode");
        send_command(0,8'h0f);
        if(pc_commands!=0 || dut.hmi_stop) $fatal(1,"L20 accepted PC stop in debug mode");
        send_command(1,8'h0f);
        if(screen_commands!=1 || !dut.hmi_stop) $fatal(1,"screen emergency stop no longer works");
        force dut.theta_meas=12345;
        force dut.frequency_q8=3500*256;
        force dut.motor_frequency_q8=1400*256;
        force dut.travel_positive_limit_q8=1400*256;
        force dut.travel_negative_limit_q8=4000*256;
        force dut.run_exit_reason=2;
        force dut.run_exit_count=1;
        repeat(5) @(negedge clk);
        release dut.theta_meas;release dut.frequency_q8;release dut.motor_frequency_q8;
        release dut.travel_positive_limit_q8;release dut.travel_negative_limit_q8;
        wait(event_frames>=2);
        if(capture_file) $fclose(capture_file);
        $display("PASS: K20 v4 framing/checksum/exit history, L20 isolation, screen stop retained (%0d frames)",frames);
        $finish;
    end
    initial begin #10000000;$fatal(1,"timeout");end
endmodule
