@echo off
rem ===========================================================================
rem run_dual_slave.bat - 双摆从摆链路回归（三条用例）
rem   用法: run_dual_slave.bat [iverilog.exe] [vvp.exe]
rem   默认用 PATH 里的 iverilog / vvp
rem ===========================================================================
setlocal
set IV=iverilog
set VP=vvp
if not "%~1"=="" set IV=%~1
if not "%~2"=="" set VP=%~2

cd /d "%~dp0.."

echo [1/3] HMI 2.1 dual-pendulum command decode
%IV% -g2005 -I src -I sim -s tb_hmi_dual_cmd -o sim\tb_hmi_dual_cmd.vvp ^
  sim\tb_hmi_dual_cmd.v src\hmi_control.v src\hmi_scale.v src\hmi_div_const.v src\hmi_record_ram.v || goto :fail
%VP% sim\tb_hmi_dual_cmd.vvp || goto :fail

echo [2/3] slave link pass-through + poll + telemetry
%IV% -g2005 -I src -I sim -s tb_hmi_slave -o sim\tb_hmi_slave.vvp ^
  sim\tb_hmi_slave.v src\slave_link.v src\serial_tx.v src\serial_rx.v || goto :fail
%VP% sim\tb_hmi_slave.vvp || goto :fail

echo [3/3] end-to-end telemetry in ASCII snapshot (slow, whole top)
%IV% -g2005 -I src -I sim -s tb_hmi_dual_snap -o sim\tb_hmi_dual_snap.vvp ^
  sim\tb_hmi_dual_snap.v src\*.v src\rv32\picorv32.v sim\prim_sim_stub.v || goto :fail
%VP% sim\tb_hmi_dual_snap.vvp || goto :fail

echo ALL DUAL-SLAVE CHECKS PASSED
exit /b 0

:fail
echo CHECK FAILED
exit /b 1
