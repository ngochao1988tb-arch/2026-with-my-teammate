`timescale 1ns/1ps
// ============================================================================
// tb_voice_router.v — 语音动作路由的完成/失败判定仿真
// ============================================================================
// 验证起摆、复位、移动完成判定以及急停抢占：
//   1) 已经在 RUN(state=3) 时喊「起摆」，不能当拍就报完成；
//      监督器消费启动脉冲后才判完成，无固定 200ms 等待；
//   2) 当前处于故障(state=4) 时喊「起摆」，不能当拍报失败；
//   3) 未标定(calibrated=0) 时喊「左移/右移」，立即判失败，不空等超时；
//   4) 已标定时右移 30°，参考追到 30° 且 moving=0 后判完成。
// ============================================================================
module tb_voice_router;

    localparam CLK = 20;
    // 仿真把模块时钟参数按比例缩小：CLK_HZ=100k 而实际时钟仍是 20ns，
    // 模块内部的毫秒计数变成 100 个时钟 => 1 个"模块 ms" = 2000ns。
    // 超时按同一比例缩放，握手仍按实际时钟周期验证。
    localparam SIM_CLK_HZ = 100000;
    localparam MS  = 2000;               // 1 个模块 ms = 2000 ns
    localparam [3:0] A_SWING_UP = 4'd1;
    localparam [3:0] A_MOVE_RIGHT = 4'd6;

    reg clk = 1'b0;
    reg rst_n = 1'b0;
    always #(CLK/2) clk = ~clk;

    reg        cmd_valid = 1'b0;
    reg [3:0]  cmd_action = 4'd0;
    reg [7:0]  cmd_angle = 8'd0;
    reg        cmd_right = 1'b0;
    reg [2:0]  sup_state = 3'd0;
    reg        calibrated = 1'b0;
    reg        feedback_ready = 1'b0;
    reg        moving = 1'b0;
    reg signed [31:0] arm_ref = 32'sd0;

    wire        v_start, v_reset, v_stop, v_target_valid;
    wire signed [31:0] v_target_q16;
    wire        local_done, local_fail;

    voice_action_router #(
        .CLK_HZ(SIM_CLK_HZ),
        .TIMEOUT_MS(600)
    ) dut (
        .clk(clk), .rst_n(rst_n),
        .local_cmd_valid(cmd_valid),
        .local_action(cmd_action),
        .local_angle(cmd_angle),
        .local_right(cmd_right),
        .state(sup_state),
        .calibrated(calibrated),
        .feedback_ready(feedback_ready),
        .moving(moving),
        .arm_reference_q16(arm_ref),
        .v_start(v_start), .v_reset(v_reset), .v_stop(v_stop),
        .v_target_valid(v_target_valid), .v_target_q16(v_target_q16),
        .local_done(local_done), .local_fail(local_fail)
    );

    integer errors = 0;

    // 粘滞记录，避免漏掉单周期脉冲
    reg saw_done = 1'b0;
    reg saw_fail = 1'b0;
    reg        seen_target = 1'b0;
    reg signed [31:0] tgt_cap = 32'sd0;
    always @(posedge clk) begin
        if (local_done) saw_done <= 1'b1;
        if (local_fail) saw_fail <= 1'b1;
        if (v_target_valid) begin
            seen_target <= 1'b1;
            tgt_cap     <= v_target_q16;
        end
    end

    task issue(input [3:0] act, input [7:0] ang, input right);
        begin
            @(negedge clk);
            saw_done    = 1'b0;
            saw_fail    = 1'b0;
            seen_target = 1'b0;
            cmd_action = act;
            cmd_angle  = ang;
            cmd_right  = right;
            cmd_valid  = 1'b1;
            @(negedge clk);
            cmd_valid  = 1'b0;
        end
    endtask

    task check(input cond, input [639:0] msg);
        begin
            if (cond === 1'b1) $display("  ok   %0s", msg);
            else begin $display("  FAIL %0s", msg); errors = errors + 1; end
        end
    endtask

    initial begin
        rst_n = 1'b0;
        repeat (10) @(posedge clk);
        rst_n = 1'b1;
        repeat (5) @(posedge clk);

        // ======== 场景 1：已经在 RUN 时喊起摆 ========
        $display("[场景 1] state=3(RUN) 时喊起摆，不得当拍报完成");
        sup_state      = 3'd3;
        calibrated     = 1'b1;
        feedback_ready = 1'b1;
        issue(A_SWING_UP, 8'd0, 1'b0);

        check(v_start && !local_done && !local_fail, "start immediately, no stale completion");
        @(negedge clk); // 监督器在这个周期消费 v_start，离开旧 RUN
        sup_state = 3'd2;
        repeat (5) @(negedge clk);
        check(!saw_done && !saw_fail, "old RUN not counted as completion");
        sup_state = 3'd3;
        repeat (3) @(negedge clk);
        check(saw_done, "updated RUN completes within cycles, not 200ms");
        repeat (5) @(posedge clk);

        // ======== 场景 2：故障态喊起摆 ========
        $display("[场景 2] state=4(FAULT) 时喊起摆，不得当拍报失败");
        sup_state = 3'd4;
        issue(A_SWING_UP, 8'd0, 1'b0);

        check(v_start && !local_fail, "start in FAULT does not fail on issue");
        @(negedge clk);
        sup_state = 3'd1;                 // 监督器开始重新标定
        #(150 * MS);
        check(!saw_fail, "no false fail right after issue in FAULT");
        #(400 * MS);
        check(!saw_done && !saw_fail, "still calibrating: neither done nor fail");
        // 让它超时收尾
        #(1800 * MS);
        check(saw_fail, "fail after timeout");
        repeat (5) @(posedge clk);

        // ======== 场景 3：未标定时移动 ========
        $display("[场景 3] 未标定时右移 30 度");
        sup_state  = 3'd2;
        calibrated = 1'b0;
        issue(A_MOVE_RIGHT, 8'd30, 1'b1);
        #(5 * MS);
        check(saw_fail, "immediate fail when not calibrated");
        repeat (5) @(posedge clk);

        // ======== 场景 4：已标定右移 30 度 ========
        $display("[场景 4] 已标定右移 30 度");
        calibrated = 1'b1;
        arm_ref    = 32'sd0;
        moving     = 1'b1;
        issue(A_MOVE_RIGHT, 8'd30, 1'b1);
        #(1 * MS);
        check(seen_target && tgt_cap == 32'sd34320, "target pulse captured, q16 == 34320");
        // 30° -> 30 * 1144 = 34320 (Q16)
        #(300 * MS);
        check(!saw_done, "not done before reference arrives");
        arm_ref = 32'sd34320;
        moving  = 1'b0;
        repeat (3) @(negedge clk);
        check(saw_done, "done within cycles after reference reaches target");
        repeat (5) @(posedge clk);

        // 急停抢占在途命令，不得被旧命令的超时/完成覆盖。
        sup_state = 3'd1;
        issue(A_SWING_UP, 8'd0, 1'b0);
        repeat (5) @(negedge clk);
        issue(4'd2, 8'd0, 1'b0);
        check(v_stop && local_done && !local_fail, "stop preempts active action immediately");
        repeat (3) @(negedge clk);
        check(dut.fsm == 0, "stop leaves router idle");

        // 复位也必须读到监督器更新后的状态。
        sup_state = 3'd2;
        calibrated = 1'b1;
        issue(4'd3, 8'd0, 1'b0);
        check(v_reset && !local_done, "reset pulse without stale READY completion");
        @(negedge clk);
        sup_state = 3'd1;
        calibrated = 1'b0;
        repeat (5) @(negedge clk);
        check(!saw_done && !saw_fail, "reset waits for real calibration");
        sup_state = 3'd2;
        calibrated = 1'b1;
        repeat (3) @(negedge clk);
        check(saw_done, "reset completion has no fixed delay");

        if (errors == 0) $display("\nPASS: voice_action_router 完成/失败判定全部通过");
        else             $fatal(1, "FAIL: %0d errors", errors);
        $finish;
    end

    initial begin
        #(15000 * MS);
        $fatal(1, "FAIL: simulation timeout");
    end

endmodule
