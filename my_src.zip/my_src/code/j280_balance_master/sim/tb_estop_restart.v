`timescale 1ns/1ps
// 验证「急停后再起摆」能正常工作：external_stop 不能把后续的 remote_start 压制掉。
// 回归的是 lqr_system 里 external_stop / remote_start 的信号组合逻辑
// （stop_control 里的 remote_start/remote_reset 项必须被 external_stop 抵消）。
module tb_estop_restart;
 reg clk=0,rst_n=0;always #10 clk=~clk;
 reg remote_start=0,remote_reset=0,external_stop=0;
 reg us_tick=0,sample_valid=0;
 reg [2:0] buttons=0;
 reg [12:0] ad_value=13'd2048;
 reg [15:0] encoder_raw=0;
 reg encoder_update=0,encoder_valid=0;
 reg signed [31:0] signed_pulses=0; reg pul=0;
 reg signed [31:0] alpha_dot=0,theta_dot=0;
 reg saturated=0,numeric_fault=0;
 reg swing_velocity_valid=0,travel_recovery_request=0;
 reg signed [31:0] arm_reference_q16=0;
 wire [2:0] state; wire [7:0] fault; wire run,core_clear,core_tick,new_encoder;
 wire signed [31:0] alpha_meas,theta_meas,alpha_c;
 wire [15:0] encoder_zero; wire [12:0] ad_zero;
 wire [31:0] encoder_seq,encoder_age_us; wire calibrated; wire feedback_ready;

 control_supervisor dut(.clk(clk),.rst_n(rst_n),.us_tick(us_tick),.sample_valid(sample_valid),
  .buttons(buttons),.ad_value(ad_value),.encoder_raw(encoder_raw),.encoder_update(encoder_update),
  .encoder_valid(encoder_valid),.signed_pulses(signed_pulses),.pul(pul),.alpha_dot(alpha_dot),
  .theta_dot(theta_dot),.saturated(saturated),.numeric_fault(numeric_fault),
  .state(state),.fault(fault),.run(run),.core_clear(core_clear),.core_tick(core_tick),
  .new_encoder(new_encoder),.alpha_meas(alpha_meas),.theta_meas(theta_meas),.alpha_c(alpha_c),
  .encoder_zero(encoder_zero),.ad_zero(ad_zero),.encoder_seq(encoder_seq),
  .encoder_age_us(encoder_age_us),.calibrated(calibrated),.remote_start(remote_start),
  .remote_reset(remote_reset),.external_stop(external_stop),.feedback_ready(feedback_ready),
  .swing_velocity_valid(swing_velocity_valid),.travel_recovery_request(travel_recovery_request),
  .arm_reference_q16(arm_reference_q16));

 integer i;
 initial begin
  repeat(4) @(negedge clk); rst_n=1;
  repeat(10) @(negedge clk);

  // ---- 场景 1：先起摆，验证能进入标定/起摆流程（state 离开 0）----
  remote_start=1;
  @(negedge clk); remote_start=0;
  repeat(5) @(negedge clk);
  if(state==0) $fatal(1,"start did not leave idle: state=%0d",state);
  $display("[1] 起摆后 state=%0d（离开 idle）",state);

  // ---- 场景 2：急停（external_stop 拉高一拍）----
  external_stop=1;
  @(negedge clk); external_stop=0;
  repeat(5) @(negedge clk);
  $display("[2] 急停后 state=%0d（应回 0/2，非故障）",state);
  if(state==4) $fatal(1,"estop landed in fault: state=%0d fault=%0d",state,fault);

  // ---- 场景 3：急停后再起摆，必须能重新离开 idle/ready ----
  remote_start=1;
  @(negedge clk); remote_start=0;
  repeat(5) @(negedge clk);
  $display("[3] 急停后再起摆 state=%0d",state);
  // 关键断言：急停后起摆不能停留在 idle(0)；应进入标定(1)或 ready(2) 等非空闲状态。
  if(state==0) $fatal(1,"estop blocked restart: state stuck at 0");

  $display("PASS: estop -> restart works, state leaves idle both times");
  $finish;
 end
 initial begin #2000000;$fatal(1,"timeout");end
endmodule
