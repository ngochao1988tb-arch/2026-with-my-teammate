`timescale 1ns/1ps
`include "control_config.vh"
// PROJECT_ALL 集成用例：语音(Y14/Y15) + 上位机(L20/K20) + 串口屏(K22/L22) 四路串口共存。
// 验证目标：
//   1) 上位机命令在语音模块接在板上的情况下照样生效；
//   2) 语音急停帧(AA 55 00 41 FB)能产生 v_stop，不会被上位机流量吞掉；
//   3) 语音急停之后上位机仍能继续下发命令（不会被语音锁死）；
//   4) 语音口持续跑数据时，上位机口的上行快照照常输出，两路互不串字节。
module tb_hmi_voice_iso;
 localparam TB_CLK_HZ=1152000;      // 10 拍/bit，配合 10ns 时钟 ≈ 仿真快 87 倍
 reg clk=0,rst_n=0;always #5 clk=~clk;
 reg rx_pc=1,rx_scr=1,rx_voice=1;
 wire pul,dir,ena,mtx,aclk,oe,tx_pc,tx_scr,tx_voice,tx_slave;
 top #(.PC_DEBUG_EN(0)) dut(.clk_50m(clk),.rst_n(rst_n),.key_sw(4'b1111),.pul_out(pul),.dir_out(dir),.ena_out(ena),
  .motor_rx(1'b1),.motor_tx(mtx),.adc_clk(aclk),.adc_oe_n(oe),.adc_data_in(10'd466),
  .hmi_rx(rx_pc),.hmi_tx(tx_pc),.screen_rx(rx_scr),.screen_tx(tx_scr),
  .slave_rx(1'b1),.slave_tx(tx_slave),.voice_rx(rx_voice),.voice_tx(tx_voice),.telemetry_tx());

 defparam dut.u_lqr.u_hmi_rx_pc.CLK_HZ=TB_CLK_HZ;
 defparam dut.u_lqr.u_hmi_rx_screen.CLK_HZ=TB_CLK_HZ;
 defparam dut.u_lqr.u_hmi_tx_pc.CLK_HZ=TB_CLK_HZ;
 defparam dut.u_lqr.u_hmi_tx_screen.CLK_HZ=TB_CLK_HZ;
 defparam dut.u_lqr.u_voice.CLK_HZ=TB_CLK_HZ;
 defparam dut.u_lqr.u_slave_link.CLK_HZ=TB_CLK_HZ;

 // 上行快照监视（上位机口）
 wire b_pc,fe1;wire [7:0] byte_pc;
 serial_rx #(.CLK_HZ(TB_CLK_HZ),.BAUD(115200)) mon_pc(clk,rst_n,tx_pc,byte_pc,b_pc,fe1);
 integer n_pc=0;
 always @(posedge clk) if(b_pc) n_pc=n_pc+1;

 // 语音急停脉冲计数（v_stop 是单拍脉冲，直接抓）
 integer n_vstop=0;
 always @(posedge clk) if(dut.u_lqr.v_stop) n_vstop=n_vstop+1;

 // 上位机回执计数
 integer n_ack=0;
 always @(posedge clk) if(dut.u_lqr.hmi_ack_valid) n_ack=n_ack+1;

 // automatic：两路串口要能真正并行发字节，静态 task 的循环变量会被另一路踩掉。
 task automatic byte_out(input integer ch, input [7:0] d);
  integer i;
  begin
   @(negedge clk);
   if(ch==0) rx_pc=0; else if(ch==1) rx_scr=0; else rx_voice=0;
   repeat(10) @(negedge clk);
   for(i=0;i<8;i=i+1) begin
    if(ch==0) rx_pc=d[i]; else if(ch==1) rx_scr=d[i]; else rx_voice=d[i];
    repeat(10) @(negedge clk);
   end
   if(ch==0) rx_pc=1; else if(ch==1) rx_scr=1; else rx_voice=1;
   repeat(10) @(negedge clk);
  end
 endtask

 // 上位机 18 字节帧
 task hmi_frame;input [7:0] c;input signed [31:0] s;input signed [31:0] a;input signed [31:0] v;begin
  byte_out(0,8'h55);byte_out(0,8'haa);byte_out(0,8'h20);byte_out(0,c);
  byte_out(0,s[7:0]);byte_out(0,s[15:8]);byte_out(0,s[23:16]);byte_out(0,s[31:24]);
  byte_out(0,a[7:0]);byte_out(0,a[15:8]);byte_out(0,a[23:16]);byte_out(0,a[31:24]);
  byte_out(0,v[7:0]);byte_out(0,v[15:8]);byte_out(0,v[23:16]);byte_out(0,v[31:24]);
  byte_out(0,8'h0d);byte_out(0,8'h0a);
  repeat(60) @(negedge clk);
 end endtask

 // 语音帧 AA 55 FUNC ID FB
 task voice_frame;input [7:0] func;input [7:0] id;begin
  byte_out(2,8'haa);byte_out(2,8'h55);byte_out(2,func);byte_out(2,id);byte_out(2,8'hfb);
  repeat(300) @(negedge clk);
 end endtask

 integer k;
 initial begin
  repeat(6) @(negedge clk);rst_n=1;repeat(60) @(negedge clk);

  // ---------- 1) 上位机基线：三条速度命令都要落地 ----------
  hmi_frame(8'h11,1,57,30);
  if(dut.u_lqr.u_hmi_control.speed_limit!=57) $fatal(1,"pc baseline 1: %0d",dut.u_lqr.u_hmi_control.speed_limit);
  hmi_frame(8'h11,2,44,30);
  if(dut.u_lqr.u_hmi_control.speed_limit!=44) $fatal(1,"pc baseline 2: %0d",dut.u_lqr.u_hmi_control.speed_limit);
  $display("  [1] PC commands OK before voice activity (speed=44)");

  // ---------- 2) 语音口先灌无效字节：不能产生任何动作 ----------
  for(k=0;k<40;k=k+1) byte_out(2,8'h5a);
  repeat(200) @(negedge clk);
  if(n_vstop!=0) $fatal(1,"garbage on voice port caused v_stop");
  $display("  [2] 40 garbage bytes on voice port: no action");

  // ---------- 3) 语音急停：必须产生 v_stop ----------
  voice_frame(8'h00,8'h41);          // 0x41 = ESTOP
  if(n_vstop==0) $fatal(1,"voice ESTOP frame did not raise v_stop");
  $display("  [3] voice ESTOP accepted (v_stop pulses=%0d)",n_vstop);

  // ---------- 4) 急停之后上位机仍能下发命令 ----------
  hmi_frame(8'h11,3,66,30);
  if(dut.u_lqr.u_hmi_control.speed_limit!=66)
   $fatal(1,"pc command blocked after voice ESTOP: %0d",dut.u_lqr.u_hmi_control.speed_limit);
  $display("  [4] PC still accepted after voice ESTOP (speed=66)");

  // ---------- 5) 语音口持续发数据时，上位机行帧不受影响 ----------
  fork
   begin : voice_noise
    for(k=0;k<30;k=k+1) byte_out(2,8'haa ^ k[7:0]);   // 半帧噪声，不应被认成命令
   end
   begin : pc_traffic
    hmi_frame(8'h11,4,77,30);
    hmi_frame(8'h11,5,88,30);
   end
  join
  repeat(100) @(negedge clk);
  if(dut.u_lqr.u_hmi_control.speed_limit!=88)
   $fatal(1,"pc frames corrupted by concurrent voice traffic: %0d",dut.u_lqr.u_hmi_control.speed_limit);
  $display("  [5] PC frames clean with concurrent voice traffic (speed=88)");

  // ---------- 6) 语音急停不会打断上行快照 ----------
  if(n_pc<50) $fatal(1,"snapshot stopped after voice traffic: %0d bytes",n_pc);
  if(n_ack==0) $fatal(1,"no ack seen");
  $display("  [6] uplink alive: %0d snapshot bytes, %0d acks",n_pc,n_ack);

  $display("PASS HMI+voice isolation: 4 UARTs coexist (pc/screen/slave/voice), voice ESTOP works, PC unaffected");
  $finish;
 end
 initial begin #60000000;$fatal(1,"voice isolation timeout");end
endmodule
