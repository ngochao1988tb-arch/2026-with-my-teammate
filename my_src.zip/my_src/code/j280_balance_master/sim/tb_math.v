`timescale 1ns/1ps
module tb_math;
 reg clk=0;always #10 clk=~clk;
 reg signed [15:0] x;wire [31:0] sq;
 square16_pipe dut(clk,x,sq);
 integer i,j;reg signed [31:0] expanded;reg [31:0] expect_q[0:4];
 reg rst_n=0,sample=0,enable=0,restart=0,approach=0;
 reg [12:0] ad=2048;
 reg signed [31:0] alpha=0,command_angle=0,refangle=0,approach_freq=0,approach_vel=0,restart_freq=0;
 wire signed [31:0] f0,f1,v0,v1,u0,u1;wire valid0,valid1,safe0,safe1,aa0,aa1,rec0,rec1;
 swingup_reference #(.UPDATE_CLOCKS(220)) a(clk,rst_n,sample,enable,ad,alpha,command_angle,refangle,f0,v0,u0,valid0,safe0,approach,approach_freq,approach_vel,aa0,restart,restart_freq,rec0);
 swingup_core #(.UPDATE_CLOCKS(220)) b(clk,rst_n,sample,enable,ad,alpha,command_angle,refangle,f1,v1,u1,valid1,safe1,approach,approach_freq,approach_vel,aa1,restart,restart_freq,rec1);
 initial begin
  for(j=0;j<5;j=j+1)expect_q[j]=0;
  x=0;repeat(8)@(negedge clk);
  for(i=-32768;i<32773;i=i+1)begin
   x=i;expanded=$signed(x);
   @(posedge clk);#1;
   if(i>=-32764 && sq!==expect_q[3])$fatal(1,"square x=%d actual=%h expected=%h",i-4,sq,expect_q[3]);
   for(j=4;j>0;j=j-1)expect_q[j]=expect_q[j-1];expect_q[0]=expanded*expanded;
   @(negedge clk);
  end
  rst_n=1;enable=1;
  for(i=0;i<500;i=i+1)begin
   ad=(i%90==0)?0:(i%91==0)?8190:2048+(i%100)*5;
   alpha=(i%11==0)?200000:0;command_angle=alpha;approach=i%5==0;approach_freq=(i%7)*1000;
   restart=i%73==0;restart_freq=(i%2)?500000:-500000;
   repeat(40)@(negedge clk);restart=0;sample=1;@(negedge clk);sample=0;
   repeat(300)@(negedge clk);
   if({f0,v0,u0,valid0,safe0,aa0,rec0}!=={f1,v1,u1,valid1,safe1,aa1,rec1})
    $fatal(1,"sample equivalence frame=%d freq %d/%d speed %d/%d u %d/%d",i,f0,f1,v0,v1,u0,u1);
  end
  $display("PASS: 65536 signed squares; 500 sampled swing-up frames equivalent to PROJECT_ALL (endpoint, approach, restart, recovery).");$finish;
 end
 initial begin #100000000;$fatal(1,"timeout");end
endmodule
