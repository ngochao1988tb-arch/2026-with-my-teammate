`timescale 1ns/1ps
`include "control_config.vh"
// 端到端验证：串口屏「急停(0x0f)」后再「起摆(0x01)」能真正重新起摆。
// 回归 lqr_system 里 external_stop 的组合逻辑：
//   stop_control = estop||remote_reset||remote_start||停止cmd，
//   external_stop 必须抵消掉 remote_start/remote_reset 项，否则起摆被当成停止、永远起不来。
module tb_estop_restart_e2e;
 localparam TB_RX_CLK_HZ=1152000;   // 10 拍/bit
 reg clk=0,rst_n=0;always #5 clk=~clk;
 reg rx_scr=1,rx_pc=1;
 wire pul,dir,ena,mtx,aclk,oe,tx_pc,tx_scr;
 top dut(.clk_50m(clk),.rst_n(rst_n),.key_sw(4'b1111),.pul_out(pul),.dir_out(dir),.ena_out(ena),
  .motor_rx(1'b1),.motor_tx(mtx),.adc_clk(aclk),.adc_oe_n(oe),.adc_data_in(10'd466),
  .hmi_rx(rx_pc),.hmi_tx(tx_pc),.screen_rx(rx_scr),.screen_tx(tx_scr),
  .slave_rx(1'b1),.slave_tx(),.voice_rx(1'b1),.voice_tx(),.telemetry_tx());
 defparam dut.u_lqr.u_hmi_rx_pc.CLK_HZ=TB_RX_CLK_HZ;
 defparam dut.u_lqr.u_hmi_rx_screen.CLK_HZ=TB_RX_CLK_HZ;
 defparam dut.u_lqr.u_hmi_tx_pc.CLK_HZ=TB_RX_CLK_HZ;
 defparam dut.u_lqr.u_hmi_tx_screen.CLK_HZ=TB_RX_CLK_HZ;

 integer bitn;
 // 从串口屏口(ch=1)发一个字节
 task byte_out;input [7:0] d;begin
  @(negedge clk); rx_scr=0;
  repeat(10) @(negedge clk);
  for(bitn=0;bitn<8;bitn=bitn+1) begin rx_scr=d[bitn]; repeat(10) @(negedge clk); end
  rx_scr=1; repeat(10) @(negedge clk);
 end endtask
 // 发一个完整 HMI 帧：55 AA 20 cmd seq arg speed 0d 0a
 task frame;input [7:0] c;input signed [31:0] s;begin
  byte_out(8'h55);byte_out(8'haa);byte_out(8'h20);byte_out(c);
  byte_out(s[7:0]);byte_out(s[15:8]);byte_out(s[23:16]);byte_out(s[31:24]);
  byte_out(8'd0);byte_out(8'd0);byte_out(8'd0);byte_out(8'd0);   // arg=0
  byte_out(8'd0);byte_out(8'd0);byte_out(8'd0);byte_out(8'd0);   // speed=0
  byte_out(8'h0d);byte_out(8'h0a);
  repeat(40) @(negedge clk);
 end endtask

 wire [2:0] state = dut.u_lqr.state;
 reg [2:0] prev_state;
 integer i;

 initial begin
  repeat(6) @(negedge clk); rst_n=1;
  repeat(40) @(negedge clk);

  $display("[初始] state=%0d", state);

  // 1) 发起摆 0x01
  frame(8'h01, 100);
  repeat(20) @(negedge clk);
  $display("[起摆1] state=%0d", state);

  // 2) 急停 0x0f
  frame(8'h0f, 101);
  repeat(20) @(negedge clk);
  $display("[急停] state=%0d", state);
  if(state==4) $fatal(1,"estop landed in fault");

  // 3) 再起摆 0x01 —— 关键：必须能重新起摆
  frame(8'h01, 102);
  repeat(20) @(negedge clk);
  $display("[起摆2] state=%0d", state);

  // 起摆后 state 应离开空闲(0)。注意：急停前若已标定，起摆会进 ready(2)；
  // 若未标定则进标定(1)。无论哪种，都不应卡在 0。
  if(state==0) $fatal(1,"estop blocked restart: state stuck at 0");

  $display("PASS e2e: estop(0x0f) then restart(0x01) works, state=%0d", state);
  $finish;
 end
 initial begin #5000000;$fatal(1,"timeout");end
endmodule
