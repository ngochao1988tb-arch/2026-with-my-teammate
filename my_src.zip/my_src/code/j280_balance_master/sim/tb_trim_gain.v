`timescale 1ns/1ps
`include "control_config.vh"
module tb_trim_gain;
    reg clk=0,rst_n=0,tick=0,enable=1,clear=0;
    always #20 clk=~clk;
    reg signed [31:0] position=655;
    wire done;
    wire signed [31:0] trim;
    lqr_core dut(.clk(clk),.rst_n(rst_n),.tick(tick),.clear(clear),.enable(enable),
        .alpha_meas(position),.alpha_update(1'b1),.theta_meas(32'sd0),.alpha_c(position),
        .seed(1'b0),.seed_alpha_dot(32'sd0),.seed_theta_dot(32'sd0),.seed_u(32'sd0),
        .trim_u_q16(trim),.done(done),.arm_reference_q16(32'sd0),
        .reference_changing(1'b0),.feedforward_q16(32'sd0),.trim_pause(1'b0));
    integer i,cycles,updates;
    reg signed [63:0] before_trim,delta_trim;
    task frame;
        begin
            @(negedge clk);tick=1;
            @(negedge clk);tick=0;cycles=0;
            while(!done && cycles<150)begin @(negedge clk);cycles=cycles+1;end
            if(!done)$fatal(1,"LQR result timeout");
            @(negedge clk);
        end
    endtask
    task check_direction(input signed [31:0] value);
        begin
            @(negedge clk);clear=1;position=value;
            @(negedge clk);clear=0;updates=0;
            for(i=0;i<1300;i=i+1)begin
                before_trim=dut.trim_q36;
                frame;
                delta_trim=dut.trim_q36-before_trim;
                // Ki=.5, dt=.0005 and Q20 step rounding give 262;
                // the signed position error is 655 Q16 units.
                if(delta_trim!=0)begin
                    if(delta_trim!=((value>0)?64'sd171610:-64'sd171610))
                        $fatal(1,"incorrect integral increment: %0d",delta_trim);
                    updates=updates+1;
                end
                if(i<1000 && dut.trim_q36!=0)$fatal(1,"trim started before quiet qualification");
            end
            if(updates<250)$fatal(1,"qualified integral failed to update: %0d",updates);
            if(dut.numeric_fault || dut.saturated)$fatal(1,"small-error trim caused fault/saturation");
            $display("PASS: Ki=0.5 signed error=%0d, %0d bounded integral updates after qualification",value,updates);
        end
    endtask
    initial begin
        repeat(5)@(negedge clk);rst_n=1;
        if(dut.TRIM_STEP_Q20!=262)$fatal(1,"Ki=.5 fixed-point scale=%0d",dut.TRIM_STEP_Q20);
        check_direction(655);
        check_direction(-655);
        enable=0;@(negedge clk);
        if(trim!=0 || dut.trim_q36!=0)$fatal(1,"disable failed to clear trim");
        $display("PASS: trim disable clears accumulated bias");
        $finish;
    end
    initial begin #100000000;$fatal(1,"trim test timeout");end
endmodule
