// =============================================================================
// prim_sim_stub.v  --  仅供 iverilog/ModelSim 仿真使用的 Gowin 原语替身
//
// top.v 里用 rPLL 把板载 50 MHz 分成 25 MHz 系统时钟。Gowin 综合器自带这个原语，
// 但 iverilog 不认识它，所以仿真时把这个文件一起编进去。
// **不要把它加进 project_01.gprj**（会与综合器内置原语冲突）。
//
// 这里把 CLKOUT 直接跟随 CLKIN（不做分频）：
//   sim/ 下的测试平台本来就是按“测试时钟直接当逻辑时钟”写的（用 defparam 把
//   hmi_rx/hmi_tx 的 CLK_HZ 缩到 1.152 MHz 来加速），分频反而会打断它们的比特率假设。
//   功能仿真与时基无关，因此直通最省事，也不影响任何断言。
// =============================================================================
`timescale 1ns/1ps

module rPLL (
    output wire CLKOUT,
    output wire CLKOUTP,
    output wire CLKOUTD,
    output wire CLKOUTD3,
    output reg  LOCK,
    input  wire CLKIN,
    input  wire CLKFB,
    input  wire [5:0] FBDSEL,
    input  wire [5:0] IDSEL,
    input  wire [5:0] ODSEL,
    input  wire [3:0] DUTYDA,
    input  wire [3:0] PSDA,
    input  wire [3:0] FDLY,
    input  wire RESET,
    input  wire RESET_P
);
    parameter FCLKIN = "100.0";
    parameter DYN_IDIV_SEL = "false";
    parameter IDIV_SEL = 0;
    parameter DYN_FBDIV_SEL = "false";
    parameter FBDIV_SEL = 0;
    parameter DYN_ODIV_SEL = "false";
    parameter ODIV_SEL = 8;
    parameter PSDA_SEL = "0000";
    parameter DYN_DA_EN = "false";
    parameter DUTYDA_SEL = "1000";
    parameter CLKOUT_FT_DIR = 1'b1;
    parameter CLKOUTP_FT_DIR = 1'b1;
    parameter CLKOUT_DLY_STEP = 0;
    parameter CLKOUTP_DLY_STEP = 0;
    parameter CLKFB_SEL = "internal";
    parameter CLKOUT_BYPASS = "false";
    parameter CLKOUTP_BYPASS = "false";
    parameter CLKOUTD_BYPASS = "false";
    parameter DYN_SDIV_SEL = 2;
    parameter CLKOUTD_SRC = "CLKOUT";
    parameter CLKOUTD3_SRC = "CLKOUT";
    parameter DEVICE = "GW2A-55";

    // 直通（见文件头说明）
    assign CLKOUT  = CLKIN;
    assign CLKOUTP = CLKIN;
    assign CLKOUTD = CLKIN;
    assign CLKOUTD3= CLKIN;

    // 上电后 100 ns 报锁定，避免复位链卡在 X
    initial LOCK = 1'b0;
    initial #100 LOCK = 1'b1;

    // 综合保护：真机上绝对不允许走到这里
    // synopsys translate_off
    always @(posedge CLKIN) if (RESET === 1'b1) LOCK <= 1'b0;
    // synopsys translate_on
endmodule
