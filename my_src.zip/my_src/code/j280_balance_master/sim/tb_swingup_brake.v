`timescale 1ns/1ps
`include "control_config.vh"
// Capture-approach deceleration for first swing-up and RUN -> SWINGUP retry.
// The saved baseline can run with -Ptb_swingup_brake.REQUIRE_ZERO=0.
// iverilog -g2012 -I src -s tb_swingup_brake -o sim/brake.vvp src/swingup_core.v sim/tb_swingup_brake.v
// vvp sim/brake.vvp
module tb_swingup_brake;
    parameter REQUIRE_ZERO=1;
    parameter TEST_HZ=1920;
    localparam integer EXPECTED_DECEL_Q8=
        (`CFG_SWINGUP_APPROACH_DECEL_HZ_PER_S*64'sd256*`CFG_MOTION_PERIOD_US)/1000000;
`ifdef CFG_SWINGUP_RETRY_APPROACH_DECEL_HZ_PER_S
    localparam integer EXPECTED_RETRY_DECEL_Q8=
        (`CFG_SWINGUP_RETRY_APPROACH_DECEL_HZ_PER_S*64'sd256*`CFG_MOTION_PERIOD_US)/1000000;
`else
    localparam integer EXPECTED_RETRY_DECEL_Q8=EXPECTED_DECEL_Q8;
`endif
    localparam integer EXPECTED_RECOVERY_Q8=
        (`CFG_SWINGUP_RECOVERY_ACCEL_HZ_PER_S*64'sd256*`CFG_MOTION_PERIOD_US)/1000000;
    localparam integer EXPECTED_ACCEL_Q8=
        (`CFG_SWINGUP_APPROACH_ACCEL_HZ_PER_S*64'sd256*`CFG_MOTION_PERIOD_US)/1000000;
    reg clk=0, rst_n=0, sample=0, enable=0, preview=1, restart=0;
    always #20 clk=~clk;
    reg [12:0] ad=13'd1313; // Approximately +20 degrees, inside approach entry.
    reg signed [31:0] target=0, restart_frequency=0;
    wire signed [31:0] frequency;
    wire active, valid, recovery, safe;
    swingup_core #(.UPDATE_CLOCKS(220)) dut(
        .clk(clk),.rst_n(rst_n),.sample_valid(sample),.enable(enable),
        .ad_value(ad),.alpha_meas(32'sd0),.alpha_c(32'sd0),
        .arm_reference_q16(32'sd0),.frequency_q8(frequency),
        .theta_dot_q16(),.u_q16(),.velocity_valid(valid),.capture_safe(safe),
        .approach_valid(preview),.approach_frequency_q8(target),
        .approach_arm_velocity(32'sd0),.approach_active(active),
        .restart(restart),.restart_frequency_q8(restart_frequency),
        .recovery_active(recovery),.launch_phase());
    task motion_frame;
        integer j;
        begin
            for(j=0;j<`CFG_MOTION_PERIOD_US/`CFG_CONTROL_PERIOD_US;j=j+1) begin
                @(negedge clk); sample=1;
                @(negedge clk); sample=0;
                repeat(240) @(negedge clk);
            end
        end
    endtask
    task settle(input integer command_q8);
        begin
            target=command_q8;
            repeat(30) motion_frame;
            if(!active || frequency!==target) $fatal(1,"Approach failed to reach target");
        end
    endtask
    integer retry, direction, frames, old_frequency, drop, first_drop, accel_step;
    integer zero_seen, recovery_frames;
    initial begin
        repeat(10) @(negedge clk);
        rst_n=1;
        repeat(8) motion_frame;
        if(!valid) $fatal(1,"Stationary ADC did not establish velocity validity");
        enable=1;
        for(retry=0;retry<=1;retry=retry+1) begin
            for(direction=1;direction>=-1;direction=direction-2) begin
                if(retry) begin
                    restart_frequency=direction*TEST_HZ*256;
                    @(negedge clk); restart=1;
                    @(negedge clk); restart=0;
                    if(!recovery || frequency!==restart_frequency || safe)
                        $fatal(1,"Retry must inherit command and block capture during recovery");
                    recovery_frames=0;
                    while(recovery && recovery_frames<20) begin
                        if(safe || active) $fatal(1,"Approach or capture enabled during recovery");
                        old_frequency=frequency;
                        motion_frame;
                        recovery_frames=recovery_frames+1;
                        drop=direction*(old_frequency-frequency);
                        if(drop<=0 || direction*frequency<0 || drop>EXPECTED_RECOVERY_Q8)
                            $fatal(1,"Retry recovery failed monotonic bounded braking");
                        if(recovery_frames==1 && drop!=EXPECTED_RECOVERY_Q8)
                            $fatal(1,"Retry initial recovery step does not match configuration");
                    end
                    if(recovery || frequency!==0) $fatal(1,"Retry recovery did not stop");
                    $display("RECOVERY direction=%0d first_drop_q8=%0d frames=%0d time_ms=%0d",direction,EXPECTED_RECOVERY_Q8,recovery_frames,recovery_frames*2);
                end
                settle(direction*TEST_HZ*256);
                target=0;
                frames=0;
                first_drop=0;
                while(frequency!=0 && frames<20) begin
                    old_frequency=frequency;
                    motion_frame;
                    frames=frames+1;
                    if(!active) $fatal(1,"Approach dropped out while braking");
                    drop=direction*(old_frequency-frequency);
                    if(drop<=0 || direction*frequency<0) $fatal(1,"Stop was not monotonic or overshot");
                    if(frames==1) first_drop=drop;
                end
                if(frequency!==0) $fatal(1,"Approach failed to stop");
                if(first_drop!=(retry ? EXPECTED_RETRY_DECEL_Q8 : EXPECTED_DECEL_Q8))
                    $fatal(1,"Braking step does not match first/retry profile");
                $display("STOP retry=%0d direction=%0d first_drop_q8=%0d frames=%0d time_ms=%0d",retry,direction,first_drop,frames,frames*2);
                target=direction*TEST_HZ*256;
                motion_frame;
                accel_step=direction*frequency;
                if(accel_step<=0) $fatal(1,"Acceleration failed");
                if(accel_step!=EXPECTED_ACCEL_Q8) $fatal(1,"Ordinary approach acceleration changed");
                $display("ACCEL retry=%0d direction=%0d first_step_q8=%0d",retry,direction,accel_step);
                settle(direction*TEST_HZ*256);
                // A lower nonzero target must be reached without undershooting it.
                target=direction*480*256;
                repeat(8) begin
                    motion_frame;
                    if(direction*frequency<480*256) $fatal(1,"Slowing undershot nonzero target");
                end
                if(frequency!==target) $fatal(1,"Slowing did not reach nonzero target");
                settle(direction*TEST_HZ*256);
                target=-direction*TEST_HZ*256;
                frames=0; zero_seen=0;
                while(frequency!=target && frames<40) begin
                    old_frequency=frequency;
                    motion_frame;
                    frames=frames+1;
                    if(frequency==0) zero_seen=1;
                    if(REQUIRE_ZERO && direction*old_frequency>0 && direction*frequency<0)
                        $fatal(1,"Reversal crossed zero without completing brake stage");
                    if(REQUIRE_ZERO && direction*old_frequency<=0 && direction*(old_frequency-frequency)>accel_step)
                        $fatal(1,"Reverse acceleration exceeded ordinary acceleration rate");
                end
                if(frequency!==target || (REQUIRE_ZERO && !zero_seen)) $fatal(1,"Reverse target not reached through zero");
                $display("REVERSE retry=%0d direction=%0d zero_seen=%0d frames=%0d",retry,direction,zero_seen,frames);
            end
        end
        target=0;
        repeat(10) motion_frame;
        preview=0;
        repeat(2) motion_frame;
        if(!active || frequency!==0) $fatal(1,"Short preview gap did not hold last target");
        preview=1;
        settle(TEST_HZ*256);
        ad=13'd1000; // Approximately +43 degrees, outside approach exit.
        repeat(2) motion_frame;
        if(active) $fatal(1,"Approach ignored angle exit");
        ad=13'd1313;
        repeat(12) motion_frame;
        settle(TEST_HZ*256);
        ad=0;
        motion_frame;
        if(active || safe) $fatal(1,"Endpoint did not block approach and capture");
        enable=0;
        repeat(2) @(negedge clk);
        if(frequency!==0 || active) $fatal(1,"Disable did not clear motor command");
        // A new enable episode must not retain the previous retry's stronger profile.
        ad=13'd1313;preview=1;enable=1;
        repeat(12) motion_frame;
        settle(TEST_HZ*256);
        target=0;old_frequency=frequency;
        motion_frame;
        if(old_frequency-frequency!=EXPECTED_DECEL_Q8)
            $fatal(1,"Retry profile leaked into a new first swing-up");
        $display("FRESH first_drop_q8=%0d",old_frequency-frequency);
        enable=0;
        $display("PASS: approach braking, retry, reverse, preview hold, angle/endpoint exit, disable");
        $finish;
    end
    initial begin #100000000; $fatal(1,"Timeout"); end
endmodule
