`timescale 1ns/1ps
`include "control_config.vh"
module tb_adc_precision;
    reg clk=0,rst_n=0;
    always #20 clk=~clk;
    reg [9:0] adc=0;
    wire [12:0] ad;
    wire valid;
    adc_sampler dut(.clk(clk),.rst_n(rst_n),.adc_data_in(adc),
        .adc_clk(),.adc_oe_n(),.ad_value(ad),.sample_valid(valid));
    reg signed [31:0] injected;
    integer i,q,expected,checks=0,frames=0,clocks=0,last_sample=-1;
    integer max_mid_error=0;
    reg check_cadence=0;
    always @(posedge clk) begin
        clocks=clocks+1;
        #1;
        if(rst_n && valid && check_cadence) begin
            if(last_sample>=0 && clocks-last_sample!=dut.FRAME_CYCLES)
                $fatal(1,"sample period changed: %0d clocks",clocks-last_sample);
            last_sample=clocks;
            frames=frames+1;
        end
    end
    task check_fraction(input integer raw_q16,input integer want);
        begin
            @(negedge clk);
            injected=raw_q16;
            force dut.y2_q=injected;
            force dut.frame_pos=dut.FRAME_CYCLES-1;
            @(posedge clk);#2;
            if(!valid || ad!==want[12:0])
                $fatal(1,"ADC conversion raw_q16=%0d got=%0d want=%0d",raw_q16,ad,want);
            checks=checks+1;
            @(negedge clk);
            release dut.frame_pos;
            release dut.y2_q;
            // Each isolated conversion starts a fresh cadence measurement.
            last_sample=-1;
        end
    endtask
    initial begin
        repeat(5) @(negedge clk);rst_n=1;
        // Sweep eighth-count inputs across the entire ten-bit sensor span.
        // Expected output advances in uploaded counts, including fractional
        // filter values that the former four-count output grid discarded.
        for(i=0;i<=8184;i=i+1) begin
            expected=135+(i+1)/2;
            check_fraction(i*8192,expected);
        end
        check_fraction(362*65536,1583);
        check_fraction(362*65536+16384,1584);
        check_fraction(362*65536+32768,1585);
        check_fraction(362*65536+49152,1586);
        check_fraction(363*65536,1587);
        // Verify both sides of a half-uploaded-count rounding boundary.
        check_fraction(362*65536+8191,1583);
        check_fraction(362*65536+8192,1584);
        check_fraction(362*65536+8193,1584);
        $display("PASS: %0d full-span/fractional ADC conversions, upright zero and rounding boundaries",checks);
        rst_n=0;last_sample=-1;check_cadence=1;repeat(5) @(negedge clk);
        adc=0;rst_n=1;
        repeat(6) begin @(posedge valid);#2; end
        if(ad!=135)$fatal(1,"zero ADC rail=%0d",ad);
        @(negedge clk);rst_n=0;last_sample=-1;adc=1023;
        repeat(5) @(negedge clk);rst_n=1;
        repeat(6) begin @(posedge valid);#2; end
        if(ad!=4227)$fatal(1,"full ADC rail=%0d",ad);
        // The physical input remains ten-bit. A small dither around the
        // upright half-count demonstrates that the running EMA retains its
        // mean instead of being rounded back to 1583/1587.
        @(negedge clk);rst_n=0;last_sample=-1;adc=362;
        repeat(5) @(negedge clk);rst_n=1;
        for(i=0;i<80;i=i+1) begin
            @(posedge valid);#2;
            if(i>=40) begin
                q=$signed({1'b0,ad})-1585;
                if(q<0)q=-q;
                if(q>max_mid_error)max_mid_error=q;
                if(q>1)$fatal(1,"EMA midpoint not preserved: ad=%0d",ad);
            end
            @(negedge clk);adc=(i%2==0)?363:362;
        end
        $display("PASS: ADC rails 135/4227, 500 us cadence, dithered midpoint within %0d uploaded count",max_mid_error);
        $finish;
    end
    initial begin #100000000;$fatal(1,"ADC test timeout");end
endmodule
