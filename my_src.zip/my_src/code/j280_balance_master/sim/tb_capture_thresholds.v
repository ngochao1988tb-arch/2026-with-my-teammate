`timescale 1ns/1ps
`include "control_config.vh"
// Exercise the real supervisor capture comparison and dwell, both signs and
// first/retry entry. Isolate measured inputs so each threshold is tested alone.
module tb_capture_thresholds;
    reg clk=0,rst_n=0,sample_valid=0;
    always #20 clk=~clk;
    reg signed [31:0] angle_counts=0,arm_speed=0,pendulum_speed=0,arm_angle=0,command_angle=0;
    reg velocity_valid=1,rail=0;
    wire [2:0] state;
    wire [7:0] fault;
    localparam integer ANGLE=$rtoi(`CFG_SWINGUP_CAPTURE_ANGLE_DEG/180.0*`CFG_ADC_THETA_COUNTS_PER_PI);
    localparam integer SPEED=$rtoi(`CFG_SWINGUP_CAPTURE_SPEED_RAD_S*65536.0);
    localparam integer ARM_SPEED=$rtoi(`CFG_SWINGUP_CAPTURE_ARM_SPEED_RAD_S*65536.0);
    localparam integer TRACKING=$rtoi(`CFG_SWINGUP_CAPTURE_TRACKING_DEG*3.141592653589793*65536.0/180.0);
    localparam integer ARM_POSITION=$rtoi(`CFG_SWINGUP_CAPTURE_ARM_POSITION_DEG*3.141592653589793*65536.0/180.0);
    control_supervisor dut(
        .clk(clk),.rst_n(rst_n),.us_tick(1'b0),.sample_valid(sample_valid),.buttons(3'd0),
        .ad_value(13'd1560),.encoder_raw(16'd0),.encoder_update(1'b0),.encoder_valid(1'b1),
        .signed_pulses(32'sd0),.pul(1'b0),.alpha_dot(arm_speed),.theta_dot(pendulum_speed),
        .saturated(1'b0),.numeric_fault(1'b0),.state(state),.fault(fault),
        .remote_start(1'b0),.remote_reset(1'b0),.external_stop(1'b0),
        .swing_velocity_valid(velocity_valid),.travel_recovery_request(1'b0),.arm_reference_q16(32'sd0));
    task check(input integer ok,input [639:0] message);
        if(!ok) $fatal(1,"%0s state=%0d fault=%0d",message,state,fault);
    endtask
    task enter_swing(input integer retry);
        begin
            @(negedge clk);rst_n=0;sample_valid=0;
            angle_counts=0;arm_speed=0;pendulum_speed=0;arm_angle=0;command_angle=0;velocity_valid=1;rail=0;
            repeat(4) @(negedge clk);rst_n=1;
            @(negedge clk);dut.calibrated=1;dut.state=retry ? 3:5;
            if(retry) angle_counts=`CFG_FALLEN_COUNTS+1;
            repeat(4) @(negedge clk);
            angle_counts=0;
            repeat(4) @(negedge clk);
            check(state==5,"enter first/retry swing-up");
        end
    endtask
    task frame;
        begin
            @(negedge clk);sample_valid=1;
            @(negedge clk);sample_valid=0;
            repeat(300) @(negedge clk);
        end
    endtask
    task capture_with_dwell;
        begin
            repeat(`CFG_SWINGUP_CAPTURE_FRAMES-1) frame();
            check(state==5,"capture must retain confirmation dwell");
            frame();check(state==3 && fault==0,"capture at relaxed boundary");
        end
    endtask
    task reject_capture;
        begin repeat(`CFG_SWINGUP_CAPTURE_FRAMES+1) frame();check(state==5,"invalid capture must be rejected");end
    endtask
    integer retry,direction;
    initial begin
        force dut.feedback_ok=1;
        force dut.encoder_seen=1;
        force dut.arm_limit=0;
        force dut.endpoint_failed=0;
        force dut.ad_relative_q=angle_counts;
        force dut.alpha_meas=arm_angle;
        force dut.alpha_c=command_angle;
        force dut.rail=rail;
        check(ANGLE==171 && SPEED==247726 && ARM_SPEED==240844,"+5 percent capture thresholds after quantization");
        check(`CFG_SWINGUP_CAPTURE_FRAMES==20,"capture confirmation frames unchanged");
        for(retry=0;retry<=1;retry=retry+1) begin
            for(direction=1;direction>=-1;direction=direction-2) begin
                enter_swing(retry);angle_counts=direction*ANGLE;capture_with_dwell();
                enter_swing(retry);angle_counts=direction*(ANGLE+1);reject_capture();
                enter_swing(retry);pendulum_speed=direction*SPEED;capture_with_dwell();
                enter_swing(retry);pendulum_speed=direction*(SPEED+1);reject_capture();
                enter_swing(retry);arm_speed=direction*ARM_SPEED;capture_with_dwell();
                enter_swing(retry);arm_speed=direction*(ARM_SPEED+1);reject_capture();
                enter_swing(retry);arm_angle=direction*(TRACKING+1);reject_capture();
                enter_swing(retry);arm_angle=direction*(ARM_POSITION+1);command_angle=arm_angle;reject_capture();
                $display("CAPTURE retry=%0d direction=%0d angle_counts=%0d speed_q16=%0d arm_speed_q16=%0d PASS",retry,direction,ANGLE,SPEED,ARM_SPEED);
            end
        end
        enter_swing(0);velocity_valid=0;reject_capture();
        enter_swing(1);rail=1;reject_capture();
        enter_swing(0);angle_counts=ANGLE;
        repeat(10) frame();angle_counts=ANGLE+1;frame();angle_counts=ANGLE;
        capture_with_dwell();
        $display("PASS: first/retry capture boundaries, both signs, 20-frame dwell/reset, tracking/travel/feedback guards");
        $finish;
    end
    initial begin #100000000;$fatal(1,"timeout");end
endmodule
