`timescale 1ns/1ps
`include "control_config.vh"
// Multi-rate model observer and one five-state LQR. State: signed Q16;
// coefficients: signed Q20. One shared multiply/accumulate pipeline.
module lqr_core #(
    parameter FEEDFORWARD_EN=0, PAUSE_TRIM_EN=0,
    parameter signed [31:0] U_MAX_Q16 = (`CFG_PULSE_RAD_Q32 * 64'sd1 * `CFG_CONTROL_MAX_FREQUENCY_HZ) >>> 16
)(
    input clk, input rst_n, input tick, input clear, input enable,
    input signed [31:0] alpha_meas, input alpha_update,
    input signed [31:0] theta_meas, input signed [31:0] alpha_c,
    output signed [31:0] alpha_hat, theta_hat, alpha_dot_hat, theta_dot_hat,
    output reg signed [31:0] u_q16,
    output reg saturated, output reg done, output reg numeric_fault,
    input seed, input signed [31:0] seed_alpha_dot, seed_theta_dot,
    input signed [31:0] seed_u,
    output signed [31:0] trim_u_q16,
    output reg [7:0] trim_status,
    input signed [31:0] arm_reference_q16,
    input reference_changing,
    input signed [31:0] feedforward_q16,
    input trim_pause
);
    `include "lqr_coefficients.vh"
    reg signed [31:0] x [0:3];
    reg signed [31:0] snapshot [0:4];
    reg signed [31:0] predicted [0:3];
    reg signed [31:0] am, tm, ea, et;
    reg fresh, enabled;
    reg signed [31:0] reference_snapshot,feedback_alpha,feedback_command;
    reg signed [31:0] ff_snapshot;
    wire signed [67:0] feedback_alpha_wide={{36{x[0][31]}},x[0]}-{{36{reference_snapshot[31]}},reference_snapshot};
    wire signed [67:0] feedback_command_wide={{36{snapshot[4][31]}},snapshot[4]}-{{36{reference_snapshot[31]}},reference_snapshot};
    wire signed [32:0] target_error=$signed({am[31],am})-$signed({reference_snapshot[31],reference_snapshot});
    reg [3:0] stage;
    reg [2:0] row, col;
    reg signed [63:0] product;
    reg signed [67:0] accumulator;
    wire signed [67:0] product_ext={{4{product[63]}},product};
    wire signed [67:0] sum=accumulator+product_ext;
    wire signed [67:0] scaled=sum>>>20;
    wire signed [67:0] correction=product_ext>>>20;
    wire signed [67:0] corrected=$signed(predicted[row])+correction;
    wire signed [67:0] innovation_a={{36{am[31]}},am}-{{36{predicted[0][31]}},predicted[0]};
    wire signed [67:0] innovation_t={{36{tm[31]}},tm}-{{36{predicted[1][31]}},predicted[1]};
    assign alpha_hat=x[0]; assign theta_hat=x[1];
    assign alpha_dot_hat=x[2]; assign theta_dot_hat=x[3];
    function signed [31:0] bounded;
        input signed [67:0] value;
        begin
            if(value>68'sd2147483647) bounded=32'sh7fffffff;
            else if(value< -68'sd2147483648) bounded=32'sh80000000;
            else bounded=value[31:0];
        end
    endfunction
    // Positive integral sign follows this five-state plant's nonminimum-phase
    // response; this is a slow bias trim, never a large-angle recovery loop.
    localparam signed [31:0] TRIM_STEP_Q20 = (`CFG_RUN_TRIM_KI * `CFG_RUN_TRIM_UPDATE_US * 1.048576);
    localparam signed [63:0] TRIM_LIMIT_Q36 = (`CFG_RUN_TRIM_LIMIT * 68719476736.0);
    localparam integer QUIET_FRAMES = (`CFG_RUN_TRIM_QUIET_US + `CFG_RUN_TRIM_UPDATE_US-1)/`CFG_RUN_TRIM_UPDATE_US;
    // rad/s^2 times the LQR period, represented in Q36.
    localparam signed [63:0] TRIM_RETURN_STEP_Q36 = (`CFG_RUN_TRIM_RETURN_RATE * `CFG_LQR_PERIOD_US * 68719.476736);
    reg trim_return_pending;
    reg signed [63:0] trim_q36;
    reg [15:0] quiet_frames;
    localparam integer SPEED_GRACE_FRAMES = (`CFG_RUN_TRIM_SPEED_GRACE_US+`CFG_LQR_PERIOD_US-1)/`CFG_LQR_PERIOD_US;
    reg [15:0] trim_speed_bad_frames;
    wire signed [67:0] trim_q16 = $signed(trim_q36) >>> 20;
    assign trim_u_q16=trim_q16[31:0];
    // 26103148: optional low-pass on the trim contribution. SHIFT=0 bypasses
    // it (26103150 base), SHIFT=6 is ~5 Hz, SHIFT=8 is ~1.2 Hz at 2 kHz.
    localparam integer TRIM_LP_SHIFT=`CFG_RUN_TRIM_LP_SHIFT;
    localparam signed [31:0] TRIM_LP_HALF=(TRIM_LP_SHIFT==0) ? 32'sd0 :
        (32'sd1<<(TRIM_LP_SHIFT-1));
    reg signed [31:0] trim_lp_q16;
    always @(posedge clk or negedge rst_n)
        if(!rst_n) trim_lp_q16<=0;
        else if(clear || seed) trim_lp_q16<=0;
        else if(done) trim_lp_q16<=(TRIM_LP_SHIFT==0) ? $signed(trim_u_q16) :
            trim_lp_q16+(($signed(trim_u_q16)-trim_lp_q16+TRIM_LP_HALF)>>>TRIM_LP_SHIFT);
    wire signed [67:0] requested = -scaled + $signed(trim_lp_q16);
    wire signed [32:0] tracking_error = $signed({am[31],am})-$signed({snapshot[4][31],snapshot[4]});
    localparam signed [32:0] TRIM_DEADBAND=$rtoi(`CFG_RUN_TRIM_DEADBAND_DEG*3.141592653589793*65536.0/180.0+0.5);
    localparam signed [32:0] TRIM_POSITION_MAX=$rtoi(`CFG_RUN_TRIM_POSITION_MAX_DEG*3.141592653589793*65536.0/180.0+0.5);
    reg signed [31:0] trim_error;
    reg trim_tracking_good,trim_target_good,trim_theta_good,trim_speed_good;
    // Snapshot inputs settle many clocks before the final MAC result. Register
    // these independent gates so the trim counter does not span a subtract,
    // comparisons and the full eligibility reduction in one clock.
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            trim_error<=0;
            trim_tracking_good<=0;trim_target_good<=0;trim_theta_good<=0;trim_speed_good<=0;
        end else begin
            // Snapshots settle before the final MAC. A continuous soft band
            // avoids a step in integral drive when crossing the boundary.
            if(target_error>TRIM_DEADBAND) trim_error<=target_error-TRIM_DEADBAND;
            else if(target_error< -TRIM_DEADBAND) trim_error<=target_error+TRIM_DEADBAND;
            else trim_error<=0;
            trim_tracking_good<=tracking_error > -3431 && tracking_error < 3431;
            trim_target_good<=target_error > -TRIM_POSITION_MAX && target_error < TRIM_POSITION_MAX;
            trim_theta_good<=tm > -9151 && tm < 9151;
            trim_speed_good<=x[2] > -65536 && x[2] < 65536 && x[3] > -65536 && x[3] < 65536;
        end
    end
    wire trim_state_eligible = enabled && enable && !numeric_fault && !reference_changing && !trim_return_pending &&
        !(PAUSE_TRIM_EN && trim_pause) &&
        trim_theta_good && trim_target_good && trim_tracking_good;
    wire trim_base_eligible = trim_state_eligible && requested < U_MAX_Q16 && requested > -U_MAX_Q16;
    // 26103182: stage 7 replaces product with the integral increment. In
    // stage 8, requested no longer contains the final alpha_c feedback term.
    // Preserve headroom from the completed LQR result, while rechecking the
    // live state/feedback/motion guards before committing the increment.
    reg trim_headroom_at_result;
    // 26110302: LQR/观测器按 3 ms 一拍运行，编码器约 482 Hz（~2 ms 一个样本），
    // 所以每拍本来就能拿到新样本，无需长窗口。窗口从 7 拍（3 ms 下 21 ms）收到 2 拍
    // （6 ms）：允许丢一个样本，但不会长时间用陈旧误差积分。
    reg [2:0] fresh_age;
    always @(posedge clk or negedge rst_n)
        if(!rst_n) fresh_age<=0;
        else if(alpha_update) fresh_age<=0;
        else if(tick && stage==0 && fresh_age<3'd3) fresh_age<=fresh_age+1'b1;
    wire fresh_recent=alpha_update || (fresh_age<3'd2);
    wire trim_eligible = trim_base_eligible && fresh_recent && trim_speed_good;
    wire signed [64:0] next_trim = $signed(trim_q36)+$signed(product);
    integer i;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            for(i=0;i<4;i=i+1) begin x[i]<=0; predicted[i]<=0; end
            for(i=0;i<5;i=i+1) snapshot[i]<=0;
            reference_snapshot<=0;feedback_alpha<=0;feedback_command<=0;
            ff_snapshot<=0;
            am<=0; tm<=0; ea<=0; et<=0; fresh<=0; enabled<=0;
            stage<=0; row<=0; col<=0; product<=0; accumulator<=0;
            u_q16<=0; saturated<=0; done<=0; numeric_fault<=0; trim_q36<=0; quiet_frames<=0; trim_status<=0;
            trim_speed_bad_frames<=0;trim_return_pending<=0;
            trim_headroom_at_result<=0;
        end else if(clear) begin
            for(i=0;i<4;i=i+1) begin x[i]<=0; predicted[i]<=0; end
            stage<=0; u_q16<=0; saturated<=0; done<=0; numeric_fault<=0; trim_q36<=0; quiet_frames<=0; trim_status<=0;
            trim_speed_bad_frames<=0;trim_return_pending<=0;
            trim_headroom_at_result<=0;
        end else if(seed) begin
            x[0]<=alpha_meas; x[1]<=theta_meas;
            x[2]<=seed_alpha_dot; x[3]<=seed_theta_dot;
            stage<=0; u_q16<=seed_u; saturated<=0; done<=0; numeric_fault<=0; trim_q36<=0; quiet_frames<=0; trim_status<=0;
            trim_speed_bad_frames<=0;trim_return_pending<=0;
            trim_headroom_at_result<=0;
        end else begin
            done<=0;
            // Latch even a one-clock accepted-target event, including events
            // arriving during the observer MAC or the final integral stage.
            if(reference_changing) trim_return_pending<=1;
            if(!enable) begin u_q16<=0; trim_q36<=0; quiet_frames<=0; trim_status<=0; end
            case(stage)
                0:if(tick) begin
                    for(i=0;i<4;i=i+1) snapshot[i]<=x[i];
                    snapshot[4]<=alpha_c; am<=alpha_meas; tm<=theta_meas;
                    reference_snapshot<=arm_reference_q16;
                    ff_snapshot<=FEEDFORWARD_EN ? feedforward_q16:32'sd0;
                    fresh<=alpha_update; enabled<=enable;
                    row<=0; col<=0; accumulator<=0; stage<=1;
                end
                1:begin product<=$signed(coefficient(row*5+col))*$signed(snapshot[col]); stage<=2; end
                2:begin
                    if(col==4) begin
                        predicted[row]<=bounded(scaled);
                        if(scaled>68'sd2147483647 || scaled< -68'sd2147483648) numeric_fault<=1;
                        col<=0; accumulator<=0;
                        if(row==3) stage<=3;
                        else begin row<=row+1'b1; stage<=1; end
                    end else begin accumulator<=sum; col<=col+1'b1; stage<=1; end
                end
                3:begin
                    ea<=fresh ? bounded(innovation_a) : 0; et<=bounded(innovation_t);
                    if((fresh && (innovation_a>68'sd2147483647 || innovation_a< -68'sd2147483648)) ||
                       innovation_t>68'sd2147483647 || innovation_t< -68'sd2147483648) numeric_fault<=1;
                    row<=0; stage<=4;
                end
                4:begin
                    product<=$signed(coefficient(20+row))*$signed(row[0] ? et : ea);
                    stage<=5;
                end
                5:begin
                    x[row]<=bounded(corrected);
                    if(corrected>68'sd2147483647 || corrected< -68'sd2147483648) numeric_fault<=1;
                    if(row==3) begin
                        // Observer remains in physical coordinates; only the
                        // two position terms in -K*x use the latched target.
                        feedback_alpha<=bounded(feedback_alpha_wide);
                        feedback_command<=bounded(feedback_command_wide);
                        if(feedback_alpha_wide>68'sd2147483647 || feedback_alpha_wide< -68'sd2147483648 ||
                           feedback_command_wide>68'sd2147483647 || feedback_command_wide< -68'sd2147483648) numeric_fault<=1;
                        // Bias the existing MAC: requested = ff - K*error + trim.
                        // FF participates in the same saturation and fault path.
                        col<=0; accumulator<=-($signed({{36{ff_snapshot[31]}},ff_snapshot})<<<20); stage<=6;
                    end
                    else begin row<=row+1'b1; stage<=4; end
                end
                6:begin
                    product<=$signed(coefficient(24+col))*$signed(col==4 ? feedback_command : col==0 ? feedback_alpha : x[col]);
                    stage<=7;
                end
                7:begin
                    if(col==4) begin
                        trim_headroom_at_result<=requested < U_MAX_Q16 && requested > -U_MAX_Q16;
                        if(!enabled || !enable) begin u_q16<=0; saturated<=0; end
                        else if(requested>U_MAX_Q16) begin u_q16<=U_MAX_Q16; saturated<=1; end
                        else if(requested< -U_MAX_Q16) begin u_q16<=-U_MAX_Q16; saturated<=1; end
                        else begin u_q16<=requested; saturated<=0; end
                        // Diagnostic bits: fresh, theta/arm/tracking/speed bounds,
                        // output headroom, accumulated dwell, eligible this frame.
                        trim_status<={trim_eligible, (quiet_frames>=QUIET_FRAMES-1 && trim_eligible),
                            (requested<U_MAX_Q16 && requested>-U_MAX_Q16),
                            trim_speed_good,trim_tracking_good,trim_target_good,trim_theta_good, fresh};
                        // Remove the old position's bias once per control
                        // result. Keep returning after a short target event;
                        // a stopped ramp cannot retain a partially removed bias.
                        if(reference_changing || trim_return_pending) begin
                            quiet_frames<=0;trim_speed_bad_frames<=0;
                            if(trim_q36 > TRIM_RETURN_STEP_Q36)
                                trim_q36<=trim_q36-TRIM_RETURN_STEP_Q36;
                            else if(trim_q36 < -TRIM_RETURN_STEP_Q36)
                                trim_q36<=trim_q36+TRIM_RETURN_STEP_Q36;
                            else begin
                                trim_q36<=0;
                                if(!reference_changing) trim_return_pending<=0;
                            end
                        end
                        // Reuse the MAC multiplier; update trim for the next frame.
                        product <= $signed(trim_error)*$signed(TRIM_STEP_Q20);
                        if(trim_eligible) begin
                            trim_speed_bad_frames<=0;
                            if(quiet_frames < QUIET_FRAMES) quiet_frames<=quiet_frames+1'b1;
                            stage<=8;
                        end else begin
                            // Never integrate stale or invalid-speed frames.
                            // A brief gap preserves dwell: the 2kHz loop can
                            // outrun the roughly 482Hz encoder response stream.
                            if(trim_base_eligible && trim_speed_bad_frames<SPEED_GRACE_FRAMES) begin
                                trim_speed_bad_frames<=trim_speed_bad_frames+1'b1;
                            end else begin
                                quiet_frames<=0;
                                trim_speed_bad_frames<=0;
                            end
                            done<=1; stage<=0;
                        end
                    end else begin accumulator<=sum; col<=col+1'b1; stage<=6; end
                end
                8:begin
                    if(trim_state_eligible && trim_headroom_at_result && fresh_recent &&
                       trim_speed_good && quiet_frames >= QUIET_FRAMES) begin
                        if(next_trim > TRIM_LIMIT_Q36) trim_q36<=TRIM_LIMIT_Q36;
                        else if(next_trim < -TRIM_LIMIT_Q36) trim_q36<=-TRIM_LIMIT_Q36;
                        else trim_q36<=next_trim[63:0];
                    end
                    done<=1; stage<=0;
                end
                default:stage<=0;
            endcase
            // Motion immediately invalidates qualification, but trim itself
            // changes only at the result boundary above. Disable stays immediate.
            if(reference_changing || trim_return_pending) begin
                trim_speed_bad_frames<=0;quiet_frames<=0;trim_status<=0;
            end
            if(!enable) begin
                trim_return_pending<=0;trim_speed_bad_frames<=0;
                trim_q36<=0;quiet_frames<=0;trim_status<=0;
            end
        end
    end
endmodule
