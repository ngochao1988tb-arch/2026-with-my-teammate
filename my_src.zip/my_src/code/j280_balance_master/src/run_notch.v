`timescale 1ns/1ps
`include "control_config.vh"
// RUN command notch. The serial multiplier keeps the
// filter off the DSP fabric and outside the 50 MHz critical path.
module run_notch #(
    parameter signed [15:0] C0=`CFG_RUN_NOTCH_C0_Q13,
    parameter signed [15:0] C1=`CFG_RUN_NOTCH_C1_Q13,
    parameter signed [15:0] C2=`CFG_RUN_NOTCH_C2_Q13,
    parameter signed [15:0] C3=`CFG_RUN_NOTCH_C3_Q13,
    parameter signed [15:0] C4=`CFG_RUN_NOTCH_C4_Q13
)(
    input clk, input rst_n, input tick, input enable,
    input signed [31:0] u,
    output reg signed [31:0] y,
    output reg done
);
    // Q13 coefficients from the single tuning header at the configured rate.
    // y = b0*x + b1*x1 + b2*x2 + (-a1)*y1 + (-a2)*y2.

    localparam GUARD_BITS=`CFG_RUN_NOTCH_GUARD_BITS;
    localparam STATE_WIDTH=32+GUARD_BITS;
    localparam signed [67:0] STATE_MAX=(68'sd1<<<(STATE_WIDTH-1))-1;
    localparam signed [67:0] STATE_MIN=-(68'sd1<<<(STATE_WIDTH-1));
    localparam [GUARD_BITS-1:0] HALF=1<<(GUARD_BITS-1);
    reg signed [STATE_WIDTH-1:0] x0, x1, x2, y1, y2;
    wire signed [STATE_WIDTH-1:0] input_state={u,{GUARD_BITS{1'b0}}};
    reg signed [63:0] multiplicand;
    reg [15:0] multiplier;
    reg negate;
    reg [4:0] bit_index;
    reg [2:0] term;
    reg signed [63:0] partial;
    reg signed [67:0] accumulator;
    reg [2:0] stage;
    reg first;

    function signed [31:0] bounded;
        input signed [67:0] value;
        begin
            if(value>68'sd2147483647) bounded=32'sh7fffffff;
            else if(value< -68'sd2147483648) bounded=32'sh80000000;
            else bounded=value[31:0];
        end
    endfunction

    function signed [STATE_WIDTH-1:0] bounded_state;
        input signed [67:0] value;
        begin
            if(value>STATE_MAX) bounded_state=STATE_MAX[STATE_WIDTH-1:0];
            else if(value<STATE_MIN) bounded_state=STATE_MIN[STATE_WIDTH-1:0];
            else bounded_state=value[STATE_WIDTH-1:0];
        end
    endfunction

    // Round nearest, exact ties away from zero. For a negative number the
    // upper slice is floor(), so increment only when remainder > one half.
    wire round_up=(y1[GUARD_BITS-1:0]>HALF) ||
        (y1[GUARD_BITS-1:0]==HALF && !y1[STATE_WIDTH-1]);
    wire signed [32:0] rounded_output=
        $signed({y1[STATE_WIDTH-1],y1[STATE_WIDTH-1:GUARD_BITS]})+
        $signed({32'd0,round_up});

    wire [STATE_WIDTH-1:0] state = term==0 ? x0 : term==1 ? x1 : term==2 ? x2 :
                         term==3 ? y1 : y2;
    wire signed [15:0] coeff = term==0 ? C0 : term==1 ? C1 : term==2 ? C2 :
                               term==3 ? C3 : C4;
    wire signed [67:0] product_ext={{4{partial[63]}},partial};
    wire signed [67:0] product = negate ? -product_ext : product_ext;
    wire signed [67:0] sum = accumulator + product;

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            x0<=0; x1<=0; x2<=0; y1<=0; y2<=0; y<=0; done<=0;
            multiplicand<=0; multiplier<=0; negate<=0; bit_index<=0;
            term<=0; partial<=0; accumulator<=0; stage<=0; first<=1;
        end else if(!enable) begin
            x0<=0; x1<=0; x2<=0; y1<=0; y2<=0; y<=0; done<=0;
            multiplicand<=0; multiplier<=0; negate<=0; bit_index<=0;
            term<=0; partial<=0; accumulator<=0; stage<=0; first<=1;
        end else if(tick) begin
            done<=0;
            x0<=input_state; x1<=x0; x2<=x1;
            if(first) begin
                x0<=input_state; x1<=input_state; x2<=input_state;
                y1<=input_state; y2<=input_state; y<=u;
                first<=0; stage<=0; done<=1;
            end else begin
                term<=0; accumulator<=0; partial<=0; bit_index<=0; stage<=1;
            end
        end else begin
            done<=0;
            case(stage)
                1:begin
                    multiplicand<=$signed({{(64-STATE_WIDTH){state[STATE_WIDTH-1]}},state});
                    multiplier<=coeff[15] ? -coeff : coeff;
                    negate<=coeff[15];
                    partial<=0; bit_index<=0; stage<=2;
                end
                2:begin
                    partial<=partial+(multiplier[0] ? multiplicand : 64'sd0);
                    multiplicand<=multiplicand<<<1;
                    multiplier<=multiplier>>1;
                    if(bit_index==15) stage<=3; else bit_index<=bit_index+1'b1;
                end
                3:begin
                    accumulator<=sum;
                    if(term==4) stage<=4;
                    else begin term<=term+1'b1; stage<=1; end
                end
                4:begin
                    y2<=y1;
                    y1<=bounded_state(accumulator>>>13);
                    stage<=5;
                end
                5:begin
                    // Separate the wide state clamp from Q16 rounding. One
                    // extra 50MHz clock; still applied in the same control frame.
                    y<=bounded({{35{rounded_output[32]}},rounded_output});
                    done<=1;
                    stage<=0;
                end
                default:stage<=0;
            endcase
        end
    end
endmodule
