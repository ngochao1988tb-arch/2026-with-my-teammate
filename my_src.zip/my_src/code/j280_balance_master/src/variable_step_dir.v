`timescale 1ns/1ps
`include "control_config.vh"
// Signed variable-frequency STP/DIR source. Frequency is Q8 Hz.
// The signed pulse counter changes only on physical STP rising edges.
module variable_step_dir #(
    parameter CLK_HZ=`CFG_HARDWARE_CLOCK_HZ,
    parameter DIR_SETUP_US=`CFG_CONTROL_DIR_SETUP_US,
    parameter PULSE_HIGH_US=`CFG_CONTROL_PULSE_HIGH_US,
    parameter ENABLE_ACTIVE_HIGH=`CFG_HARDWARE_ENABLE_ACTIVE_HIGH
)(
    input clk, input rst_n, input run,
    input signed [31:0] frequency_q8,
    output reg pul, output reg dir,
    output ena,
    output reg signed [31:0] signed_pulses,
    output reg pulse_event
);
    localparam SETUP_CYCLES=CLK_HZ/1000000*DIR_SETUP_US;
    localparam HIGH_CYCLES=CLK_HZ/1000000*PULSE_HIGH_US;
    // Signed commanded displacement minus displacement already emitted.
    // Keep fractional steps across reversals and zero commands; clear on STOP.
    // Continue integrating during pulse-high and DIR setup, with no extra edges.
    localparam signed [40:0] PHASE_MODULUS=41'sd256*CLK_HZ;
    reg signed [40:0] phase;
    reg [31:0] setup_timer, high_timer;
    wire signed [40:0] frequency_ext={{9{frequency_q8[31]}},frequency_q8};
    wire signed [40:0] phase_sum=phase+frequency_ext;
    // A pending full step takes priority; otherwise prepare DIR in advance.
    wire wanted_dir=(phase_sum>=PHASE_MODULUS) ? 1'b0 :
                    (phase_sum<=-PHASE_MODULUS) ? 1'b1 : frequency_q8[31];
    assign ena=ENABLE_ACTIVE_HIGH ? 1'b1 : 1'b0;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            pul<=0; dir<=0; phase<=0; setup_timer<=0; high_timer<=0;
            signed_pulses<=0; pulse_event<=0;
        end else begin
            pulse_event<=0;
            if(run) phase<=phase_sum;
            else begin phase<=0; setup_timer<=0; end
            if(pul) begin
                if(high_timer==HIGH_CYCLES-1) begin pul<=0; high_timer<=0; end
                else high_timer<=high_timer+1'b1;
            end else if(!run || frequency_q8==0) begin
                setup_timer<=0;
            end else if(wanted_dir!=dir) begin
                dir<=wanted_dir; setup_timer<=0;
            end else if(setup_timer<SETUP_CYCLES) begin
                setup_timer<=setup_timer+1'b1;
            end else begin
                if(phase_sum>=PHASE_MODULUS) begin
                    phase<=phase_sum-PHASE_MODULUS;
                    pul<=1; high_timer<=0; pulse_event<=1;
                    signed_pulses<=signed_pulses+1'b1;
                end else if(phase_sum<=-PHASE_MODULUS) begin
                    phase<=phase_sum+PHASE_MODULUS;
                    pul<=1; high_timer<=0; pulse_event<=1;
                    signed_pulses<=signed_pulses-1'b1;
                end
            end
        end
    end
endmodule
