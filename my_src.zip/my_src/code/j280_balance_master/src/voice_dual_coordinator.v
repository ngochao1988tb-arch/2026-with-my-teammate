`timescale 1ns / 1ps

module voice_dual_coordinator #(
    parameter integer CLK_HZ = 50_000_000,
    parameter integer ACTION_TIMEOUT_MS = 10000
) (
    input  wire       clk,
    input  wire       rst_n,
    input  wire       command_valid,
    input  wire [1:0] command_target_mask,
    input  wire [3:0] command_action,
    input  wire [7:0] command_id,
    input  wire [7:0] command_angle,
    input  wire       command_right,
    input  wire       local_done,
    input  wire       local_fail,
    input  wire       remote_done,
    input  wire       remote_fail,
    output reg        local_cmd_valid,
    output reg  [3:0] local_action,
    output reg  [7:0] local_action_id,
    output reg  [7:0] local_angle,
    output reg        local_right,
    output reg        remote_cmd_valid,
    output reg  [3:0] remote_action,
    output reg  [7:0] remote_action_id,
    output reg  [7:0] remote_angle,
    output reg        remote_right,
    output reg        report_valid,
    output reg  [1:0] report_target_mask,
    output reg  [7:0] report_action_id,
    output reg  [2:0] report_result,
    output wire       ready,
    output wire       busy
);

    localparam [3:0] ACTION_ESTOP = 4'd2;

    localparam [2:0] RESULT_OK         = 3'd0;
    localparam [2:0] RESULT_MAIN_FAIL  = 3'd1;
    localparam [2:0] RESULT_SLAVE_FAIL = 3'd2;
    localparam [2:0] RESULT_BOTH_FAIL  = 3'd3;
    localparam [2:0] RESULT_LINK_FAIL  = 3'd4;

    localparam [0:0] S_IDLE = 1'b0;
    localparam [0:0] S_WAIT = 1'b1;

    localparam integer TIMEOUT_CYCLES =
        (CLK_HZ / 1000) * ACTION_TIMEOUT_MS;
    localparam integer TIMEOUT_WIDTH =
        $clog2(TIMEOUT_CYCLES + 1);

    reg       state;
    reg [1:0] target_latched;
    reg [3:0] action_latched;
    reg [7:0] action_id_latched;
    reg [7:0] angle_latched;
    reg       right_latched;
    reg       local_pending;
    reg       remote_pending;
    reg       local_failed_flag;
    reg       remote_failed_flag;
    reg [TIMEOUT_WIDTH-1:0] timeout_counter;

    wire local_finished =
        local_pending && (local_done || local_fail);
    wire remote_finished =
        remote_pending && (remote_done || remote_fail);

    wire all_finished =
        (state == S_WAIT) &&
        (!local_pending || local_finished) &&
        (!remote_pending || remote_finished);

    wire effective_local_fail =
        local_failed_flag || (local_finished && local_fail);
    wire effective_remote_fail =
        remote_failed_flag || (remote_finished && remote_fail);

    wire [2:0] completion_result =
        (effective_local_fail && effective_remote_fail) ?
        RESULT_BOTH_FAIL :
        effective_local_fail ? RESULT_MAIN_FAIL :
        effective_remote_fail ? RESULT_SLAVE_FAIL :
        RESULT_OK;

    assign ready = (state == S_IDLE);
    assign busy  = (state == S_WAIT);

    always @(posedge clk) begin
        if (!rst_n) begin
            state               <= S_IDLE;
            target_latched      <= 2'b00;
            action_latched      <= 4'd0;
            action_id_latched   <= 8'd0;
            angle_latched       <= 8'd0;
            right_latched       <= 1'b0;
            local_pending       <= 1'b0;
            remote_pending      <= 1'b0;
            local_failed_flag   <= 1'b0;
            remote_failed_flag  <= 1'b0;
            timeout_counter     <= {TIMEOUT_WIDTH{1'b0}};
            local_cmd_valid     <= 1'b0;
            local_action        <= 4'd0;
            local_action_id     <= 8'd0;
            local_angle         <= 8'd0;
            local_right         <= 1'b0;
            remote_cmd_valid    <= 1'b0;
            remote_action       <= 4'd0;
            remote_action_id    <= 8'd0;
            remote_angle        <= 8'd0;
            remote_right        <= 1'b0;
            report_valid        <= 1'b0;
            report_target_mask  <= 2'b00;
            report_action_id    <= 8'd0;
            report_result       <= RESULT_OK;
        end else begin
            local_cmd_valid  <= 1'b0;
            remote_cmd_valid <= 1'b0;
            report_valid     <= 1'b0;

            if (command_valid && (command_action == ACTION_ESTOP)) begin
                // Emergency stop always reaches both controllers immediately.
                local_cmd_valid  <= 1'b1;
                remote_cmd_valid <= 1'b1;
                local_action     <= command_action;
                remote_action    <= command_action;
                local_action_id  <= command_id;
                remote_action_id <= command_id;
                local_angle      <= command_angle;
                remote_angle     <= command_angle;
                local_right      <= command_right;
                remote_right     <= command_right;
                report_valid     <= 1'b1;
                report_target_mask <= 2'b11;
                report_action_id <= command_id;
                report_result    <= RESULT_OK;
                local_pending    <= 1'b0;
                remote_pending   <= 1'b0;
                state            <= S_IDLE;
            end else begin
                case (state)
                    S_IDLE: begin
                        if (command_valid &&
                            (command_target_mask != 2'b00)) begin
                            target_latched     <= command_target_mask;
                            action_latched     <= command_action;
                            action_id_latched  <= command_id;
                            angle_latched      <= command_angle;
                            right_latched      <= command_right;
                            local_pending      <= command_target_mask[0];
                            remote_pending     <= command_target_mask[1];
                            local_failed_flag  <= 1'b0;
                            remote_failed_flag <= 1'b0;
                            timeout_counter    <=
                                {TIMEOUT_WIDTH{1'b0}};

                            if (command_target_mask[0]) begin
                                local_cmd_valid <= 1'b1;
                                local_action    <= command_action;
                                local_action_id <= command_id;
                                local_angle     <= command_angle;
                                local_right     <= command_right;
                            end

                            if (command_target_mask[1]) begin
                                remote_cmd_valid <= 1'b1;
                                remote_action    <= command_action;
                                remote_action_id <= command_id;
                                remote_angle     <= command_angle;
                                remote_right     <= command_right;
                            end

                            state <= S_WAIT;
                        end
                    end

                    S_WAIT: begin
                        if (local_finished) begin
                            local_pending <= 1'b0;
                            if (local_fail)
                                local_failed_flag <= 1'b1;
                        end

                        if (remote_finished) begin
                            remote_pending <= 1'b0;
                            if (remote_fail)
                                remote_failed_flag <= 1'b1;
                        end

                        if (all_finished) begin
                            report_valid       <= 1'b1;
                            report_target_mask <= target_latched;
                            report_action_id   <= action_id_latched;
                            report_result      <= completion_result;
                            state              <= S_IDLE;
                        end else if (timeout_counter >=
                                     (TIMEOUT_CYCLES - 1)) begin
                            report_valid       <= 1'b1;
                            report_target_mask <= target_latched;
                            report_action_id   <= action_id_latched;
                            report_result      <= RESULT_LINK_FAIL;
                            local_pending      <= 1'b0;
                            remote_pending     <= 1'b0;
                            state              <= S_IDLE;
                        end else begin
                            timeout_counter <= timeout_counter + 1'b1;
                        end
                    end

                    default: state <= S_IDLE;
                endcase
            end
        end
    end

endmodule
