`timescale 1ns/1ps
`include "control_config.vh"
module key_debounce #(parameter CLK_HZ=`CFG_HARDWARE_CLOCK_HZ, DEBOUNCE_MS=`CFG_BUTTONS_DEBOUNCE_MS)(
    input clk, input rst_n, input key_n, output reg pressed
);
    localparam COUNT=CLK_HZ/1000*DEBOUNCE_MS;
    reg meta, sync, stable;
    reg [31:0] timer;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin meta<=1; sync<=1; stable<=1; timer<=0; pressed<=0; end
        else begin
            meta<=key_n; sync<=meta; pressed<=0;
            if (sync==stable) timer<=0;
            else if (timer==COUNT-1) begin stable<=sync; timer<=0; if (!sync) pressed<=1; end
            else timer<=timer+1'b1;
        end
    end
endmodule
