// =============================================================================
// rv32_soc.v  --  PicoRV32 软核子系统（RV32I + IMEM/DMEM + LCD8080 + 状态快照）
//
// 设计要点
//   * 只有一路 CPU 总线（picorv32 原生存储接口），地址译码后接 4 个从设备：
//       IMEM 0x0000_0000 32 KB  只读（写被丢弃并置错误位）
//       DMEM 0x0001_0000 16 KB  可读写，按字节通道做读-改-写
//       LCD  0x2000_0000        窗口访问走时序状态机，寄存器访问 1 周期
//       SNAP 0x3000_0000        一致快照（只读）
//       SYS  0x3000_0080        系统/命令寄存器
//     未映射地址立即应答并置 BUS_ERR，绝不挂死总线。
//   * 软核复位有两条独立路径：外部 rst_n、软件 SYS_CTRL[0]。
//     两条都只复位本子系统，与平衡控制逻辑无任何连接（只读快照除外）。
//   * 该模块不包含任何跨时钟域逻辑：整机只有一个 50 MHz 时钟。
// =============================================================================
`timescale 1ns/1ps
`include "lcd_config.vh"

module rv32_soc #(
    parameter integer IMEM_KB    = `CFG_RV_IMEM_BYTES/1024,
    parameter integer DMEM_KB    = `CFG_RV_DMEM_BYTES/1024,
    parameter         IMEM_INIT  = "imem.hex",
    parameter         DMEM_INIT  = "dmem.hex",
    parameter integer RV_MUL     = 0,      // 1=启用 picorv32 串行乘法器（不用 DSP）
    parameter integer ENABLE_CMD = `CFG_RV_ENABLE_CMD,
    parameter integer ENABLE_TOUCH = 0,
    parameter integer DATA_WIDTH = `CFG_LCD_DATA_WIDTH,
    // 系统时钟频率：只影响状态快照的刷新节拍（默认周期 1000us）。
    // 2026-11-02 起系统时钟为 25 MHz（rPLL 二分频）。
    parameter integer CLK_HZ     = 25_000_000
)(
    input  wire        clk,
    input  wire        rst_n,

    // ---------------- 状态输入（来自 lqr_system，只读） ----------------
    input  wire signed [31:0] st_alpha_q16,
    input  wire signed [31:0] st_theta_q16,
    input  wire signed [31:0] st_arm_ref_q16,
    input  wire signed [31:0] st_freq_q8,
    input  wire signed [31:0] st_u_q16,
    input  wire signed [31:0] st_alpha_dot,
    input  wire signed [31:0] st_theta_dot,
    input  wire signed [31:0] st_alpha_c,
    input  wire        [31:0] st_enc_raw,
    input  wire        [31:0] st_enc_age_us,
    input  wire        [31:0] st_enc_seq,
    input  wire        [31:0] st_ctrl_count,
    input  wire        [31:0] st_t_us,
    input  wire        [12:0] st_ad_value,
    input  wire         [7:0] st_state,
    input  wire         [7:0] st_fault,
    input  wire         [7:0] st_flags,
    input  wire        [31:0] st_build_tag,
    input  wire               st_run,
    input  wire               st_calibrated,
    input  wire               st_saturated,
    input  wire               st_fb_ready,
    input  wire               st_swing_active,

    // ---------------- LCD 物理侧 ----------------
    output wire               lcd_cs_n,
    output wire               lcd_wr_n,
    output wire               lcd_rd_n,
    output wire               lcd_rs,
    output wire               lcd_reset_n,
    output wire [DATA_WIDTH-1:0] lcd_data_o,
    output wire               lcd_data_oe,
    input  wire [DATA_WIDTH-1:0] lcd_data_i,
    output wire               lcd_bl,

    // Optional HR2046 touch GPIO, SYS+0x2c output / SYS+0x30 input.
    input wire touch_miso,
    input wire touch_pen_n,
    output wire touch_cs_n,
    output wire touch_clk,
    output wire touch_mosi,

    // ---------------- 命令通道（可选，默认关闭） ----------------
    input  wire               hmi_req_active,   // UART 侧正在发请求，让出总线
    output wire               rv_req,           // 单周期提交脉冲
    output wire [7:0]         rv_cmd,
    output wire [31:0]        rv_seq,
    output wire [31:0]        rv_arg,
    output wire [31:0]        rv_speed,
    input  wire               rv_ack,           // hmi_control.ack_valid
    input  wire [31:0]        rv_ack_seq,
    input  wire [31:0]        rv_ack_result
);

    // -----------------------------------------------------------------
    // 复位
    // -----------------------------------------------------------------
    reg [1:0] rst_sync;
    always @(posedge clk or negedge rst_n)
        if (!rst_n) rst_sync <= 2'b00; else rst_sync <= {rst_sync[0], 1'b1};
    wire rstn_ext = rst_sync[1];

    reg [1:0]  srst_cnt;
    reg        srst_hold;
    wire       soft_reset = srst_hold;
    wire       cpu_resetn = rstn_ext && !soft_reset;

    // -----------------------------------------------------------------
    // 存储器
    // -----------------------------------------------------------------
    localparam integer IMEM_WORDS = IMEM_KB * 1024 / 4;
    localparam integer DMEM_WORDS = DMEM_KB * 1024 / 4;

    reg [31:0] imem [0:IMEM_WORDS-1];
    reg [31:0] dmem [0:DMEM_WORDS-1];

    // 存储器初始化：由 tools/bin2hex.py 生成**满长度**的 hex 文件（未用部分填 0），
    // 因此这里只调用 $readmemh，不做 8K/4K 次的 for 清零循环
    // （Gowin 综合的循环展开上限是 2000 次，会直接报 EX3934）。
    initial begin
        $readmemh(IMEM_INIT, imem);
        $readmemh(DMEM_INIT, dmem);
    end

    // -----------------------------------------------------------------
    // CPU
    // -----------------------------------------------------------------
    wire        mem_valid, mem_instr, mem_ready;
    wire [31:0] mem_addr, mem_wdata, mem_rdata;
    wire [3:0]  mem_wstrb;
    wire        cpu_trap;

    picorv32 #(
        .ENABLE_COUNTERS      (1),
        .ENABLE_COUNTERS64    (0),
        .ENABLE_REGS_16_31    (1),
        .ENABLE_REGS_DUALPORT (1),
        .LATCHED_MEM_RDATA    (0),
        .TWO_STAGE_SHIFT      (1),
        .BARREL_SHIFTER       (0),
        .COMPRESSED_ISA       (0),
        .CATCH_MISALIGN       (1),
        .CATCH_ILLINSN        (1),
        .ENABLE_MUL           (RV_MUL),
        .ENABLE_FAST_MUL      (0),
        .ENABLE_DIV           (0),
        .ENABLE_IRQ           (0),
        .ENABLE_TRACE         (0),
        .REGS_INIT_ZERO       (0),
        .PROGADDR_RESET       (`CFG_RV_IMEM_BASE),
        .STACKADDR            (`CFG_RV_DMEM_BASE + `CFG_RV_DMEM_BYTES)
    ) u_cpu (
        .clk       (clk),
        .resetn    (cpu_resetn),
        .trap      (cpu_trap),
        .mem_valid (mem_valid),
        .mem_instr (mem_instr),
        .mem_ready (mem_ready),
        .mem_addr  (mem_addr),
        .mem_wdata (mem_wdata),
        .mem_wstrb (mem_wstrb),
        .mem_rdata (mem_rdata),
        .mem_la_read  (),
        .mem_la_write (),
        .mem_la_addr  (),
        .mem_la_wdata (),
        .mem_la_wstrb (),
        .pcpi_wr   (1'b0),
        .pcpi_rd   (32'd0),
        .pcpi_wait (1'b0),
        .pcpi_ready(1'b0),
        .irq       (32'd0),
        .eoi       ()
    );

    // -----------------------------------------------------------------
    // 地址译码
    // -----------------------------------------------------------------
    wire is_wr = |mem_wstrb;

    wire sel_imem = (mem_addr[31:15] == 17'd0);   // 0x0000_0000..0x0000_3FFF (16 KB)
    wire sel_dmem = (mem_addr[31:14] == 18'h0_0004);
    wire sel_snap = (mem_addr[31:8]  == 24'h30_0000);
    wire sel_sys  = sel_snap && mem_addr[7];
    wire sel_snap0= sel_snap && !mem_addr[7];
    wire sel_lcd  = (mem_addr[31:24] == 8'h20);
    wire sel_none = !(sel_imem | sel_dmem | sel_snap | sel_lcd);

    wire lcd_window = (mem_addr[7:0] == `CFG_LCD_REG_CMD) || (mem_addr[7:0] == `CFG_LCD_REG_DATA);

    wire dmem_byte_wr = sel_dmem && is_wr && (mem_wstrb != 4'hF);

    // 立即完成（读数据是组合逻辑）：快照 / 系统寄存器 / 未映射
    wire fast_acc = sel_snap | sel_none;
    // 1 个等待周期：同步 BRAM（数据下一拍才有效）、LCD 寄存器（rdata 是寄存器）
    wire mem_acc  = sel_imem | (sel_dmem && !dmem_byte_wr) | (sel_lcd && !lcd_window);

    // -----------------------------------------------------------------
    // 总线状态机
    // -----------------------------------------------------------------
    localparam [1:0] B_IDLE = 2'd0, B_ACC = 2'd1, B_LOW = 2'd2, B_MEM = 2'd3;
    reg [1:0] bstate;
    reg       mem_ready_r;
    reg [31:0] rdata_r;

    wire start = (bstate == B_IDLE) && mem_valid && cpu_resetn;

    // 各从设备片选（单周期脉冲）
    wire cs_lcd  = start && sel_lcd;
    wire cs_snap = start && sel_snap0;
    wire cs_sys  = start && sel_sys;

    wire lcd_done;
    wire [31:0] lcd_rdata;

    // DMEM 字节写：读-改-写（DMEM 16 KB = 4096 word，索引 addr[13:2]）
    wire [11:0] dm_raddr = mem_addr[13:2];
    reg  [11:0] dm_waddr_r;
    reg  [31:0] dm_wdata_r;
    reg  [3:0]  dm_wstrb_r;
    reg         rmw_active;
    reg  [31:0] dm_q;

    wire [31:0] dm_merged = {
        dm_wstrb_r[3] ? dm_wdata_r[31:24] : dm_q[31:24],
        dm_wstrb_r[2] ? dm_wdata_r[23:16] : dm_q[23:16],
        dm_wstrb_r[1] ? dm_wdata_r[15:8]  : dm_q[15:8],
        dm_wstrb_r[0] ? dm_wdata_r[7:0]   : dm_q[7:0]
    };

    wire dm_we    = (start && sel_dmem && is_wr && (mem_wstrb == 4'hF)) || rmw_active;
    wire [11:0] dm_wa = rmw_active ? dm_waddr_r : dm_raddr;
    wire [31:0] dm_wd = rmw_active ? dm_merged  : mem_wdata;

    // 慢速访问完成
    wire slow_done = dmem_byte_wr ? rmw_active : (sel_lcd && lcd_window) ? lcd_done : 1'b0;

    always @(posedge clk or negedge cpu_resetn) begin
        if (!cpu_resetn) begin
            rmw_active <= 1'b0;
            dm_waddr_r <= 12'd0;
            dm_wdata_r <= 32'd0;
            dm_wstrb_r <= 4'd0;
        end else if (start && dmem_byte_wr) begin
            rmw_active <= 1'b1;
            dm_waddr_r <= dm_raddr;
            dm_wdata_r <= mem_wdata;
            dm_wstrb_r <= mem_wstrb;
        end else begin
            rmw_active <= 1'b0;
        end
    end

    // 单口 BRAM：读端口常开，写端口带使能
    // imem 地址固定取 addr[13:2]（16 KB = 4096 word，索引 12 位，永不出界）
    reg [31:0] imem_q;
    always @(posedge clk) begin
        if (dm_we) dmem[dm_wa] <= dm_wd;
        dm_q   <= dmem[dm_raddr];
        imem_q <= imem[mem_addr[14:2]];
    end

    // 寄存器窗口（组合读）
    wire [31:0] snap_rdata;
    wire [31:0] sys_rdata;

    // 读数据选择
    wire [31:0] fast_rdata = sel_imem ? imem_q :
                             sel_dmem ? dm_q :
                             sel_snap0 ? snap_rdata :
                             sel_sys ? sys_rdata :
                             sel_lcd ? lcd_rdata :
                             32'h0000_0000;

    always @(posedge clk or negedge cpu_resetn) begin
        if (!cpu_resetn) begin
            bstate      <= B_IDLE;
            mem_ready_r <= 1'b0;
            rdata_r     <= 32'd0;
        end else begin
            mem_ready_r <= 1'b0;
            case (bstate)
                B_IDLE: if (mem_valid) begin
                    if (fast_acc) begin
                        rdata_r     <= fast_rdata;
                        mem_ready_r <= 1'b1;
                        bstate      <= B_LOW;
                    end else if (mem_acc) begin
                        bstate <= B_MEM;       // 等 BRAM 输出寄存器
                    end else begin
                        bstate <= B_ACC;
                    end
                end
                B_MEM: begin
                    rdata_r     <= sel_imem ? imem_q :
                                   sel_dmem ? dm_q   : lcd_rdata;
                    mem_ready_r <= 1'b1;
                    bstate      <= B_LOW;
                end
                B_ACC: if (slow_done) begin
                    rdata_r     <= lcd_rdata;
                    mem_ready_r <= 1'b1;
                    bstate      <= B_LOW;
                end
                B_LOW: if (!mem_valid) bstate <= B_IDLE;
                default: bstate <= B_IDLE;
            endcase
        end
    end

    assign mem_ready = mem_ready_r;
    assign mem_rdata = rdata_r;

    // -----------------------------------------------------------------
    // 总线错误锁存
    // -----------------------------------------------------------------
    reg bus_err_none, bus_err_imem;
    always @(posedge clk or negedge rstn_ext) begin
        if (!rstn_ext) begin
            bus_err_none <= 1'b0;
            bus_err_imem <= 1'b0;
        end else begin
            if (start && sel_none)                   bus_err_none <= 1'b1;
            if (start && sel_imem && is_wr)          bus_err_imem <= 1'b1;
            if (cs_sys && is_wr && (mem_addr[6:0] == 7'h08) && mem_wdata[0]) bus_err_none <= 1'b0;
            if (cs_sys && is_wr && (mem_addr[6:0] == 7'h08) && mem_wdata[1]) bus_err_imem <= 1'b0;
        end
    end

    // -----------------------------------------------------------------
    // 状态快照
    // -----------------------------------------------------------------
    status_snapshot #(.CLK_HZ(CLK_HZ)) u_snap (
        .clk (clk),
        .rst_n (rstn_ext),
        .i_alpha_q16   (st_alpha_q16),
        .i_theta_q16   (st_theta_q16),
        .i_arm_ref_q16 (st_arm_ref_q16),
        .i_freq_q8     (st_freq_q8),
        .i_u_q16       (st_u_q16),
        .i_alpha_dot   (st_alpha_dot),
        .i_theta_dot   (st_theta_dot),
        .i_alpha_c     (st_alpha_c),
        .i_enc_raw     (st_enc_raw),
        .i_enc_age_us  (st_enc_age_us),
        .i_enc_seq     (st_enc_seq),
        .i_ctrl_count  (st_ctrl_count),
        .i_t_us        (st_t_us),
        .i_ad_value    (st_ad_value),
        .i_state       (st_state),
        .i_fault       (st_fault),
        .i_flags       (st_flags),
        .i_build_tag   (st_build_tag),
        .i_run         (st_run),
        .i_calibrated  (st_calibrated),
        .i_saturated   (st_saturated),
        .i_fb_ready    (st_fb_ready),
        .i_swing_active(st_swing_active),
        .cs    (cs_snap),
        .we    (is_wr),
        .addr  (mem_addr[7:0]),
        .wdata (mem_wdata),
        .wstrb (mem_wstrb),
        .rdata (snap_rdata)
    );

    // -----------------------------------------------------------------
    // LCD8080
    // -----------------------------------------------------------------
    lcd8080 #(.DATA_WIDTH(DATA_WIDTH)) u_lcd (
        .clk        (clk),
        .rst_n      (rstn_ext),
        .cs         (cs_lcd),
        .we         (is_wr),
        .addr       (mem_addr[7:0]),
        .wdata      (mem_wdata),
        .wstrb      (mem_wstrb),
        .rdata      (lcd_rdata),
        .done       (lcd_done),
        .lcd_cs_n   (lcd_cs_n),
        .lcd_wr_n   (lcd_wr_n),
        .lcd_rd_n   (lcd_rd_n),
        .lcd_rs     (lcd_rs),
        .lcd_reset_n(lcd_reset_n),
        .lcd_data_o (lcd_data_o),
        .lcd_data_oe(lcd_data_oe),
        .lcd_data_i (lcd_data_i),
        .lcd_bl     (lcd_bl)
    );

    // -----------------------------------------------------------------
    // SYS 寄存器 + 命令通道
    // -----------------------------------------------------------------
    localparam [6:0] S_ID     = 7'h00;
    localparam [6:0] S_SCRATCH= 7'h04;
    localparam [6:0] S_BUSERR = 7'h08;
    localparam [6:0] S_CTRL   = 7'h0C;
    localparam [6:0] S_CMD    = 7'h10;
    localparam [6:0] S_ARG    = 7'h14;
    localparam [6:0] S_SPEED  = 7'h18;
    localparam [6:0] S_GO     = 7'h1C;
    localparam [6:0] S_STAT   = 7'h20;
    localparam [6:0] S_RES    = 7'h24;
    localparam [6:0] S_CYC    = 7'h28;   // 自由运行 32 位周期计数器（软件延时基准）

    reg [2:0] touch_out;
    reg [1:0] touch_in_meta, touch_in_sync;
    assign {touch_mosi, touch_clk, touch_cs_n} = ENABLE_TOUCH ? touch_out : 3'b001;
    always @(posedge clk or negedge cpu_resetn) begin
        if (!cpu_resetn) begin
            touch_out <= 3'b001;
            touch_in_meta <= 2'b11;
            touch_in_sync <= 2'b11;
        end else begin
            touch_in_meta <= ENABLE_TOUCH ? {touch_pen_n,touch_miso} : 2'b11;
            touch_in_sync <= touch_in_meta;
            if (ENABLE_TOUCH && cs_sys && is_wr && mem_addr[6:0] == 7'h2c && mem_wstrb[0])
                touch_out <= mem_wdata[2:0];
        end
    end

    reg [31:0] scratch;
    reg [31:0] cyc_cnt;
    reg [7:0]  cmd_reg;
    reg [31:0] arg_reg, speed_reg;
    reg [7:0] cmd_active;
    reg [31:0] arg_active, speed_active;
    reg        go_pulse;
    reg        cmd_disabled;

    // 命令通道状态机
    reg        cmd_busy, cmd_done, cmd_timeout;
    reg [31:0] cmd_seq_cnt;
    reg [31:0] cmd_seq_lat, ack_res_lat;
    reg [31:0] cmd_tmo;
    reg        rv_pending;
    wire       rv_fire = rv_pending && !hmi_req_active;
    wire       my_ack  = rv_ack && (rv_ack_seq == cmd_seq_lat);

    assign rv_req   = rv_fire;
    assign rv_cmd   = cmd_active;
    assign rv_seq   = cmd_seq_lat;
    assign rv_arg   = arg_active;
    assign rv_speed = speed_active;

    always @(posedge clk or negedge rstn_ext) begin
        if (!rstn_ext) begin
            scratch      <= 32'd0;
            cyc_cnt      <= 32'd0;
            cmd_reg      <= 8'd0;
            cmd_active<=0; arg_active<=0; speed_active<=0;
            arg_reg      <= 32'd0;
            speed_reg    <= 32'd0;
            go_pulse     <= 1'b0;
            cmd_disabled <= 1'b0;
            cmd_busy     <= 1'b0;
            cmd_done     <= 1'b0;
            cmd_timeout  <= 1'b0;
            cmd_seq_cnt  <= 32'h4000_0000;
            cmd_seq_lat  <= 32'd0;
            ack_res_lat  <= 32'd0;
            cmd_tmo      <= 32'd0;
            rv_pending   <= 1'b0;
            srst_hold    <= 1'b0;
            srst_cnt     <= 2'd0;
        end else begin
            go_pulse <= 1'b0;
            cyc_cnt  <= cyc_cnt + 32'd1;

            // 软复位：保持 4 个周期
            if (srst_cnt != 2'd0) begin
                srst_cnt  <= srst_cnt - 2'd1;
                srst_hold <= (srst_cnt != 2'd1);
            end

            if (cs_sys && is_wr) begin
                case (mem_addr[6:0])
                    S_SCRATCH: if (mem_wstrb[0]) scratch <= mem_wdata;
                    S_CTRL:    if (mem_wstrb[0] && mem_wdata[0]) begin
                                   srst_cnt  <= 2'd3;
                                   srst_hold <= 1'b1;
                               end
                    S_CMD:     if (mem_wstrb[0]) cmd_reg   <= mem_wdata[7:0];
                    S_ARG:     if (mem_wstrb[0]) arg_reg   <= mem_wdata;
                    S_SPEED:   if (mem_wstrb[0]) speed_reg <= mem_wdata;
                    S_GO:      if (mem_wstrb[0] && mem_wdata[0]) go_pulse <= 1'b1;
                    default: ;
                endcase
            end

            // 提交
            if (go_pulse) begin
                cmd_done    <= 1'b0;
                cmd_timeout <= 1'b0;
                if (!ENABLE_CMD) begin
                    cmd_disabled <= 1'b1;
                end else if (!cmd_busy) begin
                    cmd_seq_lat <= cmd_seq_cnt;
                    cmd_active <= cmd_reg; arg_active <= arg_reg; speed_active <= speed_reg;
                    cmd_seq_cnt <= cmd_seq_cnt == 32'h7ffffffe ? 32'h40000000 : cmd_seq_cnt + 32'd1;
                    cmd_busy    <= 1'b1;
                    rv_pending  <= 1'b1;
                    cmd_tmo     <= 32'd0;
                end
            end

            if (rv_fire) rv_pending <= 1'b0;

            if (cmd_busy) begin
                if (my_ack) begin
                    cmd_busy    <= 1'b0;
                    cmd_done    <= 1'b1;
                    ack_res_lat <= rv_ack_result;
                end else if (cmd_tmo >= 32'd100_000_000) begin  // 2 s @50 MHz
                    cmd_busy    <= 1'b0;
                    cmd_timeout <= 1'b1;
                    rv_pending  <= 1'b0;
                end else begin
                    cmd_tmo <= cmd_tmo + 32'd1;
                end
            end
        end
    end

    assign sys_rdata = (mem_addr[6:0] == S_ID)      ? 32'h5256_3332 :   // "RV32"
                       (mem_addr[6:0] == S_SCRATCH) ? scratch :
                       (mem_addr[6:0] == S_BUSERR)  ? {30'd0, bus_err_imem, bus_err_none} :
                       (mem_addr[6:0] == S_CTRL)    ? {31'd0, soft_reset} :
                       (mem_addr[6:0] == S_CMD)     ? {24'd0, cmd_reg} :
                       (mem_addr[6:0] == S_ARG)     ? arg_reg :
                       (mem_addr[6:0] == S_SPEED)   ? speed_reg :
                       (mem_addr[6:0] == S_STAT)    ? {16'd0, ack_res_lat[7:0],
                                                      4'd0, cmd_timeout, cmd_disabled, cmd_done, cmd_busy} :
                       (mem_addr[6:0] == S_RES)     ? ack_res_lat :
                       (mem_addr[6:0] == S_CYC)     ? cyc_cnt :
                       (mem_addr[6:0] == 7'h2c) ? {29'd0,touch_out} :
                       (mem_addr[6:0] == 7'h30) ? {30'd0,touch_in_sync} :
                                                      32'h0000_0000;

endmodule
