`timescale 1ns/1ps
`include "control_config.vh"
// Directional velocity envelope. No multipliers or division in the control path.
// Applied to both RUN and SWINGUP; the supervisor retains the hard travel stop.
module arm_travel_guard #(
    parameter MAX_FREQ_HZ=`CFG_CONTROL_MAX_FREQUENCY_HZ
)(
    input clk,rst_n,
    input signed [31:0] alpha_meas,alpha_c,arm_reference_q16,arm_velocity,
    input velocity_valid,
    output reg signed [31:0] positive_limit_q8,negative_limit_q8
);
    localparam signed [31:0] A60=$rtoi(60.0*`CFG_ARM_GUARD_SCALE*3.141592653589793*65536.0/180.0);
    localparam signed [31:0] A70=$rtoi(70.0*`CFG_ARM_GUARD_SCALE*3.141592653589793*65536.0/180.0);
    localparam signed [31:0] A80=$rtoi(80.0*`CFG_ARM_GUARD_SCALE*3.141592653589793*65536.0/180.0);
    localparam signed [31:0] A85=$rtoi(85.0*`CFG_ARM_GUARD_SCALE*3.141592653589793*65536.0/180.0);
    localparam signed [32:0] HARD_EDGE=$rtoi(`CFG_SWINGUP_HARD_ARM_DEG*3.141592653589793*65536.0/180.0);
    localparam signed [32:0] HARD_STOP=HARD_EDGE-$rtoi(1.0*3.141592653589793*65536.0/180.0);
    localparam signed [32:0] HARD_5=HARD_EDGE-$rtoi(5.0*3.141592653589793*65536.0/180.0);
    localparam signed [32:0] HARD_15=HARD_EDGE-$rtoi(15.0*3.141592653589793*65536.0/180.0);
    localparam signed [32:0] HARD_30=HARD_EDGE-$rtoi(30.0*3.141592653589793*65536.0/180.0);
    localparam signed [32:0] INVALID_MARGIN=$rtoi(`CFG_ARM_TRAVEL_INVALID_MARGIN_DEG*3.141592653589793*65536.0/180.0);
    reg signed [31:0] alpha_meas_s1,alpha_c_s1,relative_meas_s1,relative_command_s1,arm_velocity_s1;
    reg velocity_valid_s1;
    reg signed [32:0] relative_positive_pose_s2,relative_negative_pose_s2;
    reg signed [32:0] physical_positive_pose_s2,physical_negative_pose_s2;
    wire signed [32:0] measured_ext={alpha_meas_s1[31],alpha_meas_s1};
    wire signed [32:0] command_ext={alpha_c_s1[31],alpha_c_s1};
    wire signed [32:0] velocity_ext={arm_velocity_s1[31],arm_velocity_s1};
    wire signed [31:0] relative_meas=relative_meas_s1;
    wire signed [31:0] relative_command=relative_command_s1;
    wire signed [32:0] relative_meas_ext={relative_meas[31],relative_meas};
    wire signed [32:0] relative_command_ext={relative_command[31],relative_command};
    wire signed [32:0] ahead=velocity_ext>>>`CFG_ARM_TRAVEL_LOOKAHEAD_SHIFT;
    // Bound the projection in 33 bits; never let signed wrap hide a boundary.
    wire signed [32:0] positive_pose=(measured_ext>command_ext ? measured_ext : command_ext)+
        (velocity_valid_s1 ? (arm_velocity_s1>0 ? ahead : 33'sd0) : INVALID_MARGIN);
    wire signed [32:0] negative_pose=(measured_ext<command_ext ? measured_ext : command_ext)+
        (velocity_valid_s1 ? (arm_velocity_s1<0 ? ahead : 33'sd0) : -INVALID_MARGIN);
    wire signed [33:0] relative_positive_wide=$signed(relative_meas_ext>relative_command_ext ? relative_meas_ext : relative_command_ext)+
        (velocity_valid_s1 ? (arm_velocity_s1>0 ? $signed(ahead) : 34'sd0) : $signed(INVALID_MARGIN));
    wire signed [33:0] relative_negative_wide=$signed(relative_meas_ext<relative_command_ext ? relative_meas_ext : relative_command_ext)+
        (velocity_valid_s1 ? (arm_velocity_s1<0 ? $signed(ahead) : 34'sd0) : -$signed(INVALID_MARGIN));
    wire signed [32:0] relative_positive_pose=relative_positive_wide>=A85 ? A85 :
        relative_positive_wide<=-A85 ? -A85 : relative_positive_wide[32:0];
    wire signed [32:0] relative_negative_pose=relative_negative_wide>=A85 ? A85 :
        relative_negative_wide<=-A85 ? -A85 : relative_negative_wide[32:0];
    wire signed [33:0] physical_positive_wide=$signed(measured_ext>command_ext ? measured_ext : command_ext)+
        (velocity_valid_s1 ? (arm_velocity_s1>0 ? $signed(ahead) : 34'sd0) : $signed(INVALID_MARGIN));
    wire signed [33:0] physical_negative_wide=$signed(measured_ext<command_ext ? measured_ext : command_ext)+
        (velocity_valid_s1 ? (arm_velocity_s1<0 ? $signed(ahead) : 34'sd0) : -$signed(INVALID_MARGIN));
    wire signed [32:0] physical_positive_pose=physical_positive_wide>=HARD_EDGE ? HARD_EDGE :
        physical_positive_wide<=-HARD_EDGE ? -HARD_EDGE : physical_positive_wide[32:0];
    wire signed [32:0] physical_negative_pose=physical_negative_wide>=HARD_EDGE ? HARD_EDGE :
        physical_negative_wide<=-HARD_EDGE ? -HARD_EDGE : physical_negative_wide[32:0];
    function signed [31:0] envelope;
        input signed [32:0] pose;
        integer hz;
        begin
            // Outward commands stop at 85deg; inward commands retain authority.
            if(pose>=A85) hz=0;
            else if(pose>=A80) hz=600;
            else if(pose>=A70) hz=1400;
            else if(pose>=A60) hz=2000;
            else hz=MAX_FREQ_HZ;
            if(hz>MAX_FREQ_HZ) hz=MAX_FREQ_HZ;
            envelope=hz*256;
        end
    endfunction
    function signed [31:0] hard_envelope;
        input signed [32:0] pose;
        input positive_direction;
        integer hz;
        begin
            if(positive_direction && pose>=HARD_STOP || !positive_direction && pose<=-HARD_STOP) hz=0;
            else if(positive_direction && pose>=HARD_5 || !positive_direction && pose<=-HARD_5) hz=600;
            else if(positive_direction && pose>=HARD_15 || !positive_direction && pose<=-HARD_15) hz=1400;
            else if(positive_direction && pose>=HARD_30 || !positive_direction && pose<=-HARD_30) hz=2000;
            else hz=MAX_FREQ_HZ;
            if(hz>MAX_FREQ_HZ) hz=MAX_FREQ_HZ;
            hard_envelope=hz*256;
        end
    endfunction
    always @(posedge clk or negedge rst_n)
        if(!rst_n) begin
            alpha_meas_s1<=0;alpha_c_s1<=0;relative_meas_s1<=0;relative_command_s1<=0;arm_velocity_s1<=0;velocity_valid_s1<=0;
            relative_positive_pose_s2<=0;relative_negative_pose_s2<=0;
            physical_positive_pose_s2<=0;physical_negative_pose_s2<=0;
            positive_limit_q8<=0;negative_limit_q8<=0;
        end else begin
            // The guard runs every 50 MHz clock; two short register stages keep
            // wide projection and envelope comparisons out of one timing path.
            alpha_meas_s1<=alpha_meas;alpha_c_s1<=alpha_c;
            relative_meas_s1<=alpha_meas-arm_reference_q16;relative_command_s1<=alpha_c-arm_reference_q16;
            arm_velocity_s1<=arm_velocity;velocity_valid_s1<=velocity_valid;
            relative_positive_pose_s2<=relative_positive_pose;
            relative_negative_pose_s2<=relative_negative_pose;
            physical_positive_pose_s2<=physical_positive_pose;
            physical_negative_pose_s2<=physical_negative_pose;
            positive_limit_q8<=envelope(relative_positive_pose_s2)<hard_envelope(physical_positive_pose_s2,1'b1) ? envelope(relative_positive_pose_s2) : hard_envelope(physical_positive_pose_s2,1'b1);
            negative_limit_q8<=envelope(-relative_negative_pose_s2)<hard_envelope(physical_negative_pose_s2,1'b0) ? envelope(-relative_negative_pose_s2) : hard_envelope(physical_negative_pose_s2,1'b0);
        end
endmodule
