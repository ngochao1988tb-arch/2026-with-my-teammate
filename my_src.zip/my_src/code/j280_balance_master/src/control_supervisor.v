`timescale 1ns/1ps
`include "control_config.vh"
// States: 0 idle, 1 calibrating, 2 ready, 3 balancing, 4 fault, 5 swingup.
module control_supervisor #(
    parameter ENCODER_INVERT=`CFG_HARDWARE_ENCODER_INVERT, THETA_INVERT=`CFG_HARDWARE_THETA_INVERT,
    parameter SW1_AUTOSTART=`CFG_SUPERVISOR_SW1_AUTOSTART
)(
    input clk, input rst_n, input us_tick, input sample_valid,
    input [2:0] buttons, input [12:0] ad_value,
    input [15:0] encoder_raw, input encoder_update, input encoder_valid,
    input signed [31:0] signed_pulses, input pul,
    input signed [31:0] alpha_dot, theta_dot,
    input saturated, input numeric_fault,
    output reg [2:0] state, output reg [7:0] fault,
    output run, output core_clear, output core_tick, output reg new_encoder,
    output reg signed [31:0] alpha_meas, theta_meas, alpha_c,
    output reg [15:0] encoder_zero, output [12:0] ad_zero,
    output reg [31:0] encoder_seq, output reg [31:0] encoder_age_us,
    output reg calibrated,
    input remote_start, input remote_reset, input external_stop,
    output feedback_ready,
    input swing_velocity_valid,
    input travel_recovery_request,
    input signed [31:0] arm_reference_q16,
    output travel_recovery_qualified,
    output reg [7:0] run_exit_reason,
    output reg [15:0] run_exit_count
);
    assign ad_zero=`CFG_ADC_FIXED_ZERO;
    reg [15:0] previous_raw;
    reg signed [31:0] unwrapped, encoder_offset, pulse_offset;
    reg encoder_seen, adc_seen;
    reg [31:0] adc_age_us, elapsed_us, consumed_seq;
    reg [$clog2(`CFG_SUPERVISOR_STABLE_ADC_FRAMES+1)-1:0] stable_adc;
    reg [$clog2(`CFG_SUPERVISOR_WARMUP_FRAMES+1)-1:0] warmup;
    reg [$clog2(`CFG_SUPERVISOR_STABLE_ENCODER_SAMPLES+1)-1:0] stable_encoder;
    reg [$clog2(`CFG_SATURATION_FRAMES+1)-1:0] saturation_ticks;
    reg signed [31:0] encoder_anchor;
    reg [12:0] adc_anchor;
    reg commit;
    reg auto_swing_pending;
    reg remote_calibration;
    reg [255:0] tick_pipe;
    reg signed [63:0] alpha_product, theta_product, command_product;
    reg signed [39:0] theta_low_product,theta_high_product;
    // Exact compile-time products for each signed/unsigned 7-bit ADC slice.
    function signed [39:0] theta_partial_product;
        input [7:0] code;
        begin case(code)
            8'hc0: theta_partial_product=-64'sd64*`CFG_THETA_RAD_Q32;
            8'hc1: theta_partial_product=-64'sd63*`CFG_THETA_RAD_Q32;
            8'hc2: theta_partial_product=-64'sd62*`CFG_THETA_RAD_Q32;
            8'hc3: theta_partial_product=-64'sd61*`CFG_THETA_RAD_Q32;
            8'hc4: theta_partial_product=-64'sd60*`CFG_THETA_RAD_Q32;
            8'hc5: theta_partial_product=-64'sd59*`CFG_THETA_RAD_Q32;
            8'hc6: theta_partial_product=-64'sd58*`CFG_THETA_RAD_Q32;
            8'hc7: theta_partial_product=-64'sd57*`CFG_THETA_RAD_Q32;
            8'hc8: theta_partial_product=-64'sd56*`CFG_THETA_RAD_Q32;
            8'hc9: theta_partial_product=-64'sd55*`CFG_THETA_RAD_Q32;
            8'hca: theta_partial_product=-64'sd54*`CFG_THETA_RAD_Q32;
            8'hcb: theta_partial_product=-64'sd53*`CFG_THETA_RAD_Q32;
            8'hcc: theta_partial_product=-64'sd52*`CFG_THETA_RAD_Q32;
            8'hcd: theta_partial_product=-64'sd51*`CFG_THETA_RAD_Q32;
            8'hce: theta_partial_product=-64'sd50*`CFG_THETA_RAD_Q32;
            8'hcf: theta_partial_product=-64'sd49*`CFG_THETA_RAD_Q32;
            8'hd0: theta_partial_product=-64'sd48*`CFG_THETA_RAD_Q32;
            8'hd1: theta_partial_product=-64'sd47*`CFG_THETA_RAD_Q32;
            8'hd2: theta_partial_product=-64'sd46*`CFG_THETA_RAD_Q32;
            8'hd3: theta_partial_product=-64'sd45*`CFG_THETA_RAD_Q32;
            8'hd4: theta_partial_product=-64'sd44*`CFG_THETA_RAD_Q32;
            8'hd5: theta_partial_product=-64'sd43*`CFG_THETA_RAD_Q32;
            8'hd6: theta_partial_product=-64'sd42*`CFG_THETA_RAD_Q32;
            8'hd7: theta_partial_product=-64'sd41*`CFG_THETA_RAD_Q32;
            8'hd8: theta_partial_product=-64'sd40*`CFG_THETA_RAD_Q32;
            8'hd9: theta_partial_product=-64'sd39*`CFG_THETA_RAD_Q32;
            8'hda: theta_partial_product=-64'sd38*`CFG_THETA_RAD_Q32;
            8'hdb: theta_partial_product=-64'sd37*`CFG_THETA_RAD_Q32;
            8'hdc: theta_partial_product=-64'sd36*`CFG_THETA_RAD_Q32;
            8'hdd: theta_partial_product=-64'sd35*`CFG_THETA_RAD_Q32;
            8'hde: theta_partial_product=-64'sd34*`CFG_THETA_RAD_Q32;
            8'hdf: theta_partial_product=-64'sd33*`CFG_THETA_RAD_Q32;
            8'he0: theta_partial_product=-64'sd32*`CFG_THETA_RAD_Q32;
            8'he1: theta_partial_product=-64'sd31*`CFG_THETA_RAD_Q32;
            8'he2: theta_partial_product=-64'sd30*`CFG_THETA_RAD_Q32;
            8'he3: theta_partial_product=-64'sd29*`CFG_THETA_RAD_Q32;
            8'he4: theta_partial_product=-64'sd28*`CFG_THETA_RAD_Q32;
            8'he5: theta_partial_product=-64'sd27*`CFG_THETA_RAD_Q32;
            8'he6: theta_partial_product=-64'sd26*`CFG_THETA_RAD_Q32;
            8'he7: theta_partial_product=-64'sd25*`CFG_THETA_RAD_Q32;
            8'he8: theta_partial_product=-64'sd24*`CFG_THETA_RAD_Q32;
            8'he9: theta_partial_product=-64'sd23*`CFG_THETA_RAD_Q32;
            8'hea: theta_partial_product=-64'sd22*`CFG_THETA_RAD_Q32;
            8'heb: theta_partial_product=-64'sd21*`CFG_THETA_RAD_Q32;
            8'hec: theta_partial_product=-64'sd20*`CFG_THETA_RAD_Q32;
            8'hed: theta_partial_product=-64'sd19*`CFG_THETA_RAD_Q32;
            8'hee: theta_partial_product=-64'sd18*`CFG_THETA_RAD_Q32;
            8'hef: theta_partial_product=-64'sd17*`CFG_THETA_RAD_Q32;
            8'hf0: theta_partial_product=-64'sd16*`CFG_THETA_RAD_Q32;
            8'hf1: theta_partial_product=-64'sd15*`CFG_THETA_RAD_Q32;
            8'hf2: theta_partial_product=-64'sd14*`CFG_THETA_RAD_Q32;
            8'hf3: theta_partial_product=-64'sd13*`CFG_THETA_RAD_Q32;
            8'hf4: theta_partial_product=-64'sd12*`CFG_THETA_RAD_Q32;
            8'hf5: theta_partial_product=-64'sd11*`CFG_THETA_RAD_Q32;
            8'hf6: theta_partial_product=-64'sd10*`CFG_THETA_RAD_Q32;
            8'hf7: theta_partial_product=-64'sd9*`CFG_THETA_RAD_Q32;
            8'hf8: theta_partial_product=-64'sd8*`CFG_THETA_RAD_Q32;
            8'hf9: theta_partial_product=-64'sd7*`CFG_THETA_RAD_Q32;
            8'hfa: theta_partial_product=-64'sd6*`CFG_THETA_RAD_Q32;
            8'hfb: theta_partial_product=-64'sd5*`CFG_THETA_RAD_Q32;
            8'hfc: theta_partial_product=-64'sd4*`CFG_THETA_RAD_Q32;
            8'hfd: theta_partial_product=-64'sd3*`CFG_THETA_RAD_Q32;
            8'hfe: theta_partial_product=-64'sd2*`CFG_THETA_RAD_Q32;
            8'hff: theta_partial_product=-64'sd1*`CFG_THETA_RAD_Q32;
            8'h00: theta_partial_product=64'sd0*`CFG_THETA_RAD_Q32;
            8'h01: theta_partial_product=64'sd1*`CFG_THETA_RAD_Q32;
            8'h02: theta_partial_product=64'sd2*`CFG_THETA_RAD_Q32;
            8'h03: theta_partial_product=64'sd3*`CFG_THETA_RAD_Q32;
            8'h04: theta_partial_product=64'sd4*`CFG_THETA_RAD_Q32;
            8'h05: theta_partial_product=64'sd5*`CFG_THETA_RAD_Q32;
            8'h06: theta_partial_product=64'sd6*`CFG_THETA_RAD_Q32;
            8'h07: theta_partial_product=64'sd7*`CFG_THETA_RAD_Q32;
            8'h08: theta_partial_product=64'sd8*`CFG_THETA_RAD_Q32;
            8'h09: theta_partial_product=64'sd9*`CFG_THETA_RAD_Q32;
            8'h0a: theta_partial_product=64'sd10*`CFG_THETA_RAD_Q32;
            8'h0b: theta_partial_product=64'sd11*`CFG_THETA_RAD_Q32;
            8'h0c: theta_partial_product=64'sd12*`CFG_THETA_RAD_Q32;
            8'h0d: theta_partial_product=64'sd13*`CFG_THETA_RAD_Q32;
            8'h0e: theta_partial_product=64'sd14*`CFG_THETA_RAD_Q32;
            8'h0f: theta_partial_product=64'sd15*`CFG_THETA_RAD_Q32;
            8'h10: theta_partial_product=64'sd16*`CFG_THETA_RAD_Q32;
            8'h11: theta_partial_product=64'sd17*`CFG_THETA_RAD_Q32;
            8'h12: theta_partial_product=64'sd18*`CFG_THETA_RAD_Q32;
            8'h13: theta_partial_product=64'sd19*`CFG_THETA_RAD_Q32;
            8'h14: theta_partial_product=64'sd20*`CFG_THETA_RAD_Q32;
            8'h15: theta_partial_product=64'sd21*`CFG_THETA_RAD_Q32;
            8'h16: theta_partial_product=64'sd22*`CFG_THETA_RAD_Q32;
            8'h17: theta_partial_product=64'sd23*`CFG_THETA_RAD_Q32;
            8'h18: theta_partial_product=64'sd24*`CFG_THETA_RAD_Q32;
            8'h19: theta_partial_product=64'sd25*`CFG_THETA_RAD_Q32;
            8'h1a: theta_partial_product=64'sd26*`CFG_THETA_RAD_Q32;
            8'h1b: theta_partial_product=64'sd27*`CFG_THETA_RAD_Q32;
            8'h1c: theta_partial_product=64'sd28*`CFG_THETA_RAD_Q32;
            8'h1d: theta_partial_product=64'sd29*`CFG_THETA_RAD_Q32;
            8'h1e: theta_partial_product=64'sd30*`CFG_THETA_RAD_Q32;
            8'h1f: theta_partial_product=64'sd31*`CFG_THETA_RAD_Q32;
            8'h20: theta_partial_product=64'sd32*`CFG_THETA_RAD_Q32;
            8'h21: theta_partial_product=64'sd33*`CFG_THETA_RAD_Q32;
            8'h22: theta_partial_product=64'sd34*`CFG_THETA_RAD_Q32;
            8'h23: theta_partial_product=64'sd35*`CFG_THETA_RAD_Q32;
            8'h24: theta_partial_product=64'sd36*`CFG_THETA_RAD_Q32;
            8'h25: theta_partial_product=64'sd37*`CFG_THETA_RAD_Q32;
            8'h26: theta_partial_product=64'sd38*`CFG_THETA_RAD_Q32;
            8'h27: theta_partial_product=64'sd39*`CFG_THETA_RAD_Q32;
            8'h28: theta_partial_product=64'sd40*`CFG_THETA_RAD_Q32;
            8'h29: theta_partial_product=64'sd41*`CFG_THETA_RAD_Q32;
            8'h2a: theta_partial_product=64'sd42*`CFG_THETA_RAD_Q32;
            8'h2b: theta_partial_product=64'sd43*`CFG_THETA_RAD_Q32;
            8'h2c: theta_partial_product=64'sd44*`CFG_THETA_RAD_Q32;
            8'h2d: theta_partial_product=64'sd45*`CFG_THETA_RAD_Q32;
            8'h2e: theta_partial_product=64'sd46*`CFG_THETA_RAD_Q32;
            8'h2f: theta_partial_product=64'sd47*`CFG_THETA_RAD_Q32;
            8'h30: theta_partial_product=64'sd48*`CFG_THETA_RAD_Q32;
            8'h31: theta_partial_product=64'sd49*`CFG_THETA_RAD_Q32;
            8'h32: theta_partial_product=64'sd50*`CFG_THETA_RAD_Q32;
            8'h33: theta_partial_product=64'sd51*`CFG_THETA_RAD_Q32;
            8'h34: theta_partial_product=64'sd52*`CFG_THETA_RAD_Q32;
            8'h35: theta_partial_product=64'sd53*`CFG_THETA_RAD_Q32;
            8'h36: theta_partial_product=64'sd54*`CFG_THETA_RAD_Q32;
            8'h37: theta_partial_product=64'sd55*`CFG_THETA_RAD_Q32;
            8'h38: theta_partial_product=64'sd56*`CFG_THETA_RAD_Q32;
            8'h39: theta_partial_product=64'sd57*`CFG_THETA_RAD_Q32;
            8'h3a: theta_partial_product=64'sd58*`CFG_THETA_RAD_Q32;
            8'h3b: theta_partial_product=64'sd59*`CFG_THETA_RAD_Q32;
            8'h3c: theta_partial_product=64'sd60*`CFG_THETA_RAD_Q32;
            8'h3d: theta_partial_product=64'sd61*`CFG_THETA_RAD_Q32;
            8'h3e: theta_partial_product=64'sd62*`CFG_THETA_RAD_Q32;
            8'h3f: theta_partial_product=64'sd63*`CFG_THETA_RAD_Q32;
            8'h40: theta_partial_product=64'sd64*`CFG_THETA_RAD_Q32;
            8'h41: theta_partial_product=64'sd65*`CFG_THETA_RAD_Q32;
            8'h42: theta_partial_product=64'sd66*`CFG_THETA_RAD_Q32;
            8'h43: theta_partial_product=64'sd67*`CFG_THETA_RAD_Q32;
            8'h44: theta_partial_product=64'sd68*`CFG_THETA_RAD_Q32;
            8'h45: theta_partial_product=64'sd69*`CFG_THETA_RAD_Q32;
            8'h46: theta_partial_product=64'sd70*`CFG_THETA_RAD_Q32;
            8'h47: theta_partial_product=64'sd71*`CFG_THETA_RAD_Q32;
            8'h48: theta_partial_product=64'sd72*`CFG_THETA_RAD_Q32;
            8'h49: theta_partial_product=64'sd73*`CFG_THETA_RAD_Q32;
            8'h4a: theta_partial_product=64'sd74*`CFG_THETA_RAD_Q32;
            8'h4b: theta_partial_product=64'sd75*`CFG_THETA_RAD_Q32;
            8'h4c: theta_partial_product=64'sd76*`CFG_THETA_RAD_Q32;
            8'h4d: theta_partial_product=64'sd77*`CFG_THETA_RAD_Q32;
            8'h4e: theta_partial_product=64'sd78*`CFG_THETA_RAD_Q32;
            8'h4f: theta_partial_product=64'sd79*`CFG_THETA_RAD_Q32;
            8'h50: theta_partial_product=64'sd80*`CFG_THETA_RAD_Q32;
            8'h51: theta_partial_product=64'sd81*`CFG_THETA_RAD_Q32;
            8'h52: theta_partial_product=64'sd82*`CFG_THETA_RAD_Q32;
            8'h53: theta_partial_product=64'sd83*`CFG_THETA_RAD_Q32;
            8'h54: theta_partial_product=64'sd84*`CFG_THETA_RAD_Q32;
            8'h55: theta_partial_product=64'sd85*`CFG_THETA_RAD_Q32;
            8'h56: theta_partial_product=64'sd86*`CFG_THETA_RAD_Q32;
            8'h57: theta_partial_product=64'sd87*`CFG_THETA_RAD_Q32;
            8'h58: theta_partial_product=64'sd88*`CFG_THETA_RAD_Q32;
            8'h59: theta_partial_product=64'sd89*`CFG_THETA_RAD_Q32;
            8'h5a: theta_partial_product=64'sd90*`CFG_THETA_RAD_Q32;
            8'h5b: theta_partial_product=64'sd91*`CFG_THETA_RAD_Q32;
            8'h5c: theta_partial_product=64'sd92*`CFG_THETA_RAD_Q32;
            8'h5d: theta_partial_product=64'sd93*`CFG_THETA_RAD_Q32;
            8'h5e: theta_partial_product=64'sd94*`CFG_THETA_RAD_Q32;
            8'h5f: theta_partial_product=64'sd95*`CFG_THETA_RAD_Q32;
            8'h60: theta_partial_product=64'sd96*`CFG_THETA_RAD_Q32;
            8'h61: theta_partial_product=64'sd97*`CFG_THETA_RAD_Q32;
            8'h62: theta_partial_product=64'sd98*`CFG_THETA_RAD_Q32;
            8'h63: theta_partial_product=64'sd99*`CFG_THETA_RAD_Q32;
            8'h64: theta_partial_product=64'sd100*`CFG_THETA_RAD_Q32;
            8'h65: theta_partial_product=64'sd101*`CFG_THETA_RAD_Q32;
            8'h66: theta_partial_product=64'sd102*`CFG_THETA_RAD_Q32;
            8'h67: theta_partial_product=64'sd103*`CFG_THETA_RAD_Q32;
            8'h68: theta_partial_product=64'sd104*`CFG_THETA_RAD_Q32;
            8'h69: theta_partial_product=64'sd105*`CFG_THETA_RAD_Q32;
            8'h6a: theta_partial_product=64'sd106*`CFG_THETA_RAD_Q32;
            8'h6b: theta_partial_product=64'sd107*`CFG_THETA_RAD_Q32;
            8'h6c: theta_partial_product=64'sd108*`CFG_THETA_RAD_Q32;
            8'h6d: theta_partial_product=64'sd109*`CFG_THETA_RAD_Q32;
            8'h6e: theta_partial_product=64'sd110*`CFG_THETA_RAD_Q32;
            8'h6f: theta_partial_product=64'sd111*`CFG_THETA_RAD_Q32;
            8'h70: theta_partial_product=64'sd112*`CFG_THETA_RAD_Q32;
            8'h71: theta_partial_product=64'sd113*`CFG_THETA_RAD_Q32;
            8'h72: theta_partial_product=64'sd114*`CFG_THETA_RAD_Q32;
            8'h73: theta_partial_product=64'sd115*`CFG_THETA_RAD_Q32;
            8'h74: theta_partial_product=64'sd116*`CFG_THETA_RAD_Q32;
            8'h75: theta_partial_product=64'sd117*`CFG_THETA_RAD_Q32;
            8'h76: theta_partial_product=64'sd118*`CFG_THETA_RAD_Q32;
            8'h77: theta_partial_product=64'sd119*`CFG_THETA_RAD_Q32;
            8'h78: theta_partial_product=64'sd120*`CFG_THETA_RAD_Q32;
            8'h79: theta_partial_product=64'sd121*`CFG_THETA_RAD_Q32;
            8'h7a: theta_partial_product=64'sd122*`CFG_THETA_RAD_Q32;
            8'h7b: theta_partial_product=64'sd123*`CFG_THETA_RAD_Q32;
            8'h7c: theta_partial_product=64'sd124*`CFG_THETA_RAD_Q32;
            8'h7d: theta_partial_product=64'sd125*`CFG_THETA_RAD_Q32;
            8'h7e: theta_partial_product=64'sd126*`CFG_THETA_RAD_Q32;
            8'h7f: theta_partial_product=64'sd127*`CFG_THETA_RAD_Q32;
            default:theta_partial_product=0;
        endcase end
    endfunction
    reg [31:0] converted_seq;
    reg signed [31:0] ad_relative_q;
    reg [31:0] swing_elapsed_us;
    reg endpoint_tracking;
    reg [31:0] endpoint_elapsed_us;
    reg signed [31:0] endpoint_arm_origin, endpoint_command_origin;
    reg [$clog2(`CFG_SWINGUP_ENDPOINT_RECOVERY_FRAMES+1)-1:0] endpoint_good_frames;
    localparam ENDPOINT_TRAVEL=$rtoi(`CFG_SWINGUP_ENDPOINT_TRAVEL_DEG/180.0*3.141592653589793*65536.0);
    wire signed [31:0] endpoint_arm_delta=alpha_meas-endpoint_arm_origin;
    wire signed [31:0] endpoint_command_delta=alpha_c-endpoint_command_origin;
    reg endpoint_failed;
    always @(posedge clk or negedge rst_n)
        if(!rst_n) endpoint_failed<=0;
        else endpoint_failed<=endpoint_tracking &&
            (endpoint_elapsed_us>=`CFG_SWINGUP_ENDPOINT_TIMEOUT_US ||
             endpoint_arm_delta>ENDPOINT_TRAVEL || endpoint_arm_delta< -ENDPOINT_TRAVEL ||
             endpoint_command_delta>ENDPOINT_TRAVEL || endpoint_command_delta< -ENDPOINT_TRAVEL);
    reg [$clog2(`CFG_SWINGUP_CAPTURE_FRAMES+1)-1:0] catch_frames;
    localparam CATCH_COUNTS=$rtoi(`CFG_SWINGUP_CAPTURE_ANGLE_DEG/180.0*`CFG_ADC_THETA_COUNTS_PER_PI);
    localparam CATCH_SPEED=$rtoi(`CFG_SWINGUP_CAPTURE_SPEED_RAD_S*65536.0);
    localparam CATCH_ARM_SPEED=$rtoi(`CFG_SWINGUP_CAPTURE_ARM_SPEED_RAD_S*65536.0);
    localparam CATCH_TRACKING=$rtoi(`CFG_SWINGUP_CAPTURE_TRACKING_DEG/180.0*3.141592653589793*65536.0);
    wire signed [32:0] capture_tracking=$signed({alpha_meas[31],alpha_meas})-$signed({alpha_c[31],alpha_c});
    localparam ARM_LIMIT=$rtoi(`CFG_SWINGUP_HARD_ARM_DEG/180.0*3.141592653589793*65536.0);
    reg arm_limit;
    // Conversion values change only once per 3ms frame. Register the range
    // reduction before it fans out to motor/control enables (one 20ns clock).
    always @(posedge clk or negedge rst_n)
        if(!rst_n) arm_limit<=0;
        else arm_limit<=(alpha_meas>ARM_LIMIT || alpha_meas< -ARM_LIMIT || alpha_c>ARM_LIMIT || alpha_c< -ARM_LIMIT);
    wire signed [15:0] wrap_delta=encoder_raw-previous_raw;
    wire signed [31:0] next_unwrapped=unwrapped+{{16{wrap_delta[15]}},wrap_delta};
    wire signed [31:0] enc_relative=ENCODER_INVERT ? encoder_offset-unwrapped : unwrapped-encoder_offset;
    wire signed [31:0] ad_relative_raw=THETA_INVERT ? $signed({19'd0,ad_zero})-$signed({19'd0,ad_value}) :
                                                               $signed({19'd0,ad_value})-$signed({19'd0,ad_zero});
    wire signed [31:0] ad_relative=ad_relative_q;
    // Two unsigned 13-bit ADC values have an exact signed 14-bit difference.
    wire signed [13:0] ad_relative_narrow=ad_relative_q[13:0];
    wire signed [31:0] command_pulses=signed_pulses-pulse_offset;
    wire signed [31:0] enc_moved=next_unwrapped-encoder_anchor;
    wire signed [13:0] ad_moved=$signed({1'b0,ad_value})-$signed({1'b0,adc_anchor});
    reg rail;
    wire enc_ok=encoder_seen && encoder_valid && encoder_age_us<`CFG_SUPERVISOR_ENCODER_TIMEOUT_US;
    // Only readings inside the physical ADC output span can be a hanging endpoint.
    // Values beyond that span remain invalid in every state.
    reg endpoint;
    always @(posedge clk or negedge rst_n)
        if(!rst_n) begin rail<=0;endpoint<=0;end
        else begin
            rail<=(ad_value<`CFG_ADC_RAIL_MIN || ad_value>`CFG_ADC_RAIL_MAX);
            endpoint<=(ad_value<`CFG_ADC_RAIL_MIN || ad_value>`CFG_ADC_RAIL_MAX) &&
                ad_value>=`CFG_ADC_OUTPUT_OFFSET &&
                ad_value<=`CFG_ADC_OUTPUT_OFFSET+1023*`CFG_ADC_OUTPUT_SCALE;
        end
    wire endpoint_allowed=`CFG_SWINGUP_ENDPOINT_ESCAPE_ENABLED && endpoint &&
        (auto_swing_pending || state==5 || state==3 || (state==1 && remote_calibration));
    wire feedback_ok=enc_ok && adc_seen && adc_age_us<`CFG_SUPERVISOR_ADC_TIMEOUT_US && (!rail || endpoint_allowed);
    wire swing_feedback_ok=feedback_ok && encoder_seen && encoder_valid;
    localparam CAPTURE_ARM_LIMIT=$rtoi(`CFG_SWINGUP_CAPTURE_ARM_POSITION_DEG*3.141592653589793*65536.0/180.0);
    wire signed [31:0] relative_alpha=alpha_meas-arm_reference_q16;
    wire signed [31:0] relative_command=alpha_c-arm_reference_q16;
    wire catch_ok=relative_alpha<=CAPTURE_ARM_LIMIT && relative_alpha>=-CAPTURE_ARM_LIMIT &&
                   relative_command<=CAPTURE_ARM_LIMIT && relative_command>=-CAPTURE_ARM_LIMIT && !rail && swing_velocity_valid && (ad_relative<=CATCH_COUNTS && ad_relative>= -CATCH_COUNTS &&
                   theta_dot<=CATCH_SPEED && theta_dot>= -CATCH_SPEED &&
                   alpha_dot<=CATCH_ARM_SPEED && alpha_dot>= -CATCH_ARM_SPEED &&
                   capture_tracking<=CATCH_TRACKING && capture_tracking>= -CATCH_TRACKING);
    // Angle thresholds are derived from degrees and the configured AD calibration.
    localparam ENTRY_THRESHOLD = `CFG_ENTRY_COUNTS;
    localparam FALLEN_THRESHOLD = `CFG_FALLEN_COUNTS;
    wire in_catch_zone=(ad_relative<=ENTRY_THRESHOLD && ad_relative>= -ENTRY_THRESHOLD);
    wire fallen=(ad_relative>FALLEN_THRESHOLD || ad_relative< -FALLEN_THRESHOLD);
    localparam integer TRAVEL_RECOVERY_FRAMES=
        (`CFG_RUN_TRAVEL_RECOVERY_US+`CFG_CONTROL_PERIOD_US-1)/`CFG_CONTROL_PERIOD_US;
    localparam signed [31:0] TRAVEL_RECOVERY_COUNTS=
        $rtoi(`CFG_RUN_TRAVEL_RECOVERY_ANGLE_DEG/180.0*`CFG_ADC_THETA_COUNTS_PER_PI);
    localparam signed [31:0] TRAVEL_RECOVERY_SPEED=
        $rtoi(`CFG_RUN_TRAVEL_RECOVERY_SPEED_RAD_S*65536.0);
    reg [$clog2(TRAVEL_RECOVERY_FRAMES+1)-1:0] travel_limited_ticks;
    // The input is a raw request beyond the directional envelope, not a fall.
    // A brief limit hit or a pendulum already moving back toward upright stays RUN.
    wire travel_falling_away=
        (ad_relative>TRAVEL_RECOVERY_COUNTS && theta_dot>TRAVEL_RECOVERY_SPEED) ||
        (ad_relative< -TRAVEL_RECOVERY_COUNTS && theta_dot< -TRAVEL_RECOVERY_SPEED);
    always @(posedge clk or negedge rst_n)
        if(!rst_n) travel_limited_ticks<=0;
        else if(state!=3 || !travel_recovery_request || !run || remote_start || remote_reset)
            travel_limited_ticks<=0;
        else if(sample_valid && travel_limited_ticks<TRAVEL_RECOVERY_FRAMES)
            travel_limited_ticks<=travel_limited_ticks+1'b1;
    assign travel_recovery_qualified=travel_recovery_request && travel_falling_away &&
        travel_limited_ticks>=TRAVEL_RECOVERY_FRAMES;
    assign feedback_ready=enc_ok && adc_seen && adc_age_us<`CFG_SUPERVISOR_ADC_TIMEOUT_US &&
                          (!rail || (`CFG_SWINGUP_ENDPOINT_ESCAPE_ENABLED && endpoint));
    // The fall decision and the SWINGUP entry are latched on the same edge.
    // Hold RUN through that edge so the pulse generator is not stopped and
    // restarted, the last applied RUN command is the one SWINGUP inherits,
    // and top.v can hand the command over without a zero-command frame.
    // SWINGUP's own validity guards still stop the motor on the next clock.
    wire fall_handoff=(state==3) && fallen && feedback_ok && !numeric_fault && !arm_limit;
    assign run=(((state==3) && feedback_ok && !fallen && !numeric_fault && !arm_limit) || fall_handoff ||
                ((state==5) && swing_feedback_ok && !arm_limit && !endpoint_failed && swing_elapsed_us<`CFG_SWINGUP_TIMEOUT_US)) && !buttons[0] && !external_stop;
    assign core_clear=!calibrated || commit || state==5 || auto_swing_pending;
    assign core_tick=tick_pipe[5] && calibrated;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=0; fault<=0; calibrated<=0; commit<=0; auto_swing_pending<=0;remote_calibration<=0;
            run_exit_reason<=0; run_exit_count<=0;
            previous_raw<=0; unwrapped<=0; encoder_offset<=0; pulse_offset<=0;
            encoder_seen<=0; adc_seen<=0; encoder_seq<=0; consumed_seq<=0;
            encoder_age_us<=32'hffffffff; adc_age_us<=32'hffffffff;
            elapsed_us<=0; stable_adc<=0; stable_encoder<=0; warmup<=0;
            encoder_anchor<=0; adc_anchor<=0; saturation_ticks<=0;
            encoder_zero<=0; tick_pipe<=0; new_encoder<=0;
            alpha_product<=0; theta_product<=0; command_product<=0;
            theta_low_product<=0;theta_high_product<=0;
            alpha_meas<=0; theta_meas<=0; alpha_c<=0; converted_seq<=0;
            ad_relative_q<=0;
            swing_elapsed_us<=0; catch_frames<=0;
            endpoint_tracking<=0; endpoint_elapsed_us<=0; endpoint_good_frames<=0;
            endpoint_arm_origin<=0; endpoint_command_origin<=0;
        end else begin
            commit<=0; tick_pipe<={tick_pipe[254:0],sample_valid};
            ad_relative_q<=ad_relative_raw;
            alpha_product<=$signed(enc_relative)*`CFG_ENCODER_RAD_Q32;
            // The sample+4 conversion latch leaves room for this existing
            // subtract register; do not cascade ADC subtract and multiply.
            theta_low_product<=theta_partial_product({1'b0,ad_relative_narrow[6:0]});
            theta_high_product<=theta_partial_product({ad_relative_narrow[13],ad_relative_narrow[13:7]});
            theta_product<=$signed({{24{theta_low_product[39]}},theta_low_product})+
                ($signed({{24{theta_high_product[39]}},theta_high_product})<<<7);
            command_product<=$signed(command_pulses)*`CFG_PULSE_RAD_Q32;
            converted_seq<=encoder_seq;
            if(us_tick) begin
                if(encoder_age_us!=32'hffffffff) encoder_age_us<=encoder_age_us+1'b1;
                if(adc_age_us!=32'hffffffff) adc_age_us<=adc_age_us+1'b1;
                if(state==5 && swing_elapsed_us<`CFG_SWINGUP_TIMEOUT_US) swing_elapsed_us<=swing_elapsed_us+1'b1;
                if(state==1 && elapsed_us<`CFG_SUPERVISOR_CALIBRATION_TIMEOUT_US) elapsed_us<=elapsed_us+1'b1;
            end
            // Keep a single escape budget through brief good samples: require consecutive
            // valid ADC frames before allowing a new endpoint episode.
            if(state!=5) begin
                endpoint_tracking<=0; endpoint_elapsed_us<=0; endpoint_good_frames<=0;
            end else if(!endpoint_tracking) begin
                if(endpoint && `CFG_SWINGUP_ENDPOINT_ESCAPE_ENABLED) begin
                    endpoint_tracking<=1; endpoint_elapsed_us<=0; endpoint_good_frames<=0;
                    endpoint_arm_origin<=alpha_meas; endpoint_command_origin<=alpha_c;
                end
            end else begin
                if(us_tick && endpoint_elapsed_us<`CFG_SWINGUP_ENDPOINT_TIMEOUT_US)
                    endpoint_elapsed_us<=endpoint_elapsed_us+1'b1;
                // Evaluate recovery after this sample's speed-valid pipeline,
                // so a new AD jump cannot borrow the preceding sample's validity.
                if(tick_pipe[5]) begin
                    if(rail || !swing_velocity_valid) endpoint_good_frames<=0;
                    else if(endpoint_good_frames>=`CFG_SWINGUP_ENDPOINT_RECOVERY_FRAMES-1) begin
                        endpoint_tracking<=0; endpoint_elapsed_us<=0; endpoint_good_frames<=0;
                    end else endpoint_good_frames<=endpoint_good_frames+1'b1;
                end
            end
            if(sample_valid) begin adc_seen<=1; adc_age_us<=0; end
            if(encoder_update) begin
                previous_raw<=encoder_raw; encoder_seen<=1; encoder_age_us<=0;
                encoder_seq<=encoder_seq+1'b1;
                if(encoder_seen) unwrapped<=next_unwrapped;
                else unwrapped<=0;
            end
            // Consume each reply exactly once, after all conversion registers settled.
            if(tick_pipe[3]) begin
                new_encoder<=encoder_seen ? (converted_seq!=consumed_seq) : 1'b1;
                consumed_seq<=converted_seq;
                alpha_meas<=encoder_seen ? alpha_product[47:16] : alpha_c;
                theta_meas<=theta_product[47:16];
                alpha_c<=command_product[47:16];
            end
            if(external_stop) begin
                if(state==3) begin run_exit_reason<=7; run_exit_count<=run_exit_count+1'b1; end
                // External stop cancels automatic start and preserves latched faults.
                auto_swing_pending<=0;
                if(state!=4) state<=calibrated ? 2 : 0;
                saturation_ticks<=0;
            end else if(remote_start && calibrated && !remote_reset && !buttons[0]) begin
                if(state==3) begin run_exit_reason<=8; run_exit_count<=run_exit_count+1'b1; end
                // HMI start reuses the explicitly calibrated center. Never move
                // the zero/relative safety limits to the current manual position.
                state<=2; warmup<=0; saturation_ticks<=0;
                auto_swing_pending<=`CFG_SWINGUP_ENABLED;
            end else if(remote_reset || remote_start || buttons[0]) begin
                if(state==3) begin run_exit_reason<=8; run_exit_count<=run_exit_count+1'b1; end
                remote_calibration<=remote_reset || remote_start;
                // SW1: Calibrate arm/pulses, then swing automatically; fixed AD zero is unchanged.
                auto_swing_pending<=!remote_reset && (remote_start || SW1_AUTOSTART) && `CFG_SWINGUP_ENABLED;
                state<=1; calibrated<=0; fault<=0; elapsed_us<=0;
                stable_adc<=0; stable_encoder<=0; warmup<=0;
                adc_anchor<=ad_value; encoder_anchor<=unwrapped; saturation_ticks<=0;
            end else if(state==1) begin
                if(elapsed_us>=`CFG_SUPERVISOR_CALIBRATION_TIMEOUT_US) begin state<=4; fault<=1; auto_swing_pending<=0; end
                else if(pul || !feedback_ok) begin
                    stable_adc<=0; stable_encoder<=0;
                    adc_anchor<=ad_value; encoder_anchor<=unwrapped;
                end else begin
                    if(sample_valid) begin
                        if(ad_moved>`CFG_SUPERVISOR_ADC_STABILITY_COUNTS || ad_moved< -`CFG_SUPERVISOR_ADC_STABILITY_COUNTS) begin
                            stable_adc<=0; stable_encoder<=0;
                            adc_anchor<=ad_value; encoder_anchor<=unwrapped;
                        end else if(stable_adc<`CFG_SUPERVISOR_STABLE_ADC_FRAMES) stable_adc<=stable_adc+1'b1;
                    end
                    if(encoder_update) begin
                        if(enc_moved>`CFG_SUPERVISOR_ENCODER_STABILITY_COUNTS || enc_moved< -`CFG_SUPERVISOR_ENCODER_STABILITY_COUNTS) begin
                            stable_encoder<=0; stable_adc<=0;
                            encoder_anchor<=next_unwrapped; adc_anchor<=ad_value;
                        end else if(stable_encoder<`CFG_SUPERVISOR_STABLE_ENCODER_SAMPLES) stable_encoder<=stable_encoder+1'b1;
                    end
                    if(sample_valid && stable_adc>=`CFG_SUPERVISOR_STABLE_ADC_FRAMES && (!encoder_seen || stable_encoder>=`CFG_SUPERVISOR_STABLE_ENCODER_SAMPLES) && elapsed_us>=`CFG_SUPERVISOR_CALIBRATION_MIN_US &&
                       ad_moved<=`CFG_SUPERVISOR_ADC_STABILITY_COUNTS && ad_moved>= -`CFG_SUPERVISOR_ADC_STABILITY_COUNTS && (!encoder_update || (enc_moved<=`CFG_SUPERVISOR_ENCODER_STABILITY_COUNTS && enc_moved>= -`CFG_SUPERVISOR_ENCODER_STABILITY_COUNTS))) begin
                        encoder_offset<=encoder_update ? next_unwrapped : unwrapped;
                        encoder_zero<=encoder_update ? encoder_raw : previous_raw;
                        pulse_offset<=signed_pulses;
                        calibrated<=1; commit<=1; state<=2; warmup<=0;
                        consumed_seq<=encoder_seq; fault<=0;
                    end
                end
            end else if(state==2) begin
                // Allow one converted frame for new arm/pulse offsets before automatic swing.
                // SW1 always requests SWINGUP, including inside the old SW2 entry window.
                if(sample_valid && warmup<`CFG_SUPERVISOR_WARMUP_FRAMES) warmup<=warmup+1'b1;
                if(auto_swing_pending) begin
                    if(tick_pipe[5] && !commit && swing_feedback_ok && !arm_limit) begin
                        state<=5; auto_swing_pending<=0;
                        swing_elapsed_us<=0; catch_frames<=0; saturation_ticks<=0;
                    end
                end else if(buttons[1] && feedback_ok && warmup>=`CFG_SUPERVISOR_WARMUP_FRAMES) begin
                    if(in_catch_zone) begin state<=3; saturation_ticks<=0; end
                    else if(`CFG_SWINGUP_ENABLED && swing_feedback_ok && !arm_limit) begin
                        state<=5; swing_elapsed_us<=0; catch_frames<=0; saturation_ticks<=0;
                    end
                end
            end else if(state==5) begin
                // Large angles are expected here. Never apply the upright fall threshold.
                if(!swing_feedback_ok || arm_limit || endpoint_failed || swing_elapsed_us>=`CFG_SWINGUP_TIMEOUT_US) begin
                    state<=4; fault<=!swing_feedback_ok ? 2 : arm_limit ? 7 : endpoint_failed ? 8 : 6;
                // Allow the measured-state command preview to finish first.
                // core_tick remains at sample+6; capture waits 250 more clocks
                // (5us at 50MHz), not an extra 3ms control frame.
                end else if(tick_pipe[255]) begin
                    if(catch_ok) begin
                        if(catch_frames>=`CFG_SWINGUP_CAPTURE_FRAMES-1) begin state<=3; catch_frames<=0; end
                        else catch_frames<=catch_frames+1'b1;
                    end else catch_frames<=0;
                end
            end else if(state==3) begin
                // Leave LQR directly for another swingup attempt after a fall.
                // Sensor and numeric faults remain latched safety faults.
                if(!feedback_ok || numeric_fault || arm_limit) begin
                    state<=4; fault<=!feedback_ok ? 2 : numeric_fault ? 5 : 7;
                    run_exit_reason<=!feedback_ok ? 4 : numeric_fault ? 5 : 6;
                    run_exit_count<=run_exit_count+1'b1;
                end else if(fallen || travel_recovery_qualified) begin
                    state<=5; swing_elapsed_us<=0; catch_frames<=0; saturation_ticks<=0;
                    run_exit_reason<=fallen ? 1 : 2; run_exit_count<=run_exit_count+1'b1;
                end else if(sample_valid) begin
                    if(saturated) begin
                        if(saturation_ticks>=`CFG_SATURATION_FRAMES-1) begin
                            state<=5; swing_elapsed_us<=0; catch_frames<=0; saturation_ticks<=0;
                            run_exit_reason<=3; run_exit_count<=run_exit_count+1'b1;
                        end
                        else saturation_ticks<=saturation_ticks+1'b1;
                    end else saturation_ticks<=0;
                end
            end
        end
    end
endmodule
