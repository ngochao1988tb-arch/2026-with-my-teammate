`timescale 1ns/1ps
`include "control_config.vh"
// 3PA1030 interface with a frame-level adaptive first-order filter.
// Two cascaded EMA stages; alpha is selected per 500 us frame:
//   slow = 1/512 when the filtered angle moves less than TH_LO per frame,
//   fast = 1/64  when it moves more than TH_HI, with a hold time and
//   hysteresis between the thresholds. This avoids the previous design's
//   mistake of adapting on per-sample deltas, which are dominated by noise.
module adc_sampler #(
    parameter CLK_HZ=`CFG_HARDWARE_CLOCK_HZ,
    parameter SAMPLES_PER_CONTROL=`CFG_ADC_SAMPLES_PER_CONTROL
)(
    input clk, input rst_n,
    input [9:0] adc_data_in,
    output adc_clk, output adc_oe_n,
    output reg [12:0] ad_value,
    output reg sample_valid
);
    localparam integer FRAME_CYCLES=(CLK_HZ/1000000)*`CFG_CONTROL_PERIOD_US;
    localparam integer FW=$clog2(FRAME_CYCLES);
    localparam signed [31:0] INIT_RAW=
        ((`CFG_ADC_FIXED_ZERO-`CFG_ADC_OUTPUT_OFFSET)/`CFG_ADC_OUTPUT_SCALE);

    reg adc_clk_r;
    reg [9:0] adc_latched;
    assign adc_clk=adc_clk_r;
    assign adc_oe_n=1'b0;

    reg [FW-1:0] frame_pos;
    reg [FW-1:0] phase;
    reg primed;
    reg signed [31:0] y_q;
    reg signed [31:0] y2_q;
    reg signed [31:0] y2_prev_q;
    reg fast_mode;
    reg [2:0] hold_cnt;

    wire [FW-1:0] next_phase=phase+SAMPLES_PER_CONTROL;
    wire sample_now=(next_phase>=FRAME_CYCLES);
    wire signed [31:0] x_q=$signed({6'd0,adc_latched,16'd0});
    wire signed [31:0] delta=x_q-y_q;
    wire signed [31:0] step_slow=(delta+32'sd256)>>>`CFG_ADC_ALPHA_SLOW_SHIFT;
    wire signed [31:0] step_fast=(delta+32'sd32)>>>`CFG_ADC_ALPHA_FAST_SHIFT;
    wire signed [31:0] step=fast_mode?step_fast:step_slow;
    wire signed [31:0] delta2=y_q-y2_q;
    wire signed [31:0] step2_slow=(delta2+32'sd256)>>>`CFG_ADC_ALPHA_SLOW_SHIFT;
    wire signed [31:0] step2_fast=(delta2+32'sd32)>>>`CFG_ADC_ALPHA_FAST_SHIFT;
    wire signed [31:0] step2=fast_mode?step2_fast:step2_slow;
    // Keep the filtered fractional bits through the output scaling. Rounding
    // before multiplying by four discards two usable bits and skips the fixed
    // upright zero (1585). The wide product also avoids signed-width overflow.
    wire signed [63:0] scaled_y_q=$signed(y2_q)*$signed(`CFG_ADC_OUTPUT_SCALE);
    wire signed [63:0] scaled_y_code=(scaled_y_q+64'sd32768)>>>16;

    wire signed [31:0] frame_delta=y2_q-y2_prev_q;
    wire signed [31:0] frame_delta_abs=frame_delta[31] ? -frame_delta : frame_delta;

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            adc_clk_r<=0; adc_latched<=0; frame_pos<=0; phase<=0; primed<=0;
            y_q<=INIT_RAW<<<16; y2_q<=INIT_RAW<<<16; y2_prev_q<=INIT_RAW<<<16;
            fast_mode<=0; hold_cnt<=0;
            ad_value<=`CFG_ADC_OUTPUT_OFFSET; sample_valid<=0;
        end else begin
            sample_valid<=0;
            adc_clk_r<=~adc_clk_r;
            if(!adc_clk_r) adc_latched<=adc_data_in;
            if(frame_pos==FRAME_CYCLES-1) frame_pos<=0; else frame_pos<=frame_pos+1'b1;
            if(sample_now) begin
                phase<=next_phase-FRAME_CYCLES;
                if(!primed) begin y_q<=x_q; y2_q<=x_q; primed<=1; end
                else begin y_q<=y_q+step; y2_q<=y2_q+step2; end
            end else phase<=next_phase;
            if(frame_pos==FRAME_CYCLES-1) begin
                ad_value<=scaled_y_code[12:0]+`CFG_ADC_OUTPUT_OFFSET;
                sample_valid<=1;
                phase<=0;
                y2_prev_q<=y2_q;
                if(frame_delta_abs>`CFG_ADC_MOTION_TH_HI_Q16) begin
                    fast_mode<=1; hold_cnt<=`CFG_ADC_MOTION_HOLD_FRAMES;
                end else if(hold_cnt!=0) hold_cnt<=hold_cnt-1'b1;
                else if(frame_delta_abs<`CFG_ADC_MOTION_TH_LO_Q16) fast_mode<=0;
            end
        end
    end
endmodule
