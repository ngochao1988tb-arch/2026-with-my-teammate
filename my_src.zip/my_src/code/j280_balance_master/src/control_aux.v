`timescale 1ns/1ps
`include "control_config.vh"
// ============================================================================
// control_aux —— LQR_sine_move 里定义在 top.v 内部的两个"辅助执行器"模块
// ----------------------------------------------------------------------------
//
//   1) run_adc_quiet_gate：ADC 码值合格且长时间恒定后暂停脉冲输出
//      （"静默闸门"）。采集、观测器、LQR 全部照常运行，任何可观测扰动
//      （ADC 变化、横臂位移/速度、摆角/摆速、目标变化）都会立即旁路暂停。
//   2) deadzone_bridge：ADC 撞轨（摆杆接近下垂端点，真实角度未知）时，
//      用下垂侧摆杆模型 + 横臂指令加速度外推到合成的 ADC 码，
//      让监督器、起摆核心与捕获判据在这段死区里仍拿到连续的角/角速度。
//      超时或 ADC 回到量程内立即恢复直通。
// ============================================================================

// ----------------------------------------------------------------------------
// 26103190：静止 RUN 保持时，若 ADC 码值长时间精确不变，说明机械真的停住了，
// 这段时间的脉冲只会让电机发热、让观感更差，直接暂停；
// 一旦有任何可观测变化就立刻放开，且不设最短关闭时间。
// ----------------------------------------------------------------------------
module run_adc_quiet_gate(
    input clk,rst_n,tick,hold_mode,
    input [12:0] ad_value,
    input signed [31:0] theta,theta_dot,arm,arm_dot,motor_frequency_q8,
    output pause
);
    localparam integer SETTLE_FRAMES=(`CFG_STALL_RUN_SETTLE_US+`CFG_CONTROL_PERIOD_US-1)/`CFG_CONTROL_PERIOD_US;
    localparam integer COOLDOWN_FRAMES=(`CFG_STALL_COOLDOWN_US+`CFG_CONTROL_PERIOD_US-1)/`CFG_CONTROL_PERIOD_US;
    localparam signed [31:0] MAX_THETA=$rtoi(`CFG_STALL_MAX_THETA_DEG*3.141592653589793*65536.0/180.0);
    localparam signed [31:0] ENTRY_SPEED=$rtoi(`CFG_STALL_ENTRY_SPEED_RAD_S*65536.0);
    localparam signed [31:0] WAKE_SPEED=$rtoi(`CFG_STALL_RESUME_RAD_S*65536.0);
    localparam signed [31:0] ARM_WAKE=$rtoi(`CFG_STALL_ARM_WAKE_DEG*3.141592653589793*65536.0/180.0);
    localparam signed [31:0] ENTRY_FREQUENCY=`CFG_STALL_ENTRY_MAX_HZ*256;
    reg [31:0] settled,quiet_frames,cooldown;
    reg [12:0] quiet_ad,sleep_ad;
    reg signed [31:0] sleep_arm;
    reg paused;
    wire signed [32:0] arm_delta=$signed({arm[31],arm})-$signed({sleep_arm[31],sleep_arm});
    wire angle_safe=theta<MAX_THETA && theta>-MAX_THETA;
    wire disturbed=ad_value!=sleep_ad || arm_delta>=ARM_WAKE || arm_delta<=-ARM_WAKE ||
        theta_dot>=WAKE_SPEED || theta_dot<=-WAKE_SPEED ||
        arm_dot>=WAKE_SPEED || arm_dot<=-WAKE_SPEED || !angle_safe;
    wire entry_safe=angle_safe && theta_dot<ENTRY_SPEED && theta_dot>-ENTRY_SPEED &&
        arm_dot<ENTRY_SPEED && arm_dot>-ENTRY_SPEED &&
        motor_frequency_q8<ENTRY_FREQUENCY && motor_frequency_q8>-ENTRY_FREQUENCY;
    // 不设最短关闭时间：两次控制 tick 之间的运动也能立刻打开脉冲门。
    // 方向/限速/行程限制照常生效。
    assign pause=`CFG_STALL_ENABLED && paused && hold_mode && !disturbed;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            settled<=0;quiet_frames<=0;cooldown<=0;quiet_ad<=0;sleep_ad<=0;sleep_arm<=0;paused<=0;
        end else if(!`CFG_STALL_ENABLED || !hold_mode) begin
            settled<=0;quiet_frames<=0;cooldown<=0;quiet_ad<=ad_value;paused<=0;
        end else if(paused) begin
            if(disturbed) begin
                paused<=0;quiet_frames<=0;quiet_ad<=ad_value;cooldown<=COOLDOWN_FRAMES;
            end
        end else if(tick) begin
            if(settled<SETTLE_FRAMES) begin
                settled<=settled+1'b1;quiet_frames<=0;quiet_ad<=ad_value;
            end else if(cooldown!=0) begin
                cooldown<=cooldown-1'b1;quiet_frames<=0;quiet_ad<=ad_value;
            end else if(ad_value!=quiet_ad) begin
                quiet_ad<=ad_value;quiet_frames<=0;
            end else begin
                if(quiet_frames<`CFG_STALL_QUAL_FRAMES) quiet_frames<=quiet_frames+1'b1;
                if(quiet_frames>=`CFG_STALL_QUAL_FRAMES-1 && entry_safe) begin
                    paused<=1;sleep_ad<=ad_value;sleep_arm<=arm;quiet_frames<=0;
                end
            end
        end
    end
endmodule

// ----------------------------------------------------------------------------
// 26103178：摆杆 ADC 死区的短暂桥接。
//
// 原始 ADC 撞轨时真实角度未知。模块最多用 CFG_DZ_COAST_MS 的时间，
// 以下垂侧摆杆模型 + 横臂指令加速度外推最后一个有效角度，
// 再合成一个 ADC 码出去，让监督器、起摆核心与捕获判据仍有连续的角/角速度。
// 外推超时或 ADC 回到量程内，立即恢复直通原始值。
// ----------------------------------------------------------------------------
module deadzone_bridge(
    input clk, input rst_n,
    input sample_valid, input enable,
    input [12:0] ad_raw,
    input signed [31:0] alpha_meas,
    input signed [31:0] frequency_q8,
    output reg [12:0] ad_eff,
    output reg coast_active
);
    localparam integer PI_COUNTS=`CFG_ADC_THETA_COUNTS_PER_PI;
    localparam signed [31:0] ZERO=`CFG_ADC_FIXED_ZERO;
    localparam signed [31:0] PI_Q16=205887;
    localparam signed [31:0] HB_Q16=$rtoi(`CFG_SWINGUP_H_OVER_B*65536.0);
    localparam signed [31:0] COUP_Q16=$rtoi(`CFG_DZ_ARM_COUPLING*65536.0);
    localparam integer COAST_FRAMES=`CFG_DZ_COAST_MS*2;
    localparam signed [31:0] SPD_LIM=35*65536;
    localparam signed [31:0] ACC_LIM=800*65536;
    localparam signed [31:0] ARM_SPD_LIM=$rtoi(`CFG_DZ_ARM_SPEED_MAX*65536.0);

    function signed [31:0] clampv;
        input signed [31:0] v;
        input signed [31:0] lim;
        begin
            if(v>lim) clampv=lim;
            else if(v< -lim) clampv=-lim;
            else clampv=v;
        end
    endfunction

    wire signed [31:0] adx=$signed({19'd0,ad_raw});
    wire signed [31:0] raw_counts=`CFG_HARDWARE_THETA_INVERT ? (ZERO-adx) : (adx-ZERO);
    wire signed [31:0] raw_theta=raw_counts*84;
    wire rail=(ad_raw<`CFG_ADC_RAIL_MIN) || (ad_raw>`CFG_ADC_RAIL_MAX);

    reg signed [31:0] theta_q16,speed_q16,last_theta,last_speed;
    reg signed [31:0] alpha_prev,arm_speed,freq_prev,arm_acc_q16;
    reg [1:0] frame_cnt;
    reg [15:0] coast_cnt;

    // 接近下垂时 |theta| ≈ pi，sin(theta) ≈ -(theta ∓ pi)；这是撞轨唯一能藏住
    // 的区域，用它换来最便宜的外推。
    wire signed [31:0] d=(theta_q16>=0) ? (theta_q16-PI_Q16) : (theta_q16+PI_Q16);
    wire signed [31:0] dc=clampv(d,65536);
    wire signed [63:0] grav64=-($signed(HB_Q16)*$signed(dc));
    wire signed [63:0] grav=grav64>>>16;
    wire signed [31:0] df_q8=frequency_q8-freq_prev;
    wire signed [63:0] coup64=$signed(COUP_Q16)*$signed(arm_acc_q16);
    wire signed [63:0] acc_sum=grav-(coup64>>>16);
    wire signed [31:0] acc0=(acc_sum[31:0]>ACC_LIM)?ACC_LIM:(acc_sum[31:0]< -ACC_LIM)? -ACC_LIM:acc_sum[31:0];
    wire signed [63:0] acc_step=($signed(acc0)*33)>>>16;
    wire signed [31:0] speed_next=clampv(speed_q16+acc_step[31:0],SPD_LIM);
    wire signed [63:0] theta_step=($signed(speed_q16)*33)>>>16;
    wire signed [31:0] theta_next=theta_q16+theta_step[31:0];
    wire signed [31:0] theta_wrapped=(theta_next>PI_Q16)?(theta_next-2*PI_Q16):
        (theta_next< -PI_Q16)?(theta_next+2*PI_Q16):theta_next;
    wire signed [31:0] pred_counts=(theta_q16*779)>>>16;
    wire signed [31:0] pred_ad_s=`CFG_HARDWARE_THETA_INVERT ? (ZERO-pred_counts) : (ZERO+pred_counts);
    wire [12:0] pred_ad=(pred_ad_s<`CFG_ADC_RAIL_MIN)?`CFG_ADC_RAIL_MIN:
        (pred_ad_s>`CFG_ADC_RAIL_MAX)?`CFG_ADC_RAIL_MAX:pred_ad_s[12:0];
    wire arm_fast=(arm_speed>ARM_SPD_LIM) || (arm_speed< -ARM_SPD_LIM);

    always @(posedge clk or negedge rst_n)
        if(!rst_n) begin
            ad_eff<=`CFG_ADC_FIXED_ZERO; coast_active<=0;
            theta_q16<=0; speed_q16<=0; last_theta<=0; last_speed<=0;
            alpha_prev<=0; arm_speed<=0; freq_prev<=0; arm_acc_q16<=0;
            frame_cnt<=0; coast_cnt<=0;
        end else if(!enable) begin
            ad_eff<=ad_raw; coast_active<=0; coast_cnt<=0;
            theta_q16<=raw_theta; speed_q16<=0; last_theta<=raw_theta; last_speed<=0;
            alpha_prev<=alpha_meas; arm_speed<=0; freq_prev<=frequency_q8;
            arm_acc_q16<=0; frame_cnt<=0;
        end else if(sample_valid) begin
            alpha_prev<=alpha_meas;
            arm_speed<=arm_speed+((((alpha_meas-alpha_prev)*2000)-arm_speed)>>>6);
            frame_cnt<=frame_cnt+1'b1;
            if(frame_cnt==2'd3) begin
                arm_acc_q16<=df_q8*251;   // Hz/s -> rad/s^2 in Q16 at 2 ms
                freq_prev<=frequency_q8;
                frame_cnt<=0;
            end
            if(rail) begin
                if(!coast_active) begin
                    coast_active<=1; coast_cnt<=1;
                    theta_q16<=last_theta; speed_q16<=last_speed;
                    ad_eff<=pred_ad;
                end else if(coast_cnt>=COAST_FRAMES || arm_fast) begin
                    ad_eff<=ad_raw; coast_active<=0; coast_cnt<=0;
                end else begin
                    theta_q16<=theta_wrapped; speed_q16<=speed_next;
                    coast_cnt<=coast_cnt+1'b1; ad_eff<=pred_ad;
                end
            end else begin
                coast_active<=0; coast_cnt<=0; ad_eff<=ad_raw;
                theta_q16<=raw_theta;
                speed_q16<=clampv(speed_q16+(((raw_theta-last_theta)*2000-speed_q16)>>>3),SPD_LIM);
                last_theta<=raw_theta; last_speed<=speed_q16;
            end
        end
endmodule
