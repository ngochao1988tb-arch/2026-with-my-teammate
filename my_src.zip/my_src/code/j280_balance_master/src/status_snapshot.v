// =============================================================================
// status_snapshot.v  --  控制域 -> 软核 的一致状态快照（只读）
//
// 为什么需要它：
//   控制量在不同周期更新（t_us 每周期变、alpha 每采样变），CPU 若直接逐个
//   读实时寄存器，会拿到"不同采样时刻拼起来的"数据。这里把全部字段在**同一个
//   时钟沿**打进影子寄存器，并配一个 SEQ 序号；软件用 seqlock 方式
//   （读 SEQ -> 读字段 -> 再读 SEQ）保证多字段一致。
//
// 更新节奏：默认每 1000 us 一次（可写 SNAP_PERIOD 修改）。
// 本模块没有通往控制域的输出，软核不可能影响控制环。
// =============================================================================
`timescale 1ns/1ps
`include "lcd_config.vh"

module status_snapshot #(
    parameter integer CLK_HZ = 50_000_000
)(
    input  wire        clk,
    input  wire        rst_n,

    // ---- 实时控制量（来自 lqr_system） ----
    input  wire signed [31:0] i_alpha_q16,
    input  wire signed [31:0] i_theta_q16,
    input  wire signed [31:0] i_arm_ref_q16,
    input  wire signed [31:0] i_freq_q8,
    input  wire signed [31:0] i_u_q16,
    input  wire signed [31:0] i_alpha_dot,
    input  wire signed [31:0] i_theta_dot,
    input  wire signed [31:0] i_alpha_c,
    input  wire        [31:0] i_enc_raw,
    input  wire        [31:0] i_enc_age_us,
    input  wire        [31:0] i_enc_seq,
    input  wire        [31:0] i_ctrl_count,
    input  wire        [31:0] i_t_us,
    input  wire        [12:0] i_ad_value,
    input  wire         [7:0] i_state,
    input  wire         [7:0] i_fault,
    input  wire         [7:0] i_flags,
    input  wire        [31:0] i_build_tag,
    input  wire               i_run,
    input  wire               i_calibrated,
    input  wire               i_saturated,
    input  wire               i_fb_ready,
    input  wire               i_swing_active,

    // ---- CPU 总线（只读窗口，1 周期完成） ----
    input  wire        cs,
    input  wire        we,
    input  wire [7:0]  addr,
    input  wire [31:0] wdata,
    input  wire [3:0]  wstrb,
    output wire [31:0] rdata
);

    localparam [7:0] A_SEQ    = 8'h00;
    localparam [7:0] A_STATE  = 8'h04;
    localparam [7:0] A_ALPHA  = 8'h08;
    localparam [7:0] A_THETA  = 8'h0C;
    localparam [7:0] A_ARMREF = 8'h10;
    localparam [7:0] A_FREQ   = 8'h14;
    localparam [7:0] A_U      = 8'h18;
    localparam [7:0] A_ENCR   = 8'h1C;
    localparam [7:0] A_ENCAGE = 8'h20;
    localparam [7:0] A_CTRLN  = 8'h24;
    localparam [7:0] A_TUS    = 8'h28;
    localparam [7:0] A_ENCSEQ = 8'h2C;
    localparam [7:0] A_ADOT   = 8'h30;
    localparam [7:0] A_TDOT   = 8'h34;
    localparam [7:0] A_ALPHAC = 8'h38;
    localparam [7:0] A_AD     = 8'h3C;
    localparam [7:0] A_BUILD  = 8'h40;
    localparam [7:0] A_CTRL   = 8'h44;   // RW: bit0=hold, bit1=release, bit2=force_upd
    localparam [7:0] A_PERIOD = 8'h48;   // RW: 更新周期 us
    localparam [7:0] A_UPDCNT = 8'h4C;   // R : 快照更新次数

    reg        [31:0] s_alpha, s_theta, s_armref, s_freq, s_u;
    reg        [31:0] s_adot, s_tdot, s_alphac;
    reg        [31:0] s_encr, s_encage, s_encseq, s_ctrln, s_tus;
    reg        [31:0] s_ad, s_build;
    reg         [7:0] s_state, s_fault, s_flags;
    reg         [4:0] s_mode;      // {run, calibrated, saturated, fb_ready, swing_active}
    reg        [31:0] s_seq;

    reg               hold;
    reg        [15:0] period_us;
    reg        [15:0] us_div;
    reg        [31:0] us_cnt;
    reg        [31:0] last_us;
    reg        [31:0] upd_cnt;
    reg               force_upd;

    localparam [15:0] US_DIV_MAX = CLK_HZ / 1_000_000 - 1;
    wire us_tick = (us_div >= US_DIV_MAX);
    wire [31:0] period32 = {16'd0, period_us};
    wire do_update = !hold && (force_upd || ((us_cnt - last_us) >= period32));

    // 周期寄存器写入（带下限钳位）
    wire [15:0] period_in = {wstrb[1] ? wdata[15:8] : period_us[15:8],
                             wstrb[0] ? wdata[7:0]  : period_us[7:0]};
    wire [15:0] period_next = (period_in < 16'd20) ? 16'd20 : period_in;
    wire wr_ctrl   = cs && we && (addr == A_CTRL);
    wire wr_period = cs && we && (addr == A_PERIOD);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            us_div    <= 16'd0;
            us_cnt    <= 32'd0;
            last_us   <= 32'd0;
            hold      <= 1'b0;
            force_upd     <= 1'b0;
            period_us <= 16'd1000;
            upd_cnt   <= 32'd0;
            s_alpha   <= 32'd0; s_theta <= 32'd0; s_armref <= 32'd0;
            s_freq    <= 32'd0; s_u     <= 32'd0;
            s_adot    <= 32'd0; s_tdot  <= 32'd0; s_alphac <= 32'd0;
            s_encr    <= 32'd0; s_encage<= 32'd0; s_encseq <= 32'd0;
            s_ctrln   <= 32'd0; s_tus   <= 32'd0;
            s_ad      <= 32'd0; s_build <= 32'd0;
            s_state   <= 8'd0; s_fault <= 8'd0; s_flags <= 8'd0; s_mode <= 5'd0;
            s_seq     <= 32'd0;
        end else begin
            if (us_tick) begin
                us_div <= 16'd0;
                us_cnt <= us_cnt + 32'd1;
            end else begin
                us_div <= us_div + 16'd1;
            end

            // 同一时钟沿整体锁存 -> 快照内部自洽
            if (do_update) begin
                s_alpha   <= i_alpha_q16;
                s_theta   <= i_theta_q16;
                s_armref  <= i_arm_ref_q16;
                s_freq    <= i_freq_q8;
                s_u       <= i_u_q16;
                s_adot    <= i_alpha_dot;
                s_tdot    <= i_theta_dot;
                s_alphac  <= i_alpha_c;
                s_encr    <= i_enc_raw;
                s_encage  <= i_enc_age_us;
                s_encseq  <= i_enc_seq;
                s_ctrln   <= i_ctrl_count;
                s_tus     <= i_t_us;
                s_ad      <= {19'd0, i_ad_value};
                s_build   <= i_build_tag;
                s_state   <= i_state;
                s_fault   <= i_fault;
                s_flags   <= i_flags;
                s_mode    <= {i_run, i_calibrated, i_saturated, i_fb_ready, i_swing_active};
                s_seq     <= s_seq + 32'd1;
                upd_cnt   <= upd_cnt + 32'd1;
                last_us   <= us_cnt;
            end

            if (wr_ctrl) begin
                if (wstrb[0] && wdata[0]) hold <= 1'b1;
                if (wstrb[0] && wdata[1]) hold <= 1'b0;
                if (wstrb[0] && wdata[2]) force_upd <= 1'b1;
            end else if (force_upd) begin
                force_upd <= 1'b0;      // force_upd 是单周期脉冲
            end

            if (wr_period) period_us <= period_next;
        end
    end

    assign rdata = (addr == A_SEQ)    ? s_seq :
                   (addr == A_STATE)  ? {s_state, s_fault, s_flags, 3'd0, s_mode} :
                   (addr == A_ALPHA)  ? s_alpha :
                   (addr == A_THETA)  ? s_theta :
                   (addr == A_ARMREF) ? s_armref :
                   (addr == A_FREQ)   ? s_freq :
                   (addr == A_U)      ? s_u :
                   (addr == A_ENCR)   ? s_encr :
                   (addr == A_ENCAGE) ? s_encage :
                   (addr == A_CTRLN)  ? s_ctrln :
                   (addr == A_TUS)    ? s_tus :
                   (addr == A_ENCSEQ) ? s_encseq :
                   (addr == A_ADOT)   ? s_adot :
                   (addr == A_TDOT)   ? s_tdot :
                   (addr == A_ALPHAC) ? s_alphac :
                   (addr == A_AD)     ? s_ad :
                   (addr == A_BUILD)  ? s_build :
                   (addr == A_CTRL)   ? {29'd0, force_upd, 1'b0, hold} :
                   (addr == A_PERIOD) ? {16'd0, period_us} :
                   (addr == A_UPDCNT) ? upd_cnt :
                                        32'h0000_0000;

endmodule
