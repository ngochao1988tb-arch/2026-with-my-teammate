`timescale 1ns / 1ps

module uart_rx #(
    parameter integer CLK_HZ = 50_000_000,
    parameter integer BAUD   = 115200
) (
    input  wire       clk,
    input  wire       rst_n,
    input  wire       rx,
    output reg        rx_valid,
    output reg  [7:0] rx_data
);

    localparam integer CLKS_PER_BIT = (CLK_HZ + BAUD / 2) / BAUD;
    localparam integer HALF_CLKS    = CLKS_PER_BIT / 2;

    localparam [1:0] S_IDLE  = 2'd0;
    localparam [1:0] S_START = 2'd1;
    localparam [1:0] S_DATA  = 2'd2;
    localparam [1:0] S_STOP  = 2'd3;

    reg        rx_meta;
    reg        rx_sync;
    reg [1:0]  state;
    reg [31:0] clk_cnt;
    reg [2:0]  bit_idx;
    reg [7:0]  shift_data;

    always @(posedge clk) begin
        if (!rst_n) begin
            rx_meta <= 1'b1;
            rx_sync <= 1'b1;
        end else begin
            rx_meta <= rx;
            rx_sync <= rx_meta;
        end
    end

    always @(posedge clk) begin
        if (!rst_n) begin
            state      <= S_IDLE;
            clk_cnt    <= 32'd0;
            bit_idx    <= 3'd0;
            shift_data <= 8'd0;
            rx_valid   <= 1'b0;
            rx_data    <= 8'd0;
        end else begin
            rx_valid <= 1'b0;

            case (state)
                S_IDLE: begin
                    clk_cnt <= 32'd0;
                    bit_idx <= 3'd0;
                    if (!rx_sync) begin
                        state   <= S_START;
                        clk_cnt <= HALF_CLKS;
                    end
                end

                S_START: begin
                    if (clk_cnt == 0) begin
                        if (!rx_sync) begin
                            state   <= S_DATA;
                            clk_cnt <= CLKS_PER_BIT - 1;
                        end else begin
                            state <= S_IDLE;
                        end
                    end else begin
                        clk_cnt <= clk_cnt - 1'b1;
                    end
                end

                S_DATA: begin
                    if (clk_cnt == 0) begin
                        shift_data[bit_idx] <= rx_sync;
                        clk_cnt <= CLKS_PER_BIT - 1;
                        if (bit_idx == 3'd7) begin
                            bit_idx <= 3'd0;
                            state   <= S_STOP;
                        end else begin
                            bit_idx <= bit_idx + 1'b1;
                        end
                    end else begin
                        clk_cnt <= clk_cnt - 1'b1;
                    end
                end

                S_STOP: begin
                    if (clk_cnt == 0) begin
                        if (rx_sync) begin
                            rx_data  <= shift_data;
                            rx_valid <= 1'b1;
                        end
                        state <= S_IDLE;
                    end else begin
                        clk_cnt <= clk_cnt - 1'b1;
                    end
                end

                default: begin
                    state <= S_IDLE;
                end
            endcase
        end
    end

endmodule
