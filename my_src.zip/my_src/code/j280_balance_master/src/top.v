// =============================================================================
// top.v  --  集成顶层（project_01）：倒立摆控制 + 四路串口外围 + RISC-V 软核显示
//
// 时钟
//   板载 M19 是 50 MHz 固定晶振；设计内部用 rPLL 二分频出 **25 MHz 系统时钟**
//   （clk_sys）驱动全部逻辑。原因：并入四路串口后 50 MHz 余量不足（实测
//   Fmax 43.7 MHz），按使用要求整体降到 25 MHz（周期 40 ns，余量 >70%）。
//   所有按周期计数的常量都从 control_config.vh 的 CFG_HARDWARE_CLOCK_HZ 推导，
//   设计仍是单时钟域，没有新增跨时钟域路径。
//
// 组成
//   1) lqr_system：控制内核（3 ms 控制环、编码器、PWM、急停）+ 四路串口
//        · 上位机  K20/L20（板载 CH340N，18 字节命令 + 10 Hz ASCII 快照）
//        · 串口屏  K22/L22（TJC，同一套命令与广播快照）
//        · 从板    V8/V9  （UART v2 协议 + 38 字节应答 + 轮询判定）
//        · 语音    Y14/Y15（CI1302 命令词 / 播报 / 双摆协调）
//        · 遥测    telemetry_tx（82 字节二进制 v3，参数开关，默认关闭）
//   2) rv32_soc：PicoRV32 软核 + ST7789 8080 并口 + HR2046 触摸 + 状态快照，
//      本地触摸界面作为 hmi_control 的第三源（rv_req 邮箱）。
//
// 集成原则
//   1) 控制逻辑、控制参数与 ST7789 工程逐句一致，本层只做端口接线。
//   2) 软核子系统与控制在**时序上完全解耦**：没有共享 RAM、没有跨时钟域、
//      没有互相的复位耦合。软核卡死、复位、"总线错误"都只会影响它自己。
//   3) 软核唯一能影响控制的通路是 rv_req 命令通道（CFG_RV_ENABLE_CMD=1），
//      且仍要走 hmi_control 的全部状态检查与安全门控。
//   4) 双向数据总线只在**本层**做三态，外设内部只有 data_o/data_oe/data_i。
//
// LCD 管脚在 project.cst 中按用户给定接线分配；Bank 0/1 为 3.3 V。
// 本整合工程启用 ST7789 横屏、HR2046 触摸和软核命令通道。
// =============================================================================
`timescale 1ns/1ps
`include "control_config.vh"
`include "lcd_config.vh"

module top #(
    parameter integer LCD_DW     = `CFG_LCD_DATA_WIDTH,
    parameter integer ENABLE_CMD = `CFG_RV_ENABLE_CMD,
    parameter integer RV_MUL     = 0,
    parameter         IMEM_INIT  = "imem.hex",
    parameter         DMEM_INIT  = "dmem.hex",
    // 遥测开关：0=关闭（默认，引脚高阻），1=82 字节二进制遥测从 telemetry_tx 输出。
    // A14 遥测开关独立于下面的 K20 调试模式。
    parameter integer ENABLE_TELEMETRY = 0,
    parameter integer PC_DEBUG_EN = `CFG_PC_DEBUG_ENABLED,
    // 语音 / 双板参数（与 PROJECT_ALL 一致）
    parameter integer VOICE_TARGET_TIMEOUT_MS=0,
    parameter integer VOICE_GAP_MS=700,
    parameter integer VOICE_ACTION_TIMEOUT_MS=20000,
    parameter integer VOICE_COORD_TIMEOUT_MS=26000,
    parameter integer SLAVE_CENTER=10000,
    parameter integer SLAVE_TRAVEL=2150,
    parameter integer SLAVE_COUNTS_PER_REV=1000
)(
    input  wire        clk_50m,
    input  wire        rst_n,
    input  wire [3:0]  key_sw,
    output wire        pul_out,
    output wire        dir_out,
    output wire        ena_out,
    input  wire        motor_rx,
    output wire        motor_tx,
    // 遥测专用口（ENABLE_TELEMETRY=0 时高阻，不占用其他串口）
    output wire        telemetry_tx,
    output wire        adc_clk,
    output wire        adc_oe_n,
    input  wire [9:0]  adc_data_in,
    // 上位机（板载 CH340N）：L20 收 / K20 发
    input  wire        hmi_rx,
    output wire        hmi_tx,
    // TJC 串口屏：K22 收 / L22 发
    input  wire        screen_rx,
    output wire        screen_tx,
    // 从板 FPGA：V9 收 / V8 发
    input  wire        slave_rx,
    output wire        slave_tx,
    // 语音模块 CI1302：Y15 收 / Y14 发
    input  wire        voice_rx,
    output wire        voice_tx,

    // ---------------- 8080 并口屏幕（管脚见 project.cst） ----------------
    output wire        lcd_cs_n,
    output wire        lcd_wr_n,
    output wire        lcd_rd_n,
    output wire        lcd_rs,
    output wire        lcd_reset_n,
    inout  wire [LCD_DW-1:0] lcd_data,
    output wire        lcd_bl,
    input wire touch_miso, touch_pen_n,
    output wire touch_cs_n, touch_clk, touch_mosi
);

    // ------------------------------------------------------------------
    // 系统时钟：50 MHz 晶振 → rPLL 二分频 25 MHz
    //   CLKOUT = FCLKIN * (FBDIV_SEL+1) / (IDIV_SEL+1) = 50 * 1 / 2 = 25.0 MHz
    //   VCO    = CLKOUT * ODIV_SEL                     = 25 * 32    = 800 MHz
    //   两条合法区间：CLKOUT 3.90625~625 MHz、VCO 500~1250 MHz，均满足。
    //   （ODISEL 取 8 会让 VCO = 200 MHz 越下限，报 EX0210）
    // ------------------------------------------------------------------
    wire clk_sys;
    wire pll_lock;
    rPLL #(
        .FCLKIN      ("50.0"),
        .IDIV_SEL    (1),      // ÷2
        .FBDIV_SEL   (0),      // ×1
        .ODIV_SEL    (32),     // ODIV → CLKOUT = 25 MHz, VCO = 800 MHz
        .DYN_IDIV_SEL("false"),
        .DYN_FBDIV_SEL("false"),
        .DYN_ODIV_SEL ("false"),
        .DYN_DA_EN   ("false"),
        .DEVICE      ("GW2A-55")
    ) u_pll_25m (
        .CLKOUT (clk_sys),
        .LOCK   (pll_lock),
        .CLKIN  (clk_50m),
        .CLKFB  (1'b0),
        .FBDSEL (6'd0),
        .IDSEL  (6'd0),
        .ODSEL  (6'd0),
        .PSDA   (4'd0),
        .DUTYDA (4'd0),
        .FDLY   (4'd0),
        .RESET  (1'b0),
        .RESET_P(1'b0)
    );
    // 复位异步拉低、等 PLL 锁定后再释放同步链（两个子系统内部各自有 2FF 同步器）。
    wire rst_n_sys = rst_n & pll_lock;

    // ------------------------------------------------------------------
    // 控制域状态（只读）
    // ------------------------------------------------------------------
    wire [31:0] st_alpha_q16, st_theta_q16, st_arm_ref_q16, st_freq_q8, st_u_q16;
    wire [31:0] st_alpha_dot, st_theta_dot, st_alpha_c;
    wire [31:0] st_enc_raw, st_enc_age_us, st_enc_seq, st_ctrl_count, st_t_us, st_build_tag;
    wire [12:0] st_ad_value;
    wire  [7:0] st_state, st_fault, st_flags;
    wire        st_run, st_calibrated, st_saturated, st_fb_ready, st_swing_active;

    // ------------------------------------------------------------------
    // 软核侧
    // ------------------------------------------------------------------
    wire               lcd_data_oe;
    wire [LCD_DW-1:0]  lcd_data_o;
    wire               rv_req;
    wire [7:0]         rv_cmd;
    wire [31:0]        rv_seq, rv_arg, rv_speed;
    wire               rv_ack;
    wire [31:0]        rv_ack_seq, rv_ack_result;
    wire               hmi_req_pulse;

    lqr_system #(
        .ENABLE_TELEMETRY (ENABLE_TELEMETRY),
        .PC_DEBUG_EN      (PC_DEBUG_EN),
        .VOICE_TARGET_TIMEOUT_MS (VOICE_TARGET_TIMEOUT_MS),
        .VOICE_GAP_MS     (VOICE_GAP_MS),
        .VOICE_ACTION_TIMEOUT_MS (VOICE_ACTION_TIMEOUT_MS),
        .VOICE_COORD_TIMEOUT_MS  (VOICE_COORD_TIMEOUT_MS),
        .SLAVE_CENTER     (SLAVE_CENTER),
        .SLAVE_TRAVEL     (SLAVE_TRAVEL),
        .SLAVE_COUNTS_PER_REV (SLAVE_COUNTS_PER_REV)
    ) u_lqr (
        .clk_sys        (clk_sys),
        .rst_n          (rst_n_sys),
        .key_sw         (key_sw),
        .pul_out        (pul_out),
        .dir_out        (dir_out),
        .ena_out        (ena_out),
        .motor_rx       (motor_rx),
        .motor_tx       (motor_tx),
        .telemetry_tx   (telemetry_tx),
        .adc_clk        (adc_clk),
        .adc_oe_n       (adc_oe_n),
        .adc_data_in    (adc_data_in),
        .hmi_rx         (hmi_rx),
        .hmi_tx         (hmi_tx),
        .screen_rx      (screen_rx),
        .screen_tx      (screen_tx),
        .slave_rx       (slave_rx),
        .slave_tx       (slave_tx),
        .voice_rx       (voice_rx),
        .voice_tx       (voice_tx),
        .st_alpha_q16   (st_alpha_q16),
        .st_theta_q16   (st_theta_q16),
        .st_arm_ref_q16 (st_arm_ref_q16),
        .st_freq_q8     (st_freq_q8),
        .st_u_q16       (st_u_q16),
        .st_alpha_dot   (st_alpha_dot),
        .st_theta_dot   (st_theta_dot),
        .st_alpha_c     (st_alpha_c),
        .st_enc_raw     (st_enc_raw),
        .st_enc_age_us  (st_enc_age_us),
        .st_enc_seq     (st_enc_seq),
        .st_ctrl_count  (st_ctrl_count),
        .st_t_us        (st_t_us),
        .st_ad_value    (st_ad_value),
        .st_state       (st_state),
        .st_fault       (st_fault),
        .st_flags       (st_flags),
        .st_build_tag   (st_build_tag),
        .st_run         (st_run),
        .st_calibrated  (st_calibrated),
        .st_saturated   (st_saturated),
        .st_fb_ready    (st_fb_ready),
        .st_swing_active(st_swing_active),
        .rv_req         (rv_req),
        .rv_cmd         (rv_cmd),
        .rv_seq         (rv_seq),
        .rv_arg         (rv_arg),
        .rv_speed       (rv_speed),
        .rv_ack         (rv_ack),
        .rv_ack_seq     (rv_ack_seq),
        .rv_ack_result  (rv_ack_result),
        .hmi_req_pulse  (hmi_req_pulse)
    );

    rv32_soc #(
        .IMEM_INIT  (IMEM_INIT),
        .DMEM_INIT  (DMEM_INIT),
        .RV_MUL     (RV_MUL),
        .ENABLE_CMD (ENABLE_CMD),
        .ENABLE_TOUCH(1),
        .DATA_WIDTH (LCD_DW)
    ) u_soc (
        .clk (clk_sys),
        .rst_n (rst_n_sys),
        .st_alpha_q16   (st_alpha_q16),
        .st_theta_q16   (st_theta_q16),
        .st_arm_ref_q16 (st_arm_ref_q16),
        .st_freq_q8     (st_freq_q8),
        .st_u_q16       (st_u_q16),
        .st_alpha_dot   (st_alpha_dot),
        .st_theta_dot   (st_theta_dot),
        .st_alpha_c     (st_alpha_c),
        .st_enc_raw     (st_enc_raw),
        .st_enc_age_us  (st_enc_age_us),
        .st_enc_seq     (st_enc_seq),
        .st_ctrl_count  (st_ctrl_count),
        .st_t_us        (st_t_us),
        .st_ad_value    (st_ad_value),
        .st_state       (st_state),
        .st_fault       (st_fault),
        .st_flags       (st_flags),
        .st_build_tag   (st_build_tag),
        .st_run         (st_run),
        .st_calibrated  (st_calibrated),
        .st_saturated   (st_saturated),
        .st_fb_ready    (st_fb_ready),
        .st_swing_active(st_swing_active),
        .lcd_cs_n       (lcd_cs_n),
        .lcd_wr_n       (lcd_wr_n),
        .lcd_rd_n       (lcd_rd_n),
        .lcd_rs         (lcd_rs),
        .lcd_reset_n    (lcd_reset_n),
        .lcd_data_o     (lcd_data_o),
        .lcd_data_oe    (lcd_data_oe),
        .lcd_data_i     (lcd_data),
        .lcd_bl         (lcd_bl),
        .touch_miso(touch_miso), .touch_pen_n(touch_pen_n),
        .touch_cs_n(touch_cs_n), .touch_clk(touch_clk), .touch_mosi(touch_mosi),
        .hmi_req_active (hmi_req_pulse),
        .rv_req         (rv_req),
        .rv_cmd         (rv_cmd),
        .rv_seq         (rv_seq),
        .rv_arg         (rv_arg),
        .rv_speed       (rv_speed),
        .rv_ack         (rv_ack),
        .rv_ack_seq     (rv_ack_seq),
        .rv_ack_result  (rv_ack_result)
    );

    // 外部双向总线的三态只在这一层
    assign lcd_data = lcd_data_oe ? lcd_data_o : {LCD_DW{1'bz}};

endmodule
