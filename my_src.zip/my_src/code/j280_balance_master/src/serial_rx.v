`timescale 1ns/1ps
`include "control_config.vh"
// 8N1 with input synchronizer, start-bit qualification and stop-bit check.
module serial_rx #(parameter CLK_HZ=`CFG_HARDWARE_CLOCK_HZ, parameter BAUD=`CFG_MOTOR_UART_BAUD)(
    input clk, input rst_n, input rx,
    output reg [7:0] data, output reg valid, output reg framing_error
);
    localparam DIV=(CLK_HZ+BAUD/2)/BAUD;
    reg rx_meta, rx_sync, rx_prev;
    reg [2:0] state;
    reg [2:0] bit_index;
    reg [7:0] shift;
    reg [31:0] ticks;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin rx_meta<=1; rx_sync<=1; rx_prev<=1; end
        else begin rx_meta<=rx; rx_sync<=rx_meta; rx_prev<=rx_sync; end
    end
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin state<=0; bit_index<=0; shift<=0; ticks<=0; data<=0; valid<=0; framing_error<=0; end
        else begin
            valid<=0; framing_error<=0;
            case (state)
                0: if (rx_prev && !rx_sync) begin ticks<=DIV/2-1; state<=1; end
                1: if (ticks!=0) ticks<=ticks-1'b1;
                   else if (!rx_sync) begin ticks<=DIV-1; bit_index<=0; state<=2; end
                   else state<=0;
                2: if (ticks!=0) ticks<=ticks-1'b1;
                   else begin
                       shift[bit_index]<=rx_sync; ticks<=DIV-1;
                       if (bit_index==7) state<=3; else bit_index<=bit_index+1'b1;
                   end
                3: if (ticks!=0) ticks<=ticks-1'b1;
                   else begin
                       if (rx_sync) begin data<=shift; valid<=1; end
                       else framing_error<=1;
                       state<=0;
                   end
                default: state<=0;
            endcase
        end
    end
endmodule
