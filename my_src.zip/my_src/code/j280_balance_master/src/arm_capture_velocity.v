`timescale 1ns/1ps
`include "control_config.vh"
// Approximately 12ms of converted encoder history, independent of tick rate.
// Only used for swing capture/seed, not as a replacement for the RUN observer.
module arm_capture_velocity(
    input clk, input rst_n, input clear, input tick, input fresh,
    input signed [31:0] angle,
    output signed [31:0] velocity,
    output valid
);
    localparam integer DECIMATION=`CFG_MOTION_PERIOD_US/`CFG_CONTROL_PERIOD_US;
    reg [(DECIMATION>1 ? $clog2(DECIMATION):1)-1:0] phase;
    reg fresh_seen;
    wire measurement_tick=tick && phase==DECIMATION-1;
    wire interval_fresh=fresh_seen || fresh;
    localparam integer WINDOW_FRAMES=(`CFG_ARM_VELOCITY_WINDOW_US+`CFG_MOTION_PERIOD_US-1)/`CFG_MOTION_PERIOD_US;
    localparam signed [31:0] SCALE=$rtoi(65536.0*1000000.0/(1.0*WINDOW_FRAMES*`CFG_MOTION_PERIOD_US)+0.5);
    reg signed [31:0] history[0:WINDOW_FRAMES-1];
    reg [$clog2(WINDOW_FRAMES+1)-1:0] count;
    reg signed [63:0] product;
    reg ready;
    wire signed [32:0] delta=$signed({angle[31],angle})-$signed({history[WINDOW_FRAMES-1][31],history[WINDOW_FRAMES-1]});
    // Reject arithmetic overflow rather than wrapping a bad estimate into a
    // plausible low speed. A full 2ms interval without new feedback clears
    // the window. Fresh flags are accumulated across the fast control ticks.
    // floor(delta*SCALE/2^16) must fit signed Q16. Compare the exact
    // integer preimage bounds in parallel with multiplication, instead of
    // putting a 65-bit product compare on the register's enable/data path.
    // SCALE is positive. ceil(-2^47/SCALE) = -floor(2^47/SCALE).
    localparam signed [63:0] DELTA_MAX=((64'sd1<<<47)-1)/SCALE;
    localparam signed [63:0] DELTA_MIN=-((64'sd1<<<47)/SCALE);
    wire fits=$signed(delta)<=DELTA_MAX && $signed(delta)>=DELTA_MIN;
    // Valid deltas need only 26 signed bits over the 12ms window.
    // Derive the width for other configurations. Invalid inputs may truncate
    // here, but fits rejects them using the original full 33-bit difference.
    localparam integer REQUIRED_DELTA_BITS=$clog2(((64'sd1<<<47)/SCALE)+1)+1;
    localparam integer MULT_DELTA_BITS=REQUIRED_DELTA_BITS>33 ? 33:REQUIRED_DELTA_BITS;
    wire signed [MULT_DELTA_BITS-1:0] multiply_delta=delta[MULT_DELTA_BITS-1:0];
    wire signed [64:0] estimate=$signed(multiply_delta)*$signed(SCALE);
    assign velocity=product>>>16;
    assign valid=ready;
    integer i;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            for(i=0;i<WINDOW_FRAMES;i=i+1) history[i]<=0;
            count<=0; product<=0; ready<=0; phase<=0;fresh_seen<=0;
        end else if(clear) begin
            for(i=0;i<WINDOW_FRAMES;i=i+1) history[i]<=0;
            count<=0; product<=0; ready<=0; phase<=0;fresh_seen<=0;
        end else if(tick) begin
            if(!measurement_tick) begin
                phase<=phase+1'b1;fresh_seen<=fresh_seen || fresh;
            end else begin
                phase<=0;fresh_seen<=0;
                if(!interval_fresh) begin count<=0;product<=0;ready<=0;end
                else begin
                    history[0]<=angle;
                    for(i=1;i<WINDOW_FRAMES;i=i+1) history[i]<=history[i-1];
                    if(count<WINDOW_FRAMES) count<=count+1'b1;
                    ready<=count>=WINDOW_FRAMES && fits;
                    product<=(count>=WINDOW_FRAMES && fits) ? estimate[63:0] : 64'sd0;
                end
            end
        end
    end
endmodule
