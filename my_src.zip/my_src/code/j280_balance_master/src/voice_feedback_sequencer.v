`timescale 1ns / 1ps

module voice_feedback_sequencer #(
    parameter integer CLK_HZ = 50_000_000,
    parameter integer GAP_MS = 700
) (
    input  wire       clk,
    input  wire       rst_n,
    input  wire       report_valid,
    input  wire [1:0] report_target_mask,
    input  wire [7:0] report_action_id,
    input  wire [2:0] report_result,
    input  wire       prompt_valid,
    input  wire [7:0] prompt_id,
    input  wire       play_busy,
    input  wire       play_done,
    output reg        play_req,
    output reg  [7:0] play_id,
    output wire       ready,
    output reg        done_pulse
);

    localparam [2:0] S_IDLE     = 3'd0;
    localparam [2:0] S_ISSUE    = 3'd1;
    localparam [2:0] S_WAIT     = 3'd2;
    localparam [2:0] S_GAP      = 3'd3;

    localparam [2:0] RESULT_OK         = 3'd0;
    localparam [2:0] RESULT_MAIN_FAIL  = 3'd1;
    localparam [2:0] RESULT_SLAVE_FAIL = 3'd2;
    localparam [2:0] RESULT_BOTH_FAIL  = 3'd3;
    localparam [2:0] RESULT_LINK_FAIL  = 3'd4;

    localparam integer GAP_CYCLES = (CLK_HZ / 1000) * GAP_MS;
    localparam integer GAP_WIDTH  = $clog2(GAP_CYCLES + 1);

    reg [2:0]  state;
    reg [2:0]  step;
    reg [1:0]  sequence_target;
    reg [7:0]  sequence_action_id;
    reg [2:0]  sequence_result;
    reg        prompt_sequence;
    reg [7:0]  prompt_latched;
    reg [GAP_WIDTH-1:0] gap_counter;

    wire [7:0] target_play_id;
    reg  [7:0] action_play_id;
    reg  [7:0] result_play_id;
    reg  [7:0] current_play_id;

    assign ready = (state == S_IDLE);

    assign target_play_id =
        (sequence_target == 2'b01) ? 8'h70 :
        (sequence_target == 2'b10) ? 8'h71 : 8'h70;

    always @* begin
        case (sequence_action_id)
            8'h40: action_play_id = 8'h73;
            8'h41: action_play_id = 8'h74;
            8'h42: action_play_id = 8'h75;
            8'h43: action_play_id = 8'h76;
            8'h86: action_play_id = 8'h77;
            8'h92: action_play_id = 8'h78;
            8'hA4: action_play_id = 8'h79;
            8'hC6: action_play_id = 8'h7A;
            8'hD2: action_play_id = 8'h7B;
            8'hE4: action_play_id = 8'h7C;
            default: action_play_id = 8'h73;
        endcase
    end

    always @* begin
        case (sequence_result)
            RESULT_OK:         result_play_id = 8'h7D;
            RESULT_MAIN_FAIL:  result_play_id = 8'h7E;
            RESULT_SLAVE_FAIL: result_play_id = 8'h7F;
            RESULT_BOTH_FAIL:  result_play_id = 8'h80;
            RESULT_LINK_FAIL:  result_play_id = 8'h81;
            default:           result_play_id = 8'h81;
        endcase
    end

    always @* begin
        if (prompt_sequence)
            current_play_id = prompt_latched;
        else if (sequence_target == 2'b11) begin
            // A combined main+slave target is announced explicitly as two
            // target words before the action and result.
            case (step)
                3'd0: current_play_id = 8'h70;
                3'd1: current_play_id = 8'h71;
                3'd2: current_play_id = action_play_id;
                default: current_play_id = result_play_id;
            endcase
        end else begin
            case (step)
                3'd0: current_play_id = target_play_id;
                3'd1: current_play_id = action_play_id;
                default: current_play_id = result_play_id;
            endcase
        end
    end

    always @(posedge clk) begin
        if (!rst_n) begin
            state                 <= S_IDLE;
            step                  <= 3'd0;
            sequence_target       <= 2'b00;
            sequence_action_id    <= 8'd0;
            sequence_result       <= RESULT_OK;
            prompt_sequence       <= 1'b0;
            prompt_latched        <= 8'd0;
            gap_counter           <= {GAP_WIDTH{1'b0}};
            play_req              <= 1'b0;
            play_id               <= 8'd0;
            done_pulse            <= 1'b0;
        end else begin
            play_req   <= 1'b0;
            done_pulse <= 1'b0;

            case (state)
                S_IDLE: begin
                    step <= 3'd0;
                    if (report_valid) begin
                        sequence_target    <= report_target_mask;
                        sequence_action_id <= report_action_id;
                        sequence_result    <= report_result;
                        prompt_sequence    <= 1'b0;
                        state              <= S_ISSUE;
                    end else if (prompt_valid) begin
                        prompt_latched  <= prompt_id;
                        prompt_sequence <= 1'b1;
                        state           <= S_ISSUE;
                    end
                end

                S_ISSUE: begin
                    if (!play_busy) begin
                        play_req <= 1'b1;
                        play_id  <= current_play_id;
                        state    <= S_WAIT;
                    end
                end

                S_WAIT: begin
                    if (play_done) begin
                        gap_counter <= GAP_CYCLES;
                        state       <= S_GAP;
                    end
                end

                S_GAP: begin
                    if (gap_counter == {GAP_WIDTH{1'b0}}) begin
                        if (prompt_sequence ||
                            ((sequence_target == 2'b11) ?
                             (step == 3'd3) : (step == 3'd2))) begin
                            done_pulse <= 1'b1;
                            state      <= S_IDLE;
                        end else begin
                            step  <= step + 1'b1;
                            state <= S_ISSUE;
                        end
                    end else begin
                        gap_counter <= gap_counter - 1'b1;
                    end
                end

                default: state <= S_IDLE;
            endcase
        end
    end

endmodule
