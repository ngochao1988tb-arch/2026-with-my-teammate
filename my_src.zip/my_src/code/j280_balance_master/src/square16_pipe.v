`timescale 1ns/1ps
// Exact signed 16-bit square, six clocks. Nibble products fit logic LUTs;
// the reduction tree has one 32-bit addition per stage and uses no extra DSP.
module square16_pipe(input clk, input signed [15:0] x, output reg [31:0] y);
    wire signed [4:0] a={1'b0,x[3:0]}, b={1'b0,x[7:4]}, c={1'b0,x[11:8]};
    wire signed [4:0] d={x[15],x[15:12]};
    reg signed [9:0] p[0:9];
    reg signed [31:0] s[0:4],t[0:2],u[0:1];
    always @(posedge clk) begin
        p[0]<=a*a;p[1]<=a*b;p[2]<=a*c;p[3]<=a*d;p[4]<=b*b;
        p[5]<=b*c;p[6]<=b*d;p[7]<=c*c;p[8]<=c*d;p[9]<=d*d;
        s[0]<=$signed(p[0])+($signed(p[1])<<<5);
        s[1]<=($signed(p[2])<<<9)+($signed(p[3])<<<13);
        s[2]<=($signed(p[4])<<<8)+($signed(p[5])<<<13);
        s[3]<=($signed(p[6])<<<17)+($signed(p[7])<<<16);
        s[4]<=($signed(p[8])<<<21)+($signed(p[9])<<<24);
        t[0]<=s[0]+s[1];t[1]<=s[2]+s[3];t[2]<=s[4];
        u[0]<=t[0]+t[1];u[1]<=t[2];
        y<=u[0]+u[1];
    end
endmodule
