`timescale 1ns / 1ps

module voice_command_assembler #(
    parameter integer CLK_HZ = 50_000_000,
    // Compatibility only: mode selection now persists until reset/reselection.
    parameter integer TARGET_TIMEOUT_MS = 0
) (
    input  wire       clk,
    input  wire       rst_n,
    input  wire       command_word_valid,
    input  wire [7:0] command_word_id,
    output reg        target_changed,
    output reg  [1:0] target_mask,
    output reg        target_timeout,
    output reg        command_valid,
    output reg  [1:0] command_target_mask,
    output reg  [3:0] command_action,
    output reg  [7:0] command_id,
    output reg  [7:0] command_angle,
    output reg        command_right,
    output reg        command_rejected,
    output reg  [1:0] reject_reason
);

    localparam [1:0] TARGET_MAIN  = 2'b01;
    localparam [1:0] TARGET_SLAVE = 2'b10;
    localparam [1:0] TARGET_BOTH  = 2'b11;

    localparam [3:0] ACTION_NONE        = 4'd0;
    localparam [3:0] ACTION_SWING_UP    = 4'd1;
    localparam [3:0] ACTION_ESTOP       = 4'd2;
    localparam [3:0] ACTION_RESET       = 4'd3;
    localparam [3:0] ACTION_BALANCE     = 4'd4;
    localparam [3:0] ACTION_MOVE_LEFT   = 4'd5;
    localparam [3:0] ACTION_MOVE_RIGHT  = 4'd6;

    localparam [1:0] REJECT_NONE      = 2'd0;
    localparam [1:0] REJECT_NO_TARGET = 2'd1;
    localparam [1:0] REJECT_ESTOP     = 2'd2;

    reg                     target_is_main;
    reg                     target_is_slave;
    reg                     target_is_both;
    reg                     action_recognized;
    reg [3:0]               decoded_action;
    reg [7:0]               decoded_angle;
    reg                     decoded_right;

    always @* begin
        target_is_main  = (command_word_id == 8'hB0);
        target_is_slave = (command_word_id == 8'hB1);
        target_is_both  = (command_word_id == 8'hB2);

        action_recognized = 1'b1;
        decoded_action     = ACTION_NONE;
        decoded_angle      = 8'd0;
        decoded_right      = 1'b0;

        // Move commands carry a relative angular increment. The full
        // controller applies it to the current base position on each side.
        if ((command_word_id >= 8'h81) &&
            (command_word_id <= 8'hA4)) begin
            decoded_action = ACTION_MOVE_LEFT;
            decoded_angle  = ((command_word_id - 8'h80) << 2) +
                             (command_word_id - 8'h80);
        end else if ((command_word_id >= 8'hC1) &&
                     (command_word_id <= 8'hE4)) begin
            decoded_action = ACTION_MOVE_RIGHT;
            decoded_angle  = ((command_word_id - 8'hC0) << 2) +
                             (command_word_id - 8'hC0);
            decoded_right  = 1'b1;
        end else begin
            case (command_word_id)
                8'h40, 8'hB3: decoded_action = ACTION_SWING_UP;
                8'h41: decoded_action = ACTION_ESTOP;
                8'h42: decoded_action = ACTION_RESET;
                8'h43: decoded_action = ACTION_BALANCE;
                default: action_recognized = 1'b0;
            endcase
        end
    end

    always @(posedge clk) begin
        if (!rst_n) begin
            target_changed      <= 1'b0;
            target_mask         <= 2'b00;
            target_timeout      <= 1'b0;
            command_valid       <= 1'b0;
            command_target_mask <= 2'b00;
            command_action      <= ACTION_NONE;
            command_id          <= 8'd0;
            command_angle       <= 8'd0;
            command_right       <= 1'b0;
            command_rejected    <= 1'b0;
            reject_reason       <= REJECT_NONE;
        end else begin
            target_changed   <= 1'b0;
            target_timeout   <= 1'b0;
            command_valid    <= 1'b0;
            command_rejected <= 1'b0;
            reject_reason    <= REJECT_NONE;

            if (command_word_valid && target_is_main) begin
                // Mode flag: 1=main, 2=slave, 3=both. Last selection wins.
                target_mask    <= TARGET_MAIN;
                target_changed <= 1'b1;
            end else if (command_word_valid && target_is_slave) begin
                target_mask    <= TARGET_SLAVE;
                target_changed <= 1'b1;
            end else if (command_word_valid && target_is_both) begin
                target_mask    <= TARGET_BOTH;
                target_changed <= 1'b1;
            end else if (command_word_valid && action_recognized) begin
                if ((decoded_action == ACTION_ESTOP) ||
                    (target_mask != 2'b00)) begin
                    command_valid       <= 1'b1;
                    command_target_mask <=
                        (decoded_action == ACTION_ESTOP) ?
                        TARGET_BOTH : target_mask;
                    command_action      <= decoded_action;
                    command_id          <= command_word_id;
                    command_angle       <= decoded_angle;
                    command_right       <= decoded_right;
                    // Actions (including stop/reset) do not consume the mode.
                end else begin
                    command_rejected <= 1'b1;
                    reject_reason    <= REJECT_NO_TARGET;
                end
            end
        end
    end

endmodule
