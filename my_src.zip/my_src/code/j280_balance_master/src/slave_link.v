`timescale 1ns/1ps
`include "control_config.vh"
// ============================================================================
// slave_link.v — 主机 FPGA → 从板 FPGA 的 UART v2 协议端到端链路
// ============================================================================
// 与 Project_two_board/Project_01 的 dual_board_coupling 相比，本模块从
// 「只发不收、按键触发、固定 +139 计数」升级为：
//   1) 完整命令编码：OP00 查询 / OP20-01 起摆 / OP20-02 急停 /
//      OP20-05 清远程急停 / OP30 绝对目标 / OP31 保持生效目标；
//   2) 解析 38 字节应答（5A A5 01 OP RESULT ... CHECK），做 XOR 校验；
//   3) 按命令类型判定「完成 / 失败」，未完成时自动用 OP00 轮询，
//      供 voice_dual_coordinator 的双摆结果汇总使用；
//   4) 相对角度以「当前生效目标」为基准累加，符合语音侧
//      「左右移动是相对当前位置的角度增量」的定义。
//
// 接线：主板 V8 (TX) → 从板 W7 (FPGA RX)
//       主板 V9 (RX) ← 从板 W8 (FPGA TX)
//       115200-8N1，共地，不接 VCC。
//
// 从板目标域：中心 10000、单侧行程 2150、1000 计数/圈（沿用双板 demo 标定）。
// 该比例在协议文档中未标定，故做成参数 SLAVE_COUNTS_PER_REV，便于实测修正。
//
// ---------------------------------------------------------------------------
// 2026-11-03 双摆扩展（HMI 2.1 从摆页）：
//   1) CMD_RAW：把 (OP, arg16) 原样打包成 A5 5A 01 OP AL AH CHK 发出去，
//      只等一帧校验正确的应答就结束——不做状态/权限判定，不产生 done/fail，
//      与语音路径完全隔离（语音的双摆结果汇总不会被 HMI 操作打断）。
//   2) CMD_POLL：空闲时每 TELEM_PERIOD_MS 发一帧 OP60 遥测查询，
//      解析 38 字节应答里的从摆数据（角度/角速度/目标/两路误差/状态/标志），
//      统计一次往返时间 RTT（µs），并给出链路在线标志。
//   3) 语音用的 OP20/OP30/OP31 语义与完成判据一个字没改。
// ============================================================================
module slave_link #(
    parameter integer CLK_HZ               = 50000000,
    parameter integer BAUD                 = 115200,
    parameter integer SLAVE_CENTER         = 10000,
    parameter integer SLAVE_TRAVEL         = 2150,
    parameter integer SLAVE_COUNTS_PER_REV = 1000,
    parameter integer REPLY_TIMEOUT_MS     = 60,
    parameter integer POLL_PERIOD_MS       = 20,
    parameter integer START_TIMEOUT_MS     = 18000,
    parameter integer MOVE_TIMEOUT_MS      = 12000,
    parameter integer SETTLE_TIMEOUT_MS    = 4000,
    parameter integer MOVE_TOLERANCE       = 12,
    // 双摆遥测：轮询周期、单次超时、链路判丢时间
    parameter integer TELEM_PERIOD_MS      = 100,
    parameter integer TELEM_TIMEOUT_MS     = 20,
    parameter integer LINK_LOST_MS         = 500
)(
    input  wire        clk,
    input  wire        rst_n,

    // ---- 到从板的 UART ----
    output wire        slave_tx,
    input  wire        slave_rx,

    // ---- 命令接口（单周期 cmd_valid 启动一条命令）----
    input  wire        cmd_valid,
    input  wire [2:0]  cmd_kind,
    input  wire [7:0]  cmd_arg,        // 相对角度（度），仅 CMD_MOVE 使用
    input  wire        cmd_right,      // 1=右移(+)，0=左移(-)
    // ---- CMD_RAW 透传（HMI 2.1 从摆页）：OP + 16 位参数，原样下发给从板 ----
    input  wire [7:0]  cmd_op,
    input  wire signed [15:0] cmd_arg16,

    // ---- 执行结果 ----
    output reg         busy,
    output reg         done_pulse,
    output reg         fail_pulse,
    output reg  [2:0]  fail_code,

    // ---- 从板最近一次有效应答（供遥测/调试）----
    output reg  [7:0]  rep_op,
    output reg  [7:0]  rep_result,
    output reg  [7:0]  rep_state,
    output reg  [7:0]  rep_fault,
    output reg  [7:0]  rep_flags,
    output reg  [15:0] rep_position,
    output reg  [15:0] rep_final,
    output reg  [15:0] rep_active,
    output reg  [15:0] target_shadow,
    output reg  [3:0]  fsm_state,

    // ---- 从摆遥测（OP60 应答解析，全部为有符号补码）----
    output reg signed [15:0] ts_theta,    // 摆角 0.01°
    output reg signed [15:0] ts_wdot,     // 摆角速度 0.1°/s
    output reg signed [15:0] ts_target,   // 从控已接受的摆角目标 0.01°
    output reg signed [15:0] ts_armerr,   // 横臂误差 0.01°
    output reg signed [15:0] ts_angerr,   // 摆角误差 0.01°
    output reg signed [15:0] ts_refang,   // 参考角 0.01°
    output reg        [7:0]  ts_state,    // 0待机 1起摆 2保持 3停止 4急停 5故障
    output reg        [7:0]  ts_flags,    // bit0=数据有效 bit1=允许手动 bit2=急停锁存
    output reg        [15:0] ts_rtt_us,   // 一次 命令→应答 的往返时间，µs
    output reg               ts_valid,    // 最近 LINK_LOST_MS 内收到过遥测
    output reg               ts_fresh     // 收到遥测的单周期脉冲
);

    // ------------------------------------------------------------------
    // 命令编码
    // ------------------------------------------------------------------
    localparam [2:0] CMD_QUERY = 3'd0;
    localparam [2:0] CMD_START = 3'd1;
    localparam [2:0] CMD_ESTOP = 3'd2;
    localparam [2:0] CMD_CLEAR = 3'd3;
    localparam [2:0] CMD_MOVE  = 3'd4;
    localparam [2:0] CMD_HOLD  = 3'd5;
    localparam [2:0] CMD_RAW   = 3'd6;   // HMI 从摆命令透传（OP+arg16）
    localparam [2:0] CMD_POLL  = 3'd7;   // 后台遥测轮询（OP60）

    // 失败原因
    localparam [2:0] FAIL_NONE     = 3'd0;
    localparam [2:0] FAIL_NOREPLY  = 3'd1;
    localparam [2:0] FAIL_PROTOCOL = 3'd2;
    localparam [2:0] FAIL_FAULT    = 3'd3;
    localparam [2:0] FAIL_TARGET   = 3'd4;
    localparam [2:0] FAIL_REFUSED  = 3'd5;

    // 从板运行状态（应答字节 7）
    localparam [7:0] ST_FAULT = 8'd4;
    localparam [7:0] ST_RUN   = 8'd3;

    // ------------------------------------------------------------------
    // 目标域与角度换算
    // ------------------------------------------------------------------
    localparam signed [17:0] TARGET_MIN = SLAVE_CENTER - SLAVE_TRAVEL;
    localparam signed [17:0] TARGET_MAX = SLAVE_CENTER + SLAVE_TRAVEL;

    // 度 → 从板计数：编译期常量乘法，避免运行时除法
    localparam [31:0] DEG_NUM = (SLAVE_COUNTS_PER_REV * 8192 + 180) / 360;

    function [15:0] deg_to_counts;
        input [7:0]  deg;
        reg   [31:0] product;
        begin
            product       = deg * DEG_NUM;
            deg_to_counts = product[31:13];
        end
    endfunction

    wire [15:0]        step_counts  = deg_to_counts(cmd_arg);
    wire signed [17:0] step_signed  = {2'b00, step_counts};
    wire signed [17:0] shadow_signed = target_shadow;
    wire signed [17:0] move_cand =
        cmd_right ? (shadow_signed + step_signed) : (shadow_signed - step_signed);
    wire [15:0] move_target =
        (move_cand < TARGET_MIN) ? TARGET_MIN[15:0] :
        (move_cand > TARGET_MAX) ? TARGET_MAX[15:0] :
        move_cand[15:0];
    wire [7:0] move_check = 8'h01 ^ 8'h30 ^ move_target[7:0] ^ move_target[15:8];

    // ---- 从摆 OP 表（HMI 2.1 从摆页 → 从板）----
    localparam [7:0] SOP_ACTION = 8'h20;   // ARG_L: 01起摆 / 02急停 / 05清急停
    localparam [7:0] SOP_ABS    = 8'h30;   // 计数域绝对目标（语音用，已有）
    localparam [7:0] SOP_HOLD   = 8'h31;   // 保持当前目标（语音用，已有）
    localparam [7:0] SOP_THETA  = 8'h32;   // 摆角目标 0.01°
    localparam [7:0] SOP_ARM    = 8'h33;   // 横臂目标 0.01°
    localparam [7:0] SOP_SPEED  = 8'h34;   // 速度上限 0~100
    localparam [7:0] SOP_HOME   = 8'h35;   // 回零
    localparam [7:0] SOP_SYNC   = 8'h38;   // 位置协同开关 0/1
    localparam [7:0] SOP_TELEM  = 8'h60;   // 遥测查询 / 应答

    wire signed [15:0] raw_src = cmd_arg16;
    wire [7:0] raw_check = 8'h01 ^ cmd_op ^ raw_src[7:0] ^ raw_src[15:8];

    // 新命令帧（cmd_valid 时锁存，字节 0 位于最高位）
    reg  [55:0] new_frame;
    reg  [3:0]  new_len;
    always @* begin
        new_frame = 56'h0;
        new_len   = 4'd6;
        case (cmd_kind)
            CMD_START: begin
                new_frame = {8'hA5, 8'h5A, 8'h01, 8'h20, 8'h01, 8'h20, 8'h00};
                new_len   = 4'd6;
            end
            CMD_ESTOP: begin
                new_frame = {8'hA5, 8'h5A, 8'h01, 8'h20, 8'h02, 8'h23, 8'h00};
                new_len   = 4'd6;
            end
            CMD_CLEAR: begin
                new_frame = {8'hA5, 8'h5A, 8'h01, 8'h20, 8'h05, 8'h24, 8'h00};
                new_len   = 4'd6;
            end
            CMD_HOLD: begin
                new_frame = {8'hA5, 8'h5A, 8'h01, 8'h31, 8'h00, 8'h30, 8'h00};
                new_len   = 4'd6;
            end
            CMD_MOVE: begin
                new_frame = {8'hA5, 8'h5A, 8'h01, 8'h30,
                             move_target[7:0], move_target[15:8], move_check};
                new_len   = 4'd7;
            end
            // HMI 从摆命令：A5 5A 01 OP AL AH CHK
            CMD_RAW: begin
                new_frame = {8'hA5, 8'h5A, 8'h01, cmd_op,
                             raw_src[7:0], raw_src[15:8], raw_check};
                new_len   = 4'd7;
            end
            // 后台遥测查询：A5 5A 01 60 00 00 61
            CMD_POLL: begin
                new_frame = {8'hA5, 8'h5A, 8'h01, 8'h60, 8'h00, 8'h00, 8'h61};
                new_len   = 4'd7;
            end
            default: begin
                new_frame = {8'hA5, 8'h5A, 8'h01, 8'h00, 8'h00, 8'h01, 8'h00};
                new_len   = 4'd6;
            end
        endcase
    end

    localparam [55:0] QUERY_FRAME = {8'hA5, 8'h5A, 8'h01, 8'h00, 8'h00, 8'h01, 8'h00};
    localparam [55:0] POLL_FRAME  = {8'hA5, 8'h5A, 8'h01, 8'h60, 8'h00, 8'h00, 8'h61};

    // ------------------------------------------------------------------
    // UART
    // ------------------------------------------------------------------
    wire       tx_busy, tx_done;
    reg        tx_start;
    reg  [7:0] tx_data;
    serial_tx #(.CLK_HZ(CLK_HZ), .BAUD(BAUD)) u_slave_tx (
        .clk(clk), .rst_n(rst_n), .start(tx_start), .data(tx_data),
        .tx(slave_tx), .busy(tx_busy), .done(tx_done)
    );

    wire       rx_valid, rx_ferr;
    wire [7:0] rx_data;
    serial_rx #(.CLK_HZ(CLK_HZ), .BAUD(BAUD)) u_slave_rx (
        .clk(clk), .rst_n(rst_n), .rx(slave_rx),
        .data(rx_data), .valid(rx_valid), .framing_error(rx_ferr)
    );

    // ------------------------------------------------------------------
    // 毫秒时基
    // ------------------------------------------------------------------
    localparam integer MS_DIV = CLK_HZ / 1000;
    reg  [15:0] ms_div;
    wire        ms_tick = (ms_div == MS_DIV - 1);
    always @(posedge clk or negedge rst_n)
        if (!rst_n)        ms_div <= 16'd0;
        else if (ms_tick)  ms_div <= 16'd0;
        else               ms_div <= ms_div + 1'b1;

    // ------------------------------------------------------------------
    // 状态机
    // ------------------------------------------------------------------
    localparam [3:0] S_IDLE     = 4'd0;
    localparam [3:0] S_SEND     = 4'd1;
    localparam [3:0] S_REPLY    = 4'd2;
    localparam [3:0] S_EVAL     = 4'd3;
    localparam [3:0] S_POLLWAIT = 4'd4;
    localparam [3:0] S_FINISH   = 4'd5;

    reg  [3:0]  state;
    reg  [2:0]  kind_l;        // 用户命令类型（全程保持不变）
    reg  [2:0]  q_kind;        // 当前在途帧的类型（轮询时变为 CMD_QUERY）
    reg  [55:0] cmd_frame;     // 用户命令原始帧（重发用）
    reg  [3:0]  cmd_len;
    reg  [55:0] frame;         // 在途帧
    reg  [3:0]  frame_len;
    reg  [3:0]  tx_idx;
    reg  [5:0]  rx_idx;
    reg  [7:0]  xacc;
    reg         retried;
    reg         reply_good;    // 粘滞：本次在途帧收到了校验通过的应答

    reg  [15:0] reply_timer;
    reg  [15:0] poll_timer;
    reg  [15:0] total_timer;
    reg  [15:0] timeout_limit;
    reg  [15:0] telem_timer;      // 距上次遥测轮询的毫秒数
    reg  [15:0] link_timer;       // 距上次有效遥测的毫秒数

    // µs 时基，用于 RTT
    localparam integer US_DIV = (CLK_HZ >= 1000000) ? (CLK_HZ/1000000) : 1;
    reg  [7:0]  us_div;
    reg  [15:0] us_cnt;
    reg  [15:0] us_sent;
    wire        us_pulse = (us_div == US_DIV-1);

    // 应答字段暂存
    reg  [7:0] b_op, b_result, b_state, b_fault, b_flags;
    reg  [7:0] b_pos_l, b_pos_h, b_fin_l, b_fin_h, b_act_l, b_act_h;
    // OP60 遥测字段暂存
    reg  [7:0] t_state, t_flags;
    reg  [7:0] t_th_l, t_th_h, t_wd_l, t_wd_h;
    reg  [7:0] t_tg_l, t_tg_h, t_ae_l, t_ae_h;
    reg  [7:0] t_ge_l, t_ge_h, t_rf_l, t_rf_h;

    reg  [7:0] op_l;              // CMD_RAW 在途 OP

    wire [15:0] b_position = {b_pos_h, b_pos_l};
    wire [15:0] b_final    = {b_fin_h, b_fin_l};
    wire [15:0] b_active   = {b_act_h, b_act_l};
    wire [15:0] pos_error  = (b_position > b_final) ? (b_position - b_final)
                                                    : (b_final - b_position);

    // 在途帧对应的协议 OP 字节
    reg  [7:0] expect_op;
    always @* begin
        case (q_kind)
            CMD_MOVE: expect_op = 8'h30;
            CMD_HOLD: expect_op = 8'h31;
            CMD_QUERY: expect_op = 8'h00;
            CMD_RAW:  expect_op = op_l;
            CMD_POLL: expect_op = SOP_TELEM;
            default:  expect_op = 8'h20;   // START / ESTOP / CLEAR
        endcase
    end

    // ------------------------------------------------------------------
    // 完成判定（组合）
    // ------------------------------------------------------------------
    reg  finish_done;
    reg  finish_fail;
    reg  [2:0] finish_code;
    reg  pending;

    always @* begin
        finish_done = 1'b0;
        finish_fail = 1'b0;
        finish_code = FAIL_NONE;
        pending     = 1'b0;

        if (!reply_good) begin
            finish_fail = 1'b1;
            finish_code = FAIL_NOREPLY;
        end else if (b_op != expect_op) begin
            finish_fail = 1'b1;
            finish_code = FAIL_PROTOCOL;
        end else begin
            case (kind_l)
                CMD_QUERY: finish_done = 1'b1;

                CMD_START: begin
                    if (b_fault != 8'd0 || b_state == ST_FAULT) begin
                        finish_fail = 1'b1;
                        finish_code = FAIL_FAULT;
                    end else if (b_state == ST_RUN)
                        finish_done = 1'b1;
                    else if (b_result != 8'd0) begin
                        finish_fail = 1'b1;
                        finish_code = FAIL_REFUSED;
                    end else
                        pending = 1'b1;
                end

                CMD_ESTOP: begin
                    if (b_result == 8'd0 || b_fault == 8'd4)
                        finish_done = 1'b1;
                    else begin
                        finish_fail = 1'b1;
                        finish_code = FAIL_REFUSED;
                    end
                end

                CMD_CLEAR: begin
                    if (b_result != 8'd0) begin
                        finish_fail = 1'b1;
                        finish_code = FAIL_REFUSED;
                    end else if (b_flags[2])
                        pending = 1'b1;      // 远程急停锁存尚未清除
                    else
                        finish_done = 1'b1;
                end

                CMD_HOLD: begin
                    if (b_result == 8'd0)
                        finish_done = 1'b1;
                    else begin
                        finish_fail = 1'b1;
                        finish_code = FAIL_REFUSED;
                    end
                end

                default: begin   // CMD_MOVE（OP30 绝对目标）
                    if (b_fault != 8'd0 || b_state == ST_FAULT) begin
                        finish_fail = 1'b1;
                        finish_code = FAIL_FAULT;
                    end else if (pos_error <= MOVE_TOLERANCE && b_active == b_final)
                        finish_done = 1'b1;
                    else
                        pending = 1'b1;
                end
            endcase
        end
    end

    // ------------------------------------------------------------------
    // 主时序
    // ------------------------------------------------------------------
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state         <= S_IDLE;
            kind_l        <= CMD_QUERY;
            q_kind        <= CMD_QUERY;
            cmd_frame     <= QUERY_FRAME;
            cmd_len       <= 4'd6;
            frame         <= QUERY_FRAME;
            frame_len     <= 4'd6;
            tx_idx        <= 4'd0;
            rx_idx        <= 6'd0;
            xacc          <= 8'h01;
            retried       <= 1'b0;
            reply_good    <= 1'b0;
            reply_timer   <= 16'd0;
            poll_timer    <= 16'd0;
            total_timer   <= 16'd0;
            timeout_limit <= SETTLE_TIMEOUT_MS;
            busy          <= 1'b0;
            done_pulse    <= 1'b0;
            fail_pulse    <= 1'b0;
            fail_code     <= FAIL_NONE;
            rep_op        <= 8'h00;
            rep_result    <= 8'd0;
            rep_state     <= 8'd0;
            rep_fault     <= 8'd0;
            rep_flags     <= 8'd0;
            rep_position  <= 16'd0;
            rep_final     <= 16'd0;
            rep_active    <= 16'd0;
            target_shadow <= SLAVE_CENTER;
            fsm_state     <= S_IDLE;
            tx_start      <= 1'b0;
            tx_data       <= 8'd0;
            b_op          <= 8'd0;
            b_result      <= 8'd0;
            b_state       <= 8'd0;
            b_fault       <= 8'd0;
            b_flags       <= 8'd0;
            b_pos_l       <= 8'd0;
            b_pos_h       <= 8'd0;
            b_fin_l       <= 8'd0;
            b_fin_h       <= 8'd0;
            b_act_l       <= 8'd0;
            b_act_h       <= 8'd0;
            // 双摆遥测
            telem_timer   <= 16'd0;
            link_timer    <= 16'hFFFF;
            us_div        <= 8'd0;
            us_cnt        <= 16'd0;
            us_sent       <= 16'd0;
            op_l          <= 8'h00;
            t_state       <= 8'd0;
            t_flags       <= 8'd0;
            t_th_l        <= 8'd0; t_th_h <= 8'd0;
            t_wd_l        <= 8'd0; t_wd_h <= 8'd0;
            t_tg_l        <= 8'd0; t_tg_h <= 8'd0;
            t_ae_l        <= 8'd0; t_ae_h <= 8'd0;
            t_ge_l        <= 8'd0; t_ge_h <= 8'd0;
            t_rf_l        <= 8'd0; t_rf_h <= 8'd0;
            ts_theta      <= 16'sd0;
            ts_wdot       <= 16'sd0;
            ts_target     <= 16'sd0;
            ts_armerr     <= 16'sd0;
            ts_angerr     <= 16'sd0;
            ts_refang     <= 16'sd0;
            ts_state      <= 8'd0;
            ts_flags      <= 8'd0;
            ts_rtt_us     <= 16'd0;
            ts_valid      <= 1'b0;
            ts_fresh      <= 1'b0;
        end else begin
            done_pulse <= 1'b0;
            fail_pulse <= 1'b0;
            tx_start   <= 1'b0;
            ts_fresh   <= 1'b0;
            fsm_state  <= state;

            // µs 时基（RTT 用，16 位循环）
            if (us_pulse) begin
                us_div <= 8'd0;
                us_cnt <= us_cnt + 1'b1;
            end else begin
                us_div <= us_div + 1'b1;
            end

            if (ms_tick) begin
                if (reply_timer != 16'hFFFF) reply_timer <= reply_timer + 1'b1;
                if (poll_timer  != 16'hFFFF) poll_timer  <= poll_timer  + 1'b1;
                if (total_timer != 16'hFFFF) total_timer <= total_timer + 1'b1;
                if (telem_timer != 16'hFFFF) telem_timer <= telem_timer + 1'b1;
                if (link_timer  != 16'hFFFF) link_timer  <= link_timer  + 1'b1;
            end
            // 链路判丢：超过 LINK_LOST_MS 没有有效遥测
            if (link_timer >= LINK_LOST_MS) ts_valid <= 1'b0;

            case (state)

                // ------------------------------------------------------
                S_IDLE: begin
                    busy <= 1'b0;
                    if (cmd_valid) begin
                        kind_l      <= cmd_kind;
                        q_kind      <= cmd_kind;
                        op_l        <= cmd_op;
                        cmd_frame   <= new_frame;
                        cmd_len     <= new_len;
                        frame       <= new_frame;
                        frame_len   <= new_len;
                        tx_idx      <= 4'd0;
                        retried     <= 1'b0;
                        reply_good  <= 1'b0;
                        total_timer <= 16'd0;
                        poll_timer  <= 16'd0;
                        busy        <= 1'b1;
                        if (cmd_kind == CMD_MOVE) target_shadow <= move_target;
                        timeout_limit <= (cmd_kind == CMD_START) ? START_TIMEOUT_MS :
                                         (cmd_kind == CMD_MOVE)  ? MOVE_TIMEOUT_MS  :
                                         (cmd_kind == CMD_POLL)  ? TELEM_TIMEOUT_MS :
                                         SETTLE_TIMEOUT_MS;
                        state <= S_SEND;
                    end else if (telem_timer >= TELEM_PERIOD_MS) begin
                        // 后台遥测轮询：只查状态，不动任何控制量。
                        telem_timer <= 16'd0;
                        kind_l      <= CMD_POLL;
                        q_kind      <= CMD_POLL;
                        cmd_frame   <= POLL_FRAME;
                        cmd_len     <= 4'd7;
                        frame       <= POLL_FRAME;
                        frame_len   <= 4'd7;
                        tx_idx      <= 4'd0;
                        retried     <= 1'b1;      // 轮询失败不重发，等下一个周期
                        reply_good  <= 1'b0;
                        total_timer <= 16'd0;
                        poll_timer  <= 16'd0;
                        timeout_limit <= TELEM_TIMEOUT_MS;
                        busy        <= 1'b1;
                        state       <= S_SEND;
                    end
                end

                // ------------------------------------------------------
                S_SEND: begin
                    if (tx_done) begin
                        if (tx_idx == frame_len - 1'b1) begin
                            reply_timer <= 16'd0;
                            rx_idx      <= 6'd0;
                            xacc        <= 8'h01;      // 应答字节2 固定 0x01
                            reply_good  <= 1'b0;
                            us_sent     <= us_cnt;     // RTT 起点
                            state       <= S_REPLY;
                        end else begin
                            tx_idx <= tx_idx + 1'b1;
                        end
                    end else if (!tx_busy && !tx_start) begin
                        tx_data  <= frame[8*(6 - tx_idx) +: 8];
                        tx_start <= 1'b1;
                    end
                end

                // ------------------------------------------------------
                S_REPLY: begin
                    if (rx_valid) begin
                        case (rx_idx)
                            6'd0: begin
                                if (rx_data == 8'h5A) rx_idx <= 6'd1;
                            end
                            6'd1: rx_idx <= (rx_data == 8'hA5) ? 6'd2 :
                                            (rx_data == 8'h5A) ? 6'd1 : 6'd0;
                            6'd2: rx_idx <= (rx_data == 8'h01) ? 6'd3 :
                                            (rx_data == 8'h5A) ? 6'd1 : 6'd0;
                            default: begin
                                if (rx_idx <= 6'd36) xacc <= xacc ^ rx_data;
                                case (rx_idx)
                                    6'd3:  b_op     <= rx_data;
                                    6'd4:  b_result <= rx_data;
                                    6'd5:  t_state  <= rx_data;   // OP60：从摆状态
                                    6'd6:  t_flags  <= rx_data;   // OP60：有效/许可/急停
                                    6'd7:  begin b_state <= rx_data; t_th_l <= rx_data; end
                                    6'd8:  begin b_fault <= rx_data; t_th_h <= rx_data; end
                                    6'd9:  begin b_flags <= rx_data; t_wd_l <= rx_data; end
                                    6'd10: t_wd_h  <= rx_data;
                                    6'd11: t_tg_l  <= rx_data;
                                    6'd12: t_tg_h  <= rx_data;
                                    6'd13: t_ae_l  <= rx_data;
                                    6'd14: t_ae_h  <= rx_data;
                                    6'd15: t_ge_l  <= rx_data;
                                    6'd16: t_ge_h  <= rx_data;
                                    6'd17: t_rf_l  <= rx_data;
                                    6'd18: t_rf_h  <= rx_data;
                                    6'd19: b_pos_l  <= rx_data;
                                    6'd20: b_pos_h  <= rx_data;
                                    6'd23: b_fin_l  <= rx_data;
                                    6'd24: b_fin_h  <= rx_data;
                                    6'd25: b_act_l  <= rx_data;
                                    6'd26: b_act_h  <= rx_data;
                                    default: ;
                                endcase

                                if (rx_idx == 6'd37) begin
                                    rx_idx <= 6'd0;
                                    if ((xacc ^ rx_data) == 8'h00) begin
                                        reply_good    <= 1'b1;
                                        rep_op        <= b_op;
                                        rep_result    <= b_result;
                                        rep_state     <= b_state;
                                        rep_fault     <= b_fault;
                                        rep_flags     <= b_flags;
                                        rep_position  <= {b_pos_h, b_pos_l};
                                        rep_final     <= {b_fin_h, b_fin_l};
                                        rep_active    <= {b_act_h, b_act_l};
                                        target_shadow <= {b_act_h, b_act_l};
                                        // OP60 遥测应答：整帧校验通过后一次性更新
                                        if (b_op == SOP_TELEM) begin
                                            ts_state  <= t_state;
                                            ts_flags  <= t_flags;
                                            ts_theta  <= {t_th_h, t_th_l};
                                            ts_wdot   <= {t_wd_h, t_wd_l};
                                            ts_target <= {t_tg_h, t_tg_l};
                                            ts_armerr <= {t_ae_h, t_ae_l};
                                            ts_angerr <= {t_ge_h, t_ge_l};
                                            ts_refang <= {t_rf_h, t_rf_l};
                                            ts_rtt_us <= us_cnt - us_sent;
                                            ts_valid  <= 1'b1;
                                            ts_fresh  <= 1'b1;
                                            link_timer<= 16'd0;
                                        end
                                    end
                                    state <= S_EVAL;
                                end else begin
                                    rx_idx <= rx_idx + 1'b1;
                                end
                            end
                        endcase
                    end else if (reply_timer >= ((q_kind == CMD_POLL) ? TELEM_TIMEOUT_MS : REPLY_TIMEOUT_MS)) begin
                        reply_good <= 1'b0;
                        state      <= S_EVAL;
                    end
                end

                // ------------------------------------------------------
                S_EVAL: begin
                    reply_timer <= 16'd0;

                    if (kind_l == CMD_POLL) begin
                        // 遥测轮询：成功与否都不上报，不产生 done/fail 脉冲。
                        busy      <= 1'b0;
                        fail_code <= reply_good ? FAIL_NONE : FAIL_NOREPLY;
                        state     <= S_FINISH;
                    end else if (kind_l == CMD_RAW) begin
                        // HMI 从摆命令：只确认"从板回了一帧"，不判定接受/拒绝。
                        busy <= 1'b0;
                        if (!reply_good && !retried) begin
                            retried   <= 1'b1;
                            frame     <= cmd_frame;
                            frame_len <= cmd_len;
                            q_kind    <= kind_l;
                            tx_idx    <= 4'd0;
                            state     <= S_SEND;
                        end else begin
                            fail_code <= reply_good ? FAIL_NONE : FAIL_NOREPLY;
                            state     <= S_FINISH;
                        end
                    end else if (finish_done) begin
                        busy       <= 1'b0;
                        done_pulse <= 1'b1;
                        fail_code  <= FAIL_NONE;
                        state      <= S_FINISH;
                    end else if (finish_fail) begin
                        // 无应答允许原帧重发一次
                        if (!reply_good && !retried) begin
                            retried     <= 1'b1;
                            frame       <= cmd_frame;
                            frame_len   <= cmd_len;
                            q_kind      <= kind_l;
                            tx_idx      <= 4'd0;
                            state       <= S_SEND;
                        end else begin
                            busy       <= 1'b0;
                            fail_pulse <= 1'b1;
                            fail_code  <= finish_code;
                            state      <= S_FINISH;
                        end
                    end else if (pending) begin
                        if (total_timer >= timeout_limit) begin
                            busy       <= 1'b0;
                            fail_pulse <= 1'b1;
                            fail_code  <= (kind_l == CMD_START) ? FAIL_FAULT : FAIL_TARGET;
                            state      <= S_FINISH;
                        end else begin
                            poll_timer <= 16'd0;
                            state      <= S_POLLWAIT;
                        end
                    end else begin
                        busy       <= 1'b0;
                        fail_pulse <= 1'b1;
                        fail_code  <= FAIL_PROTOCOL;
                        state      <= S_FINISH;
                    end
                end

                // ------------------------------------------------------
                S_POLLWAIT: begin
                    if (poll_timer >= POLL_PERIOD_MS) begin
                        frame     <= QUERY_FRAME;
                        frame_len <= 4'd6;
                        q_kind    <= CMD_QUERY;
                        tx_idx    <= 4'd0;
                        state     <= S_SEND;
                    end
                end

                // ------------------------------------------------------
                S_FINISH: begin
                    busy  <= 1'b0;
                    state <= S_IDLE;
                end

                default: state <= S_IDLE;

            endcase
        end
    end

endmodule
