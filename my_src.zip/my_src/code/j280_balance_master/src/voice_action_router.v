`timescale 1ns/1ps
`include "control_config.vh"
// ============================================================================
// voice_action_router.v — 语音「主摆」动作 → 主控板本地动作
// ============================================================================
// voice_dual_coordinator 把一次语音命令拆成 local / remote 两路。本模块负责
// local 一路：
//   动作 1 起摆       → remote_start 脉冲（与 SW1 / 串口屏「起摆」同一条路径）
//   动作 2 急停       → external_stop 脉冲（与串口屏「停止」同一条路径）
//   动作 3 复位       → remote_reset 脉冲（重新标定）
//   动作 4 开始平衡   → remote_start 脉冲
//   动作 5 左移 N°    → run_target 绝对目标（当前参考 − N°）
//   动作 6 右移 N°    → run_target 绝对目标（当前参考 + N°）
//
// 同时产生 local_done / local_fail 供双摆结果汇总使用：
//   起摆/平衡：进入 state==3（RUN 平衡）为完成，故障或超时为失败
//   复位     ：重新回到 state==2 且已标定为完成
//   急停     ：立即完成（停机由监督器在下一拍生效）
//   左移/右移：参考追到新目标为完成，超时为失败
//
// 移动量为相对当前生效参考的角度增量，单位度，Q16 弧度定标 1144/度。
// ============================================================================
module voice_action_router #(
    parameter integer CLK_HZ     = 50000000,
    parameter integer TIMEOUT_MS = 20000
)(
    input  wire        clk,
    input  wire        rst_n,

    // ---- 来自 voice_dual_coordinator 的本地命令 ----
    input  wire        local_cmd_valid,
    input  wire [3:0]  local_action,
    input  wire [7:0]  local_angle,
    input  wire        local_right,

    // ---- 主控板当前状态 ----
    input  wire [2:0]        state,
    input  wire              calibrated,
    input  wire              feedback_ready,
    input  wire              moving,
    input  wire signed [31:0] arm_reference_q16,

    // ---- 到 control_supervisor ----
    output reg         v_start,
    output reg         v_reset,
    output reg         v_stop,

    // ---- 到 run_target（与串口屏目标共用入口）----
    output reg         v_target_valid,
    output reg signed [31:0] v_target_q16,

    // ---- 返回 voice_dual_coordinator ----
    output reg         local_done,
    output reg         local_fail
);

    localparam [3:0] A_SWING_UP   = 4'd1;
    localparam [3:0] A_ESTOP      = 4'd2;
    localparam [3:0] A_RESET      = 4'd3;
    localparam [3:0] A_BALANCE    = 4'd4;
    localparam [3:0] A_MOVE_LEFT  = 4'd5;
    localparam [3:0] A_MOVE_RIGHT = 4'd6;

    // Q16 弧度：1° = 1144，330° 上限给 ±360° 硬保护留 30°
    localparam signed [31:0] Q16_PER_DEG  = 32'sd1144;
    localparam signed [31:0] REF_LIMIT    = 32'sd377520;   // 330°
    localparam signed [31:0] REF_TOLERANCE = 32'sd572;     // 0.5°

    localparam [2:0] S_IDLE   = 3'd0;
    localparam [2:0] S_ACTIVE = 3'd1;

    localparam integer MS_DIV = CLK_HZ / 1000;

    // 命令发出后先经过 S_ISSUED：下一拍监督器/run_target 消费脉冲，
    // 再下一拍 S_ACTIVE 读取更新后的反馈，避免采到旧 RUN/FAULT。
    // 只需寄存器握手，不再固定等待 200ms。
    localparam [2:0] S_ISSUED = 3'd2;

    reg [2:0]  fsm;
    reg [3:0]  act_l;
    reg signed [31:0] tgt_l;
    reg [15:0] ms_div;
    reg [15:0] elapsed_ms;

    wire        ms_tick = (ms_div == MS_DIV - 1);

    // 角度增量 → Q16（编译期常量乘法，无运行时除法）
    wire signed [31:0] delta_q16 = local_angle * Q16_PER_DEG;

    wire signed [32:0] cand_right = $signed({arm_reference_q16[31], arm_reference_q16}) + delta_q16;
    wire signed [32:0] cand_left  = $signed({arm_reference_q16[31], arm_reference_q16}) - delta_q16;
    wire signed [32:0] cand_q16   = local_right ? cand_right : cand_left;

    wire signed [31:0] cand_limited =
        (cand_q16 > REF_LIMIT)  ? REF_LIMIT  :
        (cand_q16 < -REF_LIMIT) ? -REF_LIMIT : cand_q16[31:0];

    // 参考误差绝对值
    wire signed [32:0] ref_diff = $signed({arm_reference_q16[31], arm_reference_q16}) - tgt_l;
    wire signed [32:0] ref_abs  = (ref_diff < 0) ? -ref_diff : ref_diff;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            fsm            <= S_IDLE;
            act_l          <= 4'd0;
            tgt_l          <= 32'sd0;
            ms_div         <= 16'd0;
            elapsed_ms     <= 16'd0;
            v_start        <= 1'b0;
            v_reset        <= 1'b0;
            v_stop         <= 1'b0;
            v_target_valid <= 1'b0;
            v_target_q16   <= 32'sd0;
            local_done     <= 1'b0;
            local_fail     <= 1'b0;
        end else begin
            // 输出默认值：全部是单周期脉冲
            v_start        <= 1'b0;
            v_reset        <= 1'b0;
            v_stop         <= 1'b0;
            v_target_valid <= 1'b0;
            local_done     <= 1'b0;
            local_fail     <= 1'b0;

            if (ms_tick) begin
                ms_div <= 16'd0;
                if (fsm == S_ACTIVE && elapsed_ms != 16'hFFFF)
                    elapsed_ms <= elapsed_ms + 1'b1;
            end else begin
                ms_div <= ms_div + 1'b1;
            end

            // ---------------- 新命令 ----------------
            if (local_cmd_valid) begin
                case (local_action)

                    A_ESTOP: begin
                        // 急停立即生效，不占用协调器等待窗口
                        v_stop     <= 1'b1;
                        local_done <= 1'b1;
                        fsm        <= S_IDLE;
                    end

                    A_SWING_UP, A_BALANCE: begin
                        v_start    <= 1'b1;
                        act_l      <= local_action;
                        elapsed_ms <= 16'd0;
                        fsm        <= S_ISSUED;
                    end

                    A_RESET: begin
                        v_reset    <= 1'b1;
                        act_l      <= local_action;
                        elapsed_ms <= 16'd0;
                        fsm        <= S_ISSUED;
                    end

                    A_MOVE_LEFT, A_MOVE_RIGHT: begin
                        if (!feedback_ready || !calibrated) begin
                            // 未标定时 run_target 的 clear 会把目标每拍清掉，
                            // 移动根本不会发生；直接判失败，不要空等 20s。
                            local_fail <= 1'b1;
                            fsm        <= S_IDLE;
                        end else begin
                            tgt_l          <= cand_limited;
                            v_target_q16   <= cand_limited;
                            v_target_valid <= 1'b1;
                            act_l          <= local_action;
                            elapsed_ms     <= 16'd0;
                            fsm            <= S_ISSUED;
                        end
                    end

                    default: begin
                        local_fail <= 1'b1;
                        fsm        <= S_IDLE;
                    end
                endcase
            end

            // ---------------- 在途命令的完成判定 ----------------
            // 新命令优先，尤其急停不能被上一条命令的完成/超时覆盖。
            if (!local_cmd_valid && fsm == S_ISSUED)
                fsm <= S_ACTIVE;
            if (!local_cmd_valid && fsm == S_ACTIVE) begin
                case (act_l)
                    A_SWING_UP, A_BALANCE: begin
                        if (state == 3'd4) begin
                            local_fail <= 1'b1;
                            fsm        <= S_IDLE;
                        end else if (state == 3'd3) begin
                            local_done <= 1'b1;
                            fsm        <= S_IDLE;
                        end
                    end

                    A_RESET: begin
                        if (state == 3'd4) begin
                            local_fail <= 1'b1;
                            fsm        <= S_IDLE;
                        end else if (state == 3'd2 && calibrated) begin
                            local_done <= 1'b1;
                            fsm        <= S_IDLE;
                        end
                    end

                    A_MOVE_LEFT, A_MOVE_RIGHT: begin
                        if (!moving && ref_abs <= REF_TOLERANCE) begin
                            local_done <= 1'b1;
                            fsm        <= S_IDLE;
                        end
                    end

                    default: begin
                        local_fail <= 1'b1;
                        fsm        <= S_IDLE;
                    end
                endcase

                if (fsm == S_ACTIVE && elapsed_ms >= TIMEOUT_MS) begin
                    local_fail <= 1'b1;
                    fsm        <= S_IDLE;
                end
            end
        end
    end

endmodule
