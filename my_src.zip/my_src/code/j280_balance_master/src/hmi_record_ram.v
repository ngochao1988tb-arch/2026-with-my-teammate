`timescale 1ns/1ps
// 21 int32 fields x 1024 samples. Explicit GW2A 1024x16 BSRAM slices.
module hmi_record_ram #(parameter DEPTH=1024,parameter AW=$clog2(DEPTH))(
 input clk,write_enable,input [AW-1:0] write_address,read_address,
 input [671:0] write_data,output [671:0] read_data);
`ifdef __ICARUS__
 reg [671:0] mem[0:DEPTH-1];reg [671:0] read_reg;
 assign read_data=read_reg;
 always @(posedge clk) begin
  if(write_enable) mem[write_address]<=write_data;
  read_reg<=mem[read_address];
 end
`else
 wire [9:0] wa=write_address,ra=read_address;
 genvar i;
 generate for(i=0;i<42;i=i+1) begin:bank
  DPB #(.BIT_WIDTH_0(16),.BIT_WIDTH_1(16),.READ_MODE0(1'b0),.READ_MODE1(1'b0),
        .WRITE_MODE0(2'b00),.WRITE_MODE1(2'b00),.BLK_SEL_0(3'b000),.BLK_SEL_1(3'b000),.RESET_MODE("SYNC")) ram(
   .CLKA(clk),.CLKB(clk),.CEA(write_enable),.CEB(1'b1),.OCEA(1'b1),.OCEB(1'b1),
   .WREA(write_enable),.WREB(1'b0),.RESETA(1'b0),.RESETB(1'b0),
   .BLKSELA(3'b000),.BLKSELB(3'b000),.ADA({wa,4'b0}),.ADB({ra,4'b0}),
   .DIA(write_data[i*16+:16]),.DIB(16'd0),.DOA(),.DOB(read_data[i*16+:16]));
 end endgenerate
`endif
endmodule
