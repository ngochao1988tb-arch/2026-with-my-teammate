// =============================================================================
// lcd8080.v  --  类 FSMC 的 8080 并口显示控制器
//
// 结构：CPU 总线从口（picorv32 原生存储接口） + 绝对周期计时器。
//      CPU 一次访问 = 一次 8080 总线周期；外设用 done 回握手（阻塞式）。
//      所有时序单位都是 clk 周期（50 MHz 下 1 周期 = 20 ns）。
//
// 访问窗口（RS 由地址决定）：
//   0x00 LCD_CMD  : 访问时 RS=0（写=命令，读=RS=0 的数据）
//   0x04 LCD_DATA : 访问时 RS=1（写=像素/参数，读=RS=1 的数据）
//
// 一次访问的时间线（cyc 从 CS 拉低那一拍开始计 0）：
//
//   cyc = 0                          CS↓  RS 有效
//   cyc = T_AS + T_TURN              DATA 驱动（仅写）        <-- 地址/RS 建立
//   cyc = T_AS + T_TURN + T_DS       WR↓ 或 RD↓              <-- 数据建立
//   cyc = 上值 + T_PW                WR↑ 或 RD↑（读在此前采样）<-- 有效脉宽
//   cyc = 上值 + T_DH                CS↑（数据保持结束）      <-- 数据保持
//   cyc = 上值 + T_IDLE              done（访问结束）
//
//   即：t_CS→WR   = T_AS + T_TURN + T_DS
//       t_DATA→WR = T_DS + T_TURN
//       WR 低电平 = T_PW
//       WR↑→CS↑  = T_DH
//       CS 间隔   = T_IDLE
//       访问总长  = T_AS + T_TURN + T_DS + T_PW + T_DH + T_IDLE + 1
//
// 关键约定：
//   1) 双向数据总线在这里只做 data_o / data_oe / data_i 三分，三态只在顶层。
//   2) 复位期间 CS_N/WR_N/RD_N 全为 1，RS=0，data_oe=0（高阻）。
//   3) 访问方向与上次不同时，在 T_AS 之后额外插入 T_TURN 再驱动数据/拉低选通。
//   4) 16 位模式下按字节通道（wstrb）合并写数据，支持 sb/sh/sw 混用。
//   5) 未使能 / 只写模式读 / 未映射地址都不会挂死总线：立即完成并置错误位。
//   6) 单次访问有看门狗，超时强制完成并置 ERR_TIMEOUT。
//   7) 本版本不含发送 FIFO：FIFO_STAT 恒读 0x1（空、未满）。
// =============================================================================
`timescale 1ns/1ps
`include "lcd_config.vh"

module lcd8080 #(
    parameter integer DATA_WIDTH = `CFG_LCD_DATA_WIDTH,
    parameter integer TIMEOUT    = `CFG_LCD_TIMEOUT_CYCLES
)(
    input  wire                clk,
    input  wire                rst_n,

    // ---------------- CPU 侧 ----------------
    input  wire                cs,      // 选中脉冲（1 周期）
    input  wire                we,      // 1=写 0=读
    input  wire [7:0]          addr,    // 字节偏移
    input  wire [31:0]         wdata,
    input  wire [3:0]          wstrb,
    output reg  [31:0]         rdata,
    output reg                 done,    // 访问完成脉冲（1 周期）

    // ---------------- LCD 物理侧 ----------------
    output wire                lcd_cs_n,
    output wire                lcd_wr_n,
    output wire                lcd_rd_n,
    output reg                 lcd_rs,
    output wire                lcd_reset_n,
    output wire [DATA_WIDTH-1:0] lcd_data_o,
    output wire                lcd_data_oe,
    input  wire [DATA_WIDTH-1:0] lcd_data_i,
    output wire                lcd_bl
);

    // ------------------------------------------------------------------
    // 寄存器地址
    // ------------------------------------------------------------------
    localparam [7:0] R_CMD   = `CFG_LCD_REG_CMD;
    localparam [7:0] R_DATA  = `CFG_LCD_REG_DATA;
    localparam [7:0] R_CTRL  = `CFG_LCD_REG_CTRL;
    localparam [7:0] R_STAT  = `CFG_LCD_REG_STATUS;
    localparam [7:0] R_TAS   = `CFG_LCD_REG_T_AS;
    localparam [7:0] R_TDS   = `CFG_LCD_REG_T_DS;
    localparam [7:0] R_TPW   = `CFG_LCD_REG_T_PW;
    localparam [7:0] R_TDH   = `CFG_LCD_REG_T_DH;
    localparam [7:0] R_TIDLE = `CFG_LCD_REG_T_IDLE;
    localparam [7:0] R_TTURN = `CFG_LCD_REG_T_TURN;
    localparam [7:0] R_FIFO  = `CFG_LCD_REG_FIFO_STAT;
    localparam [7:0] R_ECLR  = `CFG_LCD_REG_ERR_CLR;
    localparam [7:0] R_ID    = `CFG_LCD_REG_ID;
    localparam [7:0] R_WCNT  = `CFG_LCD_REG_WR_CNT;
    localparam [7:0] R_LCYC  = `CFG_LCD_REG_LAST_CYC;
    localparam [7:0] R_VER   = `CFG_LCD_REG_VER;

    localparam [31:0] ID_VALUE  = 32'h4C43_4438; // "LCD8"
    localparam [31:0] VER_VALUE = 32'h0001_0000; // 1.0

    localparam CTRL_EN        = 0;
    localparam CTRL_SRST      = 1;
    localparam CTRL_WRONLY    = 2;
    localparam CTRL_BL        = 3;
    localparam CTRL_PANEL_RST = 4;

    // ------------------------------------------------------------------
    // 配置寄存器
    // ------------------------------------------------------------------
    reg        cfg_en, cfg_wronly, cfg_bl, cfg_panel_rst, cfg_srst;
    reg [7:0]  cfg_tas, cfg_tds, cfg_tpw, cfg_tdh, cfg_tidle, cfg_tturn;

    // 实际生效值：T_DS / T_PW 为 0 会破坏建立时间或产生零脉宽，统一钳到 1
    wire [7:0] use_tas   = cfg_tas;
    wire [7:0] use_tds   = (cfg_tds   == 8'd0) ? 8'd1 : cfg_tds;
    wire [7:0] use_tpw   = (cfg_tpw   == 8'd0) ? 8'd1 : cfg_tpw;
    wire [7:0] use_tdh   = cfg_tdh;
    wire [7:0] use_tidle = cfg_tidle;
    wire [7:0] use_tturn = cfg_tturn;

    // ------------------------------------------------------------------
    // 状态 / 错误
    // ------------------------------------------------------------------
    reg        err_param, err_rdonly, err_disabled, err_timeout;
    reg [31:0] wr_cnt;
    reg [15:0] last_cyc;

    // ------------------------------------------------------------------
    // 访问计时
    // ------------------------------------------------------------------
    localparam [0:0] S_IDLE = 1'b0, S_RUN = 1'b1;

    reg        state;
    reg [15:0] cyc;
    reg [15:0] p_dataon, p_stb, p_stbend, p_csoff, p_end;
    reg        cur_we;
    reg        last_we, last_valid;
    reg [7:0]  dlo, dhi;
    reg [15:0] rd16;

    // 16 位模式：按 wstrb 合并字节通道
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            dlo <= 8'h00;
            dhi <= 8'h00;
        end else if (cs && we && (addr == R_CMD || addr == R_DATA)) begin
            if (wstrb[0]) dlo <= wdata[7:0];
            if (wstrb[1]) dhi <= wdata[15:8];
        end
    end

    generate
        if (DATA_WIDTH == 16) begin : g_data16
            assign lcd_data_o = {dhi, dlo};
        end else begin : g_data8
            assign lcd_data_o = dlo;
        end
    endgenerate

    assign lcd_cs_n = !(state == S_RUN);
    assign lcd_wr_n = !(state == S_RUN &&  cur_we && cyc >= p_stb && cyc < p_stbend);
    assign lcd_rd_n = !(state == S_RUN && !cur_we && cyc >= p_stb && cyc < p_stbend);

    // 只有写访问、且进入数据建立阶段之后才驱动总线
    assign lcd_data_oe = (state == S_RUN) && cur_we &&
                         (cyc >= p_dataon) && (cyc < p_csoff);

    assign lcd_bl = cfg_bl && cfg_en;

    // 面板复位：上电保持 + 软件控制
    reg [31:0] por_cnt;
    reg        por_done;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            por_cnt  <= 32'd0;
            por_done <= 1'b0;
        end else if (!por_done) begin
            if (por_cnt >= `CFG_LCD_POR_RESET_CYCLES) por_done <= 1'b1;
            else por_cnt <= por_cnt + 32'd1;
        end
    end
    assign lcd_reset_n = por_done ? cfg_panel_rst : 1'b0;

    // ------------------------------------------------------------------
    // 主逻辑
    // ------------------------------------------------------------------
    wire is_window = (addr == R_CMD) || (addr == R_DATA);
    wire win_rs    = (addr == R_DATA);
    wire rd_block  = !we && (cfg_wronly || !cfg_en);

    // 时间线（组合，进入访问时锁存）
    wire [7:0]  turn_now = (last_valid && (last_we != we)) ? use_tturn : 8'd0;
    wire [15:0] t_dataon = {8'd0, use_tas} + {8'd0, turn_now};
    wire [15:0] t_stb    = t_dataon + {8'd0, use_tds};
    wire [15:0] t_stbend = t_stb + {8'd0, use_tpw};
    wire [15:0] t_csoff  = t_stbend + {8'd0, use_tdh};
    wire [15:0] t_end    = t_csoff + {8'd0, use_tidle};

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state        <= S_IDLE;
            cyc          <= 16'd0;
            p_dataon     <= 16'd0;
            p_stb        <= 16'd0;
            p_stbend     <= 16'd0;
            p_csoff      <= 16'd0;
            p_end        <= 16'd0;
            cur_we       <= 1'b0;
            last_we      <= 1'b1;
            last_valid   <= 1'b0;
            done         <= 1'b0;
            rdata        <= 32'h0000_0000;
            lcd_rs       <= 1'b0;
            rd16         <= 16'h0000;
            err_param    <= 1'b0;
            err_rdonly   <= 1'b0;
            err_disabled <= 1'b0;
            err_timeout  <= 1'b0;
            wr_cnt       <= 32'd0;
            last_cyc     <= 16'd0;
            cfg_en        <= 1'b0;
            cfg_wronly    <= 1'b0;
            cfg_bl        <= 1'b0;
            cfg_panel_rst <= 1'b1;
            cfg_tas   <= `CFG_LCD_T_AS;
            cfg_tds   <= `CFG_LCD_T_DS;
            cfg_tpw   <= `CFG_LCD_T_PW;
            cfg_tdh   <= `CFG_LCD_T_DH;
            cfg_tidle <= `CFG_LCD_T_IDLE;
            cfg_tturn <= `CFG_LCD_T_TURN;
            cfg_srst  <= 1'b0;
        end else begin
            done     <= 1'b0;
            cfg_srst <= 1'b0;

            // ---------------- 寄存器读写：1 周期完成 ----------------
            if (cs && !is_window) begin
                if (we) begin
                    case (addr)
                        R_CTRL: begin
                            if (wstrb[0]) begin
                                cfg_en        <= wdata[CTRL_EN];
                                cfg_srst      <= wdata[CTRL_SRST];
                                cfg_wronly    <= wdata[CTRL_WRONLY];
                                cfg_bl        <= wdata[CTRL_BL];
                                cfg_panel_rst <= wdata[CTRL_PANEL_RST];
                            end
                        end
                        R_TAS:   if (wstrb[0]) cfg_tas   <= wdata[7:0];
                        // 0 是非法值：钳到 1 并置错误位，回读即钳位后的值
                        R_TDS:   if (wstrb[0]) begin
                                     cfg_tds <= (wdata[7:0] == 8'd0) ? 8'd1 : wdata[7:0];
                                     if (wdata[7:0] == 8'd0) err_param <= 1'b1;
                                 end
                        R_TPW:   if (wstrb[0]) begin
                                     cfg_tpw <= (wdata[7:0] == 8'd0) ? 8'd1 : wdata[7:0];
                                     if (wdata[7:0] == 8'd0) err_param <= 1'b1;
                                 end
                        R_TDH:   if (wstrb[0]) cfg_tdh   <= wdata[7:0];
                        R_TIDLE: if (wstrb[0]) cfg_tidle <= wdata[7:0];
                        R_TTURN: if (wstrb[0]) cfg_tturn <= wdata[7:0];
                        // 写 1 清除对应错误位（与 STATUS 位号一致）
                        R_ECLR: begin
                            if (wstrb[0] && wdata[4]) err_param    <= 1'b0;
                            if (wstrb[0] && wdata[5]) err_rdonly   <= 1'b0;
                            if (wstrb[0] && wdata[6]) err_disabled <= 1'b0;
                            if (wstrb[0] && wdata[7]) err_timeout  <= 1'b0;
                        end
                        default: ;
                    endcase
                end else begin
                    case (addr)
                        R_CTRL:   rdata <= {27'd0, cfg_panel_rst, cfg_bl, cfg_wronly, 1'b0, cfg_en};
                        R_STAT:   rdata <= {24'd0,
                                            err_timeout, err_disabled, err_rdonly, err_param,
                                            3'b000, (state != S_IDLE)};
                        R_TAS:    rdata <= {24'd0, cfg_tas};
                        R_TDS:    rdata <= {24'd0, cfg_tds};
                        R_TPW:    rdata <= {24'd0, cfg_tpw};
                        R_TDH:    rdata <= {24'd0, cfg_tdh};
                        R_TIDLE:  rdata <= {24'd0, cfg_tidle};
                        R_TTURN:  rdata <= {24'd0, cfg_tturn};
                        R_FIFO:   rdata <= 32'h0000_0001;
                        R_ID:     rdata <= ID_VALUE;
                        R_WCNT:   rdata <= wr_cnt;
                        R_LCYC:   rdata <= {16'd0, last_cyc};
                        R_VER:    rdata <= VER_VALUE;
                        default:  rdata <= 32'h0000_0000;
                    endcase
                end
                done <= 1'b1;
            end

            // ---------------- 窗口访问 ----------------
            if (state == S_IDLE) begin
                cyc <= 16'd0;
                if (cs && is_window) begin
                    if (!cfg_en) begin
                        err_disabled <= 1'b1;
                        rdata        <= 32'h0000_0000;
                        done         <= 1'b1;
                    end else if (rd_block) begin
                        err_rdonly <= 1'b1;
                        rdata      <= 32'h0000_0000;
                        done       <= 1'b1;
                    end else begin
                        cur_we   <= we;
                        lcd_rs   <= win_rs;
                        p_dataon <= t_dataon;
                        p_stb    <= t_stb;
                        p_stbend <= t_stbend;
                        p_csoff  <= t_csoff;
                        p_end    <= t_end;
                        state    <= S_RUN;
                    end
                end
            end else begin
                // S_RUN
                cyc <= cyc + 16'd1;

                // 读：在 RD 上升沿之前一个周期采样
                if (!cur_we && (cyc == p_stbend - 16'd1)) begin
                    rd16 <= lcd_data_i;
                end

                if (cyc >= p_end) begin
                    last_we    <= cur_we;
                    last_valid <= 1'b1;
                    last_cyc   <= cyc;
                    wr_cnt     <= wr_cnt + 32'd1;
                    state      <= S_IDLE;
                    cyc        <= 16'd0;
                    done       <= 1'b1;
                    if (cur_we) rdata <= 32'h0000_0000;
                    else        rdata <= (DATA_WIDTH == 16) ? {16'h0000, rd16}
                                                            : {24'h0000, rd16[7:0]};
                end

                // 看门狗
                if (cyc > TIMEOUT) begin
                    err_timeout <= 1'b1;
                    last_valid  <= 1'b0;   // 换向状态未知，保守清掉
                    rdata       <= 32'h0000_0000;
                    last_cyc    <= cyc;
                    done        <= 1'b1;
                    state       <= S_IDLE;
                    cyc         <= 16'd0;
                end
            end

            // ---------------- 软件复位 ----------------
            if (cfg_srst) begin
                state        <= S_IDLE;
                cyc          <= 16'd0;
                done         <= 1'b0;
                last_valid   <= 1'b0;
                lcd_rs       <= 1'b0;
                err_param    <= 1'b0;
                err_rdonly   <= 1'b0;
                err_disabled <= 1'b0;
                err_timeout  <= 1'b0;
                wr_cnt       <= 32'd0;
                last_cyc     <= 16'd0;
            end
        end
    end

endmodule
