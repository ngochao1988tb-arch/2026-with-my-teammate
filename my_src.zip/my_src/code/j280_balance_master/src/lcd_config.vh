// =============================================================================
// lcd_config.vh  --  显示子系统集中配置（RTL 与文档的唯一来源）
//
// 所有"待确认"项都集中在此文件。改这里即可，不需要逐个改 RTL。
// 软件侧的同一份常量由 tools/gen_sw_header.py 从本文件生成 sw/lcd_regs.h，
// 避免 RTL 与 C 代码的寄存器地址/默认值漂移。
//
// 本工程：ST7789 / ID 0x8552，320x240 横屏，16 位 8080，HR2046 触摸。
// 正常固件由 sw/build_hmi.ps1 生成到本目录 imem.hex。
// =============================================================================
`ifndef LCD_CONFIG_VH
`define LCD_CONFIG_VH

// ---------------------------------------------------------------------------
// 1. 屏幕电气/几何参数（3.3 V I/O）
// ---------------------------------------------------------------------------
// 1 = ST7789（参考例程 ID 0x8552）；0 = 保留原 ILI9341 初始化。
`define CFG_LCD_USE_ST7789      1
// 数据宽度：8 = 8080-8bit，16 = 8080-16bit。目标为并口 8080。
`define CFG_LCD_DATA_WIDTH      16

// 横屏：ST7789 使用 MADCTL=0x60，ILI9341 使用 0x68。
`define CFG_LCD_PANEL_W         320
`define CFG_LCD_PANEL_H         240

// RGB565 像素；颜色顺序由 lcd.c 的 MADCTL 位控制。
`define CFG_LCD_COLOR_BITS      16

// ---------------------------------------------------------------------------
// 2. 8080 总线时序（单位：50 MHz 时钟周期，1 cycle = 20 ns）
//
//    T_AS   : CS 有效 / RS 建立 到 WR(或 RD) 有效之前的建立时间
//    T_TURN : 总线换向时间（本次访问方向与上次不同时，在 T_AS 之后额外插入）
//    T_DS   : 数据建立时间（WR 下降沿之前数据必须稳定的时间）
//    T_PW   : WR / RD 有效脉宽
//    T_DH   : 数据保持时间（WR 上升沿之后继续驱动数据的时间）
//    T_IDLE : 连续两次访问之间的 CS 无效间隔
//
//    默认值 = 40/40/80/40/40/80 ns。ILI9341 写要求：周期 >=66 ns，
//    WR 高/低 >=15 ns，数据建立/保持 >=10 ns；当前参数有余量。
//    只写模式在固件中启用。读显存要求 RD 低 >=355 ns，不能沿用此脉宽。
// ---------------------------------------------------------------------------
`define CFG_LCD_T_AS            2
`define CFG_LCD_T_DS            2
`define CFG_LCD_T_PW            4
`define CFG_LCD_T_DH            2
`define CFG_LCD_T_IDLE          2
`define CFG_LCD_T_TURN          4

// 单次访问的看门狗上限（时钟周期）。超过即强制结束并置错误位，
// 防止外设 bug 把 CPU 总线挂死。正常访问远小于此值（默认 13 周期）。
`define CFG_LCD_TIMEOUT_CYCLES  4096

// 上电后面板复位保持时间（时钟周期）。50000 = 1 ms @50 MHz。
`define CFG_LCD_POR_RESET_CYCLES 50000

// ---------------------------------------------------------------------------
// 3. 地址映射（与 rv32_soc.v / sw/lcd_regs.h 保持一致）
// ---------------------------------------------------------------------------
// 指令存储器 IMEM
`define CFG_RV_IMEM_BASE        32'h0000_0000
`define CFG_RV_IMEM_BYTES       (32*1024)
// 数据存储器 DMEM
`define CFG_RV_DMEM_BASE        32'h0001_0000
`define CFG_RV_DMEM_BYTES       (16*1024)
// 状态快照窗口
`define CFG_RV_SNAP_BASE        32'h3000_0000
// 系统控制窗口
`define CFG_RV_SYS_BASE         32'h3000_0080
// LCD8080 外设
`define CFG_LCD_BASE            32'h2000_0000

// LCD8080 寄存器偏移
`define CFG_LCD_REG_CMD         8'h00   // W: 命令(RS=0)  R: 读数据(RS=0)
`define CFG_LCD_REG_DATA        8'h04   // W: 数据(RS=1)  R: 读数据(RS=1)
`define CFG_LCD_REG_CTRL        8'h08
`define CFG_LCD_REG_STATUS      8'h0C
`define CFG_LCD_REG_T_AS        8'h10
`define CFG_LCD_REG_T_DS        8'h14
`define CFG_LCD_REG_T_PW        8'h18
`define CFG_LCD_REG_T_DH        8'h1C
`define CFG_LCD_REG_T_IDLE      8'h20
`define CFG_LCD_REG_T_TURN      8'h24
`define CFG_LCD_REG_FIFO_STAT   8'h28
`define CFG_LCD_REG_ERR_CLR     8'h2C
`define CFG_LCD_REG_ID          8'h30
`define CFG_LCD_REG_WR_CNT      8'h34
`define CFG_LCD_REG_LAST_CYC    8'h38
`define CFG_LCD_REG_VER         8'h3C

// ---------------------------------------------------------------------------
// 4. 软核命令通道（默认关闭）
//    只有把 CFG_RV_ENABLE_CMD 改为 1 重新综合，软核才能提交 0x01/0x02/0x04。
//    命令仍然经过 hmi_control 的全部状态检查与安全门控，软核无法绕过。
// ---------------------------------------------------------------------------
`define CFG_RV_ENABLE_CMD       1

`endif // LCD_CONFIG_VH
