`timescale 1ns/1ps
`include "control_config.vh"
// Continuous RUN reference oscillator. Physical calibration offsets are untouched.
// 上位机协议扩展（0x20~0x26）：
//   set_valid 直接装载 set_period_us/set_amp_q16 并按 kind 启动（正弦/方波/三角）；
//   track_mode + point_valid 进入"手写轨迹跟随"，按 TRACK_STEP 限速跟随点目标；
//   osc_stop 停止输出但保留参数。
// 波形整形复用同一乘法器（方波/三角波只做移位与加减），不增加 DSP 占用。
module sine_reference(
    input clk,rst_n,clear,tick,enable,start,period_step,amplitude_step,
    input signed [31:0] current_reference,
    output reg active,valid,accepted,rejected,
    output reg signed [31:0] reference_q16,
    output reg [31:0] period_us,
    output reg signed [31:0] amplitude_q16,
    // ---- 正弦前馈采样：与 reference_q16 同一拍输出，供 sine_feedforward 使用 ----
    // 相位用"本帧累加前"的值，周期/幅值用本帧实际生效值，三者严格同源。
    output reg [31:0] sample_phase,sample_period,
    output reg signed [31:0] sample_amplitude,
    // 纯正弦（kind=0）且不在手写轨迹模式时才允许前馈修正。
    output ff_ok,
    // ---- 上位机扩展 ----
    input [1:0] kind,
    input set_valid,
    input [31:0] set_period_us,
    input signed [31:0] set_amp_q16,
    input osc_stop,
    input track_mode,
    input point_valid,
    input signed [31:0] point_q16,
    output reg [1:0] kind_active
);
    localparam [31:0] INITIAL_PERIOD=`CFG_SINE_PERIOD_US;
    localparam [31:0] INITIAL_INCREMENT=(64'd4294967296*`CFG_CONTROL_PERIOD_US+INITIAL_PERIOD/2)/INITIAL_PERIOD;
    localparam signed [31:0] INITIAL_AMPLITUDE=$rtoi(`CFG_SINE_AMPLITUDE_DEG*3.141592653589793*65536.0/180.0+0.5);
    localparam signed [31:0] MAX_AMPLITUDE=$rtoi(`CFG_SINE_MAX_AMPLITUDE_DEG*3.141592653589793*65536.0/180.0+0.5);
    localparam signed [31:0] ENVELOPE=$rtoi(`CFG_SINE_REFERENCE_LIMIT_DEG*3.141592653589793*65536.0/180.0+0.5);
    reg signed [31:0] center_q16;
    // Slew the envelope at 15 deg/s so SW4 cannot step the LQR reference.
    localparam signed [31:0] AMPLITUDE_STEP=$rtoi(15.0*`CFG_CONTROL_PERIOD_US*3.141592653589793*65536.0/180000000.0+0.5);
    // 手写轨迹跟随的参考限速：120 deg/s，兼顾跟随精度与机械冲击。
    localparam signed [31:0] TRACK_STEP=$rtoi(120.0*`CFG_CONTROL_PERIOD_US*3.141592653589793*65536.0/180000000.0+0.5);
    // 相位增量 = 2^32 * 控制周期 / 波形周期，只在参数装载时做一次顺序除法。
    localparam [43:0] INC_NUM=44'd4294967296*`CFG_CONTROL_PERIOD_US;
    localparam [31:0] PERIOD_MIN=32'd50000;
    localparam [31:0] PERIOD_MAX=32'd120000000;
    reg signed [31:0] applied_amplitude_q16;
    reg [31:0] phase,phase_increment;
    wire signed [31:0] abs_center=center_q16[31] ? -center_q16:center_q16;
    wire signed [31:0] available=ENVELOPE-abs_center;
    wire signed [31:0] amplitude_limit=available<MAX_AMPLITUDE ? available:MAX_AMPLITUDE;
    wire signed [31:0] abs_current=current_reference[31] ? -current_reference:current_reference;
    wire [31:0] larger_amplitude,larger_period;
    wire amplitude_done,period_done;
    sine_scale_four_thirds period_scale(.clk(clk),.rst_n(rst_n),.clear(clear),
        .start(enable && period_step),.value(period_us),.result(larger_period),.done(period_done));
    sine_scale_four_thirds amplitude_scale(.clk(clk),.rst_n(rst_n),.clear(clear),
        .start(enable && amplitude_step),.value(amplitude_q16),.result(larger_amplitude),.done(amplitude_done));
    function [15:0] sine_quarter;
        input [6:0] index;
        begin case(index)
            7'd0: sine_quarter=16'd0;
            7'd1: sine_quarter=16'd804;
            7'd2: sine_quarter=16'd1608;
            7'd3: sine_quarter=16'd2410;
            7'd4: sine_quarter=16'd3212;
            7'd5: sine_quarter=16'd4011;
            7'd6: sine_quarter=16'd4808;
            7'd7: sine_quarter=16'd5602;
            7'd8: sine_quarter=16'd6393;
            7'd9: sine_quarter=16'd7179;
            7'd10: sine_quarter=16'd7962;
            7'd11: sine_quarter=16'd8739;
            7'd12: sine_quarter=16'd9512;
            7'd13: sine_quarter=16'd10278;
            7'd14: sine_quarter=16'd11039;
            7'd15: sine_quarter=16'd11793;
            7'd16: sine_quarter=16'd12539;
            7'd17: sine_quarter=16'd13279;
            7'd18: sine_quarter=16'd14010;
            7'd19: sine_quarter=16'd14732;
            7'd20: sine_quarter=16'd15446;
            7'd21: sine_quarter=16'd16151;
            7'd22: sine_quarter=16'd16846;
            7'd23: sine_quarter=16'd17530;
            7'd24: sine_quarter=16'd18204;
            7'd25: sine_quarter=16'd18868;
            7'd26: sine_quarter=16'd19519;
            7'd27: sine_quarter=16'd20159;
            7'd28: sine_quarter=16'd20787;
            7'd29: sine_quarter=16'd21403;
            7'd30: sine_quarter=16'd22005;
            7'd31: sine_quarter=16'd22594;
            7'd32: sine_quarter=16'd23170;
            7'd33: sine_quarter=16'd23731;
            7'd34: sine_quarter=16'd24279;
            7'd35: sine_quarter=16'd24811;
            7'd36: sine_quarter=16'd25329;
            7'd37: sine_quarter=16'd25832;
            7'd38: sine_quarter=16'd26319;
            7'd39: sine_quarter=16'd26790;
            7'd40: sine_quarter=16'd27245;
            7'd41: sine_quarter=16'd27683;
            7'd42: sine_quarter=16'd28105;
            7'd43: sine_quarter=16'd28510;
            7'd44: sine_quarter=16'd28898;
            7'd45: sine_quarter=16'd29268;
            7'd46: sine_quarter=16'd29621;
            7'd47: sine_quarter=16'd29956;
            7'd48: sine_quarter=16'd30273;
            7'd49: sine_quarter=16'd30571;
            7'd50: sine_quarter=16'd30852;
            7'd51: sine_quarter=16'd31113;
            7'd52: sine_quarter=16'd31356;
            7'd53: sine_quarter=16'd31580;
            7'd54: sine_quarter=16'd31785;
            7'd55: sine_quarter=16'd31971;
            7'd56: sine_quarter=16'd32137;
            7'd57: sine_quarter=16'd32285;
            7'd58: sine_quarter=16'd32412;
            7'd59: sine_quarter=16'd32521;
            7'd60: sine_quarter=16'd32609;
            7'd61: sine_quarter=16'd32678;
            7'd62: sine_quarter=16'd32728;
            7'd63: sine_quarter=16'd32757;
            7'd64: sine_quarter=16'd32767;
            default:sine_quarter=16'd32767;
        endcase end
    endfunction
    // Fold each quadrant onto 0..pi/2, linearly interpolate the 65-entry ROM.
    wire [30:0] folded=phase[30] ? 31'd1073741824-{1'b0,phase[29:0]}:{1'b0,phase[29:0]};
    reg [30:0] folded_sample;
    wire [6:0] index=folded_sample[30:24];
    reg [15:0] lo,hi,fraction1,fraction2,base2,base3;
    reg [9:0] difference;
    reg [25:0] interpolation;
    reg [5:0] sign_pipe;
    reg signed [31:0] amp_pipe[0:4];
    reg signed [31:0] center_pipe[0:5];
    reg [31:0] phase_pipe[0:5];
    integer stage;
    reg signed [17:0] sine_value;
    reg signed [49:0] product;
    reg [5:0] pipeline;
    // ---- 前馈采样流水：与 6 级乘积流水对齐，保证 phase/period/amplitude 同拍 ----
    reg [31:0] pending_phase,pending_period;
    reg signed [31:0] pending_amplitude;
    // ---- 上位机扩展状态 ----
    reg armed,track_active,track_prev;
    reg signed [31:0] track_ref,track_target;
    wire [31:0] set_period_clamped=set_period_us<PERIOD_MIN ? PERIOD_MIN :
        set_period_us>PERIOD_MAX ? PERIOD_MAX : set_period_us;
    wire signed [31:0] point_clamped=point_q16>ENVELOPE ? ENVELOPE :
        point_q16< -ENVELOPE ? -ENVELOPE : point_q16;
    wire signed [31:0] track_next=track_ref<track_target-TRACK_STEP ? track_ref+TRACK_STEP :
        track_ref>track_target+TRACK_STEP ? track_ref-TRACK_STEP : track_target;
    assign ff_ok = !track_active && (kind_active==2'd0);
    // 顺序除法：phase_increment = 2^32 * 控制周期 / 波形周期（约 0.9us @50MHz，只在装载时跑）
    reg inc_busy,inc_ready;
    reg [5:0] inc_index;
    reg [43:0] inc_num;
    reg [31:0] inc_div,inc_quot;
    reg [32:0] inc_rem;
    wire [32:0] inc_rem_shift={inc_rem[31:0],inc_num[43]};
    wire inc_sub=inc_rem_shift>={1'b0,inc_div};
    wire [32:0] inc_quot_next={inc_quot[31:0],inc_sub};
    // 波形整形：0 正弦（ROM+插值）、1 方波、2 三角波，全部 Q15 定标且不使用乘法器。
    function signed [17:0] unit_shape;
        input [31:0] p;
        reg [17:0] ph;
        begin
            ph={1'b0,p[31:15]};
            case(kind_active)
                2'd1: unit_shape=p[31] ? -18'sd32767 : 18'sd32767;
                2'd2: unit_shape=p[31:30]==2'd0 ? ph :
                      p[31:30]==2'd3 ? ph-18'sd131072 : 18'sd65536-ph;
                default: unit_shape=sine_value;
            endcase
        end
    endfunction
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            active<=0;valid<=0;accepted<=0;rejected<=0;reference_q16<=0;            period_us<=INITIAL_PERIOD;phase_increment<=INITIAL_INCREMENT;
            amplitude_q16<=INITIAL_AMPLITUDE;applied_amplitude_q16<=INITIAL_AMPLITUDE;center_q16<=0;phase<=0;
            pipeline<=0;interpolation<=0;sign_pipe<=0;folded_sample<=0;
            lo<=0;hi<=0;fraction1<=0;fraction2<=0;base2<=0;base3<=0;difference<=0;
            for(stage=0;stage<5;stage=stage+1) amp_pipe[stage]<=0;
            for(stage=0;stage<6;stage=stage+1) center_pipe[stage]<=0;
            for(stage=0;stage<6;stage=stage+1) phase_pipe[stage]<=0;
            sine_value<=0;product<=0;
            sample_phase<=0;sample_period<=INITIAL_PERIOD;sample_amplitude<=0;
            pending_phase<=0;pending_period<=INITIAL_PERIOD;pending_amplitude<=0;
            armed<=0;track_active<=0;track_prev<=0;track_ref<=0;track_target<=0;kind_active<=0;
            inc_busy<=0;inc_index<=0;inc_num<=0;inc_div<=1;inc_quot<=0;inc_rem<=0;inc_ready<=1;
        end else begin
            valid<=0;accepted<=0;
            pipeline<={pipeline[4:0],tick && active && enable && !track_active};
            sign_pipe<={sign_pipe[4:0],phase[31]};
            for(stage=1;stage<5;stage=stage+1) amp_pipe[stage]<=amp_pipe[stage-1];
            for(stage=1;stage<6;stage=stage+1) center_pipe[stage]<=center_pipe[stage-1];
            for(stage=1;stage<6;stage=stage+1) phase_pipe[stage]<=phase_pipe[stage-1];
            if(tick && active && enable && !track_active) begin
                folded_sample<=folded;
                phase_pipe[0]<=phase;
                amp_pipe[0]<=applied_amplitude_q16;center_pipe[0]<=center_q16;
                pending_phase<=phase;pending_period<=period_us;pending_amplitude<=applied_amplitude_q16;
                if(applied_amplitude_q16<amplitude_q16-AMPLITUDE_STEP)
                    applied_amplitude_q16<=applied_amplitude_q16+AMPLITUDE_STEP;
                else applied_amplitude_q16<=amplitude_q16;
                if(inc_ready) phase<=phase+phase_increment;
            end
            if(pipeline[0]) begin
                lo<=sine_quarter(index);hi<=sine_quarter(index==64 ? 7'd64:index+1'b1);
                fraction1<=folded_sample[23:8];
            end
            if(pipeline[1]) begin difference<=hi-lo;base2<=lo;fraction2<=fraction1;end
            if(pipeline[2]) begin interpolation<=difference*fraction2;base3<=base2;end
            if(pipeline[3]) sine_value<=sign_pipe[3] ?
                -$signed({2'b00,base3}+{8'd0,interpolation[25:16]}) :
                 $signed({2'b00,base3}+{8'd0,interpolation[25:16]});
            if(pipeline[4]) product<=unit_shape(phase_pipe[4])*amp_pipe[4];
            if(pipeline[5] && !track_active) begin
                reference_q16<=center_pipe[5]+(product>>>15);valid<=1;
                sample_phase<=pending_phase;sample_period<=pending_period;
                sample_amplitude<=pending_amplitude;
            end
            // 前馈只对纯正弦有效：方波/三角与手写轨迹一律给 0 幅值，
            // 让 sine_feedforward 按其斜率平滑回零，而不是用一个错误的相位算修正。
            if(track_active || kind_active!=2'd0) sample_amplitude<=0;
            // 离开 RUN / 反馈失效时停住输出，但保留 armed：上位机可以先下发参数，
            // 等进入稳定保持后自动开始一次（0x23/0x02/0x0F/复位会清掉 armed）。
            if(!enable) begin active<=0;pipeline<=0;valid<=0;track_active<=0;end
            if(enable && period_done && larger_period<=`CFG_SINE_MAX_PERIOD_US) begin
                period_us<=larger_period[31:0];
                phase_increment<=(phase_increment*64'd3+2)/4;
            end
            if(enable && amplitude_done) begin
                if(larger_amplitude>MAX_AMPLITUDE || (active && larger_amplitude>$unsigned(amplitude_limit)))
                    rejected<=1;
                else begin amplitude_q16<=larger_amplitude[31:0];rejected<=0;end
            end
            if(enable && start) begin
                if(abs_current>ENVELOPE-amplitude_q16) rejected<=1;
                else begin
                    center_q16<=current_reference;phase<=0;pipeline<=0;applied_amplitude_q16<=amplitude_q16;
                    reference_q16<=current_reference;valid<=1;active<=1;accepted<=1;rejected<=0;armed<=0;
                    sample_phase<=0;sample_period<=period_us;
                    sample_amplitude<=(kind_active==2'd0) ? amplitude_q16 : 32'sd0;
                end
            end else if(enable && armed && !active && !track_active) begin
                // 上位机下发参数时可能还没进入 RUN，这里等 enable 有效后自动启动一次。
                if(abs_current>ENVELOPE-amplitude_q16) begin rejected<=1;armed<=0;end
                else begin
                    center_q16<=current_reference;phase<=0;pipeline<=0;applied_amplitude_q16<=amplitude_q16;
                    reference_q16<=current_reference;valid<=1;active<=1;accepted<=1;rejected<=0;armed<=0;
                    sample_phase<=0;sample_period<=set_period_clamped;
                    sample_amplitude<=(kind==2'd0) ? amplitude_q16 : 32'sd0;
                end
            end
            // ---- 上位机参数装载 ----
            if(set_valid) begin
                kind_active<=kind;
                period_us<=set_period_clamped;
                amplitude_q16<=set_amp_q16>MAX_AMPLITUDE ? MAX_AMPLITUDE : set_amp_q16;
                rejected<=set_amp_q16>MAX_AMPLITUDE;
                armed<=1;
            end
            // ---- 相位增量顺序除法 ----
            if(!inc_busy) begin
                if(set_valid) begin
                    inc_num<=INC_NUM;inc_div<=set_period_clamped;
                    inc_quot<=0;inc_rem<=0;inc_index<=0;inc_busy<=1;inc_ready<=0;
                end
            end else begin
                inc_num<=inc_num<<1;
                inc_quot<=inc_quot_next;
                inc_rem<=inc_sub ? inc_rem_shift-{1'b0,inc_div}:inc_rem_shift;
                inc_index<=inc_index+1'b1;
                if(inc_index==43) begin phase_increment<=inc_quot_next;inc_busy<=0;inc_ready<=1;end
            end
            // ---- 手写轨迹跟随 ----
            if(osc_stop) begin active<=0;armed<=0;track_active<=0;valid<=0;pipeline<=0;accepted<=0;end
            if(track_mode && !track_prev) begin
                track_active<=1;track_ref<=current_reference;track_target<=current_reference;
                reference_q16<=current_reference;valid<=1;active<=1;armed<=0;pipeline<=0;
            end
            // 退出轨迹模式时不再恢复之前的波形输出，参考就地保持（需要重新下发 0x20~0x22 才动）
            if(!track_mode && track_active) begin active<=0;pipeline<=0;end
            if(!track_mode) track_active<=0;
            if(track_active && enable) begin
                if(point_valid) track_target<=point_clamped;
                if(tick) begin
                    track_ref<=track_next;reference_q16<=track_next;valid<=1;active<=1;
                end
            end
            track_prev<=track_mode;
            if(clear) begin
                active<=0;valid<=0;pipeline<=0;accepted<=0;rejected<=0;phase<=0;
                period_us<=INITIAL_PERIOD;phase_increment<=INITIAL_INCREMENT;
                amplitude_q16<=INITIAL_AMPLITUDE;applied_amplitude_q16<=INITIAL_AMPLITUDE;
                sample_phase<=0;sample_period<=INITIAL_PERIOD;sample_amplitude<=0;
                pending_phase<=0;pending_period<=INITIAL_PERIOD;pending_amplitude<=0;
                armed<=0;track_active<=0;kind_active<=0;track_ref<=0;track_target<=0;inc_ready<=1;
            end
        end
    end
endmodule

// Exact round(value*4/3), one quotient bit per clock. Button latency <1us
// at 50MHz; no long combinational divider on the 20ns clock path.
module sine_scale_four_thirds(input clk,rst_n,clear,start,input [31:0] value,
    output reg [31:0] result,output reg done);
    reg busy;
    reg [31:0] numerator,quotient;
    reg [1:0] remainder;
    reg [5:0] index;
    wire [2:0] trial={remainder,numerator[31]};
    wire subtract=trial>=3;
    wire [31:0] next_quotient={quotient[30:0],subtract};
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin busy<=0;done<=0;result<=0;numerator<=0;quotient<=0;remainder<=0;index<=0;end
        else begin
            done<=0;
            if(start && !busy) begin
                numerator<=(value<<2)+1;quotient<=0;remainder<=0;index<=0;busy<=1;
            end else if(busy) begin
                numerator<=numerator<<1;quotient<=next_quotient;
                remainder<=subtract ? trial-3:trial;index<=index+1'b1;
                if(index==31) begin result<=next_quotient;done<=1;busy<=0;end
            end
            if(clear) begin busy<=0;done<=0;end
        end
    end
endmodule
