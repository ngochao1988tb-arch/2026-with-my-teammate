`timescale 1ns/1ps
`include "control_config.vh"
// Vendor protocol with fixed 0x6B check byte, NOT Modbus RTU CRC16.
// One outstanding request; no automatic zeroing at startup.
module motor_encoder_link #(
    parameter CLK_HZ=`CFG_HARDWARE_CLOCK_HZ, BAUD=`CFG_MOTOR_UART_BAUD,
    parameter [7:0] ADDRESS=`CFG_MOTOR_UART_ADDRESS,
    parameter POLL_MS=`CFG_MOTOR_UART_POLL_MS, TIMEOUT_MS=`CFG_MOTOR_UART_TIMEOUT_MS, BYTE_TIMEOUT_MS=`CFG_MOTOR_UART_BYTE_TIMEOUT_MS,
    parameter DATA_MSB_FIRST=`CFG_MOTOR_UART_DATA_MSB_FIRST
)(
    input clk, input rst_n, input motor_rx, output motor_tx,
    input clear_request,
    output reg [15:0] encoder_raw, output reg encoder_valid,
    output reg encoder_update,
    output reg clear_done, output reg [7:0] clear_status,
    output reg [31:0] timeout_count
);
    localparam POLL_CYCLES=CLK_HZ/1000*POLL_MS;
    localparam TIMEOUT_CYCLES=CLK_HZ/1000*TIMEOUT_MS;
    localparam BYTE_CYCLES=CLK_HZ/1000*BYTE_TIMEOUT_MS;
    localparam GAP=0, SEND=1, TX_WAIT=2, RESPONSE=3;
    reg [1:0] state;
    reg [31:0] timer, byte_timer;
    reg pending_clear, is_clear;
    reg [2:0] tx_index, received;
    reg tx_start;
    reg [7:0] tx_data;
    wire tx_busy, tx_done, rx_valid, rx_error;
    wire [7:0] rx_data;
    reg [31:0] window;
    serial_tx #(.CLK_HZ(CLK_HZ),.BAUD(BAUD)) u_tx
        (.clk(clk),.rst_n(rst_n),.start(tx_start),.data(tx_data),.tx(motor_tx),.busy(tx_busy),.done(tx_done));
    serial_rx #(.CLK_HZ(CLK_HZ),.BAUD(BAUD)) u_rx
        (.clk(clk),.rst_n(rst_n),.rx(motor_rx),.data(rx_data),.valid(rx_valid),.framing_error(rx_error));
    always @* begin
        case (tx_index)
            0: tx_data=ADDRESS;
            1: tx_data=is_clear ? 8'h0a : 8'h31;
            2: tx_data=is_clear ? 8'h6d : 8'h6b;
            default: tx_data=8'h6b;
        endcase
    end
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state<=GAP; timer<=0; byte_timer<=0; pending_clear<=0; is_clear<=0;
            tx_index<=0; received<=0; tx_start<=0; window<=0;
            encoder_raw<=0; encoder_valid<=0; encoder_update<=0;
            clear_done<=0; clear_status<=0; timeout_count<=0;
        end else begin
            tx_start<=0; encoder_update<=0; clear_done<=0;
            if (clear_request) pending_clear<=1;
            case (state)
                GAP: if (timer==POLL_CYCLES-1) begin
                    timer<=0; tx_index<=0; is_clear<=pending_clear;
                    if (!clear_request) pending_clear<=0;
                    if (pending_clear) encoder_valid<=0;
                    state<=SEND;
                end else timer<=timer+1'b1;
                SEND: if (!tx_busy) begin tx_start<=1; state<=TX_WAIT; end
                TX_WAIT: if (tx_done) begin
                    if (tx_index==(is_clear ? 3 : 2)) begin
                        state<=RESPONSE; timer<=0; byte_timer<=0; window<=0; received<=0;
                    end else begin tx_index<=tx_index+1'b1; state<=SEND; end
                end
                RESPONSE: begin
                    timer<=timer+1'b1;
                    if (byte_timer<BYTE_CYCLES) byte_timer<=byte_timer+1'b1;
                    if (rx_error || timer==TIMEOUT_CYCLES-1) begin
                        encoder_valid<=0; timeout_count<=timeout_count+1'b1;
                        if (is_clear) begin clear_done<=1; clear_status<=8'hff; end
                        state<=GAP; timer<=0; received<=0;
                    end else if (rx_valid) begin
                        byte_timer<=0;
                        if (byte_timer>=BYTE_CYCLES) begin window<={24'b0,rx_data}; received<=1; end
                        else begin
                            window<={window[23:0],rx_data};
                            if (received<4) received<=received+1'b1;
                            if (!is_clear && received>=4 && window[31:24]==ADDRESS &&
                                window[23:16]==8'h31 && rx_data==8'h6b) begin
                                encoder_raw<=DATA_MSB_FIRST ? window[15:0] : {window[7:0],window[15:8]};
                                encoder_valid<=1; encoder_update<=1; state<=GAP; timer<=0;
                            end else if (is_clear && received>=3 && window[23:16]==ADDRESS &&
                                         window[15:8]==8'h0a && rx_data==8'h6b) begin
                                clear_status<=window[7:0]; clear_done<=1;
                                state<=GAP; timer<=0;
                            end
                        end
                    end
                end
                default: begin state<=GAP; timer<=0; end
            endcase
        end
    end
endmodule
