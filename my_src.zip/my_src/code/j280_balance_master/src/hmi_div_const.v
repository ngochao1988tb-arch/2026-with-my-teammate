`timescale 1ns/1ps
module hmi_div_const #(parameter DIVISOR=10)(input clk,rst_n,input [31:0] value,output reg [31:0] result);
 reg [31:0] numerator,quotient;reg [5:0] index;reg busy;
 reg [7:0] remainder;
 wire [8:0] trial={remainder,numerator[31]};
 wire ge=trial>=DIVISOR;
 always @(posedge clk or negedge rst_n) begin
  if(!rst_n) begin numerator<=0;quotient<=0;index<=0;busy<=0;remainder<=0;result<=0;end
  else if(!busy) begin numerator<=value;quotient<=0;remainder<=0;index<=0;busy<=1;end
  else begin
   numerator<=numerator<<1;quotient<={quotient[30:0],ge};remainder<=ge ? trial-DIVISOR:trial;
   index<=index+1'b1;
   if(index==31) begin result<={quotient[30:0],ge};busy<=0;end
  end
 end
endmodule
