`timescale 1ns/1ps
`include "control_config.vh"
// ============================================================================
// ----------------------------------------------------------------------------
// 一次解析同时服务三台主机，命令语义按来源区分：
//   rx_source = 1 / source_rv = 0 → 上位机（K20/L20 板载 CH340）
//   rx_source = 0 / source_rv = 0 → 串口屏（K22/L22 TJC）
//     两者的命令集完全沿用 PROJECT_ALL（LQR_sine_move）：01/02/04/0F/10~14/
//     20~26/30/31/40~43，含上位机波形与手写轨迹。
//   source_rv = 1 → 片内 RISC-V 软核（ST7789 本地触摸界面）
//     沿用 ST7789 本地命令集：0x23=保持、0x24=绝对目标 0.1°、0x10=0..100
//     映射 0..360°、0x12=回零；0x23/0x24 需要回执（界面轮询 SYS 状态位）。
//   0x24 在两条路径上含义不同：上位机是"轨迹点"，软核是"绝对目标"。
// 三源各自独立判重（seq 银行），不共用序号空间。
// 0=standby 1=swinging 2=stable。
// READY cmd 10 is a relative slider move: -600..+600 -> -180..+180 degrees.
// RUN cmd 10 remains an absolute LQR reference over 0..360 degrees.
// Speed slider 0-100 maps linearly 1x-4x of base slew rate.
// ============================================================================
module hmi_control #(
 parameter CLK_HZ=`CFG_HARDWARE_CLOCK_HZ,
 parameter MANUAL_MAX_HZ=800, parameter MANUAL_ACCEL_HZ_S=2000,
 parameter RECORD_DEPTH=1024,
 // Top-level hardware uses relative pulse-counted READY motion for cmd 10.
 parameter RELATIVE_MANUAL=0
)(
 input clk,rst_n,us_tick,sample_valid,
 input rx_valid,input [7:0] cmd,input signed [31:0] seq,arg,speed,input screen_boot,
 input rx_source,   // 0=串口屏 1=上位机：源切换时重置序号去重
 input source_rv,   // 1=片内软核命令（本地触摸界面）：沿用 ST7789 本地命令集
 input [2:0] state,input [7:0] fault,input calibrated,feedback_ok,rail,
 input [2:0] buttons,
 input signed [31:0] arm_q16,theta_q16,command_q16,theta_velocity_q16,frequency_q8,
 input ack_ready,input snapshot_sent,
 output reg ack_valid,output reg signed [31:0] ack_seq,ack_result,
 // 回执来源：随 ack_seq 一并锁存。2'd2=软核，1'b1=上位机，1'b0=串口屏。
 // 用于上行回执定向，避免上位机/串口屏互相收到不属于自己的回执。
 output reg [1:0] ack_source,
 output reg remote_start,remote_reset,output stop_control,
 output manual_run,output reg signed [31:0] manual_frequency_q8,
 output reg arm_target_valid,output signed [31:0] arm_target_q16,
 output reg arm_speed_valid,output [6:0] arm_speed_percent,
 output reg arm_hold_valid,
 output [671:0] values,
 // Appended to preserve the legacy positional simulation instantiation.
 input signed [31:0] signed_pulses,
 // ---- 上位机波形 / 轨迹扩展（0x20~0x26）----
 input signed [31:0] reference_q16,
 output reg wave_set,output reg [1:0] wave_kind,
 output reg [31:0] wave_period_us,output reg signed [31:0] wave_amp_q16,
 output reg wave_stop,output reg track_request,
 output reg point_valid,output reg signed [31:0] point_q16,
 // ---- 双摆从控扩展（0x16 / 0x50~0x56 / 0x60~0x63）----
 // slave_req_* 是单周期请求，由顶层打包成从板 OP 帧（见 docs/双摆对接_从摆协议.md）。
 // 这里只做参数范围检查，不做状态/权限仲裁：从摆能不能动由从摆自己决定。
 output reg slave_req_valid,
 output reg [7:0] slave_req_op,
 output reg signed [15:0] slave_req_arg,
 output reg sync_enable
);
 function signed [31:0] degrees100;
  input signed [31:0] radians;
  reg signed [63:0] product;
  begin product=$signed(radians)*64'sd366693;degrees100=product>>>22;end
 endfunction
 reg signed [31:0] target;
 wire signed [31:0] theta,arm,command_angle,theta_speed;
 hmi_scale angle_theta(clk,rst_n,1'b0,theta_q16,theta);
 hmi_scale angle_arm(clk,rst_n,1'b0,arm_q16,arm);
 hmi_scale angle_command(clk,rst_n,1'b0,command_q16,command_angle);
 hmi_scale #(.FACTOR(36669)) velocity_theta(clk,rst_n,1'b0,theta_velocity_q16,theta_speed);
 // Legacy absolute target conversion. READY cmd 10 can bypass this in
 // RELATIVE_MANUAL mode and use a pulse-counted relative move instead.
 hmi_scale #(.FACTOR(64'd749602),.SHIFT(16)) target_scale(clk,rst_n,1'b0,target,arm_target_q16);
 reg [9:0] us_count; reg [31:0] milliseconds;
 wire ms_tick=us_tick && us_count==999;
 reg estop,stopped,manual_active,position_mode;
 reg signed [31:0] jog_direction;
 reg relative_move;
 reg signed [31:0] relative_start_pulses;
 reg [31:0] relative_pulse_limit;
 wire relative_pulse_done;
 reg [6:0] speed_limit;            // raw slider value 0-100
 reg [31:0] lease;
 reg [1:0] position_settle_frames;
 reg [65:0] arm_target_pending;
 wire inputs_ok=feedback_ok && calibrated && !rail && fault==0;
 // Simplified: always permit arm control when feedback is healthy and not in fault.
 // The screen shows gstate; we always accept valid commands — no "rejected" states.
 wire permit=inputs_ok && !estop && state!=4;
 wire direct_manual_permit=permit && state==2;
 // 0x61 = 双摆同步停止：主摆走和 0x02 完全相同的停止路径。
 wire immediate_stop=rx_valid && (cmd==8'h02 || cmd==8'h0f || cmd==8'h13 || cmd==8'h61);
 reg manual_angle_ok;
 always @(posedge clk or negedge rst_n)
  if(!rst_n) manual_angle_ok<=0;
  else manual_angle_ok<=arm<36000 && arm> -36000 && command_angle<36000 && command_angle> -36000;
 assign stop_control=estop || remote_reset || remote_start || (rx_valid && (cmd==8'h02 || cmd==8'h0f || cmd==8'h61));
 assign manual_run=manual_active && direct_manual_permit && !immediate_stop && !screen_boot && !(|buttons) &&
                   (relative_move ? !relative_pulse_done : (!position_mode ? lease<300 : 1'b1)) &&
                   manual_angle_ok;
 // Speed slider: raw 0-100 passed through; run_target maps it linearly 0x-4x.
 assign arm_speed_percent=speed_limit;
 reg signed [31:0] previous_arm,arm_velocity;
// 三源各自的序号银行：0=串口屏 1=上位机 2=软核。
// 三台主机的 seq 完全独立，绝不能互相判重（否则屏幕的命令会被当成过期帧丢掉）。
wire [1:0] src_index = source_rv ? 2'd2 : {1'b0,rx_source};
reg signed [31:0] seq_bank[0:2], result_bank[0:2], arg_bank[0:2], speed_bank[0:2];
reg [7:0] cmd_bank[0:2];
reg seen_bank[0:2];
wire signed [31:0] last_seq=seq_bank[src_index], last_result=result_bank[src_index];
wire signed [31:0] last_arg=arg_bank[src_index], last_speed=speed_bank[src_index];
wire [7:0] last_cmd=cmd_bank[src_index];
wire seen=seen_bank[src_index];
integer bank;
 reg [31:0] heartbeat;
 reg [31:0] record_id;reg recording,record_full;
 reg [31:0] record_origin,run_origin,enter_time,capture_time;
 reg [31:0] swing_time,stable_ms,hold_ms,band,hold_count;
 reg active_attempt,entered,captured,qualification;
 reg [2:0] previous_state;
 reg [31:0] mean,peak;
 reg [8:0] stats_count;
 reg [31:0] stats_sum;
 reg divide_busy;
 reg [5:0] divide_index;
 reg [31:0] dividend,divisor,quotient;
 reg [32:0] remainder;
 wire [32:0] remainder_next={remainder[31:0],dividend[31]};
 wire subtract_divisor=remainder_next>={1'b0,divisor};
 wire [31:0] quotient_next={quotient[30:0],subtract_divisor};
 reg [6:0] stats_tick;
 wire [31:0] absolute_error=theta[31] ? -theta:theta;
 wire in_band=inputs_ok && state==3 && absolute_error<=band*10;
 wire [31:0] elapsed_record=milliseconds-record_origin;
 wire [31:0] swing_display,stable_display;
 hmi_div_const #(.DIVISOR(10)) swing_units(clk,rst_n,swing_time,swing_display);
 hmi_div_const #(.DIVISOR(100)) stable_units(clk,rst_n,stable_ms,stable_display);
 wire signed [31:0] normalized_output;
 function [31:0] relative_pulse_count;
  input signed [31:0] slider;
  reg [9:0] magnitude;
  begin
   magnitude=slider[31] ? -slider : slider;
   // Validated range is 0..600. All case values are compile-time constants,
   // avoiding the old 64-bit runtime divide on the manual motor stop path.
   case(magnitude)
    10'd0: relative_pulse_count=(0*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd1: relative_pulse_count=(1*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd2: relative_pulse_count=(2*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd3: relative_pulse_count=(3*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd4: relative_pulse_count=(4*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd5: relative_pulse_count=(5*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd6: relative_pulse_count=(6*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd7: relative_pulse_count=(7*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd8: relative_pulse_count=(8*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd9: relative_pulse_count=(9*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd10: relative_pulse_count=(10*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd11: relative_pulse_count=(11*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd12: relative_pulse_count=(12*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd13: relative_pulse_count=(13*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd14: relative_pulse_count=(14*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd15: relative_pulse_count=(15*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd16: relative_pulse_count=(16*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd17: relative_pulse_count=(17*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd18: relative_pulse_count=(18*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd19: relative_pulse_count=(19*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd20: relative_pulse_count=(20*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd21: relative_pulse_count=(21*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd22: relative_pulse_count=(22*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd23: relative_pulse_count=(23*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd24: relative_pulse_count=(24*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd25: relative_pulse_count=(25*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd26: relative_pulse_count=(26*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd27: relative_pulse_count=(27*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd28: relative_pulse_count=(28*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd29: relative_pulse_count=(29*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd30: relative_pulse_count=(30*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd31: relative_pulse_count=(31*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd32: relative_pulse_count=(32*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd33: relative_pulse_count=(33*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd34: relative_pulse_count=(34*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd35: relative_pulse_count=(35*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd36: relative_pulse_count=(36*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd37: relative_pulse_count=(37*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd38: relative_pulse_count=(38*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd39: relative_pulse_count=(39*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd40: relative_pulse_count=(40*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd41: relative_pulse_count=(41*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd42: relative_pulse_count=(42*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd43: relative_pulse_count=(43*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd44: relative_pulse_count=(44*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd45: relative_pulse_count=(45*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd46: relative_pulse_count=(46*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd47: relative_pulse_count=(47*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd48: relative_pulse_count=(48*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd49: relative_pulse_count=(49*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd50: relative_pulse_count=(50*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd51: relative_pulse_count=(51*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd52: relative_pulse_count=(52*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd53: relative_pulse_count=(53*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd54: relative_pulse_count=(54*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd55: relative_pulse_count=(55*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd56: relative_pulse_count=(56*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd57: relative_pulse_count=(57*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd58: relative_pulse_count=(58*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd59: relative_pulse_count=(59*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd60: relative_pulse_count=(60*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd61: relative_pulse_count=(61*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd62: relative_pulse_count=(62*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd63: relative_pulse_count=(63*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd64: relative_pulse_count=(64*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd65: relative_pulse_count=(65*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd66: relative_pulse_count=(66*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd67: relative_pulse_count=(67*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd68: relative_pulse_count=(68*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd69: relative_pulse_count=(69*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd70: relative_pulse_count=(70*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd71: relative_pulse_count=(71*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd72: relative_pulse_count=(72*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd73: relative_pulse_count=(73*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd74: relative_pulse_count=(74*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd75: relative_pulse_count=(75*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd76: relative_pulse_count=(76*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd77: relative_pulse_count=(77*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd78: relative_pulse_count=(78*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd79: relative_pulse_count=(79*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd80: relative_pulse_count=(80*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd81: relative_pulse_count=(81*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd82: relative_pulse_count=(82*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd83: relative_pulse_count=(83*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd84: relative_pulse_count=(84*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd85: relative_pulse_count=(85*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd86: relative_pulse_count=(86*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd87: relative_pulse_count=(87*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd88: relative_pulse_count=(88*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd89: relative_pulse_count=(89*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd90: relative_pulse_count=(90*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd91: relative_pulse_count=(91*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd92: relative_pulse_count=(92*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd93: relative_pulse_count=(93*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd94: relative_pulse_count=(94*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd95: relative_pulse_count=(95*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd96: relative_pulse_count=(96*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd97: relative_pulse_count=(97*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd98: relative_pulse_count=(98*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd99: relative_pulse_count=(99*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd100: relative_pulse_count=(100*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd101: relative_pulse_count=(101*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd102: relative_pulse_count=(102*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd103: relative_pulse_count=(103*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd104: relative_pulse_count=(104*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd105: relative_pulse_count=(105*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd106: relative_pulse_count=(106*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd107: relative_pulse_count=(107*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd108: relative_pulse_count=(108*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd109: relative_pulse_count=(109*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd110: relative_pulse_count=(110*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd111: relative_pulse_count=(111*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd112: relative_pulse_count=(112*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd113: relative_pulse_count=(113*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd114: relative_pulse_count=(114*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd115: relative_pulse_count=(115*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd116: relative_pulse_count=(116*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd117: relative_pulse_count=(117*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd118: relative_pulse_count=(118*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd119: relative_pulse_count=(119*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd120: relative_pulse_count=(120*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd121: relative_pulse_count=(121*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd122: relative_pulse_count=(122*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd123: relative_pulse_count=(123*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd124: relative_pulse_count=(124*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd125: relative_pulse_count=(125*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd126: relative_pulse_count=(126*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd127: relative_pulse_count=(127*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd128: relative_pulse_count=(128*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd129: relative_pulse_count=(129*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd130: relative_pulse_count=(130*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd131: relative_pulse_count=(131*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd132: relative_pulse_count=(132*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd133: relative_pulse_count=(133*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd134: relative_pulse_count=(134*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd135: relative_pulse_count=(135*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd136: relative_pulse_count=(136*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd137: relative_pulse_count=(137*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd138: relative_pulse_count=(138*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd139: relative_pulse_count=(139*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd140: relative_pulse_count=(140*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd141: relative_pulse_count=(141*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd142: relative_pulse_count=(142*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd143: relative_pulse_count=(143*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd144: relative_pulse_count=(144*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd145: relative_pulse_count=(145*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd146: relative_pulse_count=(146*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd147: relative_pulse_count=(147*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd148: relative_pulse_count=(148*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd149: relative_pulse_count=(149*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd150: relative_pulse_count=(150*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd151: relative_pulse_count=(151*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd152: relative_pulse_count=(152*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd153: relative_pulse_count=(153*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd154: relative_pulse_count=(154*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd155: relative_pulse_count=(155*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd156: relative_pulse_count=(156*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd157: relative_pulse_count=(157*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd158: relative_pulse_count=(158*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd159: relative_pulse_count=(159*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd160: relative_pulse_count=(160*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd161: relative_pulse_count=(161*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd162: relative_pulse_count=(162*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd163: relative_pulse_count=(163*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd164: relative_pulse_count=(164*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd165: relative_pulse_count=(165*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd166: relative_pulse_count=(166*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd167: relative_pulse_count=(167*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd168: relative_pulse_count=(168*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd169: relative_pulse_count=(169*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd170: relative_pulse_count=(170*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd171: relative_pulse_count=(171*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd172: relative_pulse_count=(172*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd173: relative_pulse_count=(173*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd174: relative_pulse_count=(174*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd175: relative_pulse_count=(175*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd176: relative_pulse_count=(176*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd177: relative_pulse_count=(177*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd178: relative_pulse_count=(178*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd179: relative_pulse_count=(179*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd180: relative_pulse_count=(180*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd181: relative_pulse_count=(181*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd182: relative_pulse_count=(182*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd183: relative_pulse_count=(183*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd184: relative_pulse_count=(184*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd185: relative_pulse_count=(185*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd186: relative_pulse_count=(186*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd187: relative_pulse_count=(187*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd188: relative_pulse_count=(188*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd189: relative_pulse_count=(189*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd190: relative_pulse_count=(190*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd191: relative_pulse_count=(191*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd192: relative_pulse_count=(192*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd193: relative_pulse_count=(193*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd194: relative_pulse_count=(194*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd195: relative_pulse_count=(195*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd196: relative_pulse_count=(196*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd197: relative_pulse_count=(197*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd198: relative_pulse_count=(198*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd199: relative_pulse_count=(199*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd200: relative_pulse_count=(200*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd201: relative_pulse_count=(201*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd202: relative_pulse_count=(202*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd203: relative_pulse_count=(203*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd204: relative_pulse_count=(204*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd205: relative_pulse_count=(205*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd206: relative_pulse_count=(206*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd207: relative_pulse_count=(207*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd208: relative_pulse_count=(208*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd209: relative_pulse_count=(209*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd210: relative_pulse_count=(210*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd211: relative_pulse_count=(211*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd212: relative_pulse_count=(212*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd213: relative_pulse_count=(213*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd214: relative_pulse_count=(214*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd215: relative_pulse_count=(215*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd216: relative_pulse_count=(216*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd217: relative_pulse_count=(217*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd218: relative_pulse_count=(218*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd219: relative_pulse_count=(219*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd220: relative_pulse_count=(220*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd221: relative_pulse_count=(221*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd222: relative_pulse_count=(222*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd223: relative_pulse_count=(223*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd224: relative_pulse_count=(224*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd225: relative_pulse_count=(225*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd226: relative_pulse_count=(226*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd227: relative_pulse_count=(227*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd228: relative_pulse_count=(228*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd229: relative_pulse_count=(229*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd230: relative_pulse_count=(230*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd231: relative_pulse_count=(231*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd232: relative_pulse_count=(232*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd233: relative_pulse_count=(233*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd234: relative_pulse_count=(234*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd235: relative_pulse_count=(235*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd236: relative_pulse_count=(236*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd237: relative_pulse_count=(237*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd238: relative_pulse_count=(238*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd239: relative_pulse_count=(239*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd240: relative_pulse_count=(240*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd241: relative_pulse_count=(241*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd242: relative_pulse_count=(242*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd243: relative_pulse_count=(243*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd244: relative_pulse_count=(244*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd245: relative_pulse_count=(245*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd246: relative_pulse_count=(246*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd247: relative_pulse_count=(247*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd248: relative_pulse_count=(248*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd249: relative_pulse_count=(249*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd250: relative_pulse_count=(250*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd251: relative_pulse_count=(251*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd252: relative_pulse_count=(252*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd253: relative_pulse_count=(253*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd254: relative_pulse_count=(254*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd255: relative_pulse_count=(255*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd256: relative_pulse_count=(256*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd257: relative_pulse_count=(257*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd258: relative_pulse_count=(258*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd259: relative_pulse_count=(259*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd260: relative_pulse_count=(260*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd261: relative_pulse_count=(261*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd262: relative_pulse_count=(262*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd263: relative_pulse_count=(263*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd264: relative_pulse_count=(264*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd265: relative_pulse_count=(265*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd266: relative_pulse_count=(266*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd267: relative_pulse_count=(267*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd268: relative_pulse_count=(268*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd269: relative_pulse_count=(269*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd270: relative_pulse_count=(270*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd271: relative_pulse_count=(271*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd272: relative_pulse_count=(272*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd273: relative_pulse_count=(273*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd274: relative_pulse_count=(274*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd275: relative_pulse_count=(275*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd276: relative_pulse_count=(276*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd277: relative_pulse_count=(277*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd278: relative_pulse_count=(278*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd279: relative_pulse_count=(279*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd280: relative_pulse_count=(280*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd281: relative_pulse_count=(281*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd282: relative_pulse_count=(282*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd283: relative_pulse_count=(283*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd284: relative_pulse_count=(284*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd285: relative_pulse_count=(285*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd286: relative_pulse_count=(286*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd287: relative_pulse_count=(287*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd288: relative_pulse_count=(288*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd289: relative_pulse_count=(289*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd290: relative_pulse_count=(290*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd291: relative_pulse_count=(291*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd292: relative_pulse_count=(292*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd293: relative_pulse_count=(293*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd294: relative_pulse_count=(294*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd295: relative_pulse_count=(295*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd296: relative_pulse_count=(296*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd297: relative_pulse_count=(297*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd298: relative_pulse_count=(298*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd299: relative_pulse_count=(299*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd300: relative_pulse_count=(300*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd301: relative_pulse_count=(301*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd302: relative_pulse_count=(302*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd303: relative_pulse_count=(303*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd304: relative_pulse_count=(304*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd305: relative_pulse_count=(305*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd306: relative_pulse_count=(306*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd307: relative_pulse_count=(307*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd308: relative_pulse_count=(308*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd309: relative_pulse_count=(309*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd310: relative_pulse_count=(310*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd311: relative_pulse_count=(311*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd312: relative_pulse_count=(312*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd313: relative_pulse_count=(313*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd314: relative_pulse_count=(314*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd315: relative_pulse_count=(315*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd316: relative_pulse_count=(316*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd317: relative_pulse_count=(317*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd318: relative_pulse_count=(318*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd319: relative_pulse_count=(319*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd320: relative_pulse_count=(320*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd321: relative_pulse_count=(321*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd322: relative_pulse_count=(322*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd323: relative_pulse_count=(323*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd324: relative_pulse_count=(324*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd325: relative_pulse_count=(325*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd326: relative_pulse_count=(326*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd327: relative_pulse_count=(327*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd328: relative_pulse_count=(328*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd329: relative_pulse_count=(329*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd330: relative_pulse_count=(330*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd331: relative_pulse_count=(331*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd332: relative_pulse_count=(332*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd333: relative_pulse_count=(333*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd334: relative_pulse_count=(334*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd335: relative_pulse_count=(335*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd336: relative_pulse_count=(336*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd337: relative_pulse_count=(337*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd338: relative_pulse_count=(338*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd339: relative_pulse_count=(339*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd340: relative_pulse_count=(340*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd341: relative_pulse_count=(341*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd342: relative_pulse_count=(342*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd343: relative_pulse_count=(343*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd344: relative_pulse_count=(344*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd345: relative_pulse_count=(345*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd346: relative_pulse_count=(346*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd347: relative_pulse_count=(347*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd348: relative_pulse_count=(348*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd349: relative_pulse_count=(349*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd350: relative_pulse_count=(350*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd351: relative_pulse_count=(351*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd352: relative_pulse_count=(352*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd353: relative_pulse_count=(353*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd354: relative_pulse_count=(354*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd355: relative_pulse_count=(355*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd356: relative_pulse_count=(356*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd357: relative_pulse_count=(357*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd358: relative_pulse_count=(358*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd359: relative_pulse_count=(359*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd360: relative_pulse_count=(360*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd361: relative_pulse_count=(361*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd362: relative_pulse_count=(362*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd363: relative_pulse_count=(363*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd364: relative_pulse_count=(364*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd365: relative_pulse_count=(365*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd366: relative_pulse_count=(366*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd367: relative_pulse_count=(367*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd368: relative_pulse_count=(368*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd369: relative_pulse_count=(369*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd370: relative_pulse_count=(370*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd371: relative_pulse_count=(371*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd372: relative_pulse_count=(372*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd373: relative_pulse_count=(373*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd374: relative_pulse_count=(374*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd375: relative_pulse_count=(375*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd376: relative_pulse_count=(376*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd377: relative_pulse_count=(377*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd378: relative_pulse_count=(378*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd379: relative_pulse_count=(379*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd380: relative_pulse_count=(380*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd381: relative_pulse_count=(381*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd382: relative_pulse_count=(382*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd383: relative_pulse_count=(383*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd384: relative_pulse_count=(384*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd385: relative_pulse_count=(385*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd386: relative_pulse_count=(386*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd387: relative_pulse_count=(387*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd388: relative_pulse_count=(388*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd389: relative_pulse_count=(389*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd390: relative_pulse_count=(390*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd391: relative_pulse_count=(391*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd392: relative_pulse_count=(392*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd393: relative_pulse_count=(393*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd394: relative_pulse_count=(394*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd395: relative_pulse_count=(395*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd396: relative_pulse_count=(396*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd397: relative_pulse_count=(397*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd398: relative_pulse_count=(398*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd399: relative_pulse_count=(399*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd400: relative_pulse_count=(400*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd401: relative_pulse_count=(401*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd402: relative_pulse_count=(402*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd403: relative_pulse_count=(403*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd404: relative_pulse_count=(404*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd405: relative_pulse_count=(405*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd406: relative_pulse_count=(406*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd407: relative_pulse_count=(407*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd408: relative_pulse_count=(408*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd409: relative_pulse_count=(409*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd410: relative_pulse_count=(410*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd411: relative_pulse_count=(411*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd412: relative_pulse_count=(412*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd413: relative_pulse_count=(413*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd414: relative_pulse_count=(414*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd415: relative_pulse_count=(415*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd416: relative_pulse_count=(416*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd417: relative_pulse_count=(417*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd418: relative_pulse_count=(418*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd419: relative_pulse_count=(419*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd420: relative_pulse_count=(420*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd421: relative_pulse_count=(421*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd422: relative_pulse_count=(422*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd423: relative_pulse_count=(423*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd424: relative_pulse_count=(424*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd425: relative_pulse_count=(425*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd426: relative_pulse_count=(426*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd427: relative_pulse_count=(427*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd428: relative_pulse_count=(428*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd429: relative_pulse_count=(429*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd430: relative_pulse_count=(430*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd431: relative_pulse_count=(431*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd432: relative_pulse_count=(432*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd433: relative_pulse_count=(433*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd434: relative_pulse_count=(434*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd435: relative_pulse_count=(435*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd436: relative_pulse_count=(436*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd437: relative_pulse_count=(437*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd438: relative_pulse_count=(438*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd439: relative_pulse_count=(439*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd440: relative_pulse_count=(440*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd441: relative_pulse_count=(441*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd442: relative_pulse_count=(442*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd443: relative_pulse_count=(443*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd444: relative_pulse_count=(444*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd445: relative_pulse_count=(445*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd446: relative_pulse_count=(446*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd447: relative_pulse_count=(447*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd448: relative_pulse_count=(448*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd449: relative_pulse_count=(449*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd450: relative_pulse_count=(450*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd451: relative_pulse_count=(451*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd452: relative_pulse_count=(452*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd453: relative_pulse_count=(453*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd454: relative_pulse_count=(454*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd455: relative_pulse_count=(455*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd456: relative_pulse_count=(456*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd457: relative_pulse_count=(457*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd458: relative_pulse_count=(458*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd459: relative_pulse_count=(459*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd460: relative_pulse_count=(460*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd461: relative_pulse_count=(461*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd462: relative_pulse_count=(462*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd463: relative_pulse_count=(463*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd464: relative_pulse_count=(464*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd465: relative_pulse_count=(465*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd466: relative_pulse_count=(466*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd467: relative_pulse_count=(467*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd468: relative_pulse_count=(468*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd469: relative_pulse_count=(469*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd470: relative_pulse_count=(470*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd471: relative_pulse_count=(471*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd472: relative_pulse_count=(472*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd473: relative_pulse_count=(473*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd474: relative_pulse_count=(474*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd475: relative_pulse_count=(475*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd476: relative_pulse_count=(476*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd477: relative_pulse_count=(477*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd478: relative_pulse_count=(478*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd479: relative_pulse_count=(479*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd480: relative_pulse_count=(480*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd481: relative_pulse_count=(481*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd482: relative_pulse_count=(482*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd483: relative_pulse_count=(483*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd484: relative_pulse_count=(484*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd485: relative_pulse_count=(485*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd486: relative_pulse_count=(486*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd487: relative_pulse_count=(487*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd488: relative_pulse_count=(488*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd489: relative_pulse_count=(489*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd490: relative_pulse_count=(490*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd491: relative_pulse_count=(491*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd492: relative_pulse_count=(492*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd493: relative_pulse_count=(493*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd494: relative_pulse_count=(494*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd495: relative_pulse_count=(495*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd496: relative_pulse_count=(496*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd497: relative_pulse_count=(497*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd498: relative_pulse_count=(498*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd499: relative_pulse_count=(499*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd500: relative_pulse_count=(500*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd501: relative_pulse_count=(501*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd502: relative_pulse_count=(502*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd503: relative_pulse_count=(503*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd504: relative_pulse_count=(504*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd505: relative_pulse_count=(505*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd506: relative_pulse_count=(506*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd507: relative_pulse_count=(507*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd508: relative_pulse_count=(508*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd509: relative_pulse_count=(509*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd510: relative_pulse_count=(510*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd511: relative_pulse_count=(511*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd512: relative_pulse_count=(512*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd513: relative_pulse_count=(513*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd514: relative_pulse_count=(514*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd515: relative_pulse_count=(515*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd516: relative_pulse_count=(516*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd517: relative_pulse_count=(517*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd518: relative_pulse_count=(518*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd519: relative_pulse_count=(519*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd520: relative_pulse_count=(520*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd521: relative_pulse_count=(521*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd522: relative_pulse_count=(522*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd523: relative_pulse_count=(523*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd524: relative_pulse_count=(524*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd525: relative_pulse_count=(525*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd526: relative_pulse_count=(526*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd527: relative_pulse_count=(527*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd528: relative_pulse_count=(528*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd529: relative_pulse_count=(529*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd530: relative_pulse_count=(530*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd531: relative_pulse_count=(531*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd532: relative_pulse_count=(532*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd533: relative_pulse_count=(533*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd534: relative_pulse_count=(534*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd535: relative_pulse_count=(535*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd536: relative_pulse_count=(536*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd537: relative_pulse_count=(537*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd538: relative_pulse_count=(538*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd539: relative_pulse_count=(539*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd540: relative_pulse_count=(540*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd541: relative_pulse_count=(541*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd542: relative_pulse_count=(542*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd543: relative_pulse_count=(543*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd544: relative_pulse_count=(544*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd545: relative_pulse_count=(545*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd546: relative_pulse_count=(546*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd547: relative_pulse_count=(547*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd548: relative_pulse_count=(548*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd549: relative_pulse_count=(549*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd550: relative_pulse_count=(550*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd551: relative_pulse_count=(551*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd552: relative_pulse_count=(552*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd553: relative_pulse_count=(553*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd554: relative_pulse_count=(554*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd555: relative_pulse_count=(555*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd556: relative_pulse_count=(556*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd557: relative_pulse_count=(557*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd558: relative_pulse_count=(558*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd559: relative_pulse_count=(559*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd560: relative_pulse_count=(560*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd561: relative_pulse_count=(561*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd562: relative_pulse_count=(562*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd563: relative_pulse_count=(563*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd564: relative_pulse_count=(564*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd565: relative_pulse_count=(565*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd566: relative_pulse_count=(566*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd567: relative_pulse_count=(567*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd568: relative_pulse_count=(568*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd569: relative_pulse_count=(569*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd570: relative_pulse_count=(570*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd571: relative_pulse_count=(571*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd572: relative_pulse_count=(572*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd573: relative_pulse_count=(573*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd574: relative_pulse_count=(574*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd575: relative_pulse_count=(575*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd576: relative_pulse_count=(576*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd577: relative_pulse_count=(577*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd578: relative_pulse_count=(578*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd579: relative_pulse_count=(579*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd580: relative_pulse_count=(580*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd581: relative_pulse_count=(581*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd582: relative_pulse_count=(582*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd583: relative_pulse_count=(583*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd584: relative_pulse_count=(584*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd585: relative_pulse_count=(585*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd586: relative_pulse_count=(586*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd587: relative_pulse_count=(587*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd588: relative_pulse_count=(588*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd589: relative_pulse_count=(589*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd590: relative_pulse_count=(590*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd591: relative_pulse_count=(591*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd592: relative_pulse_count=(592*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd593: relative_pulse_count=(593*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd594: relative_pulse_count=(594*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd595: relative_pulse_count=(595*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd596: relative_pulse_count=(596*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd597: relative_pulse_count=(597*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd598: relative_pulse_count=(598*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd599: relative_pulse_count=(599*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    10'd600: relative_pulse_count=(600*`CFG_HARDWARE_PULSES_PER_REVOLUTION+600)/1200;
    default:relative_pulse_count=0;
   endcase
  end
 endfunction
 wire signed [31:0] relative_pulse_delta=signed_pulses-relative_start_pulses;
 wire signed [31:0] relative_limit_signed=relative_pulse_limit;
 assign relative_pulse_done=!relative_move || relative_pulse_limit==0 ||
     (jog_direction[31] ? relative_pulse_delta<=-relative_limit_signed :
                          relative_pulse_delta>=relative_limit_signed);
 // Three user-facing states: 0 standby, 1 swinging/calibrating, 2 upright LQR.
 wire [1:0] hmi_state_code=(state==1 || state==5) ? 2'd1 : state==3 ? 2'd2 : 2'd0;
 wire signed [31:0] hmi_state={30'd0,hmi_state_code};
 localparam RECORD_AW=$clog2(RECORD_DEPTH);
// ================= 上位机波形 / 轨迹扩展（0x20~0x26） =================
// RUN 状态下 gtarget 上报真实 LQR 参考，上位机用 garm-gtarget 得到横臂跟随误差。
wire signed [31:0] reference_deg100;
hmi_scale angle_reference(clk,rst_n,1'b0,reference_q16,reference_deg100);
wire signed [31:0] reported_target=(state==3) ? reference_deg100 : target;
reg [31:0] wave_amp_raw;
reg signed [31:0] point_raw;
reg amp_trigger,point_trigger,pending_wave,pending_point;
reg [1:0] scale_kind;
reg [5:0] scale_delay;
wire signed [31:0] amp_scale_out,point_scale_out;
// 0.1° -> Q16 rad 系数 65536*pi/1800 = 114.392；FACTOR/SHIFT 形式用移位相加实现，不占用 DSP。
hmi_scale #(.FACTOR(64'd7496794),.SHIFT(16),.TRIGGERED(1)) wave_amp_scale(
    clk,rst_n,amp_trigger,wave_amp_raw,amp_scale_out);
hmi_scale #(.FACTOR(64'd7496794),.SHIFT(16),.TRIGGERED(1)) track_point_scale(
    clk,rst_n,point_trigger,point_raw,point_scale_out);
 (* syn_keep=1, syn_preserve=1 *) reg [671:0] record_probe;
 reg [$clog2(RECORD_DEPTH+1)-1:0] record_count;
 reg [6:0] record_tick;
 assign values={theta,32'sd0,theta,arm,reported_target,theta_speed,arm_velocity,
                 normalized_output,
                 swing_display,stable_display,mean,peak,
                 record_id,{31'd0,recording},run_origin,enter_time,capture_time,
                 hmi_state,{31'd0,permit},{31'd0,inputs_ok},heartbeat};
 reg signed [31:0] result;
 reg signed [31:0] desired_freq,delta_freq,position_error,cap_freq,raw_desired,limited_desired;
 wire signed [31:0] scaled_arm_velocity;
 hmi_scale #(.FACTOR(64'd4294967296000/(`CFG_CONTROL_MAX_FREQUENCY_HZ*256)),.SHIFT(32)) output_scale(clk,rst_n,1'b0,frequency_q8,normalized_output);
 hmi_scale #(.FACTOR(64'd6553600000/`CFG_CONTROL_PERIOD_US),.SHIFT(16),.TRIGGERED(1)) arm_speed_scale(clk,rst_n,sample_valid,arm-previous_arm,scaled_arm_velocity);
 always @(posedge clk) begin
  // Manual speed: 200Hz floor at low slider, linear to 800Hz at 100%.
  cap_freq<=speed_limit<25 ? 25*(MANUAL_MAX_HZ*256/100) : speed_limit*(MANUAL_MAX_HZ*256/100);
  position_error<=target-arm;
  raw_desired<=position_mode ? position_error<<<8:(jog_direction[31] ? -cap_freq:cap_freq);
  limited_desired<=raw_desired>cap_freq ? cap_freq:raw_desired< -cap_freq ? -cap_freq:raw_desired;
  desired_freq<=position_mode && ((position_error<10 && position_error> -10) ||
    (limited_desired>0 && command_angle>=target) || (limited_desired<0 && command_angle<=target)) ? 0:limited_desired;
  delta_freq<=desired_freq-manual_frequency_q8;
 end
 localparam ACCEL_STEP=(MANUAL_ACCEL_HZ_S*256*`CFG_CONTROL_PERIOD_US)/1000000;
 // Simplified validation: only reject on invalid parameters, never on system state.
   // Slider cmd 10 uses -600..+600; READY interprets each count as 0.3 degrees.
 always @* begin
  result=0;
  // 新增的波形/轨迹命令用 speed 字段承载幅值(0.1°)或点间隔(ms)，不受 0..100 限制。
  if(seq<=0) result=1;
  else if((cmd<8'h20 || cmd>8'h26) && (speed<0 || speed>100)) result=1;
  if(result==0) case(cmd)
   // 软核（本地界面）沿用 ST7789 的状态守卫：正在标定/起摆/平衡/手动时不允许再起摆，
   // 否则点一下"起摆"会把已直立的摆重新打回起摆。串口主机按 PROJECT_ALL 语义
   // （随时可重新起摆），两者互不影响。
   8'h01:if(arg!=0) result=1;
        else if(source_rv && (estop || state==4 || state==1 || state==3 || state==5 ||
                              manual_active || !feedback_ok)) result=2;
   8'h02,8'h0f,8'h13:if(arg!=0) result=1;
   8'h04:if(arg!=0) result=1;
        // 标定中或按键占用时不允许软核复位（同样沿用 ST7789 语义）。
        else if(source_rv && (state==1 || !feedback_ok || (|buttons))) result=2;
   8'h10:if(source_rv ? (arg<0 || arg>100) : (arg<-600 || arg>600)) result=1;
   8'h11:if(arg<0 || arg>100) result=1;
   8'h12:if(arg!=0) result=1;
   8'h14:if(arg!= -1 && arg!=1) result=1;
   8'h30:if(arg!=5 && arg!=10 && arg!=15 && arg!=20) result=1;
   8'h31:if(arg<0 || arg>2) result=1;
   8'h40:if(arg!=0) result=1;
   8'h41:if(arg!=0) result=1;
   8'h42:if(arg<1 || arg>100) result=1;
   8'h43:if(arg<100 || arg>10000) result=1;
   // 波形参数帧：arg=周期ms，speed=幅值(0.1°)
   8'h20,8'h21,8'h22:if(arg<50 || arg>60000 || speed<0 || speed>9000) result=1;
   8'h23:if(arg!=0) result=1;
   // 轨迹点：arg=位置(0.1°)，±180°；轨迹开始：arg=总点数，speed=点间隔ms
   8'h24:if(arg<-1800 || arg>1800) result=1;
        // 软核的 0x24 是"绝对目标"，只能在 RUN（LQR 在线）时改参考。
        else if(source_rv && (!permit || state!=3)) result=2;
   8'h25:if(arg<1 || arg>100000 || speed<0 || speed>1000) result=1;
   8'h26:if(arg!=0) result=1;
   // ---- 双摆扩展：只查参数范围，状态由从摆/控制器自己裁定 ----
   // 0x16 主摆横臂目标 / 0x50 从摆摆角目标 / 0x56·0x63 横臂目标：0.1°，±60°
   8'h16,8'h50,8'h56,8'h63:if(arg<-600 || arg>600) result=1;
   // 0x51 从摆速度上限：0~100 %
   8'h51:if(arg<0 || arg>100) result=1;
   // 0x52 回零 / 0x53 起摆 / 0x54 停止 / 0x55 复位 / 0x60 同步起摆 / 0x61 同步停止
   8'h52,8'h53,8'h54,8'h55,8'h60,8'h61:if(arg!=0) result=1;
   // 0x62 位置协同开关：0/1
   8'h62:if(arg!=0 && arg!=1) result=1;
   default:result=3;
  endcase
 end
 // 高频轨迹点不应答，避免把上行链路淹没在回执里。
 // 软核的 0x24 是"绝对目标"，不是轨迹点，必须给回执（界面要轮询结果）。
 wire wants_ack=(cmd==8'h14 || cmd==8'h30 || cmd==8'h31) ? 1'b0 :
                (cmd==8'h24) ? source_rv : 1'b1;
 wire [RECORD_AW-1:0] record_write_address=record_count[RECORD_AW-1:0];
 wire [RECORD_AW-1:0] record_read_address=record_count==0 ? 0:record_count[RECORD_AW-1:0]-1'b1;
 wire record_write=ms_tick && recording && record_tick==99 && record_count<RECORD_DEPTH;
 wire [671:0] record_read_data;
 hmi_record_ram #(.DEPTH(RECORD_DEPTH)) trace_ram(clk,record_write,record_write_address,record_read_address,values,record_read_data);
 always @(posedge clk) record_probe<=record_read_data;
 always @(posedge clk or negedge rst_n) begin
  if(!rst_n) begin
   us_count<=0;milliseconds<=0;estop<=0;stopped<=0;manual_active<=0;position_mode<=1;
   target<=0;speed_limit<=30;jog_direction<=0;relative_move<=0;relative_start_pulses<=0;relative_pulse_limit<=0;
   lease<=300;manual_frequency_q8<=0;position_settle_frames<=0;
   arm_target_valid<=0;arm_target_pending<=0;arm_speed_valid<=0;arm_hold_valid<=0;
   previous_arm<=0;arm_velocity<=0;
   for(bank=0;bank<3;bank=bank+1) begin
    seq_bank[bank]<=0;result_bank[bank]<=0;cmd_bank[bank]<=0;
    arg_bank[bank]<=0;speed_bank[bank]<=0;seen_bank[bank]<=0;
   end
   heartbeat<=1;ack_valid<=0;ack_seq<=0;ack_result<=0;ack_source<=0;remote_start<=0;remote_reset<=0;
   record_id<=0;recording<=0;record_full<=0;record_origin<=0;run_origin<=0;enter_time<=0;capture_time<=0;
   swing_time<=0;stable_ms<=0;band<=20;hold_ms<=1000;hold_count<=0;
   active_attempt<=0;entered<=0;captured<=0;qualification<=0;previous_state<=0;
   mean<=0;peak<=0;stats_count<=0;stats_sum<=0;stats_tick<=0;record_count<=0;record_tick<=0;
   divide_busy<=0;divide_index<=0;dividend<=0;divisor<=1;quotient<=0;remainder<=0;
   wave_set<=0;wave_kind<=0;wave_period_us<=0;wave_amp_q16<=0;wave_stop<=0;track_request<=0;
   point_valid<=0;point_q16<=0;wave_amp_raw<=0;point_raw<=0;
   slave_req_valid<=0;slave_req_op<=8'd0;slave_req_arg<=16'sd0;sync_enable<=0;
   amp_trigger<=0;point_trigger<=0;pending_wave<=0;pending_point<=0;scale_kind<=0;scale_delay<=0;
  end else begin
   remote_start<=0;remote_reset<=0;previous_state<=state;
   wave_set<=0;point_valid<=0;wave_stop<=0;
   // 0.1° -> Q16 角度转换调度：命令间隔远大于 33 拍，这里只做串行排队。
   if(amp_trigger) amp_trigger<=0;
   if(point_trigger) point_trigger<=0;
   if(scale_kind==2'd0) begin
    if(pending_wave) begin scale_kind<=2'd1;scale_delay<=0;amp_trigger<=1;pending_wave<=0;end
    else if(pending_point) begin scale_kind<=2'd2;scale_delay<=0;point_trigger<=1;pending_point<=0;end
   end else if(scale_delay<40) scale_delay<=scale_delay+1'b1;
   else begin
    if(scale_kind==2'd1) begin wave_amp_q16<=amp_scale_out;wave_set<=1;end
    else begin point_q16<=point_scale_out;point_valid<=1;end
    scale_kind<=2'd0;
   end
   arm_target_valid<=arm_target_pending[65];
   arm_target_pending<={arm_target_pending[64:0],1'b0};
   arm_speed_valid<=0;arm_hold_valid<=0;
   slave_req_valid<=0;
   if(ack_valid && ack_ready) ack_valid<=0;
   if(snapshot_sent) heartbeat<=heartbeat+1'b1;
   if(divide_busy) begin
    dividend<=dividend<<1;quotient<=quotient_next;
    remainder<=subtract_divisor ? remainder_next-{1'b0,divisor}:remainder_next;
    divide_index<=divide_index+1'b1;
    if(divide_index==31) begin mean<=quotient_next;divide_busy<=0;end
   end
   if(us_tick) begin
    if(ms_tick) begin us_count<=0;milliseconds<=milliseconds+1'b1;end
    else us_count<=us_count+1'b1;
   end
   if(sample_valid) begin
    arm_velocity<=scaled_arm_velocity;
    previous_arm<=arm;
    if(!manual_run) manual_frequency_q8<=0;
    else if(delta_freq>ACCEL_STEP) manual_frequency_q8<=manual_frequency_q8+ACCEL_STEP;
    else if(delta_freq< -ACCEL_STEP) manual_frequency_q8<=manual_frequency_q8-ACCEL_STEP;
    else manual_frequency_q8<=desired_freq;
    if(manual_run && position_mode && position_error<10 && position_error> -10 && manual_frequency_q8==0) begin
     if(position_settle_frames==2) begin manual_active<=0;position_settle_frames<=0;end
     else position_settle_frames<=position_settle_frames+1'b1;
    end else position_settle_frames<=0;
   end
   if(!manual_run) manual_frequency_q8<=0;
   if(!permit || (|buttons) || screen_boot) begin
    manual_active<=0;relative_move<=0;
   end
   if(RELATIVE_MANUAL && relative_move && relative_pulse_done) begin
    manual_active<=0;relative_move<=0;manual_frequency_q8<=0;
   end
   if(state==3) manual_active<=0;
   if(ms_tick) begin
    if(lease<300) lease<=lease+1'b1;
    // Legacy jog commands use a 300 ms lease. Relative slider moves are
    // pulse-counted and must run to their requested displacement instead.
    if(lease>=299 && !position_mode && !relative_move) manual_active<=0;
    if(active_attempt && !captured) swing_time<=milliseconds-record_origin-run_origin;
    if(active_attempt && in_band) begin
     if(!qualification) begin qualification<=1;hold_count<=1;enter_time<=elapsed_record;entered<=1;end
     else if(!captured && elapsed_record-enter_time>=hold_ms) begin captured<=1;capture_time<=elapsed_record;swing_time<=elapsed_record-run_origin;end
     else if(!captured) hold_count<=hold_count+1'b1;
     stable_ms<=stable_ms+1'b1;
    end else begin qualification<=0;hold_count<=0;stable_ms<=0;end
    if(captured && state==3 && inputs_ok && stats_count<500) begin
     if(stats_tick==9) begin
      stats_tick<=0;stats_count<=stats_count+1'b1;stats_sum<=stats_sum+absolute_error;
      dividend<=stats_sum+absolute_error;divisor<={23'd0,stats_count}+1'b1;
      quotient<=0;remainder<=0;divide_index<=0;divide_busy<=1;
      if(absolute_error>peak) peak<=absolute_error;
     end else stats_tick<=stats_tick+1'b1;
    end
    if(recording) begin
     if(record_tick==99) begin
      record_tick<=0;
      if(record_count<RECORD_DEPTH) record_count<=record_count+1'b1;
      if(record_count==RECORD_DEPTH-1) begin recording<=0;record_full<=1;end
     end else record_tick<=record_tick+1'b1;
    end
   end
   if(buttons[0] && !estop) begin
    active_attempt<=1;captured<=0;entered<=0;qualification<=0;hold_count<=0;stable_ms<=0;
    run_origin<=elapsed_record;enter_time<=-1;capture_time<=-1;swing_time<=0;
    stats_count<=0;stats_sum<=0;stats_tick<=0;mean<=0;peak<=0;stopped<=0;divide_busy<=0;
   end
   if(state==4 || (previous_state==3 && state!=3) || (previous_state==5 && state!=5 && state!=3)) begin
    active_attempt<=0;qualification<=0;hold_count<=0;stable_ms<=0;
   end
   if(screen_boot) begin
    for(bank=0;bank<3;bank=bank+1) seen_bank[bank]<=0;
    manual_active<=0;relative_move<=0;arm_target_pending<=0;
   end
   if(rx_valid) begin
    // Safety stop/estop always accepted regardless of seq/validation.
    if(cmd==8'h02 || cmd==8'h0f || cmd==8'h13 || cmd==8'h61) begin
     manual_active<=0;relative_move<=0;manual_frequency_q8<=0;arm_target_pending<=0;arm_target_valid<=0;
    end
    if(cmd==8'h02 || cmd==8'h0f || cmd==8'h61) begin stopped<=1;active_attempt<=0;qualification<=0;stable_ms<=0;
      track_request<=0;wave_stop<=1;end
    if(cmd==8'h0f) estop<=1;
    // 三台主机的 seq 各自独立，各用各的银行，绝不互相判重。
    if(seen && seq<=last_seq) begin
     if(wants_ack) begin
      ack_valid<=1;ack_seq<=seq;ack_source<=src_index;
      ack_result<=(seq==last_seq && cmd==last_cmd && arg==last_arg && speed==last_speed) ? last_result:4;
     end
    end else begin
     seen_bank[src_index]<=1;seq_bank[src_index]<=seq;cmd_bank[src_index]<=cmd;
     arg_bank[src_index]<=arg;speed_bank[src_index]<=speed;result_bank[src_index]<=result;
     if(wants_ack) begin ack_valid<=1;ack_seq<=seq;ack_source<=src_index;ack_result<=result;end
     if(result==0) case(cmd)
      8'h01:begin
       remote_start<=1;estop<=0;stopped<=0;manual_active<=0;relative_move<=0;active_attempt<=1;captured<=0;entered<=0;
       arm_target_pending<=0;
       qualification<=0;hold_count<=0;stable_ms<=0;run_origin<=elapsed_record;enter_time<=-1;capture_time<=-1;swing_time<=0;
       stats_count<=0;stats_sum<=0;stats_tick<=0;mean<=0;peak<=0;divide_busy<=0;
      end
      8'h04:begin
       remote_reset<=1;estop<=0;stopped<=0;manual_active<=0;relative_move<=0;manual_frequency_q8<=0;
       arm_target_pending<=0;
       active_attempt<=0;captured<=0;qualification<=0;hold_count<=0;stable_ms<=0;
       position_settle_frames<=0;lease<=300;target<=0;
      end
       // Arm target: legacy absolute mapping, except that top-level READY
       // cmd 10 uses a relative pulse-counted move.
      8'h10,8'h12:begin
        if(source_rv) begin
         // 本地触摸界面（ST7789 原语义）：0x10 = 0..100 映射 0..360°，0x12 = 回零。
         target<=cmd==8'h12 ? 0:arg*360;
         position_mode<=1;
         relative_move<=0;
         arm_speed_valid<=1;
         if(state==3) begin
          // RUN 里改的是 LQR 参考，不走开环手动。
          arm_target_pending[0]<=1;manual_active<=0;manual_frequency_q8<=0;
         end else begin
          arm_target_pending[0]<=1;manual_active<=1;position_settle_frames<=0;speed_limit<=speed;
         end
        end else if(RELATIVE_MANUAL && cmd==8'h10) begin
         if(state==2) begin
          // READY slider commands are relative: one count is 0.3 degrees.
          // Completion is based only on emitted step pulses, never encoder pose.
          target<=arg*30;
          arm_target_pending<=0;
          arm_speed_valid<=1;
          position_mode<=0;
          position_settle_frames<=0;
          speed_limit<=speed;
          jog_direction<=arg;
          relative_start_pulses<=signed_pulses;
          relative_pulse_limit<=relative_pulse_count(arg);
          if(arg==0 || relative_pulse_count(arg)==0) begin
           manual_active<=0;relative_move<=0;manual_frequency_q8<=0;
          end else begin
           manual_active<=1;relative_move<=1;
          end
         end else if(state==3) begin
          // RUN remains on its LQR reference path with the legacy absolute map.
          target<=(arg+600)*30;
          arm_target_pending[0]<=1;arm_speed_valid<=1;relative_move<=0;
          manual_active<=0;manual_frequency_q8<=0;
         end else begin
          // Do not leave a deferred slider command to start on a later READY entry.
          manual_active<=0;relative_move<=0;manual_frequency_q8<=0;arm_target_pending<=0;
         end
        end else begin
         target<=cmd==8'h12 ? 18000 : (arg+600)*30;
         arm_target_pending[0]<=1;arm_speed_valid<=1;
         relative_move<=0;
         if(state!=3) begin manual_active<=1;position_mode<=1;position_settle_frames<=0;speed_limit<=speed;end
         else begin manual_active<=0;manual_frequency_q8<=0;end
        end
      end
      // Speed slider: raw 0-100 stored; arm_speed_percent maps 0->1x, 100->4x combinatorially.
      8'h11:begin speed_limit<=arg;arm_speed_valid<=1;end
      // Jog (点动): lease-based in READY, nudges target ±0.2° in RUN.
      8'h14:begin
       position_mode<=0;relative_move<=0;jog_direction<=arg;lease<=0;speed_limit<=speed;arm_speed_valid<=1;
       if(state==3) begin
        manual_active<=0;manual_frequency_q8<=0;
        if(arg<0) target<=target>20 ? target-20:0;
        else      target<=target<35980 ? target+20:36000;
        arm_target_pending[0]<=1;
       end else manual_active<=1;
      end
      8'h13:begin manual_active<=0;manual_frequency_q8<=0;arm_hold_valid<=1;end
      8'h40:begin recording<=1;record_full<=0;record_id<=record_id+1'b1;record_origin<=milliseconds;record_count<=0;record_tick<=0;
       run_origin<=-1;enter_time<=-1;capture_time<=-1;swing_time<=0;stable_ms<=0;mean<=0;peak<=0;captured<=0;divide_busy<=0;end
      8'h41:recording<=0;
      8'h42:band<=arg;
      8'h43:hold_ms<=arg;
      // ---- 上位机波形参数帧：波类型在命令字，周期 arg(ms)，幅值 speed(0.1°) ----
      8'h20,8'h21,8'h22:begin
       wave_kind<=cmd[1:0];
       wave_period_us<=(arg<<10)-(arg<<4)-(arg<<3);
       wave_amp_raw<=speed;
       pending_wave<=1;
       track_request<=0;
      end
      8'h23:begin
       if(source_rv) begin
        // 本地触摸界面（ST7789 原语义）：0x23 = 保持当前横臂目标（停波形不动参考）。
        manual_active<=0;manual_frequency_q8<=0;arm_hold_valid<=1;arm_target_pending<=0;
       end else begin wave_stop<=1;track_request<=0;end
      end
      8'h24:begin
       if(source_rv) begin
        // 本地触摸界面（ST7789 原语义）：0x24 = 绝对横臂目标，单位 0.1°。
        target<=arg*10;speed_limit<=speed;position_mode<=1;
        manual_active<=0;manual_frequency_q8<=0;arm_target_pending[0]<=1;arm_speed_valid<=1;
       end else begin point_raw<=arg;pending_point<=1;end
      end
      8'h25:begin track_request<=1;end
      8'h26:begin track_request<=0;end
      // ============ 双摆扩展（HMI 2.1 从摆页）============
      // 0x16 主摆横臂目标：0.1°，±60°，中心 = 回零位置 180.0°。
      // RUN 里改的是 LQR 参考；READY 里按绝对位置走一次手动定位。
      8'h16,8'h63:begin
       target<=32'sd18000+arg*10;
       arm_target_pending[0]<=1;arm_speed_valid<=1;relative_move<=0;jog_direction<=0;
       if(state==2) begin
        manual_active<=1;position_mode<=1;position_settle_frames<=0;speed_limit<=speed;
       end else begin
        manual_active<=0;manual_frequency_q8<=0;
       end
       // 0x63 双摆：同一横臂目标再下发给从板（0.01°）
       if(cmd==8'h63) begin
        slave_req_valid<=1;slave_req_op<=8'h33;slave_req_arg<=arg*10;
       end
      end
      // 0x50 从摆摆角目标（0.1° → 从板 0.01°）
      8'h50:begin slave_req_valid<=1;slave_req_op<=8'h32;slave_req_arg<=arg*10;end
      // 0x51 从摆速度上限 0~100
      8'h51:begin slave_req_valid<=1;slave_req_op<=8'h34;slave_req_arg<=arg;end
      // 0x52 从摆回零
      8'h52:begin slave_req_valid<=1;slave_req_op<=8'h35;slave_req_arg<=16'sd0;end
      // 0x53 从摆起摆 → OP20 子命令 01
      8'h53:begin slave_req_valid<=1;slave_req_op<=8'h20;slave_req_arg<=16'sd1;end
      // 0x54 从摆停止 → OP20 子命令 02（从板急停/停机路径）
      8'h54:begin slave_req_valid<=1;slave_req_op<=8'h20;slave_req_arg<=16'sd2;end
      // 0x55 从摆复位 → OP20 子命令 05（清远程急停）
      8'h55:begin slave_req_valid<=1;slave_req_op<=8'h20;slave_req_arg<=16'sd5;end
      // 0x56 从摆横臂目标
      8'h56:begin slave_req_valid<=1;slave_req_op<=8'h33;slave_req_arg<=arg*10;end
      // 0x60 双摆同步起摆：主摆按 0x01 起摆，从摆收 OP20/01
      8'h60:begin
       remote_start<=1;estop<=0;stopped<=0;manual_active<=0;relative_move<=0;active_attempt<=1;captured<=0;entered<=0;
       arm_target_pending<=0;
       qualification<=0;hold_count<=0;stable_ms<=0;run_origin<=elapsed_record;enter_time<=-1;capture_time<=-1;swing_time<=0;
       stats_count<=0;stats_sum<=0;stats_tick<=0;mean<=0;peak<=0;divide_busy<=0;
       slave_req_valid<=1;slave_req_op<=8'h20;slave_req_arg<=16'sd1;
      end
      // 0x61 双摆同步停止：主摆停止已在上面 common 路径做掉，这里只补从摆
      8'h61:begin slave_req_valid<=1;slave_req_op<=8'h20;slave_req_arg<=16'sd2;end
      // 0x62 位置协同开关
      8'h62:begin sync_enable<=arg[0];slave_req_valid<=1;slave_req_op<=8'h38;slave_req_arg<=arg[15:0];end
      default:begin end
     endcase
    end
   end
  end
 end
endmodule
