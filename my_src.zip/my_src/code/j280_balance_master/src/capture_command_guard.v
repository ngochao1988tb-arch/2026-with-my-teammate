`timescale 1ns/1ps
`include "control_config.vh"
// Preview -K*x at the measured capture state with a bit-serial multiplier.
// No DSP blocks are taken away from the time-critical live control datapath.
// tick follows the speed estimator by one clock. Completion takes 178 clocks;
// the supervisor decides at sample+256. Validity never survives a new tick.
module capture_command_guard(
    input clk, rst_n, tick, enable,
    input signed [31:0] alpha, theta, alpha_dot, theta_dot, alpha_c, swing_u,
    output reg compatible,
    output reg signed [31:0] candidate_u,
    output reg candidate_valid,
    input signed [31:0] arm_reference_q16
);
    `include "lqr_coefficients.vh"
    localparam signed [67:0] U_MAX=(`CFG_PULSE_RAD_Q32*64'sd1*`CFG_CONTROL_MAX_FREQUENCY_HZ)>>>16;
    localparam signed [67:0] MAX_JUMP=$rtoi(`CFG_SWINGUP_CAPTURE_COMMAND_JUMP_RAD_S*65536.0);
    reg signed [31:0] snapshot[0:4];
    
    reg signed [63:0] product;
    reg signed [63:0] partial, multiplicand;
    reg [31:0] multiplier;
    reg negative_operand;
    reg [4:0] bit_index;
    reg signed [67:0] accumulator;
    wire signed [67:0] sum=accumulator+{{4{product[63]}},product};
    reg signed [67:0] command, difference;
    reg output_fits;
    reg [2:0] stage;
    reg [2:0] col;
    integer i;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            compatible<=0;candidate_u<=0;stage<=0;col<=0;product<=0;accumulator<=0;candidate_valid<=0;
            partial<=0;multiplicand<=0;multiplier<=0;negative_operand<=0;bit_index<=0;
            command<=0;difference<=0;output_fits<=0;
            for(i=0;i<5;i=i+1) snapshot[i]<=0;
        end else if(!enable) begin compatible<=0;stage<=0;candidate_u<=0;candidate_valid<=0;end
        else begin
        // Recheck against the live swing command after approach control updates.
        // The two-clock pipeline settles well before the sample+256 decision.
        if(candidate_valid) begin
            difference<=command-$signed(swing_u);
            compatible<=output_fits && difference<=MAX_JUMP && difference>=-MAX_JUMP;
        end
        if(tick) begin
            snapshot[0]<=alpha-arm_reference_q16;snapshot[1]<=theta;snapshot[2]<=alpha_dot;
            snapshot[3]<=theta_dot;snapshot[4]<=alpha_c-arm_reference_q16;candidate_valid<=0;
            compatible<=0;col<=0;accumulator<=0;stage<=1;
        end else case(stage)
            1:begin
                multiplicand<=$signed(coefficient(24+col));
                multiplier<=snapshot[col][31] ? -snapshot[col] : snapshot[col];
                negative_operand<=snapshot[col][31];partial<=0;bit_index<=0;stage<=2;
            end
            2:begin
                partial<=partial+(multiplier[0] ? multiplicand : 64'sd0);
                multiplicand<=multiplicand<<<1;multiplier<=multiplier>>1;
                if(bit_index==31) stage<=3;else bit_index<=bit_index+1'b1;
            end
            3:begin product<=negative_operand ? -partial : partial;stage<=4;end
            4:begin
                accumulator<=sum;
                if(col==4) begin
                    stage<=5;
                end else begin col<=col+1'b1;stage<=1;end
            end
            5:begin command<=-(accumulator>>>20);stage<=6;end
            6:begin
                difference<=command-$signed(swing_u);
                output_fits<=command<=U_MAX && command>=-U_MAX;
                candidate_u<=command>68'sd2147483647 ? 32'sh7fffffff :
                             command< -68'sd2147483648 ? 32'sh80000000 : command[31:0];
                stage<=7;
            end
            7:begin candidate_valid<=1;compatible<=output_fits && difference<=MAX_JUMP && difference>=-MAX_JUMP;stage<=0;end
            default:stage<=0;
        endcase
        end
    end
endmodule
