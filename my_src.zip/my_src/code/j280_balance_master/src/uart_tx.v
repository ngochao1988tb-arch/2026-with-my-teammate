`timescale 1ns / 1ps

module uart_tx #(
    parameter integer CLK_HZ = 50_000_000,
    parameter integer BAUD   = 115200
) (
    input  wire       clk,
    input  wire       rst_n,
    input  wire       start,
    input  wire [7:0] data,
    output reg        tx,
    output reg        busy,
    output reg        done
);

    localparam integer DIV = (CLK_HZ + BAUD / 2) / BAUD;

    reg [31:0] ticks;
    reg [3:0]  bit_index;
    reg [9:0]  frame;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            tx        <= 1'b1;
            busy      <= 1'b0;
            done      <= 1'b0;
            ticks     <= 32'd0;
            bit_index <= 4'd0;
            frame     <= 10'h3FF;
        end else begin
            done <= 1'b0;

            if (!busy) begin
                tx <= 1'b1;
                if (start) begin
                    frame     <= {1'b1, data, 1'b0};
                    tx        <= 1'b0;
                    busy      <= 1'b1;
                    ticks     <= 32'd0;
                    bit_index <= 4'd0;
                end
            end else if (ticks == DIV - 1) begin
                ticks <= 32'd0;
                if (bit_index == 4'd9) begin
                    busy <= 1'b0;
                    done <= 1'b1;
                    tx   <= 1'b1;
                end else begin
                    bit_index <= bit_index + 1'b1;
                    frame     <= {1'b1, frame[9:1]};
                    tx        <= frame[1];
                end
            end else begin
                ticks <= ticks + 1'b1;
            end
        end
    end

endmodule
