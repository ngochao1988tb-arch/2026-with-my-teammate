// 调参入口：直接修改本文件，保存后重新综合/布局布线/生成位流。
// 2026-11-02：整体换成 LQR_sine_move（26103191 版）的控制参数集 —— 0.5 ms 控制周期、
// 2 ms 动作采样、新的直立零点与半周计数、三级 RUN 陷波、起摆单次助推与捕获保持。
`ifndef CONTROL_CONFIG_VH
`define CONTROL_CONFIG_VH

// 浮点增益只在编译时转换为 Q20；运行时仍是整数定点运算。
`define CFG_Q20(x) ($rtoi((x)*1048576.0 + (((x)<0.0) ? -0.5 : 0.5)))


// 硬件方向和机械比例：方向/使能填 0 或 1；时钟与开发板及 SDC 约束保持一致。
`define CFG_HARDWARE_CLOCK_HZ 32'sd25000000
`define CFG_HARDWARE_ENCODER_INVERT 32'sd0
`define CFG_HARDWARE_THETA_INVERT 32'sd1
`define CFG_HARDWARE_ENABLE_ACTIVE_HIGH 32'sd1
`define CFG_HARDWARE_PULSES_PER_REVOLUTION 32'sd3200
`define CFG_HARDWARE_ENCODER_COUNTS_PER_REVOLUTION 32'sd65536

// 控制和脉冲：时间单位 us，频率 Hz。改控制周期时须同步修改后面的离散预测矩阵。
`define CFG_CONTROL_PERIOD_US 32'sd500
// LQR 执行周期：ADC/监督器/起摆仍按 0.5 ms 帧运行，但 LQR+观测器+陷波按 3 ms
// 一拍执行（core_tick 6 分频），与 PROJECT_ALL 的稳态节奏一致。
// 目的：① 降低环路对 8~15 Hz 模态的增益；② 3 ms 一拍 > 编码器 ~2 ms 样本间隔，
// 每拍都有新鲜样本，不再有纯预测迭代累积误差。改此值须同步 3 ms 预测矩阵与陷波。
`define CFG_LQR_PERIOD_US 32'sd3000
// 编码器差分、观测器横臂修正与偏置学习仍按 2 ms 设计尺度运行。
`define CFG_MOTION_PERIOD_US 32'sd2000
`define CFG_OBSERVER_ARM_DESIGN_PERIOD_US 32'sd2000
// trim 积分步长按 LQR 实际执行周期计（3 ms），否则积分速率会慢 6 倍。
`define CFG_RUN_TRIM_UPDATE_US 32'sd3000
`define CFG_RUN_NOTCH_ALIGN_ZEROS 1
`define CFG_CONTROL_MAX_FREQUENCY_HZ 32'sd4000
`define CFG_CONTROL_DIR_SETUP_US 32'sd10
`define CFG_CONTROL_PULSE_HIGH_US 32'sd5

// ADC：AD=floor(样本总和*OUTPUT_SCALE/SAMPLES_PER_CONTROL)+OUTPUT_OFFSET；平均样本数须为 2 的幂。
// 同一 0.5 ms 窗口内均匀取 256 点；不增加额外的整帧滤波等待。
`define CFG_ADC_SAMPLES_PER_CONTROL 32'sd256
`define CFG_ADC_OUTPUT_SCALE 32'sd4
`define CFG_ADC_OUTPUT_OFFSET 32'sd135
// 26103145：帧级自适应一阶滤波。慢/快 EMA 位移与逐帧运动判据（Q16 计数）。
`define CFG_ADC_ALPHA_SLOW_SHIFT 9
`define CFG_ADC_ALPHA_FAST_SHIFT 6
`define CFG_ADC_MOTION_TH_HI_Q16 32'sd8192
`define CFG_ADC_MOTION_TH_LO_Q16 32'sd2048
`define CFG_ADC_MOTION_HOLD_FRAMES 4

// 摆杆直立零点，使用 ad_value/上传 AD 的单位；SW1 不会覆盖此值。
// 与 PROJECT_ALL 保持一致：直立零点 1560。半周仍按本机传感器标定 2448 计数。
`define CFG_ADC_FIXED_ZERO 32'sd1560
`define CFG_ADC_THETA_COUNTS_PER_PI 32'sd2448
`define CFG_ADC_RAIL_MIN 32'sd175
`define CFG_ADC_RAIL_MAX 32'sd4187

// 横臂手动定位/点动允许摆杆处于下垂端点；仍要求 ADC 在物理输出范围内、
// 反馈新鲜、已标定且 READY。此选项不放宽自动起摆或 LQR 的 ADC 保护。
`define CFG_HMI_MANUAL_ALLOW_HANGING_ENDPOINT 32'sd1

// 标定/保护：时间单位 us，稳定度单位传感器计数；当前没有启动速度门槛。
`define CFG_SUPERVISOR_ENCODER_TIMEOUT_US 32'sd30000
`define CFG_SUPERVISOR_ADC_TIMEOUT_US 32'sd9000
`define CFG_SUPERVISOR_CALIBRATION_TIMEOUT_US 32'sd2000000
`define CFG_SUPERVISOR_CALIBRATION_MIN_US 32'sd120000
`define CFG_SUPERVISOR_STABLE_ADC_FRAMES 32'sd240
`define CFG_SUPERVISOR_STABLE_ENCODER_SAMPLES 32'sd3
`define CFG_SUPERVISOR_ADC_STABILITY_COUNTS 32'sd8
`define CFG_SUPERVISOR_ENCODER_STABILITY_COUNTS 32'sd8
`define CFG_SUPERVISOR_WARMUP_FRAMES 32'sd240
`define CFG_SUPERVISOR_SATURATION_TIMEOUT_US 32'sd501000

// SW1 一键起摆：稳定标定横臂后自动进入 SWINGUP，不需要再按 SW2。
`define CFG_SUPERVISOR_SW1_AUTOSTART 32'sd1
// 以下为待实机整定的起摆初始值。
`define CFG_SWINGUP_ENABLED 32'sd1
// 26103160：支点库仑摩擦约为旧值的 5-8 倍，单周期需要更大驱动、更长时间建立能量。
// 26103191：所有起摆主动驱动频率/加速度统一降到 80%。捕获判据、相位时序、
// 行程包络与 RUN 增益均不变。
`define CFG_SWINGUP_MAX_FREQUENCY_HZ 32'sd2080
`define CFG_SWINGUP_ACCEL_HZ_PER_S 32'sd20800
// Recovery 是速度指令减速，不是物理制动保证。
// 26110306：重新起摆起始回收减速再增强 10%（126720 -> 139392）。
`define CFG_SWINGUP_RECOVERY_ACCEL_HZ_PER_S 32'sd139392
// 26103185：允许在现有软行程范围内就地捕获；目标在捕获瞬间锁存，不再要求回到原点。
`define CFG_SWINGUP_CAPTURE_ARM_POSITION_DEG 78.0
// 行程保护：31.25 ms 速度外推，速度无效时保留 5 deg 余量。
`define CFG_ARM_TRAVEL_LOOKAHEAD_SHIFT 32'sd5
`define CFG_ARM_TRAVEL_INVALID_MARGIN_DEG 5.0
`define CFG_SWINGUP_TIMEOUT_US 32'sd25000000
`define CFG_SWINGUP_KICK_US 32'sd495000 // 26103176：单次动作时间 +50%（原 330000）
// 2026-10-22 收紧直立捕获，避免在接近门限时带着较大摆速切入 RUN。
// 26103181：在更靠近直立处才交接给未改动的 RUN 控制器。180 号在 15.5 deg 捕获后 0.46 s 离开 RUN。
// 26110305：捕获摆角、摆速及横臂速度上限各放宽 5%；确认时长和行程保护不变。
`define CFG_SWINGUP_CAPTURE_ANGLE_DEG 12.6
`define CFG_SWINGUP_CAPTURE_SPEED_RAD_S 3.78
`define CFG_SWINGUP_CAPTURE_FRAMES 32'sd20
// 仅在横臂实测运动与电机指令都不大时捕获。
// 26103189：捕获试值从 3.0 放宽到 3.5 rad/s。该上限同时用于实测横臂速度和
// 出去的那一帧起摆指令。Approach 段不变。
`define CFG_SWINGUP_CAPTURE_ARM_SPEED_RAD_S 3.675
`define CFG_SWINGUP_CAPTURE_TRACKING_DEG 13.5
// 拒绝那些初始全量 LQR 指令已饱和、或与起摆指令差太多的捕获。RUN 内不加限速。
`define CFG_SWINGUP_CAPTURE_COMMAND_JUMP_RAD_S 4.5
// 原始（未滤波）样本速度与 21 ms 匀速外推保护。
`define CFG_SWINGUP_CAPTURE_INSTANT_SPEED_RAD_S 6.75
`define CFG_SWINGUP_CAPTURE_LOOKAHEAD_FRAMES 32'sd11
`define CFG_SWINGUP_CAPTURE_PROJECTED_ANGLE_DEG 31.5
// 捕获前的实测状态局部反馈。超出该区域继续能量泵。
`define CFG_SWINGUP_APPROACH_ENTRY_DEG 30.0
`define CFG_SWINGUP_APPROACH_EXIT_DEG 35.0
`define CFG_SWINGUP_APPROACH_SPEED_RAD_S 10.0
`define CFG_SWINGUP_APPROACH_INSTANT_RAD_S 14.0
`define CFG_SWINGUP_APPROACH_ARM_SPEED_RAD_S 6.5
`define CFG_SWINGUP_APPROACH_MAX_FREQUENCY_HZ 32'sd1920
// 26110203：捕获前接近段指令变化率增加 10%，让减速目标跟随更快。
`define CFG_SWINGUP_APPROACH_ACCEL_HZ_PER_S 32'sd126720
// 26110306：首次捕获前减速再增强约 5%（168664 -> 177097）。
// 换向仍先减至零，再按原加速档反向。
`define CFG_SWINGUP_APPROACH_DECEL_HZ_PER_S 32'sd177097
// 重新起摆捕获前增幅更大：再增强约 10%（177097 -> 194807），仅作用于本轮 retry。
`define CFG_SWINGUP_RETRY_APPROACH_DECEL_HZ_PER_S 32'sd194807
`define CFG_SWINGUP_APPROACH_QUAL_FRAMES 32'sd5
// 26103186：当横臂速度/预判链路恢复期间，有限时长保持上一个有效 approach 目标。
// 摆杆与行程保护仍然立即生效。
`define CFG_SWINGUP_APPROACH_HOLD_US 12000
// 26103185 实验性单次助推，之后回到常规能量/approach。
// 方向 0 跟随本板实测可见侧第一次摆动。指令是脉冲频率（不是转矩）；
// 监督器与行程限制照常生效。
`define CFG_SWINGUP_LAUNCH_ENABLED 1
`define CFG_SWINGUP_LAUNCH_NEGATIVE 0
`define CFG_SWINGUP_LAUNCH_PRIME_HZ 2400
`define CFG_SWINGUP_LAUNCH_PRIME_ACCEL 32000
`define CFG_SWINGUP_LAUNCH_PRIME_MIN_US 80000
`define CFG_SWINGUP_LAUNCH_PRIME_MAX_US 240000
`define CFG_SWINGUP_LAUNCH_PRIME_ARM_DEG 45.0
`define CFG_SWINGUP_LAUNCH_REVERSE_HZ 2560
`define CFG_SWINGUP_LAUNCH_REVERSE_ACCEL 64000
`define CFG_SWINGUP_LAUNCH_REVERSE_MAX_US 240000
// 已观测到下垂 AD=135/4227 端点：仅 SW1 标定/起摆允许短时端点脱离。
// 端点没有可靠摆角反馈，超过以下任一界限必须故障停机；RUN 仍严格检查原量程。
`define CFG_SWINGUP_ENDPOINT_ESCAPE_ENABLED 32'sd1
// 端点试探单独限速/换向，给第一次试探留出减速反向的时间。
// 首段 180 ms，随后每 360 ms 切换加速度，覆盖初始位置两侧，避免同侧往复。
`define CFG_SWINGUP_ENDPOINT_MAX_FREQUENCY_HZ 32'sd960
`define CFG_SWINGUP_ENDPOINT_KICK_US 32'sd180000
// 死区跳变不参与差分；35 rad/s 为样本合理性上限，不是起摆目标速度。
`define CFG_SWINGUP_MAX_VALID_SPEED_RAD_S 35.0
`define CFG_SWINGUP_VELOCITY_RECOVERY_FRAMES 32'sd5
`define CFG_SWINGUP_ENDPOINT_TIMEOUT_US 32'sd2000000
`define CFG_SWINGUP_ENDPOINT_TRAVEL_DEG 90.0
`define CFG_SWINGUP_ENDPOINT_RECOVERY_FRAMES 32'sd20
// 横臂相对 SW1 标定位置：软边界回拉，硬边界锁存故障；编码器和实际脉冲均检查。
`define CFG_SWINGUP_SOFT_ARM_DEG 78.0 // 26103176：+30%（原 60）
`define CFG_ARM_GUARD_SCALE 1.3 // 26103176：行程包络 60/70/80/85 -> 78/91/104/110.5
`define CFG_SWINGUP_HARD_ARM_DEG 360.0
// 26110205：超包络先限幅；连续受限且摆杆明显向外倾倒才请求重新起摆。
`define CFG_RUN_TRAVEL_RECOVERY_US 32'sd100000
`define CFG_RUN_TRAVEL_RECOVERY_ANGLE_DEG 25.0
`define CFG_RUN_TRAVEL_RECOVERY_SPEED_RAD_S 0.5
// 摆杆非线性模型 h/b，能量判据为 theta_dot^2 < 2*(h/b)*(1-cos(theta))。
`define CFG_SWINGUP_H_OVER_B 133.2905

// 按键消抖，单位 ms。
`define CFG_BUTTONS_DEBOUNCE_MS 32'sd20

// 电机串口：波特率、地址、查询间隔及超时 ms，须与驱动器一致。
`define CFG_MOTOR_UART_BAUD 32'sd115200
`define CFG_MOTOR_UART_ADDRESS 32'sd1
`define CFG_MOTOR_UART_POLL_MS 32'sd1
`define CFG_MOTOR_UART_TIMEOUT_MS 32'sd5
`define CFG_MOTOR_UART_BYTE_TIMEOUT_MS 32'sd2
`define CFG_MOTOR_UART_DATA_MSB_FIRST 32'sd1

// 电脑上传：波特率和快照频率 Hz。
// 128 字节 v4 帧在 100 Hz 下占 128000 bit/s。230400 留有余量，
// 也避开了本板 CH340 实测不可靠的非标 ~961k 链路。
// 电机/HMI 串口不变；LQR 环现在是 0.5 ms。
`define CFG_TELEMETRY_BAUD 32'sd230400
`define CFG_TELEMETRY_RATE_HZ 32'sd100
// 1：K20 输出 126 字节载荷的 v4 调试流，L20 不接收上位机命令。
// 0：恢复 K20/L20 原上位机协议；串口屏、本地触摸和语音不受此开关影响。
// 26110303：改回 0 —— K20 走 115200 10 Hz ASCII 快照（33 字段），
// L20 正常接收 18 字节命令帧，上位机监测/控制同时可用，不再占用 debug 流。
`define CFG_PC_DEBUG_ENABLED 0
// 临时 1 kHz 紧凑诊断流，同样走 230400 波特率。
`define CFG_FAST_DIAG_ENABLED 0
`define CFG_FAST_DIAG_RATE_HZ 1000
`define CFG_FAST_DIAG_STATUS_ENABLED 1

// SW2 允许启动的摆角，以及跌倒停止的摆角，单位 deg。
`define CFG_SUPERVISOR_ENTRY_ANGLE_DEG 20.0
`define CFG_SUPERVISOR_FALLEN_ANGLE_DEG 45.0

// SW2/SW3 during RUN: +/- 50 degree target step with bidirectional wrap.
`define CFG_RUN_TARGET_ANGLE_STEP_DEG 50.0
`define CFG_RUN_TARGET_ANGLE_MAX_DEG 150.0
`define CFG_RUN_TARGET_SLEW_DEG_PER_S 15.0
// SW3 during RUN doubles the target slew rate: 100/200/400/800 percent.
`define CFG_RUN_TARGET_SPEED_MULTIPLIER 2
`define CFG_RUN_TARGET_SPEED_MAX_LEVEL 3

// RUN sine demo: SW2 starts/restarts; SW3 period x4/3; SW4 amplitude x4/3.
`define CFG_SINE_PERIOD_US 10000000
`define CFG_SINE_AMPLITUDE_DEG 60.0
`define CFG_SINE_MAX_PERIOD_US 120000000
`define CFG_SINE_MAX_AMPLITUDE_DEG 180.0
`define CFG_SINE_REFERENCE_LIMIT_DEG 330.0

// RUN 正弦轨迹前馈修正；保持与起摆阶段为零前馈。
// 稳态对齐 PROJECT_ALL：PROJECT_ALL 无正弦前馈，关闭。
`define CFG_SINE_FF_ENABLED 0
`define CFG_SINE_FF_OMEGA_N 58.6
`define CFG_SINE_FF_ZETA 0.37
`define CFG_SINE_FF_C_OVER_B 1.290785
`define CFG_SINE_FF_LIMIT_RAD_S 0.7853981633974483
`define CFG_SINE_FF_SLEW_RAD_S2 0.5

// 整体反馈倍率：1.00 为当前基础增益，1.10 增强 10%；五项增益同时乘此倍率。
// LQR-only trial B：相比上一个 0.45 试值，整体状态反馈增益降低 11.1%。
// 陷波、观测器、限速与保护均不变。
// 0.45 在 2 kHz 下出现小幅震荡（采样率是 PROJECT_ALL 的 6 倍，相位裕度更小），
// 故回到 0.40。
// 26110302：LQR 降到 3 ms 执行后与 PROJECT_ALL 采样率一致，恢复 PROJECT_ALL 的 0.45。
// 0.40 是在 0.5 ms（2 kHz）下为压制小幅震荡而降低的版本；3 ms 下沿用 0.45。
`define CFG_LQR_GAIN_SCALE (0.45)
// RUN 速度指令每次 LQR 更新的最大变化率（按 CFG_LQR_PERIOD_US 折算）；用于压制 10-12 Hz 正反切换。
`define CFG_LQR_COMMAND_SLEW_HZ_PER_S 32'sd40000

// 26110302：LQR 降到 3 ms 后陷波采样率变为 333.33 Hz，三级陷波（按 2 kHz 设计）
// 全部失效，改用 PROJECT_ALL 的单节 9.5 Hz（fs=333.333 Hz, f0=9.5 Hz, r=0.95）。
// Q13 系数与 PROJECT_ALL 的 run_notch.v 完全一致，直流增益为 1。
`define CFG_RUN_NOTCH_CENTER_HZ 9.5
`define CFG_RUN_NOTCH_RADIUS 0.95
`define CFG_RUN_NOTCH_C0_Q13 16'sd8423
`define CFG_RUN_NOTCH_C1_Q13 -16'sd16576
`define CFG_RUN_NOTCH_C2_Q13 16'sd8423
`define CFG_RUN_NOTCH_C3_Q13 16'sd15316
`define CFG_RUN_NOTCH_C4_Q13 -16'sd7394

// 26110302：二级/三级陷波关闭。3 ms 下这两节系数不再对应 12.5/9.77 Hz，
// 三级串联的额外相位滞后会吃掉增益提高后的相位裕度。
`define CFG_RUN_NOTCH_AUX_ENABLED 32'sd0
`define CFG_RUN_NOTCH_AUX_CENTER_HZ 12.5
`define CFG_RUN_NOTCH_AUX_RADIUS 0.9974842302313085
// Q13 b1 调整 1 个 LSB，保持直流增益精确为 1。
`define CFG_RUN_NOTCH_AUX_C0_Q13 16'sd8431
`define CFG_RUN_NOTCH_AUX_C1_Q13 -16'sd16849
`define CFG_RUN_NOTCH_AUX_C2_Q13 16'sd8431
`define CFG_RUN_NOTCH_AUX_C3_Q13 16'sd16330
`define CFG_RUN_NOTCH_AUX_C4_Q13 -16'sd8151
// 26102903：保留低于 Q16 的递归状态，去掉旧的截断偏置。
// 内部状态用 Q(16+13)；输出仍是带符号 Q16。
`define CFG_RUN_NOTCH_GUARD_BITS 13
// 26110302：9.77 Hz 这一节在 3 ms 采样率下无效，关闭。
`define CFG_RUN_NOTCH_977_ENABLED 32'sd0
`define CFG_RUN_NOTCH_977_C0_Q13 16'sd8368
`define CFG_RUN_NOTCH_977_C1_Q13 -16'sd16728
`define CFG_RUN_NOTCH_977_C2_Q13 16'sd8368
`define CFG_RUN_NOTCH_977_C3_Q13 16'sd16294
`define CFG_RUN_NOTCH_977_C4_Q13 -16'sd8110

// LQR 反馈增益：u=-K*x；可以直接改小数，负号也属于增益。
// 顺序：[横臂角度, 摆杆角度, 横臂角速度, 摆杆角速度, 已发脉冲对应的指令位置]。
// 26103167：LQR 增益恢复到 26103160 那一组。
`define CFG_K_ALPHA (-78.704738674689352)
`define CFG_K_THETA (-43.611767000777256)
// 稳态对齐 PROJECT_ALL：横臂角速度反馈增益用 PROJECT_ALL 的值。
`define CFG_K_ALPHA_DOT (-4.394643902965861)
// 稳态对齐 PROJECT_ALL：摆杆角速度反馈增益用 PROJECT_ALL 的值。
`define CFG_K_THETA_DOT (-3.3136303828819944)
`define CFG_K_ALPHA_C (74.734897647687134)

// 26110302：观测器设计元数据同步为 3 ms 尺度（与 PROJECT_ALL 相同极点 [0.55,0.65]）。
// 仅作说明，未被 RTL 引用。
`define CFG_OBSERVER_ARM_POLE_0 0.55
`define CFG_OBSERVER_ARM_POLE_1 0.65
`define CFG_ARM_VELOCITY_WINDOW_US 32'sd12000
// 26110302：LQR/观测器降到 3 ms 执行，观测器增益换回 PROJECT_ALL 的 3 ms 设计值。
// 此时观测器校正周期、3 ms 预测矩阵、增益三者才真正配套（此前 0.5 ms 下曾因
// 周期不匹配而必须保留原值）。编码器 ~2 ms 一个样本 < 3 ms 一拍，每拍都有新样本。
`define CFG_OBSERVER_ARM_POSITION (0.5928313951728901)
`define CFG_OBSERVER_THETA_POSITION (0.51250000000000961)
`define CFG_OBSERVER_ARM_VELOCITY (23.23736168187744)
`define CFG_OBSERVER_THETA_VELOCITY (29.458210724134521)

// 以下为高级模型参数：3 ms 一步的 4x5 离散预测矩阵（与 PROJECT_ALL 完全一致）。
// 列顺序：[alpha, theta, alpha_dot, theta_dot, alpha_c]；行顺序为前四个状态。
// 改周期或重新辨识机械模型后，必须将整组矩阵同步更新，不能只改周期。
`define CFG_PREDICT_0_0 (0.98523379176787751)
`define CFG_PREDICT_0_1 (4.5325958141627958e-20)
`define CFG_PREDICT_0_2 (0.0027985923333043289)
`define CFG_PREDICT_0_3 (4.4263630997683552e-23)
`define CFG_PREDICT_0_4 (0.014766208232122446)
`define CFG_PREDICT_1_0 (0.019061941402589731)
`define CFG_PREDICT_1_1 (1.0005998672138539)
`define CFG_PREDICT_1_2 (0.00025999967999548854)
`define CFG_PREDICT_1_3 (0.0030005998432279012)
`define CFG_PREDICT_1_4 (-0.019061941402589731)
`define CFG_PREDICT_2_0 (-9.6102541288737324)
`define CFG_PREDICT_2_1 (5.5511151231257827e-17)
`define CFG_PREDICT_2_2 (0.8638756338264687)
`define CFG_PREDICT_2_3 (5.4210108624275222e-20)
`define CFG_PREDICT_2_4 (9.6102541288737324)
`define CFG_PREDICT_3_0 (12.407342482224887)
`define CFG_PREDICT_3_1 (0.39995145340376859)
`define CFG_PREDICT_3_2 (0.17574169288461045)
`define CFG_PREDICT_3_3 (1.0005998672138539)
`define CFG_PREDICT_3_4 (-12.407342482224887)

// 以下为自动换算表达式；通常不需要改。
`define CFG_ENCODER_RAD_Q32 ($rtoi(6.2831853071795864769/`CFG_HARDWARE_ENCODER_COUNTS_PER_REVOLUTION*4294967296.0+0.5))
`define CFG_THETA_RAD_Q32 ($rtoi(3.14159265358979323846/`CFG_ADC_THETA_COUNTS_PER_PI*4294967296.0+0.5))
`define CFG_PULSE_RAD_Q32 ($rtoi(6.2831853071795864769/`CFG_HARDWARE_PULSES_PER_REVOLUTION*4294967296.0+0.5))
`define CFG_FREQUENCY_CONVERSION ($rtoi(`CFG_HARDWARE_PULSES_PER_REVOLUTION/6.2831853071795864769*4096.0+0.5))
`define CFG_ENTRY_COUNTS ($rtoi(`CFG_SUPERVISOR_ENTRY_ANGLE_DEG/180.0*`CFG_ADC_THETA_COUNTS_PER_PI))
`define CFG_FALLEN_COUNTS ($rtoi(`CFG_SUPERVISOR_FALLEN_ANGLE_DEG/180.0*`CFG_ADC_THETA_COUNTS_PER_PI))
`define CFG_SATURATION_FRAMES ((`CFG_SUPERVISOR_SATURATION_TIMEOUT_US+`CFG_CONTROL_PERIOD_US-1)/`CFG_CONTROL_PERIOD_US)
// 仅 RUN 的有界回零偏置。Q36 累加器保留低于 Q16 的步长。
// 26103123：恒值 RUN 指令偏置试验（B）。朝负 alpha 方向 0.10 rad/s；
// 符号取自 u->alpha_dot 在 10 ms 滞后的相关性（+0.29）。
// 26103125：外环绝对位置 P 环（A）。Kp=2.0 rad/s per rad；
// alpha/alpha_c 增益对相互抵消，所以这是唯一的绝对刚度。
`define CFG_RUN_POS_KP_Q8 32'sd512

`define CFG_RUN_BIAS_Q16 (-32'sd6554)

// 26103136：执行器死区补偿（仅 RUN）。
// |指令| 超过 1 Hz 时追加 10 Hz；低于该值输出为 0。
`define CFG_RUN_DEADBAND_EN 0
`define CFG_RUN_DEADBAND_Q8 32'sd2560
`define CFG_RUN_DEADBAND_TH_Q8 32'sd256

// 稳态对齐 PROJECT_ALL：trim 参数用 PROJECT_ALL 的值。
// Restore the baseline trim gain while retaining the ADC precision fix.
`define CFG_RUN_TRIM_KI 0.5
// 26103183：允许在横臂位置边界附近捕获后缓慢回中（project_01 捕获保持特性，保留）。
`define CFG_RUN_TRIM_POSITION_MAX_DEG 45.0
// 26103150：偏置贡献低通位移。0=旁路，与 PROJECT_ALL 一致（无低通）。
`define CFG_RUN_TRIM_LP_SHIFT 0
// 稳态对齐 PROJECT_ALL：无积分死区。
`define CFG_RUN_TRIM_DEADBAND_DEG 0.0
`define CFG_RUN_TRIM_LIMIT 1.0
`define CFG_RUN_TRIM_QUIET_US 501000
// 稳态对齐 PROJECT_ALL：速度越界/缺样本时资格最多暂停 12 ms（PROJECT_ALL 值）。
`define CFG_RUN_TRIM_SPEED_GRACE_US 12000
// 目标变化期间/之后平滑送回旧位置偏置（rad/s^2）。
`define CFG_RUN_TRIM_RETURN_RATE 1.0
// 26103170：仅 RUN 的静摩擦踢动。若实测摆角在 STILL_DEG 内保持 QUAL_FRAMES
// （0.5 ms tick），就朝倾斜方向追加一个短 KICK_HZ 脉冲，帮助横臂突破支点粘滑。
// ENABLED=0 恢复纯 LQR。
`define CFG_KICK_ENABLED 32'sd0 // 26103172：改用冻结释放策略，不用 kick
`define CFG_KICK_STILL_DEG 0.05
`define CFG_KICK_THETA_MIN_DEG 0.8
`define CFG_KICK_THETA_MAX_DEG 8.0
`define CFG_KICK_QUAL_FRAMES 32'sd80
`define CFG_KICK_FRAMES 32'sd80
`define CFG_KICK_REFRACTORY_FRAMES 32'sd300
`define CFG_KICK_HZ 32'sd400
// 26103190：ADC 码值合格且恒定时暂停脉冲；ADC 变化、横臂位移/速度、
// 目标变化或模式变化都立即唤醒。
// 稳态对齐 PROJECT_ALL：PROJECT_ALL 无静默闸门，关闭。
`define CFG_STALL_ENABLED 32'sd0
`define CFG_STALL_QUAL_FRAMES 32'sd400
// 26103190：精确 ADC 码值静默闸门，只在静止 RUN 保持时生效。
`define CFG_STALL_RUN_SETTLE_US 1000000
`define CFG_STALL_MAX_THETA_DEG 8.0
`define CFG_STALL_ENTRY_SPEED_RAD_S 0.3
`define CFG_STALL_ENTRY_MAX_HZ 500
`define CFG_STALL_ARM_WAKE_DEG 0.25
`define CFG_STALL_COOLDOWN_US 200000
`define CFG_STALL_RESUME_RAD_S 0.3
// 26103174：直立微抖动。比赛不允许看起来完全静止；RUN 在直立附近稳定时，
// 各方向发出 PULSES 个脉冲的小步。
`define CFG_DITHER_ENABLED 32'sd0
`define CFG_DITHER_STEADY_DEG 0.5
`define CFG_DITHER_STEADY_RAD_S 0.2
`define CFG_DITHER_STEADY_MS 32'sd500
`define CFG_DITHER_PERIOD_MS 32'sd500
`define CFG_DITHER_HZ 32'sd200
`define CFG_DITHER_PULSES 32'sd4
// 26103178：SWINGUP 期间短暂的 ADC 死区桥接。
`define CFG_DZ_BRIDGE_ENABLED 32'sd0
`define CFG_DZ_COAST_MS 32'sd150
`define CFG_DZ_ARM_SPEED_MAX 8.0
`define CFG_DZ_ARM_COUPLING 1.290785
// 26103179：开环谐振泵（泵里不含摆角反馈）。
`define CFG_SWINGUP_OPENLOOP_EN 32'sd0
`define CFG_SWINGUP_OL_AMP_HZ 32'sd2600
`define CFG_SWINGUP_OL_START_HZ 32'sd180
`define CFG_SWINGUP_OL_END_HZ 32'sd110
`define CFG_SWINGUP_OL_SWEEP_MS 32'sd9000
`define CFG_SWINGUP_OL_RAMP_MS 32'sd800
`endif
