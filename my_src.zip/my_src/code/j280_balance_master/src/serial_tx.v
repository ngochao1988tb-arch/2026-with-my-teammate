`timescale 1ns/1ps
`include "control_config.vh"
// 8N1. start is accepted only while idle; data is latched for the whole byte.
module serial_tx #(parameter CLK_HZ=`CFG_HARDWARE_CLOCK_HZ, parameter BAUD=`CFG_MOTOR_UART_BAUD)(
    input clk, input rst_n, input start, input [7:0] data,
    output reg tx, output reg busy, output reg done
);
    localparam DIV=(CLK_HZ+BAUD/2)/BAUD;
    reg [31:0] ticks;
    reg [3:0] bit_index;
    reg [9:0] frame;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            tx<=1; busy<=0; done<=0; ticks<=0; bit_index<=0; frame<=10'h3ff;
        end else begin
            done<=0;
            if (!busy) begin
                tx<=1;
                if (start) begin
                    frame<={1'b1,data,1'b0}; tx<=0;
                    busy<=1; ticks<=0; bit_index<=0;
                end
            end else if (ticks==DIV-1) begin
                ticks<=0;
                if (bit_index==9) begin busy<=0; done<=1; tx<=1; end
                else begin bit_index<=bit_index+1'b1; frame<={1'b1,frame[9:1]}; tx<=frame[1]; end
            end else ticks<=ticks+1'b1;
        end
    end
endmodule
