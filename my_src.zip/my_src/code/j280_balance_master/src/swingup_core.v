`timescale 1ns/1ps
`include "control_config.vh"
// Nonlinear energy pumping for a velocity-command motor. All runtime arithmetic
// is integer. The linear LQR observer must not be used at hanging-down angles.
module swingup_core #(
    parameter THETA_INVERT=`CFG_HARDWARE_THETA_INVERT,
    parameter MAX_FREQ_HZ=`CFG_CONTROL_MAX_FREQUENCY_HZ,
    parameter UPDATE_CLOCKS=5
)(
    input clk, input rst_n, input sample_valid, input enable,
    input [12:0] ad_value,
    input signed [31:0] alpha_meas, alpha_c,
    input signed [31:0] arm_reference_q16,
    output reg signed [31:0] frequency_q8,
    output signed [31:0] theta_dot_q16,
    output signed [31:0] u_q16,
    output velocity_valid,
    output capture_safe,
    input approach_valid,
    input signed [31:0] approach_frequency_q8, approach_arm_velocity,
    output reg approach_active,
    input restart,
    input signed [31:0] restart_frequency_q8,
    output reg recovery_active,
    output [2:0] launch_phase
);
    localparam integer DECIMATION=`CFG_MOTION_PERIOD_US/`CFG_CONTROL_PERIOD_US;
    reg [(DECIMATION>1 ? $clog2(DECIMATION):1)-1:0] sample_phase;
    wire motion_sample_valid=sample_valid && sample_phase==DECIMATION-1;
    always @(posedge clk or negedge rst_n)
        if(!rst_n) sample_phase<=0;
        else if(sample_valid) sample_phase<=motion_sample_valid ? 0:sample_phase+1'b1;
    localparam integer PI_COUNTS=`CFG_ADC_THETA_COUNTS_PER_PI;
    localparam integer VELOCITY_SCALE=$rtoi(3.141592653589793*256.0*1000000.0/PI_COUNTS/`CFG_MOTION_PERIOD_US+0.5);
    localparam integer SOFT_ARM=$rtoi(`CFG_SWINGUP_SOFT_ARM_DEG/180.0*3.141592653589793*65536.0);
    localparam integer LIMIT_HZ=(`CFG_SWINGUP_MAX_FREQUENCY_HZ<MAX_FREQ_HZ) ? `CFG_SWINGUP_MAX_FREQUENCY_HZ : MAX_FREQ_HZ;
    localparam integer LIMIT_Q8=LIMIT_HZ*256;
    localparam integer RESTART_LIMIT_Q8=MAX_FREQ_HZ*256;
    localparam integer STEP_Q8=(`CFG_SWINGUP_ACCEL_HZ_PER_S*64'sd256*`CFG_MOTION_PERIOD_US)/1000000;
    localparam integer RECOVERY_STEP_Q8=(`CFG_SWINGUP_RECOVERY_ACCEL_HZ_PER_S*64'sd256*`CFG_MOTION_PERIOD_US)/1000000;
    localparam integer KICK_FRAMES=(`CFG_SWINGUP_KICK_US+`CFG_MOTION_PERIOD_US-1)/`CFG_MOTION_PERIOD_US;
    localparam integer ENDPOINT_KICK_FRAMES=(`CFG_SWINGUP_ENDPOINT_KICK_US+`CFG_MOTION_PERIOD_US-1)/`CFG_MOTION_PERIOD_US;
    localparam integer ENDPOINT_LIMIT_HZ=(`CFG_SWINGUP_ENDPOINT_MAX_FREQUENCY_HZ<LIMIT_HZ) ? `CFG_SWINGUP_ENDPOINT_MAX_FREQUENCY_HZ : LIMIT_HZ;
    localparam integer MAX_VALID_DELTA=$rtoi(`CFG_SWINGUP_MAX_VALID_SPEED_RAD_S*PI_COUNTS*`CFG_MOTION_PERIOD_US/(3.141592653589793*1000000.0));
    localparam integer RECOVERY_FRAMES=`CFG_SWINGUP_VELOCITY_RECOVERY_FRAMES;
    // 26103179: open-loop resonant pump. Ignores the pendulum ADC and drives
    // the arm with a square wave sweeping 1.80 -> 1.10 Hz; the normal capture
    // logic still runs near upright, where the sensor is valid.
    localparam integer OL_EN=`CFG_SWINGUP_OPENLOOP_EN;
    localparam integer OL_AMP_Q8=`CFG_SWINGUP_OL_AMP_HZ*256;
    localparam integer OL_START_CHZ=`CFG_SWINGUP_OL_START_HZ;
    localparam integer OL_END_CHZ=`CFG_SWINGUP_OL_END_HZ;
    localparam integer OL_SWEEP_FRAMES=(`CFG_SWINGUP_OL_SWEEP_MS+`CFG_MOTION_PERIOD_US-1)/`CFG_MOTION_PERIOD_US;
    localparam integer OL_RAMP_FRAMES=(`CFG_SWINGUP_OL_RAMP_MS+`CFG_MOTION_PERIOD_US-1)/`CFG_MOTION_PERIOD_US;
    localparam integer OL_SWEEP_STEP=(OL_SWEEP_FRAMES/(OL_START_CHZ-OL_END_CHZ)>0) ? (OL_SWEEP_FRAMES/(OL_START_CHZ-OL_END_CHZ)) : 1;
    localparam integer OL_AMP_STEP=(OL_AMP_Q8/OL_RAMP_FRAMES>0) ? (OL_AMP_Q8/OL_RAMP_FRAMES) : 1;
    reg [15:0] ol_phase,ol_sweep_cnt,ol_freq_chz;
    reg signed [31:0] ol_amp_q8;
    wire [31:0] ol_inc=({16'd0,ol_freq_chz}*32'd1342)>>10;
    reg [$clog2(RECOVERY_FRAMES+1)-1:0] good_velocity_pairs;
    reg step_valid, endpoint_trial_started;
    reg [12:0] previous_ad;
    reg velocity_seen, previous_endpoint;
    reg [1:0] endpoint_pair_pipe;
    wire endpoint=`CFG_SWINGUP_ENDPOINT_ESCAPE_ENABLED &&
        (ad_value<`CFG_ADC_RAIL_MIN || ad_value>`CFG_ADC_RAIL_MAX);
    reg signed [15:0] speed_q8;
    reg [31:0] kick_frames;
    reg kick_negative;
    wire signed [15:0] raw_delta=THETA_INVERT ? $signed({3'd0,previous_ad})-$signed({3'd0,ad_value}) :
                                                           $signed({3'd0,ad_value})-$signed({3'd0,previous_ad});
    // Unwrap a full turn at the potentiometer endpoint; do not interpret it as velocity.
    wire signed [15:0] delta_next=(raw_delta>PI_COUNTS) ? raw_delta-2*PI_COUNTS :
                             (raw_delta< -PI_COUNTS) ? raw_delta+2*PI_COUNTS : raw_delta;
    // A dead-zone crossing is not a measured full-turn displacement. Reject
    // discontinuities, including plausible-looking intermediate averaged ADs.
    wire delta_plausible=(raw_delta<=MAX_VALID_DELTA && raw_delta>= -MAX_VALID_DELTA);
    reg signed [15:0] delta;
    reg signed [31:0] instant_speed;
    reg [UPDATE_CLOCKS-1:0] sample_pipe;
    wire signed [31:0] filtered_speed=($signed(speed_q8)*3+instant_speed)>>>2;
    wire signed [15:0] angle_counts=THETA_INVERT ? `CFG_ADC_FIXED_ZERO-$signed({3'd0,ad_value}) :
                                                                $signed({3'd0,ad_value})-`CFG_ADC_FIXED_ZERO;
    localparam signed [31:0] CAPTURE_INSTANT_Q8=$rtoi(`CFG_SWINGUP_CAPTURE_INSTANT_SPEED_RAD_S*256.0);
    localparam signed [31:0] CAPTURE_PROJECTED_COUNTS=$rtoi(`CFG_SWINGUP_CAPTURE_PROJECTED_ANGLE_DEG*PI_COUNTS/180.0);
    wire signed [31:0] projected_counts=$signed(angle_counts)+$signed(delta)*`CFG_SWINGUP_CAPTURE_LOOKAHEAD_FRAMES;
    assign capture_safe=!recovery_active && velocity_valid && step_valid &&
        instant_speed<=CAPTURE_INSTANT_Q8 && instant_speed>=-CAPTURE_INSTANT_Q8 &&
        projected_counts<=CAPTURE_PROJECTED_COUNTS && projected_counts>=-CAPTURE_PROJECTED_COUNTS;
    reg [15:0] abs_angle;
    // cos(k*pi/16), Q10; 11.25 degree bins. Energy is an approximate switching
    // criterion, not a full identified nonlinear model of the real mechanism.
    function signed [15:0] cosine;
        input [15:0] a;
        reg [4:0] k;
        begin
            // Balanced constant comparisons avoid a combinational divider.
            if(a<PI_COUNTS*8/16) begin
                if(a<PI_COUNTS*4/16) begin
                    if(a<PI_COUNTS*2/16) k=(a<PI_COUNTS/16) ? 0 : 1;
                    else k=(a<PI_COUNTS*3/16) ? 2 : 3;
                end else begin
                    if(a<PI_COUNTS*6/16) k=(a<PI_COUNTS*5/16) ? 4 : 5;
                    else k=(a<PI_COUNTS*7/16) ? 6 : 7;
                end
            end else begin
                if(a<PI_COUNTS*12/16) begin
                    if(a<PI_COUNTS*10/16) k=(a<PI_COUNTS*9/16) ? 8 : 9;
                    else k=(a<PI_COUNTS*11/16) ? 10 : 11;
                end else begin
                    if(a<PI_COUNTS*14/16) k=(a<PI_COUNTS*13/16) ? 12 : 13;
                    else k=(a<PI_COUNTS*15/16) ? 14 : (a<PI_COUNTS ? 15 : 16);
                end
            end
            case(k)
                0:cosine=1024; 1:cosine=1004; 2:cosine=946; 3:cosine=851;
                4:cosine=724; 5:cosine=569; 6:cosine=392; 7:cosine=200;
                8:cosine=0; 9:cosine=-200; 10:cosine=-392; 11:cosine=-569;
                12:cosine=-724; 13:cosine=-851; 14:cosine=-946; 15:cosine=-1004;
                default:cosine=-1024;
            endcase
        end
    endfunction
    // sqrt(2*h/b*(1-cos(theta)))*256 for the same Q10 cosine bins.
    // This is equivalent to the former speed_q8^2 energy comparison but
    // avoids a 16x16 combinational square when all DSP blocks are occupied.
    // Regenerate these constants if CFG_SWINGUP_H_OVER_B changes.
    function signed [15:0] energy_speed_limit;
        input signed [15:0] c;
        begin
            case(c)
                16'sd1024:energy_speed_limit=16'sd0;
                16'sd1004:energy_speed_limit=16'sd585;
                16'sd946:energy_speed_limit=16'sd1154;
                16'sd851:energy_speed_limit=16'sd1719;
                16'sd724:energy_speed_limit=16'sd2263;
                16'sd569:energy_speed_limit=16'sd2787;
                16'sd392:energy_speed_limit=16'sd3284;
                16'sd200:energy_speed_limit=16'sd3750;
                16'sd0:energy_speed_limit=16'sd4180;
                -16'sd200:energy_speed_limit=16'sd4570;
                -16'sd392:energy_speed_limit=16'sd4916;
                -16'sd569:energy_speed_limit=16'sd5214;
                -16'sd724:energy_speed_limit=16'sd5462;
                -16'sd851:energy_speed_limit=16'sd5657;
                -16'sd946:energy_speed_limit=16'sd5798;
                -16'sd1004:energy_speed_limit=16'sd5883;
                default:energy_speed_limit=16'sd5912;
            endcase
        end
    endfunction
    reg signed [15:0] cos_q10;
    wire signed [15:0] speed_mag_q8=speed_q8[15] ? -speed_q8 : speed_q8;
    wire needs_energy=speed_mag_q8<energy_speed_limit(cos_q10);
    // theta_ddot = g*sin(theta) - coupling*cos(theta)*arm_ddot.
    // Below target, choose arm acceleration opposite to theta_dot*cos(theta).
    wire pump_negative=(speed_q8[15]^cos_q10[15]) ^ needs_energy;
    wire slow=(speed_q8<16'sd51 && speed_q8> -16'sd51);
    assign velocity_valid=(good_velocity_pairs>=RECOVERY_FRAMES) && !endpoint;
    wire blind=endpoint || !velocity_valid;
    localparam integer APPROACH_ENTRY=$rtoi(`CFG_SWINGUP_APPROACH_ENTRY_DEG*PI_COUNTS/180.0);
    localparam integer APPROACH_EXIT=$rtoi(`CFG_SWINGUP_APPROACH_EXIT_DEG*PI_COUNTS/180.0);
    localparam integer APPROACH_SPEED=$rtoi(`CFG_SWINGUP_APPROACH_SPEED_RAD_S*256.0);
    localparam integer APPROACH_RAW=$rtoi(`CFG_SWINGUP_APPROACH_INSTANT_RAD_S*256.0);
    localparam integer APPROACH_ARM_SPEED=$rtoi(`CFG_SWINGUP_APPROACH_ARM_SPEED_RAD_S*65536.0);
    localparam integer APPROACH_TRACKING=$rtoi(`CFG_SWINGUP_CAPTURE_TRACKING_DEG*3.141592653589793*65536.0/180.0);
    localparam integer APPROACH_LIMIT_HZ=(`CFG_SWINGUP_APPROACH_MAX_FREQUENCY_HZ<LIMIT_HZ) ? `CFG_SWINGUP_APPROACH_MAX_FREQUENCY_HZ : LIMIT_HZ;
    localparam integer APPROACH_STEP=(`CFG_SWINGUP_APPROACH_ACCEL_HZ_PER_S*64'sd256*`CFG_MOTION_PERIOD_US)/1000000;
    localparam integer APPROACH_DECEL_STEP=(`CFG_SWINGUP_APPROACH_DECEL_HZ_PER_S*64'sd256*`CFG_MOTION_PERIOD_US)/1000000;
    localparam integer RETRY_APPROACH_DECEL_STEP=(`CFG_SWINGUP_RETRY_APPROACH_DECEL_HZ_PER_S*64'sd256*`CFG_MOTION_PERIOD_US)/1000000;
    // Keep the stronger retry profile through recovery and subsequent capture approach.
    // Returning to RUN disables swing-up, so the next fresh start uses the first profile.
    reg retry_swingup;
    always @(posedge clk or negedge rst_n)
        if(!rst_n) retry_swingup<=0;
        else if(!enable) retry_swingup<=0;
        else if(restart) retry_swingup<=1;
    wire signed [31:0] selected_approach_decel_step=retry_swingup ? RETRY_APPROACH_DECEL_STEP : APPROACH_DECEL_STEP;
    localparam integer APPROACH_QUAL_FRAMES=`CFG_SWINGUP_APPROACH_QUAL_FRAMES;
    localparam integer APPROACH_HOLD_FRAMES=(`CFG_SWINGUP_APPROACH_HOLD_US+`CFG_MOTION_PERIOD_US-1)/`CFG_MOTION_PERIOD_US;
    wire signed [31:0] relative_alpha=alpha_meas-arm_reference_q16;
    wire signed [31:0] relative_command=alpha_c-arm_reference_q16;
    wire signed [32:0] tracking=$signed({relative_alpha[31],relative_alpha})-$signed({relative_command[31],relative_command});
    wire approach_safety_ok=velocity_valid && step_valid && !endpoint &&
        angle_counts<=(approach_active ? APPROACH_EXIT : APPROACH_ENTRY) &&
        angle_counts>=-(approach_active ? APPROACH_EXIT : APPROACH_ENTRY) &&
        speed_q8<=APPROACH_SPEED && speed_q8>=-APPROACH_SPEED &&
        instant_speed<=APPROACH_RAW && instant_speed>=-APPROACH_RAW &&
        approach_arm_velocity<=APPROACH_ARM_SPEED && approach_arm_velocity>=-APPROACH_ARM_SPEED &&
        tracking<=APPROACH_TRACKING && tracking>=-APPROACH_TRACKING &&
        relative_alpha<=SOFT_ARM && relative_alpha>=-SOFT_ARM && relative_command<=SOFT_ARM && relative_command>=-SOFT_ARM;
    wire approach_request=approach_valid && approach_safety_ok;
    reg signed [31:0] approach_target;
    reg negative_acceleration;
    reg last_pump_negative;
    reg acceleration_pipe, approach_request_pipe;
    reg approach_safety_pipe;
    reg signed [31:0] approach_target_pipe;
    reg signed [31:0] approach_last_target;
    reg signed [31:0] next_frequency;
    reg [$clog2(APPROACH_QUAL_FRAMES+1)-1:0] approach_good_frames;
    reg [$clog2(APPROACH_HOLD_FRAMES+1)-1:0] approach_bad_frames;
    // Actual command selection follows qualification and the bounded hold,
    // rather than dropping back to pumping on every invalid preview frame.
    wire approach_enter=approach_request_pipe && approach_good_frames>=APPROACH_QUAL_FRAMES-1;
    wire approach_control=approach_safety_pipe &&
        (approach_active ? (approach_request_pipe || approach_bad_frames<APPROACH_HOLD_FRAMES-1) : approach_enter);
    wire signed [31:0] approach_control_target=approach_request_pipe ? approach_target_pipe : approach_last_target;
    // 时序优化：approach_braking/reversing 是 32 位比较，连同后续的 mux（ramp_target、
    // step_q8）一起形成「approach_target_pipe → 比较 → mux → next_frequency 比较」的
    // 超长组合链（实测 44ns，Fmax 掉到 32.8MHz）。这几个中间量只依赖上一拍已稳定的
    // 寄存器（approach_request_pipe/approach_target_pipe/approach_last_target/frequency_q8），
    // 所以把它们提前打一拍锁存，本拍直接使用，把链打断成两段。
    reg signed [31:0] approach_ramp_target_q,approach_step_q8_q;
    always @(posedge clk or negedge rst_n)
        if(!rst_n) begin
            approach_ramp_target_q<=0;approach_step_q8_q<=APPROACH_STEP;
        end else begin
            // 用本拍（上一拍已稳定的）寄存器算 braking/reversing，锁存 ramp/step，
            // 下一拍直接使用，把「比较 → mux → 再比较」的长链打断成两段。
            approach_ramp_target_q<=((frequency_q8>0 && approach_control_target<0) ||
                (frequency_q8<0 && approach_control_target>0)) ? 32'sd0 : approach_control_target;
            approach_step_q8_q<=((frequency_q8>0 && approach_control_target<frequency_q8) ||
                (frequency_q8<0 && approach_control_target>frequency_q8)) ? selected_approach_decel_step : APPROACH_STEP;
        end
    // 本拍斜坡决策改用打拍后的中间量，链长从 5~6 级 32 位逻辑降到 2~3 级。
    wire signed [31:0] approach_ramp_target=approach_ramp_target_q;
    wire signed [31:0] approach_step_q8=approach_step_q8_q;
    wire launch_active;
    wire signed [31:0] launch_target_q8,launch_step_q8;
    localparam integer LAUNCH_HZ=(`CFG_SWINGUP_LAUNCH_PRIME_HZ>`CFG_SWINGUP_LAUNCH_REVERSE_HZ) ?
        `CFG_SWINGUP_LAUNCH_PRIME_HZ : `CFG_SWINGUP_LAUNCH_REVERSE_HZ;
    localparam integer LAUNCH_LIMIT_HZ=(LAUNCH_HZ<MAX_FREQ_HZ) ? LAUNCH_HZ:MAX_FREQ_HZ;
    wire launch_in_range=relative_alpha<=SOFT_ARM && relative_alpha>=-SOFT_ARM &&
        relative_command<=SOFT_ARM && relative_command>=-SOFT_ARM;
    swingup_launch_assist #(.NORMAL_HZ(LIMIT_HZ),.ENDPOINT_HZ(ENDPOINT_LIMIT_HZ),
        .APPROACH_HZ(APPROACH_LIMIT_HZ)) u_launch(.clk(clk),.rst_n(rst_n),.enable(enable),.restart(restart),
        .tick(sample_pipe[UPDATE_CLOCKS-1]),.blind(blind),.angle_counts(angle_counts),
        .speed_q8(speed_q8),.relative_alpha(relative_alpha),.relative_command(relative_command),
        .in_range(launch_in_range),.approach_ready(approach_control),.frequency_q8(frequency_q8),
        .active(launch_active),.target_q8(launch_target_q8),.step_q8(launch_step_q8),.phase(launch_phase));
    wire signed [31:0] active_limit_q8=(launch_active && launch_in_range) ? LAUNCH_LIMIT_HZ*256 :
        (blind ? ENDPOINT_LIMIT_HZ*256 : LIMIT_Q8);
    always @* begin
        // Outside the one-shot launch, retain the last measured pump direction
        // across the endpoint, with the original lower endpoint speed limit.
        negative_acceleration=blind ? last_pump_negative : ((slow) ? kick_negative : pump_negative);
        if(relative_alpha>SOFT_ARM || relative_command>SOFT_ARM) negative_acceleration=1;
        else if(relative_alpha< -SOFT_ARM || relative_command< -SOFT_ARM) negative_acceleration=0;
        approach_target=approach_frequency_q8;
        if(approach_target>APPROACH_LIMIT_HZ*256) approach_target=APPROACH_LIMIT_HZ*256;
        if(approach_target< -APPROACH_LIMIT_HZ*256) approach_target=-APPROACH_LIMIT_HZ*256;
        next_frequency=frequency_q8+(acceleration_pipe ? -STEP_Q8 : STEP_Q8);
        if(approach_control) begin
            if(approach_ramp_target>frequency_q8+approach_step_q8) next_frequency=frequency_q8+approach_step_q8;
            else if(approach_ramp_target<frequency_q8-approach_step_q8) next_frequency=frequency_q8-approach_step_q8;
            else next_frequency=approach_ramp_target;
        end else if(launch_active && launch_in_range) begin
            if(launch_target_q8>frequency_q8+launch_step_q8) next_frequency=frequency_q8+launch_step_q8;
            else if(launch_target_q8<frequency_q8-launch_step_q8) next_frequency=frequency_q8-launch_step_q8;
            else next_frequency=launch_target_q8;
        end
        if(next_frequency>active_limit_q8) next_frequency=active_limit_q8;
        if(next_frequency< -active_limit_q8) next_frequency=-active_limit_q8;
    end
    reg signed [63:0] velocity_product;
    assign u_q16=velocity_product>>>24;
    assign theta_dot_q16=$signed(speed_q8)*32'sd256;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            previous_ad<=0; velocity_seen<=0; previous_endpoint<=1; endpoint_pair_pipe<=0; speed_q8<=0;
            good_velocity_pairs<=0; step_valid<=0; endpoint_trial_started<=0;
            frequency_q8<=0; kick_frames<=0; kick_negative<=0; approach_active<=0; recovery_active<=0;
            delta<=0; instant_speed<=0; sample_pipe<=0; abs_angle<=0;
            last_pump_negative<=0;
            acceleration_pipe<=0; approach_request_pipe<=0; approach_target_pipe<=0;
            approach_safety_pipe<=0;approach_last_target<=0;
            approach_good_frames<=0; approach_bad_frames<=0;
            cos_q10<=1024; velocity_product<=0;
            ol_phase<=0; ol_sweep_cnt<=0; ol_freq_chz<=OL_START_CHZ; ol_amp_q8<=0;
        end else begin
            // Break the energy-comparison / command-adder path at 50MHz.
            acceleration_pipe<=negative_acceleration;
            approach_request_pipe<=approach_request;
            approach_safety_pipe<=approach_safety_ok;
            approach_target_pipe<=approach_target;
            // Top waits 220 clocks for this frame's serial preview and conversion.
            // Standalone energy-only tests retain the original five-clock schedule.
            sample_pipe<={sample_pipe[UPDATE_CLOCKS-2:0],motion_sample_valid};
            // Latch the angle difference at the sample edge; previous_ad changes
            // there too, so a free-running difference must not feed the pipeline.
            instant_speed<=delta*VELOCITY_SCALE;
            // Endpoint angle and speed are unavailable. Use bottom cosine for pumping,
            // discard speed history across the gap. Recovery needs consecutive
            // plausible pairs before energy control or capture can use velocity.
            abs_angle<=endpoint ? PI_COUNTS : (angle_counts[15] ? -angle_counts : angle_counts);
            endpoint_pair_pipe<={endpoint_pair_pipe[0],(motion_sample_valid && (endpoint || previous_endpoint))};
            cos_q10<=cosine(abs_angle);
            velocity_product<=$signed(frequency_q8)*`CFG_PULSE_RAD_Q32;
            if(motion_sample_valid) begin
                previous_ad<=ad_value; previous_endpoint<=endpoint;
                delta<=delta_next; step_valid<=delta_plausible;
            end
            if(sample_pipe[1]) begin
                velocity_seen<=1;
                if(!velocity_seen || endpoint_pair_pipe[1] || !step_valid) begin
                    speed_q8<=0; good_velocity_pairs<=0;
                end else begin
                    speed_q8<=filtered_speed;
                    if(good_velocity_pairs<RECOVERY_FRAMES) good_velocity_pairs<=good_velocity_pairs+1'b1;
                end
            end
            if(!blind) last_pump_negative<=pump_negative;
            if(!enable) begin
                frequency_q8<=0; kick_frames<=0; kick_negative<=0; approach_active<=0;
                approach_good_frames<=0; approach_bad_frames<=0;
                approach_last_target<=0;
                endpoint_trial_started<=0; recovery_active<=0;
                ol_phase<=0; ol_sweep_cnt<=0; ol_freq_chz<=OL_START_CHZ; ol_amp_q8<=0;
            end
            else if(restart) begin
                // Preserve the last applied RUN command (bounded by the motor
                // limit), then ramp toward zero before resuming energy pumping.
                // Applying the lower swing limit immediately would add a step.
                if(restart_frequency_q8>RESTART_LIMIT_Q8) frequency_q8<=RESTART_LIMIT_Q8;
                else if(restart_frequency_q8< -RESTART_LIMIT_Q8) frequency_q8<=-RESTART_LIMIT_Q8;
                else frequency_q8<=restart_frequency_q8;
                kick_frames<=0; kick_negative<=restart_frequency_q8[31];
                approach_active<=0;
                approach_good_frames<=0; approach_bad_frames<=0;
                approach_last_target<=0;
                endpoint_trial_started<=0; recovery_active<=1;
                ol_phase<=0; ol_sweep_cnt<=0; ol_freq_chz<=OL_START_CHZ; ol_amp_q8<=0;
            end else if(recovery_active && sample_pipe[UPDATE_CLOCKS-1]) begin
                approach_active<=0;
                approach_good_frames<=0; approach_bad_frames<=0;
                if(frequency_q8>RECOVERY_STEP_Q8) frequency_q8<=frequency_q8-RECOVERY_STEP_Q8;
                else if(frequency_q8< -RECOVERY_STEP_Q8) frequency_q8<=frequency_q8+RECOVERY_STEP_Q8;
                else begin frequency_q8<=0; recovery_active<=0; end
            end else if(OL_EN && sample_pipe[UPDATE_CLOCKS-1]) begin
                ol_phase<=ol_phase+ol_inc[15:0];
                if(ol_amp_q8<OL_AMP_Q8) ol_amp_q8<=ol_amp_q8+OL_AMP_STEP;
                if(ol_sweep_cnt>=OL_SWEEP_STEP-1) begin
                    ol_sweep_cnt<=0;
                    if(ol_freq_chz>OL_END_CHZ) ol_freq_chz<=ol_freq_chz-1'b1;
                    else ol_freq_chz<=OL_START_CHZ;
                end else ol_sweep_cnt<=ol_sweep_cnt+1'b1;
                frequency_q8<=ol_phase[15] ? -ol_amp_q8 : ol_amp_q8;
                recovery_active<=0; approach_active<=0; kick_frames<=0;
            end else if(sample_pipe[UPDATE_CLOCKS-1]) begin
                frequency_q8<=next_frequency;
                if(approach_request_pipe) approach_last_target<=approach_target_pipe;
                if(!approach_safety_pipe) begin
                    approach_active<=0;approach_good_frames<=0;approach_bad_frames<=0;
                end else if(approach_active) begin
                    approach_good_frames<=0;
                    if(approach_request_pipe) approach_bad_frames<=0;
                    else if(approach_bad_frames>=APPROACH_HOLD_FRAMES-1) begin
                        approach_active<=0; approach_bad_frames<=0;
                    end else approach_bad_frames<=approach_bad_frames+1'b1;
                end else begin
                    approach_bad_frames<=0;
                    if(approach_request_pipe) begin
                        if(approach_good_frames>=APPROACH_QUAL_FRAMES-1) begin
                            approach_active<=1; approach_good_frames<=0;
                        end else approach_good_frames<=approach_good_frames+1'b1;
                    end else approach_good_frames<=0;
                end
                if(!blind) endpoint_trial_started<=0;
                if(kick_frames>=(blind ? (endpoint_trial_started ? 2*ENDPOINT_KICK_FRAMES : ENDPOINT_KICK_FRAMES) : KICK_FRAMES)-1) begin
                    kick_frames<=0; kick_negative<=!kick_negative;
                    if(blind) endpoint_trial_started<=1;
                end
                else kick_frames<=kick_frames+1'b1;
            end
        end
    end
endmodule

// One bounded launch per enable episode. No ADC angle is invented in the gap.
// Phases: 0=idle, 1=visible-side prime, 2=reverse impulse, 3=ramped handoff,
// 4=ordinary energy/approach control. External run/travel protection has priority.
module swingup_launch_assist #(
    parameter ENABLED=`CFG_SWINGUP_LAUNCH_ENABLED,
    parameter NORMAL_HZ=`CFG_SWINGUP_MAX_FREQUENCY_HZ,
    parameter ENDPOINT_HZ=`CFG_SWINGUP_ENDPOINT_MAX_FREQUENCY_HZ,
    parameter APPROACH_HZ=`CFG_SWINGUP_APPROACH_MAX_FREQUENCY_HZ
)(
    input clk,rst_n,enable,restart,tick,blind,in_range,approach_ready,
    input signed [15:0] angle_counts,speed_q8,
    input signed [31:0] relative_alpha,relative_command,frequency_q8,
    output active,
    output signed [31:0] target_q8,step_q8,
    output reg [2:0] phase
);
    localparam integer PRIME_MIN=(`CFG_SWINGUP_LAUNCH_PRIME_MIN_US+`CFG_MOTION_PERIOD_US-1)/`CFG_MOTION_PERIOD_US;
    localparam integer PRIME_MAX=(`CFG_SWINGUP_LAUNCH_PRIME_MAX_US+`CFG_MOTION_PERIOD_US-1)/`CFG_MOTION_PERIOD_US;
    localparam integer REVERSE_MAX=(`CFG_SWINGUP_LAUNCH_REVERSE_MAX_US+`CFG_MOTION_PERIOD_US-1)/`CFG_MOTION_PERIOD_US;
    localparam integer PRIME_ARM=$rtoi(`CFG_SWINGUP_LAUNCH_PRIME_ARM_DEG*3.141592653589793*65536.0/180.0);
    localparam integer START_ANGLE=120*`CFG_ADC_THETA_COUNTS_PER_PI/180;
    localparam integer PEAK_ANGLE=160*`CFG_ADC_THETA_COUNTS_PER_PI/180;
    localparam integer PRIME_STEP=(`CFG_SWINGUP_LAUNCH_PRIME_ACCEL*64'sd256*`CFG_MOTION_PERIOD_US)/1000000;
    localparam integer REVERSE_STEP=(`CFG_SWINGUP_LAUNCH_REVERSE_ACCEL*64'sd256*`CFG_MOTION_PERIOD_US)/1000000;
    reg [15:0] frames;
    wire at_prime_arm=relative_alpha>=PRIME_ARM || relative_alpha<=-PRIME_ARM ||
        relative_command>=PRIME_ARM || relative_command<=-PRIME_ARM;
    wire visible_peak=!blind && angle_counts>-PEAK_ANGLE && angle_counts<0 && speed_q8<=0;
    wire signed [31:0] handoff_limit=approach_ready ? APPROACH_HZ*256 :
        (blind ? ENDPOINT_HZ*256 : NORMAL_HZ*256);
    assign active=ENABLED && enable && in_range && (phase==1 || phase==2 || phase==3);
    assign target_q8=(phase==1) ? (`CFG_SWINGUP_LAUNCH_NEGATIVE ? -`CFG_SWINGUP_LAUNCH_PRIME_HZ*256 : `CFG_SWINGUP_LAUNCH_PRIME_HZ*256) :
        (phase==2) ? (`CFG_SWINGUP_LAUNCH_NEGATIVE ? `CFG_SWINGUP_LAUNCH_REVERSE_HZ*256 : -`CFG_SWINGUP_LAUNCH_REVERSE_HZ*256) : 32'sd0;
    assign step_q8=(phase==1) ? PRIME_STEP:REVERSE_STEP;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin phase<=0;frames<=0;end
        else if(!enable) begin phase<=0;frames<=0;end
        else if(restart) begin phase<=4;frames<=0;end
        else if(tick) begin
            if(!ENABLED || !in_range) begin phase<=4;frames<=0;end
            else case(phase)
                0:begin
                    frames<=0;
                    if(blind) phase<=2;
                    else if(angle_counts>=START_ANGLE || angle_counts<=-START_ANGLE) phase<=1;
                    else phase<=4;
                end
                1:begin
                    if(approach_ready) begin phase<=3;frames<=0;end
                    else if(blind || at_prime_arm || frames>=PRIME_MAX-1 ||
                            (frames>=PRIME_MIN-1 && visible_peak)) begin phase<=2;frames<=0;end
                    else frames<=frames+1'b1;
                end
                2:begin
                    if(approach_ready || frames>=REVERSE_MAX-1) begin phase<=3;frames<=0;end
                    else frames<=frames+1'b1;
                end
                3:begin
                    // Leave the boosted limit only after ramping into the
                    // ordinary/endpoint/approach limit: no timeout speed step.
                    if(frequency_q8<=handoff_limit && frequency_q8>=-handoff_limit) phase<=4;
                end
                default:begin phase<=4;frames<=0;end
            endcase
        end
    end
endmodule
