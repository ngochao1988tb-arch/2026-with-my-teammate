`timescale 1ns/1ps
// Constant fixed-point conversion without taking DSP blocks from the LQR.
module hmi_scale #(parameter [63:0] FACTOR=366693,parameter SHIFT=22,parameter TRIGGERED=0)(
 input clk,rst_n,trigger,input signed [31:0] value,output reg signed [31:0] result);
 reg busy,negative;reg [5:0] index;
 reg [31:0] bits;
 reg [63:0] addend,total;
 wire [63:0] next_total=total+(bits[0] ? addend:64'd0);
 wire signed [63:0] signed_total=negative ? -next_total:next_total;
 always @(posedge clk or negedge rst_n) begin
  if(!rst_n) begin busy<=0;negative<=0;index<=0;bits<=0;addend<=0;total<=0;result<=0;end
  else if(!busy) begin
   if(!TRIGGERED || trigger) begin
    busy<=1;negative<=value[31];bits<=value[31] ? -value:value;addend<=FACTOR;total<=0;index<=0;
   end
  end else begin
   total<=next_total;bits<=bits>>1;addend<=addend<<1;index<=index+1'b1;
   if(index==31) begin result<=signed_total>>>SHIFT;busy<=0;end
  end
 end
endmodule
