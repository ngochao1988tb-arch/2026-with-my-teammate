// ============================================================================
// sine_feedforward —— RUN 正弦轨迹的模型一致前馈修正
// ----------------------------------------------------------------------------
// 在既有"位置参考型 LQR"上叠加 delta = A*(Cs*sin(phi) + Cc*cos(phi))。
// 所有乘法复用同一套串行移位/累加，不占用 DSP；ROM 是通用表，
// 增益与模型常数在综合时由 control_config.vh 展开。
// 只在正弦（kind=0）且振荡运行时有效；保持、起摆、方波/三角与手写轨迹时归零。
// ============================================================================
`timescale 1ns/1ps
`include "control_config.vh"
// Model-consistent correction to the existing position-reference LQR.
// delta=A*(Cs*sin(phi)+Cc*cos(phi)); all products use one serial shift/add.
// No DSP is allocated. ROM is universal; gains/model constants elaborate here.
module sine_feedforward #(parameter ENABLED=`CFG_SINE_FF_ENABLED)(
    input clk,rst_n,clear,tick,enable,active,sample_valid,
    input [31:0] sample_phase,sample_period,
    input signed [31:0] sample_amplitude,
    output reg signed [31:0] correction_q16
);
    // The oscillator's nine accepted period settings (round(4*p/3)).
    localparam integer P0=`CFG_SINE_PERIOD_US;
    localparam integer P1=(P0*64'd4+1)/3,P2=(P1*64'd4+1)/3,
        P3=(P2*64'd4+1)/3,P4=(P3*64'd4+1)/3,P5=(P4*64'd4+1)/3,
        P6=(P5*64'd4+1)/3,P7=(P6*64'd4+1)/3,P8=(P7*64'd4+1)/3;
    localparam real WN=`CFG_SINE_FF_OMEGA_N,D=2.0*`CFG_SINE_FF_ZETA*WN;
    localparam real W0=6283185.307179586/P0;
    localparam real CT0=-`CFG_SINE_FF_C_OVER_B*W0*W0/(`CFG_SWINGUP_H_OVER_B+W0*W0);
    localparam signed [31:0] CS0=`CFG_Q20(`CFG_LQR_GAIN_SCALE*`CFG_K_THETA*CT0-(D+`CFG_LQR_GAIN_SCALE*`CFG_K_ALPHA_C)*W0*W0/(WN*WN));
    localparam signed [31:0] CC0=`CFG_Q20(W0*(1.0+`CFG_LQR_GAIN_SCALE*`CFG_K_ALPHA_DOT+`CFG_LQR_GAIN_SCALE*`CFG_K_ALPHA_C*D/(WN*WN)+`CFG_LQR_GAIN_SCALE*`CFG_K_THETA_DOT*CT0-W0*W0/(WN*WN)));
    localparam real W1=6283185.307179586/P1;
    localparam real CT1=-`CFG_SINE_FF_C_OVER_B*W1*W1/(`CFG_SWINGUP_H_OVER_B+W1*W1);
    localparam signed [31:0] CS1=`CFG_Q20(`CFG_LQR_GAIN_SCALE*`CFG_K_THETA*CT1-(D+`CFG_LQR_GAIN_SCALE*`CFG_K_ALPHA_C)*W1*W1/(WN*WN));
    localparam signed [31:0] CC1=`CFG_Q20(W1*(1.0+`CFG_LQR_GAIN_SCALE*`CFG_K_ALPHA_DOT+`CFG_LQR_GAIN_SCALE*`CFG_K_ALPHA_C*D/(WN*WN)+`CFG_LQR_GAIN_SCALE*`CFG_K_THETA_DOT*CT1-W1*W1/(WN*WN)));
    localparam real W2=6283185.307179586/P2;
    localparam real CT2=-`CFG_SINE_FF_C_OVER_B*W2*W2/(`CFG_SWINGUP_H_OVER_B+W2*W2);
    localparam signed [31:0] CS2=`CFG_Q20(`CFG_LQR_GAIN_SCALE*`CFG_K_THETA*CT2-(D+`CFG_LQR_GAIN_SCALE*`CFG_K_ALPHA_C)*W2*W2/(WN*WN));
    localparam signed [31:0] CC2=`CFG_Q20(W2*(1.0+`CFG_LQR_GAIN_SCALE*`CFG_K_ALPHA_DOT+`CFG_LQR_GAIN_SCALE*`CFG_K_ALPHA_C*D/(WN*WN)+`CFG_LQR_GAIN_SCALE*`CFG_K_THETA_DOT*CT2-W2*W2/(WN*WN)));
    localparam real W3=6283185.307179586/P3;
    localparam real CT3=-`CFG_SINE_FF_C_OVER_B*W3*W3/(`CFG_SWINGUP_H_OVER_B+W3*W3);
    localparam signed [31:0] CS3=`CFG_Q20(`CFG_LQR_GAIN_SCALE*`CFG_K_THETA*CT3-(D+`CFG_LQR_GAIN_SCALE*`CFG_K_ALPHA_C)*W3*W3/(WN*WN));
    localparam signed [31:0] CC3=`CFG_Q20(W3*(1.0+`CFG_LQR_GAIN_SCALE*`CFG_K_ALPHA_DOT+`CFG_LQR_GAIN_SCALE*`CFG_K_ALPHA_C*D/(WN*WN)+`CFG_LQR_GAIN_SCALE*`CFG_K_THETA_DOT*CT3-W3*W3/(WN*WN)));
    localparam real W4=6283185.307179586/P4;
    localparam real CT4=-`CFG_SINE_FF_C_OVER_B*W4*W4/(`CFG_SWINGUP_H_OVER_B+W4*W4);
    localparam signed [31:0] CS4=`CFG_Q20(`CFG_LQR_GAIN_SCALE*`CFG_K_THETA*CT4-(D+`CFG_LQR_GAIN_SCALE*`CFG_K_ALPHA_C)*W4*W4/(WN*WN));
    localparam signed [31:0] CC4=`CFG_Q20(W4*(1.0+`CFG_LQR_GAIN_SCALE*`CFG_K_ALPHA_DOT+`CFG_LQR_GAIN_SCALE*`CFG_K_ALPHA_C*D/(WN*WN)+`CFG_LQR_GAIN_SCALE*`CFG_K_THETA_DOT*CT4-W4*W4/(WN*WN)));
    localparam real W5=6283185.307179586/P5;
    localparam real CT5=-`CFG_SINE_FF_C_OVER_B*W5*W5/(`CFG_SWINGUP_H_OVER_B+W5*W5);
    localparam signed [31:0] CS5=`CFG_Q20(`CFG_LQR_GAIN_SCALE*`CFG_K_THETA*CT5-(D+`CFG_LQR_GAIN_SCALE*`CFG_K_ALPHA_C)*W5*W5/(WN*WN));
    localparam signed [31:0] CC5=`CFG_Q20(W5*(1.0+`CFG_LQR_GAIN_SCALE*`CFG_K_ALPHA_DOT+`CFG_LQR_GAIN_SCALE*`CFG_K_ALPHA_C*D/(WN*WN)+`CFG_LQR_GAIN_SCALE*`CFG_K_THETA_DOT*CT5-W5*W5/(WN*WN)));
    localparam real W6=6283185.307179586/P6;
    localparam real CT6=-`CFG_SINE_FF_C_OVER_B*W6*W6/(`CFG_SWINGUP_H_OVER_B+W6*W6);
    localparam signed [31:0] CS6=`CFG_Q20(`CFG_LQR_GAIN_SCALE*`CFG_K_THETA*CT6-(D+`CFG_LQR_GAIN_SCALE*`CFG_K_ALPHA_C)*W6*W6/(WN*WN));
    localparam signed [31:0] CC6=`CFG_Q20(W6*(1.0+`CFG_LQR_GAIN_SCALE*`CFG_K_ALPHA_DOT+`CFG_LQR_GAIN_SCALE*`CFG_K_ALPHA_C*D/(WN*WN)+`CFG_LQR_GAIN_SCALE*`CFG_K_THETA_DOT*CT6-W6*W6/(WN*WN)));
    localparam real W7=6283185.307179586/P7;
    localparam real CT7=-`CFG_SINE_FF_C_OVER_B*W7*W7/(`CFG_SWINGUP_H_OVER_B+W7*W7);
    localparam signed [31:0] CS7=`CFG_Q20(`CFG_LQR_GAIN_SCALE*`CFG_K_THETA*CT7-(D+`CFG_LQR_GAIN_SCALE*`CFG_K_ALPHA_C)*W7*W7/(WN*WN));
    localparam signed [31:0] CC7=`CFG_Q20(W7*(1.0+`CFG_LQR_GAIN_SCALE*`CFG_K_ALPHA_DOT+`CFG_LQR_GAIN_SCALE*`CFG_K_ALPHA_C*D/(WN*WN)+`CFG_LQR_GAIN_SCALE*`CFG_K_THETA_DOT*CT7-W7*W7/(WN*WN)));
    localparam real W8=6283185.307179586/P8;
    localparam real CT8=-`CFG_SINE_FF_C_OVER_B*W8*W8/(`CFG_SWINGUP_H_OVER_B+W8*W8);
    localparam signed [31:0] CS8=`CFG_Q20(`CFG_LQR_GAIN_SCALE*`CFG_K_THETA*CT8-(D+`CFG_LQR_GAIN_SCALE*`CFG_K_ALPHA_C)*W8*W8/(WN*WN));
    localparam signed [31:0] CC8=`CFG_Q20(W8*(1.0+`CFG_LQR_GAIN_SCALE*`CFG_K_ALPHA_DOT+`CFG_LQR_GAIN_SCALE*`CFG_K_ALPHA_C*D/(WN*WN)+`CFG_LQR_GAIN_SCALE*`CFG_K_THETA_DOT*CT8-W8*W8/(WN*WN)));
    function signed [31:0] cs;
        input [31:0] p;
        begin case(p)
            P0:cs=CS0;P1:cs=CS1;P2:cs=CS2;
            P3:cs=CS3;P4:cs=CS4;P5:cs=CS5;
            P6:cs=CS6;P7:cs=CS7;P8:cs=CS8;
            default:cs=0;
        endcase end
    endfunction
    function signed [31:0] cc;
        input [31:0] p;
        begin case(p)
            P0:cc=CC0;P1:cc=CC1;P2:cc=CC2;
            P3:cc=CC3;P4:cc=CC4;P5:cc=CC5;
            P6:cc=CC6;P7:cc=CC7;P8:cc=CC8;
            default:cc=0;
        endcase end
    endfunction
    localparam signed [31:0] LIMIT=$rtoi(`CFG_SINE_FF_LIMIT_RAD_S*65536.0+0.5);
    localparam signed [31:0] STEP=$rtoi(`CFG_SINE_FF_SLEW_RAD_S2*`CFG_CONTROL_PERIOD_US*0.065536+0.5);
    reg signed [21:0] rom[0:1023];
    `include "sine_ff_rom.vh"
    reg [9:0] address,phase_index;
    reg signed [21:0] rom_value;
    always @(posedge clk) rom_value<=rom[address];
    reg [2:0] state;
    reg [1:0] operation;
    reg [5:0] bit_index;
    reg signed [31:0] coeff_s,coeff_c,amplitude,first_term,combined;
    reg [63:0] multiplicand,accumulator;
    reg [31:0] multiplier;
    reg negative;
    wire [63:0] next_sum=accumulator+(multiplier[0] ? multiplicand:64'd0);
    wire signed [63:0] signed_product=negative ? -$signed(next_sum):$signed(next_sum);
    wire signed [31:0] operand_a=operation==2 ? combined:{{10{rom_value[21]}},rom_value};
    wire signed [31:0] operand_b=operation==0 ? coeff_s:operation==1 ? coeff_c:amplitude;
    reg signed [31:0] target;
    wire signed [31:0] bounded_target=target>LIMIT ? LIMIT:target< -LIMIT ? -LIMIT:target;
    wire signed [32:0] difference=$signed({bounded_target[31],bounded_target})-$signed({correction_q16[31],correction_q16});
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            correction_q16<=0;state<=0;operation<=0;bit_index<=0;
            address<=0;phase_index<=0;coeff_s<=0;coeff_c<=0;amplitude<=0;
            first_term<=0;combined<=0;multiplicand<=0;multiplier<=0;
            accumulator<=0;negative<=0;target<=0;
        end else if(clear || !enable || !ENABLED) begin
            correction_q16<=0;state<=0;target<=0;
        end else if(!active) begin
            // HMI hold/target: discard unfinished work and return smoothly to zero.
            state<=0;target<=0;
            if(tick) begin
                if(correction_q16>STEP) correction_q16<=correction_q16-STEP;
                else if(correction_q16< -STEP) correction_q16<=correction_q16+STEP;
                else correction_q16<=0;
            end
        end else begin
            case(state)
                0:if(sample_valid) begin
                    coeff_s<=cs(sample_period);coeff_c<=cc(sample_period);
                    amplitude<=sample_amplitude;
                    // Half-bin offset improves the un-interpolated ROM error.
                    phase_index<=sample_phase[31:22];address<=sample_phase[31:22];
                    operation<=0;state<=1;
                end
                1:state<=2; // synchronous ROM latency
                2:begin
                    multiplicand<={32'd0,operand_a[31] ? -operand_a:operand_a};
                    multiplier<=operand_b[31] ? -operand_b:operand_b;
                    negative<=operand_a[31]^operand_b[31];accumulator<=0;bit_index<=0;state<=3;
                end
                3:begin
                    accumulator<=next_sum;multiplicand<=multiplicand<<1;multiplier<=multiplier>>1;
                    bit_index<=bit_index+1'b1;
                    if(bit_index==31) begin
                        if(operation==0) begin
                            first_term<=signed_product>>>20;operation<=1;
                            address<=phase_index+10'd256;state<=1;
                        end else if(operation==1) begin
                            combined<=first_term+(signed_product>>>20);operation<=2;state<=2;
                        end else begin target<=signed_product>>>20;state<=4;end
                    end
                end
                4:begin
                    if(difference>STEP) correction_q16<=correction_q16+STEP;
                    else if(difference< -STEP) correction_q16<=correction_q16-STEP;
                    else correction_q16<=bounded_target;
                    state<=0;
                end
                default:state<=0;
            endcase
        end
    end
endmodule
