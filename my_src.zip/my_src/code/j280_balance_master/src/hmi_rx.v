`timescale 1ns/1ps
`include "control_config.vh"
// Fixed-length framing: payload bytes may contain both header and trailer.
// FRAME_TIMEOUT_CYCLES：帧内字节间空闲超时（时钟周期数），超过则丢弃半帧重同步。
//   默认 CLK_HZ/50 = 20ms，远大于 115200 下单帧耗时（~1.6ms），正常整帧发送不会触发；
//   若上位机/串口屏采用逐字节慢速发送，可在此调大。
//   注意：不能用 CLK_HZ*us/1e6 这种 32 位乘法（大 CLK_HZ 会溢出），
//   故直接以周期数为参数。
// BOOT_WINDOW_MS：串口屏开机序列（88 FF FF FF）只在复位后此窗口内被识别为 boot，
//   避免运行中误收到 88 FF FF FF 数据把控制状态清掉。
module hmi_rx #(parameter CLK_HZ=`CFG_HARDWARE_CLOCK_HZ,
                parameter BAUD=115200,
                parameter FRAME_TIMEOUT_CYCLES=CLK_HZ/50,
                parameter BOOT_WINDOW_MS=2000)(
 input clk,rst_n,rx,input restart,
 output reg valid,output reg [7:0] cmd,
 output reg signed [31:0] seq,arg,speed,output reg boot);
 wire [7:0] byte_data; wire byte_valid,frame_error;
 serial_rx #(.CLK_HZ(CLK_HZ),.BAUD(BAUD)) uart(clk,rst_n,rx,byte_data,byte_valid,frame_error);
 reg [4:0] pos; reg [31:0] age; reg [7:0] command;
 reg [31:0] s,a,v; reg [2:0] bootpos;
 // 上电 boot 窗口计数（ms 级）：窗口外不再识别 88 FF FF FF 开机序列。
 localparam [31:0] BOOT_WINDOW = (CLK_HZ/1000) * BOOT_WINDOW_MS;
 reg [31:0] uptime;
 wire boot_window_open = (uptime < BOOT_WINDOW);
 always @(posedge clk or negedge rst_n)
  if(!rst_n) uptime<=0;
  else if(uptime<BOOT_WINDOW) uptime<=uptime+1'b1;
 always @(posedge clk or negedge rst_n) begin
  if(!rst_n) begin pos<=0;age<=0;valid<=0;cmd<=0;seq<=0;arg<=0;speed<=0;s<=0;a<=0;v<=0;command<=0;boot<=0;bootpos<=0;end
  else begin
   valid<=0;boot<=0;
   if(pos!=0) age<=age+1'b1;
   if(frame_error || age>=FRAME_TIMEOUT_CYCLES || restart) begin pos<=0;age<=0;end
   else if(byte_valid) begin
    age<=0;
    // Native startup 88 FF FF FF, recognized only outside a request AND inside boot window.
    if(pos==0 && boot_window_open) begin
     case(bootpos)
      0:bootpos<=byte_data==8'h88 ? 1:0;
      1,2:bootpos<=byte_data==8'hff ? bootpos+1'b1:0;
      3:begin if(byte_data==8'hff) boot<=1;bootpos<=0;end
      default:bootpos<=0;
     endcase
    end else bootpos<=0;
    case(pos)
     0:if(byte_data==8'h55) pos<=1;
     1:if(byte_data==8'haa) pos<=2;else pos<=byte_data==8'h55 ? 1:0;
     2:if(byte_data==8'h20) pos<=3;else pos<=byte_data==8'h55 ? 1:0;
     3:begin command<=byte_data;pos<=4;end
     4,5,6,7:begin s[(pos-4)*8+:8]<=byte_data;pos<=pos+1'b1;end
     8,9,10,11:begin a[(pos-8)*8+:8]<=byte_data;pos<=pos+1'b1;end
     12,13,14,15:begin v[(pos-12)*8+:8]<=byte_data;pos<=pos+1'b1;end
     16:if(byte_data==8'h0d) pos<=17;else pos<=byte_data==8'h55 ? 1:0;
     17:begin
      pos<=byte_data==8'h55 ? 1:0;
      if(byte_data==8'h0a) begin cmd<=command;seq<=s;arg<=a;speed<=v;valid<=1;end
     end
     default:pos<=0;
    endcase
   end
  end
 end
endmodule
