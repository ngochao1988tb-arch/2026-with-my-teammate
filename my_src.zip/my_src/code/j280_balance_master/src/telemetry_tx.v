`timescale 1ns/1ps
`include "control_config.vh"
// AA55, parameter-sized snapshot, additive 16-bit checksum BE, 0D0A.
// Top v4: 122-byte payload, 128-byte frame; baud comes from control_config.vh.
module telemetry_tx #(parameter PAYLOAD_BYTES=58, CLK_HZ=`CFG_HARDWARE_CLOCK_HZ, BAUD=`CFG_TELEMETRY_BAUD, RATE_HZ=`CFG_TELEMETRY_RATE_HZ,
    parameter PIPELINE_INPUT=1)(
    input clk, input rst_n, input [PAYLOAD_BYTES*8-1:0] payload, output uart_tx
);
    reg [PAYLOAD_BYTES*8-1:0] snapshot;
    wire [PAYLOAD_BYTES*8-1:0] sampled_payload;
    generate if(PIPELINE_INPUT) begin:input_pipeline
        // An entire vector advances together. Break the path from complex
        // control/status logic through the serializer's snapshot/shift mux.
        // Probe age increases by one FPGA clock; no control output depends
        // on this register. PIPELINE_INPUT=0 is retained for equivalence QA.
        reg [PAYLOAD_BYTES*8-1:0] staged_payload;
        always @(posedge clk or negedge rst_n)
            if(!rst_n) staged_payload<=0;
            else staged_payload<=payload;
        assign sampled_payload=staged_payload;
    end else begin:direct_input
        assign sampled_payload=payload;
    end endgenerate
    reg [31:0] timer;
    reg [2:0] state;
    localparam FRAME_BYTES=PAYLOAD_BYTES+6;
    reg [$clog2(FRAME_BYTES)-1:0] index;
    reg [15:0] checksum;
    reg start;
    reg [7:0] data;
    wire busy, done;
    serial_tx #(.CLK_HZ(CLK_HZ),.BAUD(BAUD)) u_tx(
        .clk(clk),.rst_n(rst_n),.start(start),.data(data),.tx(uart_tx),.busy(busy),.done(done));
    always @* begin
        case(index)
            0:data=8'haa; 1:data=8'h55;
            PAYLOAD_BYTES+2:data=checksum[15:8]; PAYLOAD_BYTES+3:data=checksum[7:0];
            PAYLOAD_BYTES+4:data=8'h0d; PAYLOAD_BYTES+5:data=8'h0a;
            default:data=snapshot[PAYLOAD_BYTES*8-1-:8];
        endcase
    end
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin snapshot<=0; timer<=0; state<=0; index<=0; checksum<=0; start<=0; end
        else begin
            start<=0;
            if(timer<CLK_HZ/RATE_HZ-1) timer<=timer+1'b1;
            case(state)
                0:if(timer==CLK_HZ/RATE_HZ-1) begin
                    timer<=0; snapshot<=sampled_payload; checksum<=0; index<=0; state<=1;
                end
                1:if(!busy) begin start<=1; state<=2; end
                2:if(done) begin
                    if(index>=2 && index<=PAYLOAD_BYTES+1) begin
                        checksum<=checksum+snapshot[PAYLOAD_BYTES*8-1-:8];
                        snapshot<={snapshot[PAYLOAD_BYTES*8-9:0],8'b0};
                    end
                    if(index==FRAME_BYTES-1) state<=0;
                    else begin index<=index+1'b1; state<=1; end
                end
                default:state<=0;
            endcase
        end
    end
endmodule

// Read-only diagnostic sampling. No output from this module feeds control.
// Each emitted payload is followed by the unchanged telemetry_tx framing.
module fast_diag_snapshot #(
    parameter RATE_HZ=`CFG_FAST_DIAG_RATE_HZ,
    parameter OBSERVE_CLOCKS=512,parameter META_EVERY=256,parameter STATUS_ENABLED=0
)(
    input clk,rst_n,core_tick,applied,fresh,
    input [2:0] state,input saturated,numeric_fault,
    input signed [31:0] alpha_meas,theta_meas,alpha_dot,theta_dot,raw_u,motor_frequency,
    input [31:0] sequence_number,build_tag,
    input [15:0] encoder_zero,input [12:0] ad_zero,
    input signed [31:0] reference_q16,command_position,trim_value,
    input [7:0] trim_status,
    output reg [127:0] payload
);
    localparam integer DIV=1000000/(`CFG_CONTROL_PERIOD_US*RATE_HZ);
    localparam [15:0] PERIOD_US=`CFG_CONTROL_PERIOD_US,COUNTS_PI=`CFG_ADC_THETA_COUNTS_PER_PI;
    reg [(DIV>1 ? $clog2(DIV):1)-1:0] phase;
    reg [(META_EVERY>1 ? $clog2(META_EVERY):1)-1:0] packet_index;
    reg [$clog2(OBSERVE_CLOCKS+1)-1:0] delay_count;
    reg emit_this_frame,fresh_frame,fresh_interval,applied_seen;
    reg signed [31:0] alpha_sample,theta_sample,command_sample;
    reg status_phase;
    reg [15:0] eligible_count,qualified_count;
    wire signed [32:0] tracking_error=$signed({alpha_sample[31],alpha_sample})-$signed({command_sample[31],command_sample});
    function [31:0] pack32;
        input signed [32:0] value;
        begin pack32=value>33'sd2147483647 ? 32'h7fffffff:value< -33'sd2147483648 ? 32'h80000000:value[31:0];end
    endfunction
    reg [15:0] sequence_sample;
    function [15:0] pack16;
        input signed [31:0] value;input integer shift;
        reg signed [31:0] scaled;
        begin
            scaled=value>>>shift;
            pack16=scaled>32767 ? 16'h7fff:scaled< -32768 ? 16'h8000:scaled[15:0];
        end
    endfunction
    function clipped;
        input signed [31:0] value;input integer shift;
        reg signed [31:0] scaled;
        begin scaled=value>>>shift;clipped=scaled>32767 || scaled< -32768;end
    endfunction
    wire invalid=clipped(alpha_sample,1) || clipped(theta_sample,1) ||
        clipped(alpha_dot,4) || clipped(theta_dot,4) || clipped(raw_u,4) ||
        clipped(motor_frequency,5) || (state==3 && !applied_seen);
    wire [7:0] data_flags={numeric_fault,saturated,invalid,fresh_interval,fresh_frame,state};
    wire [7:0] metadata_flags={5'd0,clipped(reference_q16,3),
        (`CFG_HARDWARE_THETA_INVERT!=0),(`CFG_HARDWARE_ENCODER_INVERT!=0)};
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            phase<=0;packet_index<=0;delay_count<=0;emit_this_frame<=0;
            fresh_frame<=0;fresh_interval<=0;applied_seen<=0;
            alpha_sample<=0;theta_sample<=0;command_sample<=0;eligible_count<=0;qualified_count<=0;status_phase<=0;sequence_sample<=0;payload<=0;
        end else begin
            if(core_tick) begin
                phase<=phase==DIV-1 ? 0:phase+1'b1;
                emit_this_frame<=phase==0;
                alpha_sample<=alpha_meas;theta_sample<=theta_meas;
                command_sample<=command_position;
                sequence_sample<=sequence_number[15:0];fresh_frame<=fresh;
                fresh_interval<=fresh_interval || fresh;
                applied_seen<=0;delay_count<=OBSERVE_CLOCKS;
            end else if(delay_count!=0) delay_count<=delay_count-1'b1;
            if(applied) begin
                applied_seen<=1;
                if(state==3 && trim_status[7]) eligible_count<=eligible_count+1'b1;
                if(state==3 && trim_status[7] && trim_status[6]) qualified_count<=qualified_count+1'b1;
            end
            // Fixed late observation point: original control is checked to
            // finish in <500 clocks, well before this 512-clock snapshot.
            if(delay_count==1 && !core_tick && emit_this_frame) begin
                if(packet_index==0) begin
                    if(STATUS_ENABLED && status_phase)
                        payload<={8'd7,trim_status,sequence_sample,trim_value,pack32(tracking_error),eligible_count,qualified_count};
                    else
                        payload<={8'd6,metadata_flags,build_tag,3'd0,ad_zero,encoder_zero,
                            COUNTS_PI,PERIOD_US,pack16(reference_q16,3)};
                    status_phase<=!status_phase;
                end else
                    payload<={8'd5,data_flags,sequence_sample,pack16(alpha_sample,1),
                        pack16(theta_sample,1),pack16(alpha_dot,4),pack16(theta_dot,4),
                        pack16(raw_u,4),pack16(motor_frequency,5)};
                packet_index<=packet_index==META_EVERY-1 ? 0:packet_index+1'b1;
                fresh_interval<=0;
            end
        end
    end
endmodule
