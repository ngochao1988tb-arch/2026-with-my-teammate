`timescale 1ns/1ps
`include "control_config.vh"
// ============================================================================
// lqr_system —— 倒立摆完整控制器（LQR_sine_move 26103191 内核）+ project_01 外围
// ----------------------------------------------------------------------------
// 控制部分与 LQR_sine_move/src/top.v 的控制链逐句一致，包含：
//   起摆（能量泵 + 单次助推 + approach 局部反馈）
//   捕获（capture_command_guard 量化检查 + 捕获保持目标锁存）
//   直立平衡（0.5 ms 预测 LQR + 扩张状态观测器 + 有界回零偏置 + 正弦前馈）
//   RUN 三级串联陷波（8.3 / 12.5 / 9.77 Hz）
//   执行器整形（限速、死区补偿、微抖动、防粘滞踢动、静默闸门）
//   保护（行程包络、跌倒、饱和、数值故障、编码器/ADC 超时）
//
// 工程外围（本工程独有，不参与控制律）：
//   1) 上位机（K20/L20，板载 CH340）  —— hmi_rx + hmi_control + hmi_tx
//   2) TJC 串口屏（K22/L22）          —— hmi_rx + 同一套 hmi_control，快照广播
//   3) 从板链路（V8/V9）              —— slave_link（UART v2 协议 + 38 字节应答）
//   4) 语音模块 CI1302（Y14/Y15）     —— voice_uart_bridge / 协调器 / 路由 / 播报
//   5) 只读状态引出 st_*（供 rv32_soc 快照）与 rv_req 软核命令邮箱
//   6) uart_tx 二进制遥测（参数开关 ENABLE_TELEMETRY，默认关闭）
// ============================================================================
module lqr_system #(
    parameter ENCODER_INVERT=`CFG_HARDWARE_ENCODER_INVERT, THETA_INVERT=`CFG_HARDWARE_THETA_INVERT,
    parameter ENABLE_ACTIVE_HIGH=`CFG_HARDWARE_ENABLE_ACTIVE_HIGH,
    parameter integer MAX_FREQ_HZ=`CFG_CONTROL_MAX_FREQUENCY_HZ,
    parameter integer DIR_SETUP_US=`CFG_CONTROL_DIR_SETUP_US,
    // 陷波总开关：0 直接用裸 LQR 指令，1 走三级串联陷波（与 demo 一致）
    parameter NOTCH_EN=1,
    parameter SW1_AUTOSTART=`CFG_SUPERVISOR_SW1_AUTOSTART,
    // ---- 遥测开关：0=不例化遥测链（默认），1=二进制遥测从 telemetry_tx 输出 ----
    parameter integer ENABLE_TELEMETRY=0,
    parameter integer PC_DEBUG_EN=`CFG_PC_DEBUG_ENABLED,
    // ---- 语音 / 双板整合参数（与 PROJECT_ALL 一致）----
    // 持久模式：1=主摆，2=从摆，3=双摆；切换模式或硬件复位才改变。
    parameter integer VOICE_TARGET_TIMEOUT_MS=0,
    parameter integer VOICE_GAP_MS=700,
    parameter integer VOICE_ACTION_TIMEOUT_MS=20000,
    parameter integer VOICE_COORD_TIMEOUT_MS=26000,
    parameter integer SLAVE_CENTER=10000,
    parameter integer SLAVE_TRAVEL=2150,
    parameter integer SLAVE_COUNTS_PER_REV=1000
)(
    input clk_sys, input rst_n, input [3:0] key_sw,
    output pul_out, output dir_out, output ena_out,
    input motor_rx, output motor_tx,
    // 遥测专用口（与上位机口分开，ENABLE_TELEMETRY=0 时高阻）
    output telemetry_tx,
    output adc_clk, output adc_oe_n, input [9:0] adc_data_in,
    // 上位机：L20 收 / K20 发（板载 CH340N）
    input hmi_rx, output hmi_tx,
    // TJC 串口屏：K22 收 / L22 发
    input screen_rx, output screen_tx,
    // 从板 FPGA：V9 收 / V8 发
    input slave_rx, output slave_tx,
    // 语音模块 CI1302：Y15 收 / Y14 发
    input voice_rx, output voice_tx,
    // ---- 只读状态引出：仅供 rv32_soc 的一致性快照，不参与任何控制逻辑 ----
    output [31:0] st_alpha_q16, output [31:0] st_theta_q16, output [31:0] st_arm_ref_q16,
    output [31:0] st_freq_q8, output [31:0] st_u_q16,
    output [31:0] st_alpha_dot, output [31:0] st_theta_dot, output [31:0] st_alpha_c,
    output [31:0] st_enc_raw, output [31:0] st_enc_age_us, output [31:0] st_enc_seq,
    output [31:0] st_ctrl_count, output [31:0] st_t_us, output [12:0] st_ad_value,
    output [7:0]  st_state, output [7:0] st_fault, output [7:0] st_flags,
    output [31:0] st_build_tag,
    output st_run, output st_calibrated, output st_saturated, output st_fb_ready, output st_swing_active,
    // ---- 软核命令注入口：与 HMI 串口共用同一条 hmi_control 状态检查通路 ----
    // rv_req 为单周期脉冲，且只在 UART 无请求时给出；默认整体常 0。
    input        rv_req,
    input [7:0]  rv_cmd,
    input [31:0] rv_seq, rv_arg, rv_speed,
    output       rv_ack,
    output [31:0] rv_ack_seq, rv_ack_result,
    output       hmi_req_pulse     // UART 侧请求脉冲，供软核侧仲裁避让
);
    // 复位异步拉低、同步释放（整片设计唯一复位域）。
    reg [1:0] reset_sync;
    always @(posedge clk_sys or negedge rst_n)
        if(!rst_n) reset_sync<=0; else reset_sync<={reset_sync[0],1'b1};
    wire reset_n=reset_sync[1];

    // ==================================================================
    // 按键 / 微秒时基
    // ==================================================================
    wire [3:0] buttons;
    wire hmi_start,hmi_reset,hmi_stop,feedback_ready,manual_run;
    wire signed [31:0] manual_frequency_q8;
    genvar j;
    generate for(j=0;j<4;j=j+1) begin:keys
        key_debounce u_key(.clk(clk_sys),.rst_n(reset_n),.key_n(key_sw[j]),.pressed(buttons[j]));
    end endgenerate
    localparam US_DIV_WIDTH=(`CFG_HARDWARE_CLOCK_HZ/1000000>1) ? $clog2(`CFG_HARDWARE_CLOCK_HZ/1000000) : 1;
    reg [US_DIV_WIDTH-1:0] us_div;
    reg [31:0] t_us;
    wire us_tick=us_div==`CFG_HARDWARE_CLOCK_HZ/1000000-1;
    always @(posedge clk_sys or negedge reset_n) begin
        if(!reset_n) begin us_div<=0; t_us<=0; end
        else if(us_tick) begin us_div<=0; t_us<=t_us+1'b1; end
        else us_div<=us_div+1'b1;
    end

    // ==================================================================
    // 传感前端：ADC（0.5 ms/256 点）+ 编码器串口
    // ==================================================================
    wire [12:0] ad_value, ad_zero, ad_eff;
    wire dz_coast;
    wire sample_valid;
    adc_sampler u_adc(.clk(clk_sys),.rst_n(reset_n),.adc_data_in(adc_data_in),
        .adc_clk(adc_clk),.adc_oe_n(adc_oe_n),.ad_value(ad_value),.sample_valid(sample_valid));
    wire [15:0] encoder_raw, encoder_zero;
    wire encoder_valid, encoder_update;
    motor_encoder_link u_encoder(.clk(clk_sys),.rst_n(reset_n),.motor_rx(motor_rx),.motor_tx(motor_tx),
        .clear_request(1'b0),.encoder_raw(encoder_raw),.encoder_valid(encoder_valid),
        .encoder_update(encoder_update),.clear_done(),.clear_status(),.timeout_count());

    // ==================================================================
    // 控制核心信号
    // ==================================================================
    wire signed [31:0] signed_pulses;
    wire signed [31:0] alpha_meas, theta_meas, alpha_c;
    wire signed [31:0] alpha_hat, theta_hat, alpha_dot, theta_dot, u_q16;
    wire run, core_clear, core_tick, new_encoder, saturated, done, numeric_fault, calibrated;
    wire [2:0] state;
    wire [7:0] fault;
    wire [31:0] encoder_seq, encoder_age;
    wire swing_active=(state==5);
    wire signed [31:0] swing_frequency_q8, swing_theta_dot, swing_u;
    wire swing_velocity_valid;
    wire swing_recovery_active;
    wire [2:0] swing_launch_phase;
    wire signed [31:0] capture_arm_velocity;
    wire swing_capture_safe, capture_command_compatible;
    wire signed [31:0] capture_candidate_u;
    wire capture_preview_valid,approach_active;
    wire signed [31:0] approach_frequency_q8;
    wire signed [31:0] arm_target_goal_q16,arm_target_q16;
    wire capture_seed;
    // 捕获预览要用"捕获后真正生效"的那个保持参考；起摆阶段目标停在原处。
    wire signed [31:0] capture_reference_q16=swing_active ? alpha_meas : arm_target_q16;
    wire arm_target_moving,arm_target_accepted,arm_target_rejected;
    wire [1:0] arm_target_speed_level;
    wire hmi_arm_target_valid,hmi_arm_speed_valid,hmi_arm_hold_valid;
    wire signed [31:0] hmi_arm_target_q16;
    wire [6:0] hmi_arm_speed_percent;
    // 上位机 0x20~0x26：波形参数 / 轨迹点（hmi_control -> run_target）
    wire hmi_wave_set,hmi_wave_stop,hmi_track_request,hmi_point_valid;
    wire [1:0] hmi_wave_kind;
    wire [31:0] hmi_wave_period_us;
    wire signed [31:0] hmi_wave_amp_q16,hmi_point_q16;
    // 正弦前馈
    wire sine_sample_valid,sine_running,sine_ff_active;
    wire [31:0] sine_sample_phase,sine_sample_period;
    wire signed [31:0] sine_sample_amplitude,sine_ff_q16;
    // 这几个信号在下面的控制链里既做输入又做输出，这里统一先声明，
    // 避免依赖隐式线网（三源 HMI / 语音 / 静默闸门 / 行程包络）。
    reg  hmi_stop_q;                                  // 打一拍版本：只给监督器与参考发生器
    wire stall_release;                               // run_adc_quiet_gate 的暂停输出
    wire signed [31:0] travel_positive_limit_q8,travel_negative_limit_q8;
    wire        v_start,v_reset,v_stop;
    wire        v_target_valid;
    wire signed [31:0] v_target_q16;

    // ---- 死区桥接：ADC 撞轨时用摆杆模型外推（CFG_DZ_BRIDGE_ENABLED=0 时直通）----
    deadzone_bridge u_deadzone(.clk(clk_sys),.rst_n(reset_n),.sample_valid(sample_valid),
        .enable(`CFG_DZ_BRIDGE_ENABLED && state==5),.ad_raw(ad_value),.alpha_meas(alpha_meas),
        .frequency_q8(swing_frequency_q8),
        .ad_eff(ad_eff),.coast_active(dz_coast));

    // ==================================================================
    // RUN 参考：手动目标 / 波形 / 手写轨迹 / 捕获保持
    // ==================================================================
    // 语音移动与串口屏目标共用 run_target 的同一条绝对目标入口；
    // 同拍撞车时语音优先（人声是即时指令，屏幕是慢速滑条）。
    wire        rt_target_valid = v_target_valid | hmi_arm_target_valid;
    wire signed [31:0] rt_target_q16 = v_target_valid ? v_target_q16 : hmi_arm_target_q16;
    // SINE_DEMO=0 保持本地按键映射（SW2 应用/SW3 倍速/SW4 步进），
    // WAVE_EN=1 打开上位机/串口屏的波形与轨迹通道，两者互不干扰。
    // CAPTURE_HOLD=1：每次捕获把目标就地锁存到当前横臂角度。
    run_target #(.SINE_DEMO(0),.WAVE_EN(1),.CAPTURE_HOLD(1)) u_run_target(.clk(clk_sys),.rst_n(reset_n),
        // A calibrated HMI start keeps the arm target selected from the screen.
        .clear(!calibrated || buttons[0] || hmi_reset || hmi_stop_q || v_reset || v_stop),
        .tick(core_tick),.run_mode(state==3 && run),
        .feedback_valid(encoder_valid && encoder_age<`CFG_SUPERVISOR_ENCODER_TIMEOUT_US),
        .angle_step(buttons[3]),.speed_double(buttons[2]),.move(buttons[1]),.alpha_meas(alpha_meas),.goal_q16(arm_target_goal_q16),
        .reference_q16(arm_target_q16),.moving(arm_target_moving),
        .accepted(arm_target_accepted),.rejected(arm_target_rejected),.speed_level(arm_target_speed_level),
        .hmi_target_valid(rt_target_valid),.hmi_target_q16(rt_target_q16),
        .hmi_speed_valid(hmi_arm_speed_valid),.hmi_speed_percent(hmi_arm_speed_percent),
        .hmi_hold_valid(hmi_arm_hold_valid),
        .neg_step(1'b0),.amplitude_step(1'b0),
        .hmi_wave_start(hmi_wave_set),.hmi_wave_kind(hmi_wave_kind),
        .hmi_wave_period_us(hmi_wave_period_us),.hmi_wave_amp_q16(hmi_wave_amp_q16),
        .hmi_wave_stop(hmi_wave_stop),.hmi_track_mode(hmi_track_request),
        .hmi_point_valid(hmi_point_valid),.hmi_point_q16(hmi_point_q16),
        .capture_hold(capture_seed),
        .sine_sample_valid(sine_sample_valid),.sine_running(sine_running),.sine_ff_active(sine_ff_active),
        .sine_sample_phase(sine_sample_phase),.sine_sample_period(sine_sample_period),
        .sine_sample_amplitude(sine_sample_amplitude));

    // ---- 正弦轨迹前馈：只修正 RUN 的跟踪误差，不改增益、不碰观测器 ----
    // enable 打一拍：run 是 supervisor 的组合输出（依赖 external_stop→hmi_stop→estop），
    // 若直接连会让「软核命令 → estop → run → sine_ff 组合 mux」成为超长组合链
    // （实测 Fmax 掉到 32.8MHz）。前馈修正是缓慢变化的，晚一拍生效无感。
    reg sine_ff_enable_q;
    always @(posedge clk_sys or negedge reset_n)
        if(!reset_n) sine_ff_enable_q<=0;
        else sine_ff_enable_q<=run && state==3;
    sine_feedforward u_sine_ff(.clk(clk_sys),.rst_n(reset_n),.clear(core_clear),
        .tick(core_tick),.enable(sine_ff_enable_q),.active(sine_ff_active),
        .sample_valid(sine_sample_valid),.sample_phase(sine_sample_phase),
        .sample_period(sine_sample_period),.sample_amplitude(sine_sample_amplitude),
        .correction_q16(sine_ff_q16));

    // ==================================================================
    // 捕获判据链
    // ==================================================================
    reg capture_preview_tick;
    always @(posedge clk_sys or negedge reset_n)
        if(!reset_n) capture_preview_tick<=0;else capture_preview_tick<=core_tick;
    capture_command_guard u_capture_guard(
        .clk(clk_sys),.rst_n(reset_n),.tick(capture_preview_tick),.enable(swing_active),
        .alpha(alpha_meas),.theta(theta_meas),.alpha_dot(capture_arm_velocity),
        .theta_dot(swing_theta_dot),.alpha_c(alpha_c),.swing_u(swing_u),
        .compatible(capture_command_compatible),.candidate_u(capture_candidate_u),
        .candidate_valid(capture_preview_valid),.arm_reference_q16(capture_reference_q16));
    wire capture_arm_valid;
    wire signed [31:0] run_trim_u;
    wire [7:0] run_trim_status;
    localparam signed [31:0] CAPTURE_ARM_SPEED=$rtoi(`CFG_SWINGUP_CAPTURE_ARM_SPEED_RAD_S*65536.0);
    reg capture_motion_valid;
    always @(posedge clk_sys or negedge reset_n)
        if(!reset_n) capture_motion_valid<=0;
        else capture_motion_valid<=!swing_recovery_active && capture_arm_valid && swing_capture_safe && capture_command_compatible &&
            approach_frequency_q8<=travel_positive_limit_q8 && approach_frequency_q8>=-travel_negative_limit_q8 &&
            swing_u<=CAPTURE_ARM_SPEED && swing_u>= -CAPTURE_ARM_SPEED;
    arm_capture_velocity u_capture_velocity(
        .clk(clk_sys),.rst_n(reset_n),.clear(!calibrated),.tick(core_tick),
        .fresh(new_encoder && encoder_valid),.angle(alpha_meas),
        .velocity(capture_arm_velocity),.valid(capture_arm_valid));

    // ==================================================================
    // 行程包络与起摆↔平衡切换
    // ==================================================================
    reg signed [31:0] frequency_q8;
    arm_travel_guard #(.MAX_FREQ_HZ(MAX_FREQ_HZ)) u_travel_guard(
        .clk(clk_sys),.rst_n(reset_n),.alpha_meas(alpha_meas),.alpha_c(alpha_c),.arm_reference_q16(arm_target_q16),
        .arm_velocity(capture_arm_velocity),.velocity_valid(capture_arm_valid),
        .positive_limit_q8(travel_positive_limit_q8),.negative_limit_q8(travel_negative_limit_q8));
    reg travel_recovery_request;
    wire travel_recovery_qualified;
    wire [7:0] run_exit_reason;
    wire [15:0] run_exit_count;
    always @(posedge clk_sys or negedge reset_n)
        if(!reset_n) travel_recovery_request<=0;
        else travel_recovery_request<=state==3 && run &&
            ((frequency_q8>travel_positive_limit_q8) || (frequency_q8< -travel_negative_limit_q8));
    reg was_swing;
    reg was_run;
    reg signed [31:0] motor_frequency_q8;
    always @(posedge clk_sys or negedge reset_n)
        if(!reset_n) begin was_swing<=0; was_run<=0; end
        else begin was_swing<=swing_active; was_run<=state==3; end
    assign capture_seed=was_swing && state==3;
    wire run_to_swing=was_run && swing_active;
    reg signed [31:0] restart_frequency_q8;
    always @(posedge clk_sys or negedge reset_n)
        if(!reset_n) restart_frequency_q8<=0;
        // 含跌倒交接沿：继承最后一次真正下发到电机的指令。
        else if(state==3 && run) restart_frequency_q8<=motor_frequency_q8;

    // ==================================================================
    // 起摆 / 捕获 / 平衡
    // ==================================================================
    swingup_core #(.THETA_INVERT(THETA_INVERT),.MAX_FREQ_HZ(MAX_FREQ_HZ),.UPDATE_CLOCKS(220)) u_swingup(
        .clk(clk_sys),.rst_n(reset_n),.sample_valid(sample_valid),.enable(swing_active && run),
        .ad_value(ad_eff),.alpha_meas(alpha_meas),.alpha_c(alpha_c),
        .approach_valid(capture_preview_valid && capture_arm_valid),.approach_active(approach_active),
        .approach_frequency_q8(approach_frequency_q8),.approach_arm_velocity(capture_arm_velocity),.arm_reference_q16(arm_target_q16),
        .frequency_q8(swing_frequency_q8),.theta_dot_q16(swing_theta_dot),.u_q16(swing_u),
        .velocity_valid(swing_velocity_valid),.capture_safe(swing_capture_safe),
        .restart(run_to_swing),.restart_frequency_q8(restart_frequency_q8),.recovery_active(swing_recovery_active),
        .launch_phase(swing_launch_phase));
    control_supervisor #(.ENCODER_INVERT(ENCODER_INVERT),.THETA_INVERT(THETA_INVERT),.SW1_AUTOSTART(SW1_AUTOSTART)) u_supervisor(
        .clk(clk_sys),.rst_n(reset_n),.us_tick(us_tick),.sample_valid(sample_valid),.buttons(buttons[2:0]),
        .ad_value(ad_eff),.encoder_raw(encoder_raw),.encoder_update(encoder_update),.encoder_valid(encoder_valid),
        // An unavailable capture speed must reject capture, never look stationary.
        .signed_pulses(signed_pulses),.pul(pul_out),
        .alpha_dot(swing_active ? (capture_motion_valid ? capture_arm_velocity : 32'sh7fffffff) : alpha_dot),
        .theta_dot(swing_active ? swing_theta_dot : theta_dot),
        .saturated(saturated),.numeric_fault(numeric_fault),.state(state),.fault(fault),.run(run),
        .core_clear(core_clear),.core_tick(core_tick),.new_encoder(new_encoder),
        .alpha_meas(alpha_meas),.theta_meas(theta_meas),.alpha_c(alpha_c),
        .encoder_zero(encoder_zero),.ad_zero(ad_zero),.encoder_seq(encoder_seq),
        .encoder_age_us(encoder_age),.calibrated(calibrated),
        // 语音「起摆 / 开始平衡」与串口屏「起摆」共用同一条启动路径。
        // 起摆/复位不额外门控：停止优先已由下面 external_stop 在 supervisor 内部
        // 的分支优先级保证（if(external_stop) 先于 else if(remote_start)）。
        // 若这里再加 !hmi_stop_q 门控，会在起摆当拍 hmi_stop_q 恰好为 1 时误挡起摆。
        .remote_start(hmi_start || v_start),
        .remote_reset(hmi_reset || v_reset),
        // 「纯停止」才停机：hmi_stop 里混有 remote_start/remote_reset 两项
        // （stop_control = estop||remote_reset||remote_start||停止命令），
        // 起摆/复位时这两项会把 hmi_stop 拉高，若不排除会把「起摆」当成「停止」、
        // 反过来压制自己的起摆，导致急停后无法再起摆（联调发现的 bug）。
        // 必须用未打拍的 hmi_stop 与未打拍的 hmi_start/hmi_reset 同拍抵消，
        // 若用打拍版 hmi_stop_q 会造成 remote_start 项与 !hmi_start 时序错位、抵消失效。
        .external_stop((hmi_stop && !hmi_start && !hmi_reset) || v_stop),
        .feedback_ready(feedback_ready),.swing_velocity_valid(swing_velocity_valid),
        .travel_recovery_request(travel_recovery_request),.arm_reference_q16(arm_target_q16),
        .travel_recovery_qualified(travel_recovery_qualified),
        .run_exit_reason(run_exit_reason),.run_exit_count(run_exit_count));

    localparam signed [31:0] U_MAX_Q16 = (`CFG_PULSE_RAD_Q32 * 64'sd1 * MAX_FREQ_HZ) >>> 16;
    // LQR 寄存器使能与监督器的反馈/限幅缩减解耦；电机通断仍在下面直连。
    reg lqr_enable;
    always @(posedge clk_sys or negedge reset_n)
        if(!reset_n) lqr_enable<=0;
        else lqr_enable<=run && !swing_active;
    // LQR 节拍：core_tick 仍是 0.5 ms 的 ADC/监督器帧，LQR+观测器+陷波按 3 ms 执行。
    // 只降速 LQR 这一条链，起摆（swingup_core 自己 2 ms 分频）、ADC、监督器全部不变。
    localparam integer LQR_TICK_DIV = `CFG_LQR_PERIOD_US/`CFG_CONTROL_PERIOD_US;
    reg [7:0] lqr_tick_div;
    reg lqr_tick;
    always @(posedge clk_sys or negedge reset_n)
        if(!reset_n) begin lqr_tick_div<=0; lqr_tick<=0; end
        else begin
            lqr_tick<=0;
            // clear 期间把分频器预置到最后一格，RUN 进来的第一拍立即出 LQR 结果，
            // 避免捕获交接时多等 3 ms。
            if(core_clear) lqr_tick_div<=LQR_TICK_DIV-1;
            else if(core_tick) begin
                if(lqr_tick_div>=LQR_TICK_DIV-1) begin lqr_tick_div<=0; lqr_tick<=1; end
                else lqr_tick_div<=lqr_tick_div+1'b1;
            end
        end
    lqr_core #(.U_MAX_Q16(U_MAX_Q16),.FEEDFORWARD_EN(`CFG_SINE_FF_ENABLED),.PAUSE_TRIM_EN(1)) u_lqr(
        .clk(clk_sys),.rst_n(reset_n),.tick(lqr_tick),.clear(core_clear),.enable(lqr_enable),
        .alpha_meas(alpha_meas),.alpha_update(new_encoder),.theta_meas(theta_meas),.alpha_c(alpha_c),
        .alpha_hat(alpha_hat),.theta_hat(theta_hat),.alpha_dot_hat(alpha_dot),.theta_dot_hat(theta_dot),
        .u_q16(u_q16),.saturated(saturated),.done(done),.numeric_fault(numeric_fault),
        .seed(capture_seed),.seed_alpha_dot(capture_arm_velocity),.seed_theta_dot(swing_theta_dot),.seed_u(swing_u),
        .trim_u_q16(run_trim_u),.trim_status(run_trim_status),
        .arm_reference_q16(arm_target_q16),
        .reference_changing(arm_target_moving || arm_target_accepted || sine_ff_q16!=0),
        .feedforward_q16(sine_ff_q16),.trim_pause(stall_release || travel_recovery_request));

    // ==================================================================
    // RUN 指令整形：三级陷波 -> 限速 -> 死区补偿 -> 抖动/踢动 -> 行程钳位
    // ==================================================================
    localparam signed [31:0] MAX_FREQ_Q8 = MAX_FREQ_HZ * 256;
    // 指令每次 LQR 更新（CFG_LQR_PERIOD_US，3 ms）才变一次，限速步长按该周期折算。
    localparam signed [31:0] RUN_FREQ_SLEW_Q8_PER_TICK =
        (`CFG_LQR_COMMAND_SLEW_HZ_PER_S*64'sd256*`CFG_LQR_PERIOD_US)/64'sd1000000;
    reg signed [63:0] frequency_product;
    reg signed [31:0] run_rate_frequency_q8;
    wire signed [31:0] run_u_q16;
    wire run_notch_done;
    wire signed [31:0] primary_notch_u_q16,aux_notch_u_q16,n977_notch_u_q16;
    wire primary_notch_done,aux_notch_done,n977_notch_done;
    // 26110302：陷波节只保留"实际使能的最后一节"。此前固定选 aux/977，
    // 一旦关闭某节，被关闭模块会把状态清零、输出恒 0，导致指令被清零。
    assign run_u_q16=!NOTCH_EN ? u_q16 :
        (`CFG_RUN_NOTCH_977_ENABLED ? n977_notch_u_q16 :
         `CFG_RUN_NOTCH_AUX_ENABLED ? aux_notch_u_q16 : primary_notch_u_q16);
    assign run_notch_done=!NOTCH_EN ? done :
        (`CFG_RUN_NOTCH_977_ENABLED ? n977_notch_done :
         `CFG_RUN_NOTCH_AUX_ENABLED ? aux_notch_done : primary_notch_done);
    reg [2:0] run_command_ready_pipe;
    // 等到选中的结果出来，再让共用乘法器与频率寄存器稳定；本帧就算完，不等下一个 0.5 ms。
    always @(posedge clk_sys or negedge reset_n)
        if(!reset_n) run_command_ready_pipe<=0;
        else if(!run || swing_active || manual_run) run_command_ready_pipe<=0;
        else run_command_ready_pipe<={run_command_ready_pipe[1:0],run_notch_done};
    run_notch u_run_notch(
        .clk(clk_sys),.rst_n(reset_n),.tick(done),.enable(run && !swing_active),
        .u(u_q16),.y(primary_notch_u_q16),.done(primary_notch_done));
    run_notch #(.C0(`CFG_RUN_NOTCH_AUX_C0_Q13),.C1(`CFG_RUN_NOTCH_AUX_C1_Q13),
        .C2(`CFG_RUN_NOTCH_AUX_C2_Q13),.C3(`CFG_RUN_NOTCH_AUX_C3_Q13),
        .C4(`CFG_RUN_NOTCH_AUX_C4_Q13)) u_run_notch_aux(
        .clk(clk_sys),.rst_n(reset_n),.tick(primary_notch_done),
        .enable(run && !swing_active && `CFG_RUN_NOTCH_AUX_ENABLED),
        .u(primary_notch_u_q16),.y(aux_notch_u_q16),.done(aux_notch_done));
    run_notch #(.C0(`CFG_RUN_NOTCH_977_C0_Q13),.C1(`CFG_RUN_NOTCH_977_C1_Q13),
        .C2(`CFG_RUN_NOTCH_977_C2_Q13),.C3(`CFG_RUN_NOTCH_977_C3_Q13),
        .C4(`CFG_RUN_NOTCH_977_C4_Q13)) u_run_notch_977(
        .clk(clk_sys),.rst_n(reset_n),.tick(aux_notch_done),
        .enable(run && !swing_active && `CFG_RUN_NOTCH_977_ENABLED),
        .u(aux_notch_u_q16),.y(n977_notch_u_q16),.done(n977_notch_done));
    // 复用同一个换算 DSP：SWINGUP 时 LQR 被 clear，这条通路刚好空出来。
    assign approach_frequency_q8=(frequency_product>>>20)>MAX_FREQ_Q8 ? MAX_FREQ_Q8 :
        (frequency_product>>>20)< -MAX_FREQ_Q8 ? -MAX_FREQ_Q8 : frequency_product>>>20;
    always @(posedge clk_sys or negedge reset_n) begin
        if(!reset_n) begin frequency_product<=0; frequency_q8<=0; end
        else begin
            frequency_product<=$signed(swing_active ? capture_candidate_u : run_u_q16)*`CFG_FREQUENCY_CONVERSION;
            if(!run) frequency_q8<=0;
            else if(run_to_swing) frequency_q8<=restart_frequency_q8;
            else if(swing_active) frequency_q8<=swing_frequency_q8;
            else if((frequency_product>>>20)>MAX_FREQ_Q8) frequency_q8<=MAX_FREQ_Q8;
            else if((frequency_product>>>20)< -MAX_FREQ_Q8) frequency_q8<=-MAX_FREQ_Q8;
            else frequency_q8<=frequency_product>>>20;
        end
    end
    // 指令选择打一拍：feedback-ready/手动许可的组合逻辑不能再和电机相位加法器同拍。
    // 停止仍走 run 直连，不增加停机延迟。
    wire signed [31:0] motor_cmd_clamped=
        (run_rate_frequency_q8>travel_positive_limit_q8) ? travel_positive_limit_q8 :
        (run_rate_frequency_q8< -travel_negative_limit_q8) ? -travel_negative_limit_q8 :
        run_rate_frequency_q8;
    // 26103138：分级死区前馈，仅 RUN。静止时为 0，4 Hz 附近升到 +2 Hz，
    // 到 20 Hz 线性回落为 0。没有阈值跳变，也没有恒定速度偏置。
    // Q8 频率单位：512=2 Hz，1024=4 Hz，5120=20 Hz；F1-F0=4096。
    localparam [31:0] DB_MAX=32'sd512;
    localparam [31:0] DB_F0=32'sd1024;
    localparam [31:0] DB_F1=32'sd5120;
    wire [31:0] db_abs = motor_cmd_clamped[31] ? -motor_cmd_clamped : motor_cmd_clamped;
    wire [31:0] db_comp = (db_abs<=DB_F0) ? (db_abs>>1) :
                          (db_abs<DB_F1) ? ((DB_F1-db_abs)>>3) : 32'd0;
    wire signed [31:0] motor_cmd_comp = motor_cmd_clamped +
        (motor_cmd_clamped[31] ? -$signed(db_comp) : $signed(db_comp));
    wire signed [31:0] motor_cmd_final=(`CFG_RUN_DEADBAND_EN && state==3 && !manual_run) ? motor_cmd_comp : motor_cmd_clamped;
    // 26103190：ADC 码值合格且恒定后暂停脉冲，但采集与观测器继续跑；
    // 任何可观测扰动都直接旁路这个暂停。
    run_adc_quiet_gate u_quiet_gate(.clk(clk_sys),.rst_n(reset_n),.tick(core_tick),
        .hold_mode(run && state==3 && !manual_run && !hmi_stop && !v_stop && !core_clear &&
            !arm_target_moving && !arm_target_accepted && !sine_running && sine_ff_q16==0),
        .ad_value(ad_value),.theta(theta_meas),.theta_dot(theta_dot),
        .arm(alpha_meas),.arm_dot(alpha_dot),.motor_frequency_q8(motor_frequency_q8),
        .pause(stall_release));
    // 26103174：直立微抖动。RUN 在直立附近稳定时，发出一小段 HZ 脉冲，
    // 每段换一次方向，让横臂保持可见的左右小动作。注入点在限速与行程钳位之后，
    // 所以脉冲个数可预期；静默释放优先。
    localparam signed [31:0] DITHER_HZ_Q8=`CFG_DITHER_HZ*256;
    localparam [31:0] DITHER_US=(`CFG_DITHER_PULSES*1000000)/`CFG_DITHER_HZ;
    localparam [31:0] DITHER_PERIOD_US=`CFG_DITHER_PERIOD_MS*1000;
    localparam [31:0] DITHER_STEADY_US=`CFG_DITHER_STEADY_MS*1000;
    localparam signed [31:0] DITHER_STEADY_DEG_Q16=$rtoi(`CFG_DITHER_STEADY_DEG*3.14159265358979323846/180.0*65536.0);
    localparam signed [31:0] DITHER_STEADY_RATE_Q16=$rtoi(`CFG_DITHER_STEADY_RAD_S*65536.0);
    reg dither_burst,dither_dir;
    reg [31:0] dither_steady_since,dither_burst_since,dither_next;
    wire dither_steady_now=run && state==3 && !swing_active && !manual_run && !stall_release &&
        !arm_target_moving && !sine_running &&
        (theta_meas<DITHER_STEADY_DEG_Q16 && theta_meas> -DITHER_STEADY_DEG_Q16) &&
        (theta_dot<DITHER_STEADY_RATE_Q16 && theta_dot> -DITHER_STEADY_RATE_Q16);
    always @(posedge clk_sys or negedge reset_n)
        if(!reset_n) begin
            dither_burst<=0; dither_dir<=0;
            dither_steady_since<=0; dither_burst_since<=0; dither_next<=0;
        end else if(!run || state!=3) begin
            dither_burst<=0; dither_steady_since<=0; dither_next<=t_us;
        end else if(core_tick) begin
            if(dither_burst) begin
                if((t_us-dither_burst_since)>=DITHER_US) begin
                    dither_burst<=0; dither_next<=t_us+DITHER_PERIOD_US;
                end
            end else if(dither_steady_now) begin
                if(dither_steady_since==0) dither_steady_since<=t_us;
                else if((t_us-dither_steady_since)>=DITHER_STEADY_US && t_us>=dither_next) begin
                    dither_burst<=1; dither_burst_since<=t_us; dither_dir<=~dither_dir;
                    dither_steady_since<=0;
                end
            end else dither_steady_since<=0;
        end
    wire signed [31:0] dither_q8=(`CFG_DITHER_ENABLED && dither_burst) ?
        (dither_dir ? -DITHER_HZ_Q8 : DITHER_HZ_Q8) : 32'sd0;
    wire signed [31:0] motor_cmd_dither_raw=motor_cmd_final+dither_q8;
    wire signed [31:0] motor_cmd_dither=(motor_cmd_dither_raw>MAX_FREQ_Q8) ? MAX_FREQ_Q8 :
        (motor_cmd_dither_raw< -MAX_FREQ_Q8) ? -MAX_FREQ_Q8 : motor_cmd_dither_raw;
    always @(posedge clk_sys or negedge reset_n)
        if(!reset_n) motor_frequency_q8<=0;
        else if(manual_run) motor_frequency_q8<=manual_frequency_q8;
        else if(stall_release) motor_frequency_q8<=0;
        else motor_frequency_q8<=motor_cmd_dither;
    // 26103170：仅 RUN 的静摩擦踢动。实测摆角在 QUAL 帧内冻住说明支点卡住，
    // 就朝倾斜方向追加一个短速度脉冲，后面的限速与行程钳位照常整形。
    // RUN 之外、饱和时、目标运动中都不踢。
    localparam signed [31:0] KICK_STILL_Q16=
        $rtoi(`CFG_KICK_STILL_DEG*3.14159265358979323846/180.0*65536.0);
    localparam signed [31:0] KICK_MIN_Q16=
        $rtoi(`CFG_KICK_THETA_MIN_DEG*3.14159265358979323846/180.0*65536.0);
    localparam signed [31:0] KICK_MAX_Q16=
        $rtoi(`CFG_KICK_THETA_MAX_DEG*3.14159265358979323846/180.0*65536.0);
    localparam signed [31:0] KICK_Q8=`CFG_KICK_HZ*256;
    reg signed [31:0] kick_ref_theta;
    reg [15:0] kick_still_cnt,kick_run_cnt,kick_cool_cnt;
    reg kick_active,kick_sign;
    wire kick_qualified=run && state==3 && !swing_active && !manual_run && !saturated &&
        !arm_target_moving && !sine_running && !hmi_stop && !v_stop && !stall_release &&
        (theta_meas>KICK_MIN_Q16 || theta_meas< -KICK_MIN_Q16) &&
        (theta_meas<KICK_MAX_Q16 && theta_meas> -KICK_MAX_Q16);
    wire signed [31:0] kick_delta=theta_meas-kick_ref_theta;
    wire kick_still=(kick_delta<KICK_STILL_Q16 && kick_delta> -KICK_STILL_Q16);
    always @(posedge clk_sys or negedge reset_n)
        if(!reset_n) begin
            kick_ref_theta<=0; kick_still_cnt<=0; kick_run_cnt<=0; kick_cool_cnt<=0;
            kick_active<=0; kick_sign<=0;
        end else if(!run || state!=3) begin
            kick_still_cnt<=0; kick_run_cnt<=0; kick_cool_cnt<=0; kick_active<=0;
        end else if(core_tick) begin
            if(kick_active) begin
                if(kick_run_cnt==0) begin kick_active<=0; kick_cool_cnt<=`CFG_KICK_REFRACTORY_FRAMES; end
                else kick_run_cnt<=kick_run_cnt-1'b1;
            end else if(kick_cool_cnt!=0) begin
                kick_cool_cnt<=kick_cool_cnt-1'b1; kick_still_cnt<=0;
            end else if(!kick_qualified) begin
                kick_still_cnt<=0;
            end else if(kick_still_cnt==0) begin
                kick_ref_theta<=theta_meas; kick_still_cnt<=1;
            end else if(kick_still) begin
                if(kick_still_cnt>=`CFG_KICK_QUAL_FRAMES-1) begin
                    kick_active<=1; kick_run_cnt<=`CFG_KICK_FRAMES-1;
                    kick_sign<=theta_meas[31]; kick_still_cnt<=0;
                end else kick_still_cnt<=kick_still_cnt+1'b1;
            end else begin
                kick_ref_theta<=theta_meas; kick_still_cnt<=1;
            end
        end
    wire signed [31:0] kick_q8=(`CFG_KICK_ENABLED && kick_active) ?
        (kick_sign ? -KICK_Q8 : KICK_Q8) : 32'sd0;
    wire signed [31:0] frequency_q8_eff=frequency_q8+kick_q8;
    wire signed [31:0] run_slew_candidate_q8=
        (frequency_q8_eff>run_rate_frequency_q8+RUN_FREQ_SLEW_Q8_PER_TICK) ?
            run_rate_frequency_q8+RUN_FREQ_SLEW_Q8_PER_TICK :
        (frequency_q8_eff<run_rate_frequency_q8-RUN_FREQ_SLEW_Q8_PER_TICK) ?
            run_rate_frequency_q8-RUN_FREQ_SLEW_Q8_PER_TICK : frequency_q8_eff;
    // 只限 RUN 的 LQR 指令；起摆恢复自己有更快的斜坡。
    always @(posedge clk_sys or negedge reset_n)
        if(!reset_n) run_rate_frequency_q8<=0;
        else if(!run) run_rate_frequency_q8<=0;
        else if(manual_run) run_rate_frequency_q8<=manual_frequency_q8;
        else if(stall_release) run_rate_frequency_q8<=0;
        // 进入 SWINGUP 时继承"真正下发到电机"的那条指令，而不是本帧未限速的 LQR 请求，
        // 否则第一帧起摆会突然回跳一个限速/行程差值。
        else if(run_to_swing) run_rate_frequency_q8<=restart_frequency_q8;
        else if(!(state==3 && !swing_active)) run_rate_frequency_q8<=frequency_q8;
        else if(run_command_ready_pipe[2]) begin
            // Track the constrained command so hidden outward slew cannot delay reversal.
            if(run_slew_candidate_q8>travel_positive_limit_q8)
                run_rate_frequency_q8<=travel_positive_limit_q8;
            else if(run_slew_candidate_q8< -travel_negative_limit_q8)
                run_rate_frequency_q8<=-travel_negative_limit_q8;
            else run_rate_frequency_q8<=run_slew_candidate_q8;
        end
    variable_step_dir #(
        .ENABLE_ACTIVE_HIGH(ENABLE_ACTIVE_HIGH),
        .DIR_SETUP_US(DIR_SETUP_US)
    ) u_motor(
        .clk(clk_sys),.rst_n(reset_n),.run((run || manual_run) && !hmi_stop && !v_stop),.frequency_q8(motor_frequency_q8),
        .pul(pul_out),.dir(dir_out),.ena(ena_out),.signed_pulses(signed_pulses),.pulse_event());

    // ==================================================================
    // 诊断：控制帧计数 / flags / 82 字节遥测
    // ==================================================================
    reg [15:0] control_count;
    always @(posedge clk_sys or negedge reset_n)
        if(!reset_n) control_count<=0; else if(done) control_count<=control_count+1'b1;
    // flag[6] 标识本版捕获判据特性；flag[7] 保留给下面的历史故障事件。
    wire [7:0] flags={2'b01,(swing_active && !swing_velocity_valid),(swing_active && (ad_value<`CFG_ADC_RAIL_MIN || ad_value>`CFG_ADC_RAIL_MAX)),numeric_fault,saturated,encoder_valid,calibrated};
    // v8 版本号；本版源码改动时递增。
    // 26110302: LQR/观测器/陷波降到 3 ms 执行（core_tick 6 分频），
    // 换用 PROJECT_ALL 的 3 ms 预测矩阵、观测器增益、单节 9.5 Hz 陷波，GAIN_SCALE 0.45。
    // 26110303: CFG_PC_DEBUG_ENABLED=0，K20/L20 恢复上位机协议（快照上行 + 命令下行）。
    // 26110304: 首次/重新起摆 approach 减速增加约 10%，其余控制与串口配置保留。
    // 26110305: 首次/重起摆分档增强减速，捕获摆角和速度门限放宽 5%。
    // 26110306: 首次捕获前减速 +5%，重起摆捕获前/起始回收减速 +10%。
    localparam [31:0] BUILD_TAG=32'h26110306;
    wire travel_envelope_active=(travel_positive_limit_q8<MAX_FREQ_Q8 || travel_negative_limit_q8<MAX_FREQ_Q8);
    wire [31:0] diagnostic_status={8'd0,swing_launch_phase,arm_target_speed_level,arm_target_moving,(arm_target_goal_q16!=0),arm_target_rejected,run_trim_status,travel_envelope_active,swing_recovery_active,
        approach_active,capture_preview_valid,capture_command_compatible,
        capture_arm_valid,swing_capture_safe,swing_velocity_valid};
    wire [655:0] live_payload={8'd3,5'd0,state,fault,flags,t_us,signed_pulses,encoder_seq,encoder_age,
        encoder_raw,3'd0,ad_value,encoder_zero,3'd0,ad_zero,
        (swing_active ? alpha_meas : alpha_hat),(swing_active ? theta_meas : theta_hat),
        (swing_active ? swing_u : alpha_dot),(swing_active ? swing_theta_dot : theta_dot),
        alpha_c,(swing_active ? swing_u : u_q16),motor_frequency_q8,control_count,
        alpha_meas,capture_arm_velocity,run_trim_u,capture_candidate_u,diagnostic_status,BUILD_TAG};

    // 遥测：82 字节二进制 v3 帧，只走 telemetry_tx，绝不占用上位机口。
    // ENABLE_TELEMETRY=0（默认）：整条遥测链不例化，引脚高阻，不影响时序与资源。
    generate
        if(ENABLE_TELEMETRY!=0) begin : g_telemetry
            wire [655:0] payload;
            wire tel_serial;
            fault_snapshot #(.PAYLOAD_BITS(656)) u_fault_snapshot(
                .clk(clk_sys),.rst_n(reset_n),.state(state),.live_payload(live_payload),.payload(payload));
            telemetry_tx #(.PAYLOAD_BYTES(82)) u_telemetry(
                .clk(clk_sys),.rst_n(reset_n),.payload(payload),.uart_tx(tel_serial));
            assign telemetry_tx = tel_serial;
        end else begin : g_no_telemetry
            assign telemetry_tx = 1'bz;
        end
    endgenerate

    // K20 debug: v4, legacy 82-byte prefix plus 44 bytes for envelope/exit diagnosis.
    // Capture on the first clock after RUN exits, before the new state replaces commands.
    reg [15:0] saved_run_exit_count;
    reg [31:0] exit_t_us;
    reg signed [31:0] exit_theta_q16,exit_request_q8,exit_motor_q8,exit_positive_q8,exit_negative_q8;
    always @(posedge clk_sys or negedge reset_n)
        if(!reset_n) begin
            saved_run_exit_count<=0;exit_t_us<=0;exit_theta_q16<=0;
            exit_request_q8<=0;exit_motor_q8<=0;exit_positive_q8<=0;exit_negative_q8<=0;
        end else if(run_exit_count!=saved_run_exit_count) begin
            saved_run_exit_count<=run_exit_count;exit_t_us<=t_us;exit_theta_q16<=theta_meas;
            exit_request_q8<=frequency_q8;exit_motor_q8<=motor_frequency_q8;
            exit_positive_q8<=travel_positive_limit_q8;exit_negative_q8<=travel_negative_limit_q8;
        end
    wire debug_serial,pc_hmi_serial;
    wire [7:0] travel_debug_status={6'd0,travel_recovery_qualified,travel_recovery_request};
    wire [1007:0] debug_payload={8'd4,live_payload[647:0],
        frequency_q8,travel_positive_limit_q8,travel_negative_limit_q8,arm_target_q16,
        run_exit_reason,run_exit_count,travel_debug_status,
        exit_t_us,exit_theta_q16,exit_request_q8,exit_motor_q8,exit_positive_q8,exit_negative_q8};
    generate if(PC_DEBUG_EN!=0) begin : g_pc_debug
        telemetry_tx #(.PAYLOAD_BYTES(126)) u_debug_tx(
            .clk(clk_sys),.rst_n(reset_n),.payload(debug_payload),.uart_tx(debug_serial));
    end else begin : g_no_pc_debug
        assign debug_serial=1'b1;
    end endgenerate
    assign hmi_tx=PC_DEBUG_EN ? debug_serial : pc_hmi_serial;

    // ==================================================================
    // 三路 HMI 接收：上位机（K20/L20）+ 串口屏（K22/L22）+ 软核邮箱
    // ------------------------------------------------------------------
    // 两台串口主机各有一个 hmi_rx；同拍撞车时上位机优先，屏幕那一帧进一拍
    // 缓存下一拍补发。软核请求单独一路（rv_req），由 rv32_soc 保证不与 UART 同拍。
    // ==================================================================
    reg hmi_request,hmi_boot;
    wire hmi_ack_valid,hmi_snapshot_sent;
    // HMI 2.1 从摆命令：hmi_control 解出 OP/arg16，由本文件打包成从板帧
    wire        hmi_slave_req;
    wire [7:0]  hmi_slave_op;
    wire signed [15:0] hmi_slave_arg;
    wire        hmi_sync_enable;
    reg [7:0] hmi_command;
    reg signed [31:0] hmi_seq,hmi_arg,hmi_speed;
    wire signed [31:0] hmi_ack_seq,hmi_result;
    wire [1:0] hmi_ack_source;
    reg hmi_source;
    wire [671:0] hmi_main_values;
    // ---- 双摆：从摆遥测拼进上行快照 ----
    // 字段顺序见 hmi_tx.v：主摆 20 个 → 从摆 12 个 → ghb。ghb 仍是最后一个数据字段。
    wire signed [15:0] sl_theta,sl_wdot,sl_target,sl_armerr,sl_angerr,sl_refang;
    wire [7:0] sl_state,sl_flags;
    wire [15:0] sl_rtt_us;
    wire sl_link_ok;
    wire [383:0] slave_snapshot={
        {{16{sl_theta[15]}},sl_theta},        // 字段20 gsttheta
        {{16{sl_angerr[15]}},sl_angerr},      // 字段21 gstangerr
        {{16{sl_armerr[15]}},sl_armerr},      // 字段22 gstarmerr
        {{16{sl_target[15]}},sl_target},      // 字段23 gsttarget
        {{16{sl_wdot[15]}},sl_wdot},          // 字段24 gstwt
        {24'd0,sl_state},                     // 字段25 gsstate
        {31'd0,sl_link_ok & sl_flags[0]},     // 字段26 gsvalid
        {31'd0,sl_link_ok & sl_flags[1]},     // 字段27 gspermit
        {31'd0,sl_link_ok},                   // 字段28 glinkh
        {16'd0,sl_rtt_us},                    // 字段29 grttus
        {31'd0,hmi_sync_enable},              // 字段30 gsync
        {{16{sl_refang[15]}},sl_refang}};     // 字段31 gsrefang
    wire [1055:0] hmi_values={hmi_main_values[671:32],slave_snapshot,hmi_main_values[31:0]};
    reg signed [31:0] hmi_report_frequency;
    always @(posedge clk_sys or negedge reset_n)
        if(!reset_n) hmi_report_frequency<=0;
        else hmi_report_frequency<=manual_run ? manual_frequency_q8:run ? frequency_q8:32'sd0;

    wire pc_valid,scr_valid,pc_boot,scr_boot;
    wire [7:0] pc_cmd,scr_cmd;
    wire signed [31:0] pc_seq,scr_seq,pc_arg,scr_arg,pc_speed,scr_speed;
    hmi_rx u_hmi_rx_pc(.clk(clk_sys),.rst_n(reset_n),.rx(PC_DEBUG_EN ? 1'b1:hmi_rx),.restart(1'b0),
        .valid(pc_valid),.cmd(pc_cmd),.seq(pc_seq),.arg(pc_arg),.speed(pc_speed),.boot(pc_boot));
    hmi_rx u_hmi_rx_screen(.clk(clk_sys),.rst_n(reset_n),.rx(screen_rx),.restart(1'b0),
        .valid(scr_valid),.cmd(scr_cmd),.seq(scr_seq),.arg(scr_arg),.speed(scr_speed),.boot(scr_boot));
    reg hold_valid,hold_source;
    reg [7:0] hold_cmd;
    reg signed [31:0] hold_seq,hold_arg,hold_speed;
    always @(posedge clk_sys or negedge reset_n)
        if(!reset_n) begin
            hmi_request<=0;hmi_boot<=0;hmi_source<=1'b1;hold_valid<=0;
            hmi_command<=0;hmi_seq<=0;hmi_arg<=0;hmi_speed<=0;
            hold_cmd<=0;hold_seq<=0;hold_arg<=0;hold_speed<=0;hold_source<=1'b0;
        end else begin
            hmi_request<=0;hmi_boot<=0;
            if(pc_boot || scr_boot) hmi_boot<=1;
            if(pc_valid) begin
                hmi_request<=1;hmi_source<=1'b1;hmi_command<=pc_cmd;
                hmi_seq<=pc_seq;hmi_arg<=pc_arg;hmi_speed<=pc_speed;
                if(scr_valid) begin
                    hold_valid<=1;hold_source<=1'b0;hold_cmd<=scr_cmd;
                    hold_seq<=scr_seq;hold_arg<=scr_arg;hold_speed<=scr_speed;
                end
            end else if(scr_valid) begin
                hmi_request<=1;hmi_source<=1'b0;hmi_command<=scr_cmd;
                hmi_seq<=scr_seq;hmi_arg<=scr_arg;hmi_speed<=scr_speed;
            end else if(hold_valid) begin
                hmi_request<=1;hmi_source<=hold_source;hmi_command<=hold_cmd;
                hmi_seq<=hold_seq;hmi_arg<=hold_arg;hmi_speed<=hold_speed;
                hold_valid<=0;
            end
        end

    // 上行快照广播到两个口：屏幕和上位机看到的内容完全一致。
    // 回执按来源定向：上位机只收上位机回执，串口屏只收串口屏回执，互不串扰。
    assign hmi_req_pulse=hmi_request;
    // 横臂手动定位用编码器反馈，允许摆杆停在下垂端点；自动控制的安全门不变。
    wire hmi_manual_endpoint=`CFG_HMI_MANUAL_ALLOW_HANGING_ENDPOINT &&
        ad_value>=`CFG_ADC_OUTPUT_OFFSET &&
        ad_value<=`CFG_ADC_OUTPUT_OFFSET+1023*`CFG_ADC_OUTPUT_SCALE;
    wire hmi_manual_adc_blocked=(ad_value<`CFG_ADC_RAIL_MIN || ad_value>`CFG_ADC_RAIL_MAX) &&
        !hmi_manual_endpoint;

    // 命令汇聚：三源共用一套 hmi_control 的状态检查、许可与急停门控。
    // 软核请求只在与 UART 无冲突时出现（rv32_soc 侧已避让），这里软核优先。
    wire        x_valid = hmi_request | rv_req;
    wire [7:0]  x_cmd   = rv_req ? rv_cmd : hmi_command;
    wire signed [31:0] x_seq   = rv_req ? $signed(rv_seq)   : hmi_seq;
    wire signed [31:0] x_arg   = rv_req ? $signed(rv_arg)   : hmi_arg;
    wire signed [31:0] x_speed = rv_req ? $signed(rv_speed) : hmi_speed;
    assign rv_ack        = hmi_ack_valid;
    assign rv_ack_seq    = hmi_ack_seq;
    assign rv_ack_result = hmi_result;
    // 软核序号固定在 0x4000_0000 起（seq[31:30]==2'b01）；其回执只回片内软核，
    // 不占用任何串口上行链路。
    wire ack_is_rv = (hmi_ack_seq[31:30]==2'b01);
    // 回执来源定向：ack_source = 2'd2(软核)/2'd1(上位机)/2'd0(串口屏)。
    wire pc_ack     = hmi_ack_valid && !ack_is_rv && (hmi_ack_source==2'd1);
    wire screen_ack = hmi_ack_valid && !ack_is_rv && (hmi_ack_source==2'd0);
    // ack_ready 按回执来源选择对应口的空闲信号。
    // 26110303：软核回执根本不上串口（rv_ack 是片内直连），不能用上位机口的
    // ready 来握手。原来借用 pc_ack_ready，而 pc 口每 100 ms 要发 33 字段快照
    // （约 52 ms 占用），ready 只有约一半时间为高：软核命令的回执被按下不动，
    // 下一条命令又把未取走的 ack 覆盖掉，固件只能等到 2 s 超时 → 手写板/WAVE
    // 表现为"第一次动一下，之后没有驱动"。软核口直接常通即可。
    wire pc_ack_ready, screen_ack_ready;
    wire hmi_ack_ready = (hmi_ack_source==2'd2) ? 1'b1 :
                         (hmi_ack_source==2'd0) ? screen_ack_ready : pc_ack_ready;

    hmi_control #(.RELATIVE_MANUAL(1)) u_hmi_control(.clk(clk_sys),.rst_n(reset_n),.us_tick(us_tick),.sample_valid(sample_valid),
        .rx_valid(x_valid),.source_rv(rv_req),.cmd(x_cmd),.seq(x_seq),.arg(x_arg),.speed(x_speed),.screen_boot(hmi_boot),
        .rx_source(hmi_source),
        .state(state),.fault(fault),.calibrated(calibrated),.feedback_ok(feedback_ready),
        .rail(hmi_manual_adc_blocked),.buttons(buttons[2:0]),
        .arm_q16(alpha_meas),.theta_q16(theta_meas),.command_q16(alpha_c),
        .theta_velocity_q16(swing_active ? swing_theta_dot:theta_dot),
        .frequency_q8(hmi_report_frequency),
        .ack_ready(hmi_ack_ready),.snapshot_sent(hmi_snapshot_sent),.ack_valid(hmi_ack_valid),
        .ack_seq(hmi_ack_seq),.ack_result(hmi_result),.ack_source(hmi_ack_source),.remote_start(hmi_start),.remote_reset(hmi_reset),
        .stop_control(hmi_stop),.manual_run(manual_run),.manual_frequency_q8(manual_frequency_q8),
        .arm_target_valid(hmi_arm_target_valid),.arm_target_q16(hmi_arm_target_q16),
        .arm_speed_valid(hmi_arm_speed_valid),.arm_speed_percent(hmi_arm_speed_percent),
        .arm_hold_valid(hmi_arm_hold_valid),.values(hmi_main_values),.signed_pulses(signed_pulses),
        .reference_q16(arm_target_q16),
        .wave_set(hmi_wave_set),.wave_kind(hmi_wave_kind),
        .wave_period_us(hmi_wave_period_us),.wave_amp_q16(hmi_wave_amp_q16),
        .wave_stop(hmi_wave_stop),.track_request(hmi_track_request),
        .point_valid(hmi_point_valid),.point_q16(hmi_point_q16),
        .slave_req_valid(hmi_slave_req),.slave_req_op(hmi_slave_op),
        .slave_req_arg(hmi_slave_arg),.sync_enable(hmi_sync_enable));
    // 上行拆分：上位机与串口屏各一个 hmi_tx，快照独立广播（内容一致），
    // 回执按来源定向，避免互相串扰。snapshot_sent 取上位机口的（触发周期节拍）。
    hmi_tx u_hmi_tx_pc(.clk(clk_sys),.rst_n(reset_n),.values(hmi_values),
        .ack_valid(pc_ack),.ack_seq(hmi_ack_seq),.ack_result(hmi_result),
        .ack_ready(pc_ack_ready),.tx(pc_hmi_serial),.snapshot_sent(hmi_snapshot_sent));
    hmi_tx u_hmi_tx_screen(.clk(clk_sys),.rst_n(reset_n),.values(hmi_values),
        .ack_valid(screen_ack),.ack_seq(hmi_ack_seq),.ack_result(hmi_result),
        .ack_ready(screen_ack_ready),.tx(screen_tx),.snapshot_sent());

    // ==================================================================
    // 语音 / 双板整合：主控侧接口
    // ==================================================================
    // hmi_stop 是 hmi_control 的组合输出（含当前帧的命令字译码）。它同时驱动
    // 三个下沉模块：脉冲输出门、监督器 external_stop、run_target.clear。
    // 直接用会让"一条串口命令 → 安全链 → 参考发生器"在单个 40ns 周期里跑完；
    // 这里打一拍再送给监督器和 run_target，电机脉冲门仍用当拍信号（急停不减速）。
    always @(posedge clk_sys or negedge reset_n)
        if(!reset_n) hmi_stop_q<=0; else hmi_stop_q<=hmi_stop;

    wire        slave_busy,slave_done,slave_fail;
    wire [1:0] voice_target_mask;
    wire       voice_target_changed,voice_target_timeout;
    wire       voice_command_valid,voice_estop_latched,voice_safe_to_run;
    wire [1:0] voice_cmd_mask;
    wire [3:0] voice_action;
    wire [7:0] voice_action_id,voice_move_angle;
    wire       voice_move_right,voice_rejected;
    wire [1:0] voice_reject_reason;
    wire       voice_play_req,voice_play_busy,voice_play_done;
    wire [7:0] voice_play_id;

    voice_uart_bridge #(
        .CLK_HZ(`CFG_HARDWARE_CLOCK_HZ),
        .BAUD(115200),
        .TARGET_TIMEOUT_MS(VOICE_TARGET_TIMEOUT_MS)
    ) u_voice (
        .clk(clk_sys),
        .rst_n(reset_n),
        .voice_uart_rx_y15(voice_rx),
        .voice_uart_tx_y14(voice_tx),
        .target_changed(voice_target_changed),
        .target_mask(voice_target_mask),
        .target_timeout(voice_target_timeout),
        .command_valid(voice_command_valid),
        .command_target_mask(voice_cmd_mask),
        .action_code(voice_action),
        .command_id(voice_action_id),
        .move_angle(voice_move_angle),
        .move_right(voice_move_right),
        .command_rejected(voice_rejected),
        .reject_reason(voice_reject_reason),
        .raw_frame_valid(),
        .raw_func(),
        .raw_id(),
        .estop_latched(voice_estop_latched),
        .safe_to_run(voice_safe_to_run),
        .play_req(voice_play_req),
        .play_id(voice_play_id),
        .play_busy(voice_play_busy),
        .play_done(voice_play_done)
    );

    // ---- 双摆协调：主摆 / 从摆 / 双摆 ----
    wire       coord_local_valid,coord_remote_valid;
    wire [3:0] coord_local_action,coord_remote_action;
    wire [7:0] coord_local_id,coord_remote_id,coord_local_angle,coord_remote_angle;
    wire       coord_local_right,coord_remote_right;
    wire       coord_report_valid,coord_ready,coord_busy;
    wire [1:0] coord_report_mask;
    wire [7:0] coord_report_id;
    wire [2:0] coord_report_result;
    wire       router_local_done,router_local_fail;

    voice_dual_coordinator #(
        .CLK_HZ(`CFG_HARDWARE_CLOCK_HZ),
        .ACTION_TIMEOUT_MS(VOICE_COORD_TIMEOUT_MS)
    ) u_coordinator (
        .clk(clk_sys),
        .rst_n(reset_n),
        .command_valid(voice_command_valid),
        .command_target_mask(voice_cmd_mask),
        .command_action(voice_action),
        .command_id(voice_action_id),
        .command_angle(voice_move_angle),
        .command_right(voice_move_right),
        .local_done(router_local_done),
        .local_fail(router_local_fail),
        .remote_done(slave_done),
        .remote_fail(slave_fail),
        .local_cmd_valid(coord_local_valid),
        .local_action(coord_local_action),
        .local_action_id(coord_local_id),
        .local_angle(coord_local_angle),
        .local_right(coord_local_right),
        .remote_cmd_valid(coord_remote_valid),
        .remote_action(coord_remote_action),
        .remote_action_id(coord_remote_id),
        .remote_angle(coord_remote_angle),
        .remote_right(coord_remote_right),
        .report_valid(coord_report_valid),
        .report_target_mask(coord_report_mask),
        .report_action_id(coord_report_id),
        .report_result(coord_report_result),
        .ready(coord_ready),
        .busy(coord_busy)
    );

    // ---- 主摆：语音动作 → 本地起摆 / 急停 / 复位 / 横臂目标 ----
    voice_action_router #(
        .CLK_HZ(`CFG_HARDWARE_CLOCK_HZ),
        .TIMEOUT_MS(VOICE_ACTION_TIMEOUT_MS)
    ) u_voice_router (
        .clk(clk_sys),
        .rst_n(reset_n),
        .local_cmd_valid(coord_local_valid),
        .local_action(coord_local_action),
        .local_angle(coord_local_angle),
        .local_right(coord_local_right),
        .state(state),
        .calibrated(calibrated),
        .feedback_ready(feedback_ready),
        .moving(arm_target_moving),
        .arm_reference_q16(arm_target_q16),
        .v_start(v_start),
        .v_reset(v_reset),
        .v_stop(v_stop),
        .v_target_valid(v_target_valid),
        .v_target_q16(v_target_q16),
        .local_done(router_local_done),
        .local_fail(router_local_fail)
    );

    // ---- 从摆：语音动作 / HMI 2.1 从摆页 → UART 命令（1 级待发缓存）----
    // 语音用固定 OP（OP20 子命令 / OP30 / OP31），HMI 用 CMD_RAW 透传 (OP,arg16)。
    // 同一拍撞车时语音优先，HMI 那一帧被丢弃（界面 272 ms 周期重发，不补发）。
    localparam [2:0] S_KIND_RAW = 3'd6;
    reg        s_pending;
    reg [2:0]  s_kind;
    reg [7:0]  s_arg;
    reg        s_right;
    reg [7:0]  s_op;
    reg signed [15:0] s_arg16;
    wire       s_issue = s_pending && !slave_busy;

    always @(posedge clk_sys or negedge reset_n)
        if(!reset_n) begin
            s_pending<=0; s_kind<=3'd0; s_arg<=8'd0; s_right<=1'b0; s_op<=8'd0; s_arg16<=16'sd0;
        end else begin
            if(coord_remote_valid) begin
                s_pending<=1'b1;
                s_arg    <= coord_remote_angle;
                s_right  <= coord_remote_right;
                case(coord_remote_action)
                    4'd1:      s_kind<=3'd1;  // 起摆      → OP20/01
                    4'd2:      s_kind<=3'd2;  // 急停      → OP20/02
                    4'd3:      s_kind<=3'd3;  // 复位      → OP20/05 清远程急停
                    4'd5,4'd6: s_kind<=3'd4;  // 左移/右移 → OP30 绝对目标
                    // 「开始平衡」在从板没有独立命令（起摆后自动捕获平衡），
                    // 为避免误触发起摆或重新标定，映射为 OP31 保持生效目标。
                    default:   s_kind<=3'd5;
                endcase
            end else if(hmi_slave_req && !s_pending) begin
                s_pending<=1'b1;
                s_kind   <=S_KIND_RAW;
                s_op     <=hmi_slave_op;
                s_arg16  <=hmi_slave_arg;
                s_right  <=1'b0;
            end else if(s_issue) begin
                s_pending<=1'b0;
            end
        end

    slave_link #(
        .CLK_HZ(`CFG_HARDWARE_CLOCK_HZ),
        .BAUD(115200),
        .SLAVE_CENTER(SLAVE_CENTER),
        .SLAVE_TRAVEL(SLAVE_TRAVEL),
        .SLAVE_COUNTS_PER_REV(SLAVE_COUNTS_PER_REV)
    ) u_slave_link (
        .clk(clk_sys),
        .rst_n(reset_n),
        .slave_tx(slave_tx),
        .slave_rx(slave_rx),
        .cmd_valid(s_issue),
        .cmd_kind(s_kind),
        .cmd_arg(s_arg),
        .cmd_right(s_right),
        .cmd_op(s_op),
        .cmd_arg16(s_arg16),
        .busy(slave_busy),
        .done_pulse(slave_done),
        .fail_pulse(slave_fail),
        .fail_code(),
        .rep_op(),.rep_result(),.rep_state(),.rep_fault(),.rep_flags(),
        .rep_position(),.rep_final(),.rep_active(),
        .target_shadow(),.fsm_state(),
        .ts_theta(sl_theta),.ts_wdot(sl_wdot),.ts_target(sl_target),
        .ts_armerr(sl_armerr),.ts_angerr(sl_angerr),.ts_refang(sl_refang),
        .ts_state(sl_state),.ts_flags(sl_flags),
        .ts_rtt_us(sl_rtt_us),.ts_valid(sl_link_ok),.ts_fresh()
    );

    // ---- 结果播报：目标 → 动作 → 结果 ----
    wire fb_ready;
    wire fb_done;
    wire fb_prompt_valid = voice_rejected && fb_ready;
    voice_feedback_sequencer #(
        .CLK_HZ(`CFG_HARDWARE_CLOCK_HZ),
        .GAP_MS(VOICE_GAP_MS)
    ) u_feedback (
        .clk(clk_sys),
        .rst_n(reset_n),
        .report_valid(coord_report_valid),
        .report_target_mask(coord_report_mask),
        .report_action_id(coord_report_id),
        .report_result(coord_report_result),
        .prompt_valid(fb_prompt_valid),
        .prompt_id(8'h82),
        .play_busy(voice_play_busy),
        .play_done(voice_play_done),
        .play_req(voice_play_req),
        .play_id(voice_play_id),
        .ready(fb_ready),
        .done_pulse(fb_done)
    );

    // ---- 状态引出（pure fanout，无逻辑） ----
    assign st_alpha_q16    = alpha_meas;
    assign st_theta_q16    = theta_meas;
    assign st_arm_ref_q16  = arm_target_q16;
    assign st_freq_q8      = motor_frequency_q8;
    assign st_u_q16        = u_q16;
    assign st_alpha_dot    = swing_active ? capture_arm_velocity : alpha_dot;
    assign st_theta_dot    = swing_active ? swing_theta_dot : theta_dot;
    assign st_alpha_c      = alpha_c;
    assign st_enc_raw      = encoder_raw;
    assign st_enc_age_us   = encoder_age;
    assign st_enc_seq      = encoder_seq;
    assign st_ctrl_count   = control_count;
    assign st_t_us         = t_us;
    assign st_ad_value     = ad_value;
    assign st_state        = {5'd0, state};
    assign st_fault        = fault;
    assign st_flags        = flags;
    assign st_build_tag    = BUILD_TAG;
    assign st_run          = run;
    assign st_calibrated   = calibrated;
    assign st_saturated    = saturated;
    assign st_fb_ready     = feedback_ready;
    assign st_swing_active = swing_active;
endmodule
