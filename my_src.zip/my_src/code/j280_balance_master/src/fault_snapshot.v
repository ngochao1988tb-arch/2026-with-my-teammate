`timescale 1ns/1ps
`include "control_config.vh"
// Preserve the first FAULT snapshot for two telemetry periods, then resume live
// data. Version-2 flag[7] marks the historical event; its t_us is event time.
module fault_snapshot #(
    parameter PAYLOAD_BITS=464,
    parameter HOLD_CYCLES=2*`CFG_HARDWARE_CLOCK_HZ/`CFG_TELEMETRY_RATE_HZ
)(input clk,rst_n,input [2:0] state,input [PAYLOAD_BITS-1:0] live_payload,
  output [PAYLOAD_BITS-1:0] payload);
    reg [2:0] previous_state;
    reg [PAYLOAD_BITS-1:0] event_payload;
    reg [$clog2(HOLD_CYCLES+1)-1:0] remaining;
    assign payload=(remaining!=0 && state==4) ? event_payload : live_payload;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin previous_state<=0;event_payload<=0;remaining<=0;end
        else begin
            previous_state<=state;
            if(state==4 && previous_state!=4) begin
                event_payload<=live_payload;
                event_payload[PAYLOAD_BITS-25]<=1'b1;
                remaining<=HOLD_CYCLES;
            end else if(state!=4) remaining<=0;
            else if(remaining!=0) remaining<=remaining-1'b1;
        end
    end
endmodule
