// Wiring only. All tunable coefficients are in control_config.vh.
// 2026-11-02（构建号 0x26110202）：控制内核换成 LQR_sine_move 之后，
// lqr_core.v 直接在模块内用 `CFG_PREDICT_*` / `CFG_K_*` 展开定点常数，
// 不再引用本文件里的 coefficient()。保留它只为兼容旧工程与旧仿真脚本，
// 改这里的数不会影响综合结果——请改 control_config.vh。
function signed [31:0] coefficient;
    input [5:0] address;
    begin
        case(address)
            6'd0: coefficient=`CFG_Q20(`CFG_PREDICT_0_0);
            6'd1: coefficient=`CFG_Q20(`CFG_PREDICT_0_1);
            6'd2: coefficient=`CFG_Q20(`CFG_PREDICT_0_2);
            6'd3: coefficient=`CFG_Q20(`CFG_PREDICT_0_3);
            6'd4: coefficient=`CFG_Q20(`CFG_PREDICT_0_4);
            6'd5: coefficient=`CFG_Q20(`CFG_PREDICT_1_0);
            6'd6: coefficient=`CFG_Q20(`CFG_PREDICT_1_1);
            6'd7: coefficient=`CFG_Q20(`CFG_PREDICT_1_2);
            6'd8: coefficient=`CFG_Q20(`CFG_PREDICT_1_3);
            6'd9: coefficient=`CFG_Q20(`CFG_PREDICT_1_4);
            6'd10: coefficient=`CFG_Q20(`CFG_PREDICT_2_0);
            6'd11: coefficient=`CFG_Q20(`CFG_PREDICT_2_1);
            6'd12: coefficient=`CFG_Q20(`CFG_PREDICT_2_2);
            6'd13: coefficient=`CFG_Q20(`CFG_PREDICT_2_3);
            6'd14: coefficient=`CFG_Q20(`CFG_PREDICT_2_4);
            6'd15: coefficient=`CFG_Q20(`CFG_PREDICT_3_0);
            6'd16: coefficient=`CFG_Q20(`CFG_PREDICT_3_1);
            6'd17: coefficient=`CFG_Q20(`CFG_PREDICT_3_2);
            6'd18: coefficient=`CFG_Q20(`CFG_PREDICT_3_3);
            6'd19: coefficient=`CFG_Q20(`CFG_PREDICT_3_4);
            6'd20: coefficient=`CFG_Q20(`CFG_OBSERVER_ARM_POSITION);
            6'd21: coefficient=`CFG_Q20(`CFG_OBSERVER_THETA_POSITION);
            6'd22: coefficient=`CFG_Q20(`CFG_OBSERVER_ARM_VELOCITY);
            6'd23: coefficient=`CFG_Q20(`CFG_OBSERVER_THETA_VELOCITY);
            6'd24: coefficient=`CFG_Q20(`CFG_LQR_GAIN_SCALE * `CFG_K_ALPHA);
            6'd25: coefficient=`CFG_Q20(`CFG_LQR_GAIN_SCALE * `CFG_K_THETA);
            6'd26: coefficient=`CFG_Q20(`CFG_LQR_GAIN_SCALE * `CFG_K_ALPHA_DOT);
            6'd27: coefficient=`CFG_Q20(`CFG_LQR_GAIN_SCALE * `CFG_K_THETA_DOT);
            6'd28: coefficient=`CFG_Q20(`CFG_LQR_GAIN_SCALE * `CFG_K_ALPHA_C);
            default: coefficient=0;
        endcase
    end
endfunction
