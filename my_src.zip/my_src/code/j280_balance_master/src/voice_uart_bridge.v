`timescale 1ns / 1ps

module voice_uart_bridge #(
    parameter integer CLK_HZ = 50_000_000,
    parameter integer BAUD = 115200,
    parameter integer TARGET_TIMEOUT_MS = 0, // compatibility; persistent modes
    // 播报帧间空闲（ms）：部分语音模块要求帧与帧之间留出空闲，否则连续播报会粘连漏帧。
    // 默认 0（保持原行为，字节连续发出）；若 CI1302 要求帧间隔，改为 2~5 即可。
    parameter integer TX_GAP_MS = 0
) (
    input  wire       clk,
    input  wire       rst_n,
    input  wire       voice_uart_rx_y15,
    output wire       voice_uart_tx_y14,
    output wire       target_changed,
    output wire [1:0] target_mask,
    output wire       target_timeout,
    output wire       command_valid,
    output wire [1:0] command_target_mask,
    output wire [3:0] action_code,
    output wire [7:0] command_id,
    output wire [7:0] move_angle,
    output wire       move_right,
    output reg        command_rejected,
    output reg  [1:0] reject_reason,
    output reg        raw_frame_valid,
    output reg  [7:0] raw_func,
    output reg  [7:0] raw_id,
    output reg        estop_latched,
    output wire       safe_to_run,
    input  wire       play_req,
    input  wire [7:0] play_id,
    output wire       play_busy,
    output reg        play_done
);

    localparam [3:0] ACTION_SWING_UP = 4'd1;
    localparam [3:0] ACTION_ESTOP    = 4'd2;
    localparam [3:0] ACTION_RESET    = 4'd3;
    localparam [3:0] ACTION_BALANCE  = 4'd4;

    localparam [1:0] REJECT_NONE  = 2'd0;
    localparam [1:0] REJECT_ESTOP = 2'd2;

    localparam [7:0] FUNC_COMMAND = 8'h00;
    localparam [7:0] FUNC_PLAY    = 8'hFF;

    localparam [2:0] S_WAIT_AA = 3'd0;
    localparam [2:0] S_WAIT_55 = 3'd1;
    localparam [2:0] S_FUNC    = 3'd2;
    localparam [2:0] S_ID      = 3'd3;
    localparam [2:0] S_END     = 3'd4;

    wire       rx_valid;
    wire [7:0] rx_data;
    reg [2:0]  frame_state;
    reg [7:0]  frame_func;
    reg [7:0]  frame_id;
    reg        decoded_word_valid;
    reg  [7:0] decoded_word_id;

    wire        assembler_command_valid;
    wire [1:0]  assembler_command_target;
    wire [3:0]  assembler_action;
    wire [7:0]  assembler_command_id;
    wire [7:0]  assembler_angle;
    wire        assembler_right;
    wire        assembler_rejected;
    wire [1:0]  assembler_reject_reason;
    wire [1:0]  target_mask_internal;
    wire        motion_blocked;
    wire        estop_now;

    reg [2:0]  play_index;
    reg        play_active;
    reg        tx_byte_started;
    reg [7:0]  play_id_latched;
    wire       tx_busy;
    wire       tx_done;
    wire       tx_start;
    reg  [7:0] tx_data;
    // 帧间空闲计数：每发完一个字节（tx_done）后，若 TX_GAP_MS>0 则等待指定毫秒再发下一字节。
    localparam integer TX_GAP_CYCLES = (CLK_HZ / 1000) * TX_GAP_MS;
    reg [31:0] gap_cnt;
    reg        gap_wait;
    wire       gap_done = !gap_wait || (gap_cnt == 0);

    assign target_mask = target_mask_internal;

    assign motion_blocked =
        estop_latched &&
        (assembler_action != ACTION_ESTOP) &&
        (assembler_action != ACTION_RESET) &&
        // 起摆 / 开始平衡是明确的重新运行意图，应解除急停锁存，
        // 否则「急停后再起摆」会被 estop_latched 永久挡住（联调发现的 bug）。
        (assembler_action != ACTION_SWING_UP) &&
        (assembler_action != ACTION_BALANCE);

    assign estop_now =
        estop_latched ||
        (assembler_command_valid && (assembler_action == ACTION_ESTOP));

    assign safe_to_run         = ~estop_now;
    assign command_valid       =
        assembler_command_valid && !motion_blocked;
    assign command_target_mask = assembler_command_target;
    assign action_code         = assembler_action;
    assign command_id          = assembler_command_id;
    assign move_angle          = assembler_angle;
    assign move_right          = assembler_right;
    assign play_busy           = play_active;
    assign tx_start            =
        play_active && !tx_byte_started && !tx_busy && gap_done;

    uart_rx #(
        .CLK_HZ(CLK_HZ),
        .BAUD(BAUD)
    ) u_voice_rx (
        .clk(clk),
        .rst_n(rst_n),
        .rx(voice_uart_rx_y15),
        .rx_valid(rx_valid),
        .rx_data(rx_data)
    );

    uart_tx #(
        .CLK_HZ(CLK_HZ),
        .BAUD(BAUD)
    ) u_voice_tx (
        .clk(clk),
        .rst_n(rst_n),
        .start(tx_start),
        .data(tx_data),
        .tx(voice_uart_tx_y14),
        .busy(tx_busy),
        .done(tx_done)
    );

    voice_command_assembler #(
        .CLK_HZ(CLK_HZ),
        .TARGET_TIMEOUT_MS(TARGET_TIMEOUT_MS)
    ) u_command_assembler (
        .clk(clk),
        .rst_n(rst_n),
        .command_word_valid(decoded_word_valid),
        .command_word_id(decoded_word_id),
        .target_changed(target_changed),
        .target_mask(target_mask_internal),
        .target_timeout(target_timeout),
        .command_valid(assembler_command_valid),
        .command_target_mask(assembler_command_target),
        .command_action(assembler_action),
        .command_id(assembler_command_id),
        .command_angle(assembler_angle),
        .command_right(assembler_right),
        .command_rejected(assembler_rejected),
        .reject_reason(assembler_reject_reason)
    );

    always @(posedge clk) begin
        if (!rst_n) begin
            frame_state        <= S_WAIT_AA;
            frame_func         <= 8'd0;
            frame_id           <= 8'd0;
            decoded_word_valid <= 1'b0;
            decoded_word_id    <= 8'd0;
            raw_frame_valid    <= 1'b0;
            raw_func           <= 8'd0;
            raw_id             <= 8'd0;
        end else begin
            decoded_word_valid <= 1'b0;
            raw_frame_valid    <= 1'b0;

            if (rx_valid) begin
                case (frame_state)
                    S_WAIT_AA: begin
                        if (rx_data == 8'hAA)
                            frame_state <= S_WAIT_55;
                    end

                    S_WAIT_55: begin
                        if (rx_data == 8'h55)
                            frame_state <= S_FUNC;
                        else if (rx_data != 8'hAA)
                            frame_state <= S_WAIT_AA;
                    end

                    S_FUNC: begin
                        frame_func  <= rx_data;
                        frame_state <= S_ID;
                    end

                    S_ID: begin
                        frame_id    <= rx_data;
                        frame_state <= S_END;
                    end

                    S_END: begin
                        if (rx_data == 8'hFB) begin
                            raw_func        <= frame_func;
                            raw_id          <= frame_id;
                            raw_frame_valid <= 1'b1;
                            if (frame_func == FUNC_COMMAND) begin
                                decoded_word_id    <= frame_id;
                                decoded_word_valid <= 1'b1;
                            end
                            frame_state <= S_WAIT_AA;
                        end else if (rx_data == 8'hAA) begin
                            frame_state <= S_WAIT_55;
                        end else begin
                            frame_state <= S_WAIT_AA;
                        end
                    end

                    default: frame_state <= S_WAIT_AA;
                endcase
            end
        end
    end

    always @(posedge clk) begin
        if (!rst_n) begin
            estop_latched   <= 1'b0;
            command_rejected <= 1'b0;
            reject_reason   <= REJECT_NONE;
        end else begin
            command_rejected <= assembler_rejected ||
                                (assembler_command_valid && motion_blocked);

            if (assembler_rejected)
                reject_reason <= assembler_reject_reason;
            else if (assembler_command_valid && motion_blocked)
                reject_reason <= REJECT_ESTOP;
            else
                reject_reason <= REJECT_NONE;

            if (assembler_command_valid &&
                (assembler_action == ACTION_ESTOP))
                estop_latched <= 1'b1;
            else if (assembler_command_valid &&
                     (assembler_action == ACTION_RESET ||
                      assembler_action == ACTION_SWING_UP ||
                      assembler_action == ACTION_BALANCE))
                // 复位 / 起摆 / 开始平衡都解除急停锁存（起摆即重新运行意图）。
                estop_latched <= 1'b0;
        end
    end

    always @* begin
        case (play_index)
            3'd0: tx_data = 8'hAA;
            3'd1: tx_data = 8'h55;
            3'd2: tx_data = FUNC_PLAY;
            3'd3: tx_data = play_id_latched;
            3'd4: tx_data = 8'hFB;
            default: tx_data = 8'hFF;
        endcase
    end

    always @(posedge clk) begin
        if (!rst_n) begin
            play_index      <= 3'd0;
            play_active     <= 1'b0;
            tx_byte_started <= 1'b0;
            play_id_latched <= 8'd0;
            play_done       <= 1'b0;
            gap_cnt         <= 32'd0;
            gap_wait        <= 1'b0;
        end else begin
            play_done <= 1'b0;

            if (play_req && !play_active) begin
                play_active     <= 1'b1;
                play_index      <= 3'd0;
                tx_byte_started <= 1'b0;
                play_id_latched <= play_id;
                gap_wait        <= 1'b0;
                gap_cnt         <= 32'd0;
            end

            if (tx_start)
                tx_byte_started <= 1'b1;

            if (gap_wait) begin
                // 帧间空闲计数递减
                if (gap_cnt != 0)
                    gap_cnt <= gap_cnt - 1'b1;
                else
                    gap_wait <= 1'b0;
            end

            if (tx_done && play_active) begin
                tx_byte_started <= 1'b0;
                if (play_index == 3'd4) begin
                    play_active <= 1'b0;
                    play_done   <= 1'b1;
                end else begin
                    play_index <= play_index + 1'b1;
                    // 字节间空闲：发完当前字节后，等待 TX_GAP_MS 再发下一个。
                    if (TX_GAP_MS > 0) begin
                        gap_wait <= 1'b1;
                        gap_cnt  <= TX_GAP_CYCLES - 1;
                    end
                end
            end
        end
    end

endmodule
