`timescale 1ns/1ps
`include "control_config.vh"
// ============================================================================
// hmi_tx.v — ASCII 快照上行（上位机 / TJC 串口屏共用）
// ----------------------------------------------------------------------------
// 2026-11-03 双摆扩展：字段由 21 个扩到 33 个，新增 12 个 gs* 从摆字段。
// 顺序：主摆 20 个字段 → 从摆 12 个字段 → ghb（必须最后，界面用它判新帧）
//       → 可选 gresult/gack（有命令时才发）。
// 每个字段格式：名字 '=' 十进制 [FF FF FF]，与 2.0 协议完全一致。
// ============================================================================
module hmi_tx #(parameter CLK_HZ=`CFG_HARDWARE_CLOCK_HZ, parameter BAUD=115200)(
 input clk,rst_n,input [1055:0] values,
 input ack_valid,input signed [31:0] ack_seq,ack_result,
 output ack_ready,output tx,output reg snapshot_sent);
 localparam integer LAST_DATA_FIELD = 32;   // ghb
 localparam integer RESULT_FIELD    = 33;
 localparam integer ACK_FIELD       = 34;
 reg [31:0] timer;reg [1055:0] snapshot;
 reg [5:0] field;reg [3:0] state;reg [79:0] name;
 reg [3:0] name_len,index,digits;reg [79:0] decimal;
 reg [31:0] magnitude;reg negative;reg [7:0] data;
 reg start;wire busy,done;reg ack_mode;reg signed [31:0] result_latched,seq_latched;
 wire signed [31:0] value=field==RESULT_FIELD ? result_latched:
                           field==ACK_FIELD    ? seq_latched:snapshot[1055:1024];
 reg [31:0] dividend,quotient;
 reg [3:0] remainder;
 reg [5:0] divide_index;
 wire [4:0] trial={remainder,dividend[31]};
 wire subtract_ten=trial>=10;
 assign ack_ready=state==0;
 serial_tx #(.CLK_HZ(CLK_HZ),.BAUD(BAUD)) uart(clk,rst_n,start,data,tx,busy,done);
 always @* begin
  name=0;name_len=0;
  case(field)
    0:begin name="gtheta";name_len=6;end
    1:begin name="grefang";name_len=7;end
    2:begin name="gerror";name_len=6;end
    3:begin name="garm";name_len=4;end
    4:begin name="gtarget";name_len=7;end
    5:begin name="gwt";name_len=3;end
    6:begin name="gwa";name_len=3;end
    7:begin name="goutput";name_len=7;end
    8:begin name="gswing";name_len=6;end
    9:begin name="gstable";name_len=7;end
    10:begin name="gmean";name_len=5;end
    11:begin name="gpeak";name_len=5;end
    12:begin name="grecid";name_len=6;end
    13:begin name="grecording";name_len=10;end
    14:begin name="gstartms";name_len=8;end
    15:begin name="genterms";name_len=8;end
    16:begin name="gcapturems";name_len=10;end
    17:begin name="gstate";name_len=6;end
    18:begin name="gpermit";name_len=7;end
    19:begin name="gvalid";name_len=6;end
    // ---- 从摆遥测（HMI 2.1 从摆页 / 总览页）----
    20:begin name="gsttheta";name_len=8;end
    21:begin name="gstangerr";name_len=9;end
    22:begin name="gstarmerr";name_len=9;end
    23:begin name="gsttarget";name_len=9;end
    24:begin name="gstwt";name_len=5;end
    25:begin name="gsstate";name_len=7;end
    26:begin name="gsvalid";name_len=7;end
    27:begin name="gspermit";name_len=8;end
    28:begin name="glinkh";name_len=6;end
    29:begin name="grttus";name_len=6;end
    30:begin name="gsync";name_len=5;end
    31:begin name="gsrefang";name_len=8;end
    32:begin name="ghb";name_len=3;end
    33:begin name="gresult";name_len=7;end
    34:begin name="gack";name_len=4;end
   default:begin name="ghb";name_len=3;end
  endcase
 end
 always @(posedge clk or negedge rst_n) begin
  if(!rst_n) begin timer<=0;snapshot<=0;field<=0;state<=0;index<=0;digits<=0;decimal<=0;magnitude<=0;negative<=0;data<=0;start<=0;ack_mode<=0;result_latched<=0;seq_latched<=0;snapshot_sent<=0;dividend<=0;quotient<=0;remainder<=0;divide_index<=0;end
  else begin
   start<=0;snapshot_sent<=0;
   if(timer<CLK_HZ/10-1) timer<=timer+1'b1;
   case(state)
    0:begin
     if(ack_valid) begin result_latched<=ack_result;seq_latched<=ack_seq;field<=RESULT_FIELD;ack_mode<=1;state<=1;end
     else if(timer>=CLK_HZ/10-1) begin snapshot<=values;field<=0;ack_mode<=0;timer<=0;state<=1;end
    end
    1:begin magnitude<=value[31] ? -value:value;negative<=value[31];digits<=0;decimal<=0;index<=0;state<=2;end
    2:begin dividend<=magnitude;quotient<=0;remainder<=0;divide_index<=0;state<=11;end
    11:begin
     dividend<=dividend<<1;quotient<={quotient[30:0],subtract_ten};
     remainder<=subtract_ten ? trial-5'd10:trial;
     divide_index<=divide_index+1'b1;if(divide_index==31) state<=12;
    end
    12:begin
     decimal<={decimal[71:0],(8'd48+{4'd0,remainder})};digits<=digits+1'b1;magnitude<=quotient;
     state<=quotient==0 ? 3:2;
    end
    3:if(!busy) begin data<=name[(name_len-1-index)*8+:8];start<=1;state<=4;end
    4:if(done) begin if(index==name_len-1) begin data<=8'h3d;state<=5;end else begin index<=index+1'b1;state<=3;end end
    5:if(!busy) begin start<=1;state<=6;end
    6:if(done) begin
     if(negative) begin data<=8'h2d;state<=7;end
     else begin data<=decimal[7:0];decimal<=decimal>>8;digits<=digits-1'b1;state<=7;negative<=0;end
    end
    7:if(!busy) begin start<=1;state<=8;end
    8:if(done) begin
     if(negative) begin negative<=0;data<=decimal[7:0];decimal<=decimal>>8;digits<=digits-1'b1;state<=7;end
     else if(digits!=0) begin data<=decimal[7:0];decimal<=decimal>>8;digits<=digits-1'b1;state<=7;end
     else begin index<=0;data<=8'hff;state<=9;end
    end
    9:if(!busy) begin start<=1;state<=10;end
    10:if(done) begin
     if(index!=2) begin index<=index+1'b1;state<=9;end
     else if(ack_mode && field==RESULT_FIELD) begin field<=ACK_FIELD;state<=1;end
     else if(ack_mode || field==LAST_DATA_FIELD) begin state<=0;if(!ack_mode) snapshot_sent<=1;end
     else begin field<=field+1'b1;snapshot<={snapshot[1023:0],32'b0};state<=1;end
    end
    default:state<=0;
   endcase
  end
 end
endmodule
