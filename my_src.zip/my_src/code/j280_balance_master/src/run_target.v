`timescale 1ns/1ps
`include "control_config.vh"
// RUN reference only. Never rewrites physical encoder/pulse calibration offsets.
// SINE_DEMO = 1: 本地按键驱动正弦（PROJECT_ALL 语义，SW2 起振、SW3 周期、SW4 幅值）。
// WAVE_EN   = 1: 上位机波形/轨迹通道（0x20~0x26）可用，与 SINE_DEMO 相互独立，
//                这样本地按键仍保持"步进 / 倍速 / 应用"的映射，同时上位机能下发波形。
// CAPTURE_HOLD = 1: 每次 SWINGUP→RUN 捕获都把目标就地锁存到当前横臂角度
//                （LQR_sine_move 26103184 行为），不再要求回到 SCREEN 上选的原点。
module run_target #(parameter SINE_DEMO=0, parameter WAVE_EN=0, parameter CAPTURE_HOLD=0)(
    input clk,rst_n,clear,tick,run_mode,feedback_valid,angle_step,neg_step,speed_double,move,
    input signed [31:0] alpha_meas,
    output reg signed [31:0] goal_q16,reference_q16,
    output moving,
    output reg accepted,rejected,
    output reg [1:0] speed_level,
    input hmi_target_valid,input signed [31:0] hmi_target_q16,
    input hmi_speed_valid,input [6:0] hmi_speed_percent,
    input hmi_hold_valid,
    input amplitude_step,
    // ---- 上位机协议扩展（0x20~0x26），非 SINE_DEMO 构建下忽略 ----
    input hmi_wave_start,input [1:0] hmi_wave_kind,
    input [31:0] hmi_wave_period_us,input signed [31:0] hmi_wave_amp_q16,
    input hmi_wave_stop,input hmi_track_mode,
    input hmi_point_valid,input signed [31:0] hmi_point_q16,
    // ---- 捕获保持与正弦前馈采样（LQR_sine_move 合入）----
    // capture_hold 为捕获瞬间的单拍脉冲（lqr_system 里的 capture_seed）。
    input capture_hold,
    // 正弦前馈：sample_valid 表示本拍刚算出一组 (phase, period, amplitude)；
    // sine_running 表示波形通道正在振荡；sine_ff_active 只在纯正弦时有效。
    output sine_sample_valid,sine_running,sine_ff_active,
    output [31:0] sine_sample_phase,sine_sample_period,
    output signed [31:0] sine_sample_amplitude
);
    localparam signed [32:0] SHIFT=$rtoi(`CFG_RUN_TARGET_ANGLE_STEP_DEG*3.141592653589793*65536.0/180.0+0.5);
    localparam signed [32:0] ANGLE_MAX=$rtoi(`CFG_RUN_TARGET_ANGLE_MAX_DEG*3.141592653589793*65536.0/180.0+0.5);
    localparam signed [31:0] HMI_ANGLE_MAX=$rtoi(65535.0*6.2831853071795864769+0.5);
    localparam signed [31:0] STEP_BASE=$rtoi(`CFG_RUN_TARGET_SLEW_DEG_PER_S*`CFG_CONTROL_PERIOD_US*3.141592653589793*65536.0/180000000.0+0.5);
    localparam [1:0] MAX_SPEED_LEVEL=`CFG_RUN_TARGET_SPEED_MAX_LEVEL;
    // 波形/轨迹通道总开关：SINE_DEMO 隐含打开，方便沿用 PROJECT_ALL 的实例化。
    wire wave_en = SINE_DEMO || WAVE_EN;
    wire signed [32:0] candidate=$signed({goal_q16[31],goal_q16})+SHIFT;
    wire signed [32:0] candidate_neg=$signed({goal_q16[31],goal_q16})-SHIFT;
    // Pre-computed step constants avoid runtime multipliers completely.
    localparam signed [31:0] STEP_1=STEP_BASE*`CFG_RUN_TARGET_SPEED_MULTIPLIER;
    localparam signed [31:0] STEP_2=STEP_1*`CFG_RUN_TARGET_SPEED_MULTIPLIER;
    localparam signed [31:0] STEP_3=STEP_2*`CFG_RUN_TARGET_SPEED_MULTIPLIER;
    localparam signed [31:0] STEP_E1=STEP_3/8;  // 1x
    localparam signed [31:0] STEP_E2=STEP_E1*2;  // 2x
    localparam signed [31:0] STEP_E3=STEP_E1*3;  // 3x
    localparam signed [31:0] STEP_E4=STEP_E1*4;  // 4x
    reg hmi_speed_active;
    reg signed [31:0] hmi_step_q16;
    wire signed [31:0] hardware_step_q16=speed_level==0 ? STEP_BASE : speed_level==1 ? STEP_1 : speed_level==2 ? STEP_2 : STEP_3;
    // Banded HMI speed: 0->stop, 1-25:1x, 26-50:2x, 51-75:3x, 76-100:4x.
    // Pure comparators — no multipliers, no dividers, fast synthesis.
    function signed [31:0] hmi_speed_step;
        input [6:0] percent;
        begin
            if(percent==0)       hmi_speed_step=0;
            else if(percent<26)  hmi_speed_step=STEP_E1;
            else if(percent<51)  hmi_speed_step=STEP_E2;
            else if(percent<76)  hmi_speed_step=STEP_E3;
            else                 hmi_speed_step=STEP_E4;
        end
    endfunction
    wire signed [31:0] step_q16=hmi_speed_active ? hmi_step_q16 : hardware_step_q16;
    wire signed [31:0] limited_hmi_target=hmi_target_q16>HMI_ANGLE_MAX ? HMI_ANGLE_MAX :
        hmi_target_q16< -HMI_ANGLE_MAX ? -HMI_ANGLE_MAX : hmi_target_q16;
    reg signed [31:0] selected_q16;
    wire sine_active,sine_valid,sine_accepted,sine_rejected;
    wire [1:0] kind_active;
    wire sine_ff_ok;
    wire signed [31:0] sine_reference_q16,sine_amplitude_q16;
    wire [31:0] sine_period_us;
    reg sine_was_active;
    // 捕获保持：仅在参数打开且捕获脉冲到来时把目标就地锁存。
    wire capture_hold_active=CAPTURE_HOLD && capture_hold;
    // clear 是"停止/复位/未标定"的组合合成信号，直接进参考发生器会形成
    // 命令 → 安全链 → goal_q16 的长组合链。这里打一拍，20ns 延迟无感。
    reg clear_q;
    always @(posedge clk or negedge rst_n)
        if(!rst_n) clear_q<=1'b1; else clear_q<=clear;
    // ---- 波形通道控制信号打一拍 ----
    // 为什么要打这一拍：hmi_wave_start / hmi_stop / hmi_target 都是 hmi_control 的
    // 组合或近端输出，直接连到 sine_reference 会让"命令 → 安全链(run/state) →
    // 振荡器相位累加器"变成一条 20ns 以上的组合链（实测 Fmax 掉到 44.2MHz）。
    // 波形是毫秒级的人机操作，晚 20ns 生效完全无感；控制环本身不经过这里。
    reg sine_clear_q,sine_enable_q,sine_start_q,sine_set_q,sine_stop_q,sine_track_q,sine_point_q;
    always @(posedge clk or negedge rst_n)
        if(!rst_n) begin
            sine_clear_q<=0;sine_enable_q<=0;sine_start_q<=0;sine_set_q<=0;
            sine_stop_q<=0;sine_track_q<=0;sine_point_q<=0;
        end else begin
            // 捕获瞬间也要复位振荡器：新目标就是当前横臂位置，不能带着旧相位继续跑。
            sine_clear_q <= clear_q || hmi_target_valid || hmi_hold_valid || capture_hold_active;
            sine_enable_q<= wave_en && run_mode && feedback_valid;
            sine_start_q <= SINE_DEMO && angle_step;
            sine_set_q   <= hmi_wave_start && wave_en;
            sine_stop_q  <= hmi_wave_stop;
            sine_track_q <= hmi_track_mode && wave_en;
            sine_point_q <= hmi_point_valid;
        end
    sine_reference u_sine(.clk(clk),.rst_n(rst_n),
        .clear(sine_clear_q),.tick(tick),
        .enable(sine_enable_q),
        .start(sine_start_q),.period_step(neg_step),.amplitude_step(amplitude_step),
        .current_reference(reference_q16),.active(sine_active),.valid(sine_valid),
        .accepted(sine_accepted),.rejected(sine_rejected),.reference_q16(sine_reference_q16),
        .period_us(sine_period_us),.amplitude_q16(sine_amplitude_q16),
        .kind(hmi_wave_kind),.set_valid(sine_set_q),
        .set_period_us(hmi_wave_period_us),.set_amp_q16(hmi_wave_amp_q16),
        .osc_stop(sine_stop_q),.track_mode(sine_track_q),
        .point_valid(sine_point_q),.point_q16(hmi_point_q16),.kind_active(kind_active),
        .sample_phase(sine_sample_phase),.sample_period(sine_sample_period),
        .sample_amplitude(sine_sample_amplitude),.ff_ok(sine_ff_ok));
    always @(posedge clk or negedge rst_n)
        if(!rst_n) sine_was_active<=0;
        else sine_was_active<=sine_active;
    // 波形通道正在振荡（含方波/三角/手写轨迹）：用于让失速闸门、微抖动、防粘滞踢动让路。
    assign sine_running = wave_en && sine_active && run_mode && feedback_valid &&
        !clear_q && !hmi_target_valid && !hmi_hold_valid;
    // 只有纯正弦才允许前馈；方波/三角与手写轨迹的相位没有物理意义。
    assign sine_ff_active = sine_running && sine_ff_ok;
    // 前馈采样与正弦值同一拍输出，所以这里再加一层"前馈有效"门控。
    assign sine_sample_valid = sine_valid && sine_ff_active;
    assign moving=(wave_en && sine_active) || reference_q16!=goal_q16;
    always @(posedge clk or negedge rst_n)
        if(!rst_n) begin
            goal_q16<=0;reference_q16<=0;selected_q16<=SHIFT[31:0];accepted<=0;rejected<=0;speed_level<=0;
            hmi_speed_active<=0;hmi_step_q16<=0;
        end
        else if(clear_q) begin
            goal_q16<=0;reference_q16<=0;selected_q16<=SHIFT[31:0];accepted<=0;rejected<=0;speed_level<=0;
            hmi_speed_active<=0;
        end
        // 26103184：每次 SWINGUP→RUN 捕获都建立新的保持位置。
        // 编码器/脉冲标定与物理限制照旧，只是不再把目标拉回屏幕选的原点。
        else if(capture_hold_active && run_mode && feedback_valid) begin
            goal_q16<=alpha_meas;reference_q16<=alpha_meas;
            selected_q16<=alpha_meas;accepted<=1;rejected<=0;
        end
        else begin
            accepted<=0;
            if(hmi_speed_valid) begin
                hmi_step_q16<=hmi_speed_step(hmi_speed_percent);
                hmi_speed_active<=1;
            end
            if(speed_double && run_mode && speed_level<MAX_SPEED_LEVEL)
                speed_level<=speed_level+1'b1;
            if(hmi_hold_valid) begin
                goal_q16<=reference_q16;
                rejected<=0;
            end else if(hmi_target_valid) begin
                if(!feedback_valid) rejected<=1;
                else begin
                    selected_q16<=limited_hmi_target;
                    goal_q16<=limited_hmi_target;
                    // READY has no live LQR reference to slew, so keep the
                    // next swing-up/capture start aligned with the arm position.
                    if(!run_mode) reference_q16<=limited_hmi_target;
                    accepted<=1;rejected<=0;
                end
            end else if(angle_step && run_mode && !SINE_DEMO) begin
                if(!feedback_valid) rejected<=1;
                else begin
                    selected_q16<=candidate<=ANGLE_MAX ? candidate[31:0] : SHIFT[31:0];
                    goal_q16<=candidate<=ANGLE_MAX ? candidate[31:0] : SHIFT[31:0];
                    accepted<=1;rejected<=0;
                end
            end else if(neg_step && run_mode && !SINE_DEMO) begin
                if(!feedback_valid) rejected<=1;
                else begin
                    selected_q16<=candidate_neg>= -ANGLE_MAX ? candidate_neg[31:0] : -SHIFT[31:0];
                    goal_q16<=candidate_neg>= -ANGLE_MAX ? candidate_neg[31:0] : -SHIFT[31:0];
                    accepted<=1;rejected<=0;
                end
            end else if(move && run_mode) begin
                if(!feedback_valid) rejected<=1;
                else begin
                    goal_q16<=selected_q16;accepted<=1;rejected<=0;
                end
            end
            // Pause the reference in SWINGUP/FAULT. A later capture sees the
            // same reference in preview and live LQR before resuming its ramp.
            if(tick && run_mode && !(wave_en && (sine_active || sine_was_active || (SINE_DEMO && angle_step)))) begin
                if(reference_q16<goal_q16-step_q16) reference_q16<=reference_q16+step_q16;
                else if(reference_q16>goal_q16+step_q16) reference_q16<=reference_q16-step_q16;
                else reference_q16<=goal_q16;
            end
            if(wave_en && !hmi_target_valid && !hmi_hold_valid) begin
                if(sine_valid && sine_active) begin
                    reference_q16<=sine_reference_q16;goal_q16<=sine_reference_q16;
                end
                if(sine_accepted) begin accepted<=1;rejected<=0;end
                else if(sine_rejected) rejected<=1;
                // Freeze the last applied reference on RUN/feedback loss.
                if(sine_was_active && !sine_active) goal_q16<=reference_q16;
            end
        end
endmodule
