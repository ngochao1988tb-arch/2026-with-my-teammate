@echo off
setlocal
cd /d "%~dp0"

rem This project MUST be built through build.tcl: it passes
rem   set_option -use_sspi_as_gpio 1
rem which is the only way SW4 on T20 (SSPI dedicated pin) can be used as a button,
rem and set_option -route_option 2 which the 50 MHz timing depends on.
rem
rem The path below must use single backslashes.

set "GWSH=D:\Gowin_soft\Gowin\Gowin_V1.9.12.03_x64\IDE\bin\gw_sh.exe"
if not exist "%GWSH%" goto nogw

echo [project_01] gw_sh = %GWSH%
echo [project_01] building through build.tcl ...
"%GWSH%" build.tcl > build.log 2>&1

rem gw_sh returns 127 even on success, so judge by the log and the artifact.
findstr /i /c:"ERROR" build.log >nul
if not errorlevel 1 goto failed
if not exist "impl\pnr\project_01.fs" goto failed

echo [OK] bitstream: impl\pnr\project_01.fs
echo [OK] report   : impl\pnr\project_01.rpt.txt
if not defined NOPAUSE pause
exit /b 0

:failed
echo [FAILED] see build.log
findstr /i /c:"ERROR" build.log
if not defined NOPAUSE pause
exit /b 1

:nogw
echo [ERROR] gw_sh.exe not found: %GWSH%
echo Edit GWSH in build.bat to your install path.
if not defined NOPAUSE pause
exit /b 1
