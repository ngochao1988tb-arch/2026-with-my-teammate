#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""把 fw.bin 转换成 Gowin $readmemh 需要的两个 .hex 文件。

IMEM：16 KB -> 4096 个 32 位字（不足补 NOP 0x00000013）
DMEM：16 KB -> 4096 个 32 位字（全 0；.bss 由 start.S 清零）
小端序：word = b0 | b1<<8 | b2<<16 | b3<<24

用法: python tools/bin2hex.py <fw.bin> <imem.hex> <dmem.hex> [imem_bytes] [dmem_bytes]
"""
import struct
import sys
from pathlib import Path


def main(argv):
    if len(argv) < 4:
        print(__doc__)
        return 2
    src = Path(argv[1])
    imem_out = Path(argv[2])
    dmem_out = Path(argv[3])
    imem_bytes = int(argv[4]) if len(argv) > 4 else 16 * 1024
    dmem_bytes = int(argv[5]) if len(argv) > 5 else 16 * 1024

    data = src.read_bytes()
    if len(data) > imem_bytes:
        print("ERROR: firmware %d bytes > IMEM %d bytes" % (len(data), imem_bytes))
        return 1
    # 未用字填 NOP(0x00000013)：既避免取到 0x00000000（非法指令），
    # 也强制综合器按完整深度推断 ROM（否则会按最后一个非零字裁剪深度）。
    nop = b"\x13\x00\x00\x00"
    pad = (imem_bytes - len(data)) // 4
    data = data + nop * pad

    words = struct.unpack("<%dI" % (imem_bytes // 4), data)
    with imem_out.open("w", encoding="ascii", newline="\n") as f:
        for w in words:
            f.write("%08x\n" % w)
    with dmem_out.open("w", encoding="ascii", newline="\n") as f:
        for _ in range(dmem_bytes // 4):
            f.write("00000000\n")
    print("imem: %d words (%d bytes used), dmem: %d words" %
          (len(words), len(src.read_bytes()), dmem_bytes // 4))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
