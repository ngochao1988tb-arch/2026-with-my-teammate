from pathlib import Path
import re
root=Path(__file__).resolve().parent.parent
s=(root/'src/control_config.vh').read_text(encoding='utf-8')
v=re.search(r'`define CFG_CONTROL_MAX_FREQUENCY_HZ\s+32\x27sd(\d+)',s)
assert v, 'Unknown motor frequency configuration'
(root/'sw/hmi_config.h').write_text('#define CFG_CONTROL_MAX_FREQUENCY_HZ '+v[1]+'\n',encoding='ascii')
