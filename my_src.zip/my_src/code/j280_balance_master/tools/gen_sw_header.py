#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""从 src/lcd_config.vh 生成 sw/lcd_regs.h，保证 RTL 与 C 的地址/默认值不漂移。

用法： python tools/gen_sw_header.py
"""
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
VH = ROOT / "src" / "lcd_config.vh"
OUT = ROOT / "sw" / "lcd_regs.h"

RE_DEF = re.compile(r"^`define\s+(\w+)\s+(.*?)\s*$")


def conv(value: str) -> str:
    v = value.split("//")[0].strip()
    m = re.fullmatch(r"(\d+)'h([0-9A-Fa-f_]+)", v)
    if m:
        return "0x%sU" % m.group(2).replace("_", "")
    m = re.fullmatch(r"(\d+)'d(\d+)", v)
    if m:
        return "%s" % m.group(2)
    m = re.fullmatch(r"(\d+)'b([01_]+)", v)
    if m:
        return "%d" % int(m.group(2).replace("_", ""), 2)
    if re.fullmatch(r"\(?[\d\s\*\+\-/\(\)]+\)?", v):
        return "(%s)" % v.strip("()")
    return v


def main() -> int:
    if not VH.exists():
        print("missing", VH)
        return 1
    items = []
    for line in VH.read_text(encoding="utf-8").splitlines():
        m = RE_DEF.match(line.strip())
        if not m:
            continue
        name, val = m.group(1), m.group(2)
        if not name.startswith("CFG_"):
            continue
        items.append((name, conv(val)))

    body = "\n".join("#define %-26s %s" % (n, v) for n, v in items)
    text = """/* ============================================================
 * lcd_regs.h  --  由 tools/gen_sw_header.py 从 src/lcd_config.vh 自动生成
 *                 请勿手工修改；改配置请改 src/lcd_config.vh 后重新生成。
 * ============================================================ */
#ifndef LCD_REGS_H
#define LCD_REGS_H

%s

#endif /* LCD_REGS_H */
""" % body
    OUT.write_text(text, encoding="utf-8")
    print("wrote %s (%d defines)" % (OUT, len(items)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
