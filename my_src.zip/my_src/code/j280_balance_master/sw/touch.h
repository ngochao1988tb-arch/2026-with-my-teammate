#ifndef TOUCH_H
#define TOUCH_H
#include <stdint.h>
typedef struct { int32_t x, y; } touch_point;
typedef struct { int32_t ax, bx, cx, ay, by, cy; } touch_cal;
void touch_init(void);
int touch_pen(void);
int touch_read(touch_point *raw);
void touch_read_raw(touch_point *raw);
int touch_calculate(touch_cal *c, const touch_point raw[3], const touch_point screen[3]);
touch_point touch_map(const touch_cal *c, touch_point raw);
#endif
