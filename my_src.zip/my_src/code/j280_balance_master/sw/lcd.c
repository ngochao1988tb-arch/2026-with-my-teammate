/* =========================================================================
 * lcd.c  --  8080 并口 LCD 驱动
 *
 * 关键点
 *  1) 窗口/数据全部通过存储器映射访问，硬件保证一次访问=一个 8080 总线周期。
 *  2) RS 由地址决定：CMD 窗口 0x00 -> RS=0，DATA 窗口 0x04 -> RS=1。
 *  3) 8 位模式下一次数据写只送 1 字节；16 位模式下一次送 2 字节。
 *  4) 只写模式（Ctrl.WR_ONLY=1）下读操作返回 0，硬件置 ERR_RDONLY；
 *     本驱动的 lcd_read_data() 会原样返回 0，调用者不应该依赖读回值。
 * ========================================================================= */
#include "lcd.h"
#include "font8x16.h"

/* Separate ST7789 test firmware; retain the working ILI9341 global baseline. */
#ifdef LCD_PANEL_ST7789
#undef CFG_LCD_USE_ST7789
#define CFG_LCD_USE_ST7789 1
#endif

#define REG(a)      (*(volatile uint32_t *)(CFG_LCD_BASE + (a)))
#define LCD_CMD     REG(CFG_LCD_REG_CMD)
#define LCD_DAT     REG(CFG_LCD_REG_DATA)
#define LCD_CTRL    REG(CFG_LCD_REG_CTRL)
#define LCD_STAT    REG(CFG_LCD_REG_STATUS)
#define LCD_ECLR    REG(CFG_LCD_REG_ERR_CLR)

#define CTRL_EN        0x01u
#define CTRL_SRST      0x02u
#define CTRL_WRONLY    0x04u
#define CTRL_BL        0x08u
#define CTRL_PANEL_RST 0x10u

/* 状态位（与 lcd8080.v 一致） */
#define ST_BUSY        0x01u
#define ST_ERR_PARAM   0x10u
#define ST_ERR_RDONLY  0x20u
#define ST_ERR_DIS     0x40u
#define ST_ERR_TMO     0x80u

/* ---------------- 简单延时：用 SYS 里的 32 位周期计数器 ---------------- */
#define SYS_BASE        (CFG_RV_SYS_BASE)
#define SYS_CYC         (*(volatile uint32_t *)(SYS_BASE + 0x28u))
#define CPU_HZ          50000000u

void delay_us(uint32_t us)
{
    uint32_t start = SYS_CYC;
    uint32_t need  = us * (CPU_HZ / 1000000u);
    while ((uint32_t)(SYS_CYC - start) < need) {
        ;
    }
}

void delay_ms(uint32_t ms)
{
    while (ms--) delay_us(1000u);
}

/* ---------------- 硬件层 ---------------- */
void lcd_hw_init(void)
{
    /* 时序参数由 lcd_config.vh 决定，这里写一遍便于现场调整 */
    REG(CFG_LCD_REG_T_AS)   = CFG_LCD_T_AS;
    REG(CFG_LCD_REG_T_DS)   = CFG_LCD_T_DS;
    REG(CFG_LCD_REG_T_PW)   = CFG_LCD_T_PW;
    REG(CFG_LCD_REG_T_DH)   = CFG_LCD_T_DH;
    REG(CFG_LCD_REG_T_IDLE) = CFG_LCD_T_IDLE;
    REG(CFG_LCD_REG_T_TURN) = CFG_LCD_T_TURN;
    LCD_ECLR = ST_ERR_PARAM | ST_ERR_RDONLY | ST_ERR_DIS | ST_ERR_TMO;
    LCD_CTRL = CTRL_EN | CTRL_WRONLY | CTRL_PANEL_RST;   /* 只写测试，释放面板复位 */
}

int lcd_selftest(void)
{
    uint32_t id = REG(CFG_LCD_REG_ID);
    if (id != 0x4C434438u) return -1;      /* "LCD8" */
    if (lcd_status() & (ST_ERR_PARAM | ST_ERR_TMO)) return -2;
    return 0;
}

uint32_t lcd_status(void)      { return LCD_STAT; }
void     lcd_clear_errors(void){ LCD_ECLR = 0xF0u; }
uint32_t lcd_access_count(void){ return REG(CFG_LCD_REG_WR_CNT); }
uint32_t lcd_last_cycles(void) { return REG(CFG_LCD_REG_LAST_CYC); }

uint32_t lcd_self_measure(uint32_t n)
{
    uint32_t c0 = SYS_CYC;
    uint32_t cnt = lcd_access_count();
    while (n--) {
        LCD_DAT = 0x1234u;
    }
    uint32_t used = SYS_CYC - c0;
    (void)cnt;
    return used;
}

/* ---------------- 总线层 ---------------- */
void lcd_write_command(uint16_t cmd)
{
    LCD_CMD = cmd;
}

void lcd_write_data(uint16_t data)
{
    LCD_DAT = data;
}

uint16_t lcd_read_data(void)
{
    return (uint16_t)(LCD_DAT & 0xFFFFu);
}

/* ---------------- 面板初始化 ----------------
 * CFG_LCD_USE_ST7789=1 selects the vendor's ATK-MD0280 ID 0x8552 branch.
 * ST7789: MADCTL=0xA0 (landscape + 180° 旋转), COLMOD=0x05 (16-bit MCU interface).
 *   （2026-11-02：MADCTL 由 0x60 改为 0xA0，画面绕面板中心旋转 180°。
 *     180° 旋转必须同时翻转行、列两个方向：0x60=(MX+MV) → 0xA0=(MY+MX)，
 *     即 MV 由 1 翻回 0、MY 由 0 置 1，MX 保持 1。
 *     注意不能写成 0xE0：0x60 里 MX 本来就是 1，再置 MY 只是翻了单轴，
 *     得到的是上下镜像（文字左右顺序不变），不是 180° 旋转。
 *     UI 布局坐标无需改动；触摸靠上电五点校准自动适配，刷新固件后必须重新校准。）
 * The actual controller has not been identified by a hardware read.
 * The ILI9341 branch below is retained for CFG_LCD_USE_ST7789=0.
 * ILI9341 (正点原子 ATK-MD0280, 2.8" / 320x240 / 8080-16bit / RGB565) 完整初始化序列。
 * 寄存器表移植自正点原子 atk_md0280.c 的 ILI9341 分支（CHIP_ID = 0x9341），
 * 仅把底层 atk_md0280_fsmc_write_cmd/write_dat 换成本工程的 lcd_write_command/write_data。
 *
 * 关键项核对结果（对照 ILI9341 数据手册）：
 *   - COLMOD(0x3A)=0x55  : RGB565 (16bpp)
 *   - MADCTL(0x36)=0x68  : MX + MV + BGR，320x240 横屏
 *   - GAMMA(0xE0/0xE1)   : 正点原子 ILI9341 标准 15 字节 gamma 曲线
 *   - PWCTR/PORCTRL/DTCA : 0xCF/0xED/0xE8/0xCB/0xF7/0xEA/0xC0/0xC1/0xC5/0xC7
 *   - 帧率 0xB1/0xB6      : NORMAL 60Hz, idle 60Hz
 *
 * 注意 MADCTL：0x68 设置 MX + MV + BGR，逻辑坐标为横屏 320x240。
 * 本工程 lcd_set_window() 按横屏逻辑坐标下发 CASET/RASET 绝对坐标，
 * 若红蓝颜色互换，可仅切换 MADCTL 的 BGR 位（0x68 -> 0x60）。
 */
#ifdef SIM_FAST_INIT
/* 仅仿真用：跳过面板上电/复位延时（真实硬件必须保留） */
#define PDELAY(ms) do { } while (0)
#else
#ifndef PDELAY
#define PDELAY(ms) delay_ms(ms)
#endif
#endif

void lcd_panel_init(void)
{
    /* 面板硬复位：先拉低 20 ms，再释放并等待 120 ms */
    LCD_CTRL = CTRL_EN | CTRL_WRONLY;   /* PANEL_RST=0 -> 复位有效 */
    PDELAY(20);
    LCD_CTRL = CTRL_EN | CTRL_WRONLY | CTRL_PANEL_RST;
    PDELAY(120);

    lcd_write_command(0x01);            /* SWRESET (software reset) */
    PDELAY(120);

#if CFG_LCD_USE_ST7789
    /* ATK-MD0280 ST7789 vendor sequence. Exit sleep before power/gamma setup. */
    lcd_write_command(0x11);
    PDELAY(120);

    lcd_write_command(0x36);            /* MY + MX, RGB, 320x240 landscape, 180° 旋转 */
    lcd_write_data(0xA0);
    lcd_write_command(0x3A);            /* DBI: RGB565 */
    lcd_write_data(0x05);

    lcd_write_command(0xB2);            /* Porch setting */
    lcd_write_data(0x0C); lcd_write_data(0x0C); lcd_write_data(0x00);
    lcd_write_data(0x33); lcd_write_data(0x33);
    lcd_write_command(0xB7); lcd_write_data(0x35);
    lcd_write_command(0xBB); lcd_write_data(0x32);
    lcd_write_command(0xC0); lcd_write_data(0x0C);
    lcd_write_command(0xC2); lcd_write_data(0x01);
    lcd_write_command(0xC3); lcd_write_data(0x10);
    lcd_write_command(0xC4); lcd_write_data(0x20);
    lcd_write_command(0xC6); lcd_write_data(0x0F);
    lcd_write_command(0xD0); lcd_write_data(0xA4); lcd_write_data(0xA1);

    lcd_write_command(0xE0);            /* Positive gamma: 14 bytes */
    lcd_write_data(0xD0); lcd_write_data(0x00); lcd_write_data(0x02);
    lcd_write_data(0x07); lcd_write_data(0x0A); lcd_write_data(0x28);
    lcd_write_data(0x32); lcd_write_data(0x44); lcd_write_data(0x42);
    lcd_write_data(0x06); lcd_write_data(0x0E); lcd_write_data(0x12);
    lcd_write_data(0x14); lcd_write_data(0x17);
    lcd_write_command(0xE1);            /* Negative gamma: 14 bytes */
    lcd_write_data(0xD0); lcd_write_data(0x00); lcd_write_data(0x02);
    lcd_write_data(0x07); lcd_write_data(0x0A); lcd_write_data(0x28);
    lcd_write_data(0x31); lcd_write_data(0x54); lcd_write_data(0x47);
    lcd_write_data(0x0E); lcd_write_data(0x1C); lcd_write_data(0x17);
    lcd_write_data(0x1B); lcd_write_data(0x1E);
#else
    /* ILI9341 Power control B */
    lcd_write_command(0xCF);
    lcd_write_data(0x00);
    lcd_write_data(0xC1);
    lcd_write_data(0x30);

    /* Power on sequence control */
    lcd_write_command(0xED);
    lcd_write_data(0x64);
    lcd_write_data(0x03);
    lcd_write_data(0x12);
    lcd_write_data(0x81);

    /* Driver timing control A */
    lcd_write_command(0xE8);
    lcd_write_data(0x85);
    lcd_write_data(0x10);
    lcd_write_data(0x7A);

    /* Power control A */
    lcd_write_command(0xCB);
    lcd_write_data(0x39);
    lcd_write_data(0x2C);
    lcd_write_data(0x00);
    lcd_write_data(0x34);
    lcd_write_data(0x02);

    /* Pump ratio control */
    lcd_write_command(0xF7);
    lcd_write_data(0x20);

    /* Driver timing control B */
    lcd_write_command(0xEA);
    lcd_write_data(0x00);
    lcd_write_data(0x00);

    /* Power control 1 (Vreg1out) */
    lcd_write_command(0xC0);
    lcd_write_data(0x1B);

    /* Power control 2 (VGH/VGL) */
    lcd_write_command(0xC1);
    lcd_write_data(0x01);

    /* VCOM control 1 */
    lcd_write_command(0xC5);
    lcd_write_data(0x30);
    lcd_write_data(0x30);

    /* VCOM control 2 */
    lcd_write_command(0xC7);
    lcd_write_data(0xB7);

    /* Memory access control (MADCTL): MX + MV + BGR, 320x240 横屏 */
    lcd_write_command(0x36);
    lcd_write_data(0x68);

    /* Pixel format (COLMOD): RGB565 */
    lcd_write_command(0x3A);
    lcd_write_data(0x55);

    /* Frame rate control (normal, 60Hz) */
    lcd_write_command(0xB1);
    lcd_write_data(0x00);
    lcd_write_data(0x1A);

    /* Display function control (idle 60Hz + REV/GS/SS) */
    lcd_write_command(0xB6);
    lcd_write_data(0x0A);
    lcd_write_data(0xA2);

    /* 3Gamma function disable */
    lcd_write_command(0xF2);
    lcd_write_data(0x00);

    /* Gamma set */
    lcd_write_command(0x26);
    lcd_write_data(0x01);

    /* Positive gamma correction (15 bytes) */
    lcd_write_command(0xE0);
    lcd_write_data(0x0F);
    lcd_write_data(0x2A);
    lcd_write_data(0x28);
    lcd_write_data(0x08);
    lcd_write_data(0x0E);
    lcd_write_data(0x08);
    lcd_write_data(0x54);
    lcd_write_data(0xA9);
    lcd_write_data(0x43);
    lcd_write_data(0x0A);
    lcd_write_data(0x0F);
    lcd_write_data(0x00);
    lcd_write_data(0x00);
    lcd_write_data(0x00);
    lcd_write_data(0x00);

    /* Negative gamma correction (15 bytes) */
    lcd_write_command(0xE1);
    lcd_write_data(0x00);
    lcd_write_data(0x15);
    lcd_write_data(0x17);
    lcd_write_data(0x07);
    lcd_write_data(0x11);
    lcd_write_data(0x06);
    lcd_write_data(0x2B);
    lcd_write_data(0x56);
    lcd_write_data(0x3C);
    lcd_write_data(0x05);
    lcd_write_data(0x10);
    lcd_write_data(0x0F);
    lcd_write_data(0x3F);
    lcd_write_data(0x3F);
    lcd_write_data(0x0F);

#endif

    /* Column address set: X=0..319 */
    lcd_write_command(0x2A);
    lcd_write_data(0x00);
    lcd_write_data(0x00);
    lcd_write_data(0x01);
    lcd_write_data(0x3F);

    /* Page address set: Y=0..239 */
    lcd_write_command(0x2B);
    lcd_write_data(0x00);
    lcd_write_data(0x00);
    lcd_write_data(0x00);
    lcd_write_data(0xEF);

#if !CFG_LCD_USE_ST7789
    /* ILI9341 sleep out (ST7789 already exited sleep above). */
    lcd_write_command(0x11);
    PDELAY(120);
#endif

    /* ST7789 IPS panel: INVON controls panel voltage polarity, not RGB ordering.
     * The replacement module returned RDID 01/85/52 and showed complemented
     * colors with the previous ILI9341/INVOFF initialization. */
#if CFG_LCD_USE_ST7789
    lcd_write_command(0x21);
#endif

    /* Display on */
    lcd_write_command(0x29);

    LCD_CTRL = CTRL_EN | CTRL_WRONLY | CTRL_PANEL_RST | CTRL_BL;   /* 开背光 */
}

/* ---------------- 绘图层 ---------------- */
void lcd_set_window(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1)
{
    lcd_write_command(0x2A);            /* CASET */
    lcd_write_data((uint16_t)(x0 >> 8)); lcd_write_data((uint16_t)(x0 & 0xFF));
    lcd_write_data((uint16_t)(x1 >> 8)); lcd_write_data((uint16_t)(x1 & 0xFF));
    lcd_write_command(0x2B);            /* RASET */
    lcd_write_data((uint16_t)(y0 >> 8)); lcd_write_data((uint16_t)(y0 & 0xFF));
    lcd_write_data((uint16_t)(y1 >> 8)); lcd_write_data((uint16_t)(y1 & 0xFF));
    lcd_write_command(0x2C);            /* RAMWR */
}

void lcd_fill_rect(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint16_t color)
{
    uint32_t n;
    if (w == 0 || h == 0) return;
    if (x >= LCD_W || y >= LCD_PANEL_H) return;
    if ((uint32_t)x + w > LCD_W) w = (uint16_t)(LCD_W - x);
    if ((uint32_t)y + h > LCD_PANEL_H) h = (uint16_t)(LCD_PANEL_H - y);
    lcd_set_window(x, y, (uint16_t)(x + w - 1), (uint16_t)(y + h - 1));
    n = (uint32_t)w * (uint32_t)h;
#if (CFG_LCD_DATA_WIDTH == 16)
    while (n--) {
        LCD_DAT = color;
    }
#else
    while (n--) {
        LCD_DAT = (uint32_t)(color >> 8);
        LCD_DAT = (uint32_t)(color & 0xFFu);
    }
#endif
}

void lcd_draw_pixel(uint16_t x, uint16_t y, uint16_t color)
{
    if (x >= LCD_W || y >= LCD_PANEL_H) return;
    lcd_set_window(x, y, x, y);
    lcd_write_data(color);
}

void lcd_hline(uint16_t x, uint16_t y, uint16_t w, uint16_t color)
{
    lcd_fill_rect(x, y, w, 1, color);
}

void lcd_vline(uint16_t x, uint16_t y, uint16_t h, uint16_t color)
{
    lcd_fill_rect(x, y, 1, h, color);
}

void lcd_rect(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint16_t color)
{
    if (w < 2 || h < 2) return;
    lcd_hline(x, y, w, color);
    lcd_hline(x, (uint16_t)(y + h - 1), w, color);
    lcd_vline(x, y, h, color);
    lcd_vline((uint16_t)(x + w - 1), y, h, color);
}

void lcd_draw_char(uint16_t x, uint16_t y, char c, uint16_t fg, uint16_t bg)
{
    const uint8_t *g;
    uint8_t row;
    int i;
    if (c < 32 || c > 126) c = '?';
    g = font8x16[(uint8_t)c - 32];
    if (x + 8 > LCD_W || y + 16 > LCD_PANEL_H) return;
    lcd_set_window(x, y, (uint16_t)(x + 7), (uint16_t)(y + 15));
    for (i = 0; i < 16; i++) {
        row = g[i];
        /* 每行 8 个像素，逐点写；位 7 是最左像素 */
#if (CFG_LCD_DATA_WIDTH == 16)
        {
            int b;
            for (b = 7; b >= 0; b--) {
                LCD_DAT = (row & (1u << b)) ? fg : bg;
            }
        }
#else
        {
            int b;
            for (b = 7; b >= 0; b--) {
                uint16_t col = (row & (1u << b)) ? fg : bg;
                LCD_DAT = (uint32_t)(col >> 8);
                LCD_DAT = (uint32_t)(col & 0xFFu);
            }
        }
#endif
    }
}

void lcd_draw_text(uint16_t x, uint16_t y, const char *s, uint16_t fg, uint16_t bg)
{
    while (*s) {
        lcd_draw_char(x, y, *s, fg, bg);
        x = (uint16_t)(x + 8);
        s++;
    }
}
