/* ============================================================
 * lcd_regs.h  --  由 tools/gen_sw_header.py 从 src/lcd_config.vh 自动生成
 *                 请勿手工修改；改配置请改 src/lcd_config.vh 后重新生成。
 * ============================================================ */
#ifndef LCD_REGS_H
#define LCD_REGS_H

#define CFG_LCD_USE_ST7789         (1)
#define CFG_LCD_DATA_WIDTH         (16)
#define CFG_LCD_PANEL_W            (320)
#define CFG_LCD_PANEL_H            (240)
#define CFG_LCD_COLOR_BITS         (16)
#define CFG_LCD_T_AS               (2)
#define CFG_LCD_T_DS               (2)
#define CFG_LCD_T_PW               (4)
#define CFG_LCD_T_DH               (2)
#define CFG_LCD_T_IDLE             (2)
#define CFG_LCD_T_TURN             (4)
#define CFG_LCD_TIMEOUT_CYCLES     (4096)
#define CFG_LCD_POR_RESET_CYCLES   (50000)
#define CFG_RV_IMEM_BASE           0x00000000U
#define CFG_RV_IMEM_BYTES          (32*1024)
#define CFG_RV_DMEM_BASE           0x00010000U
#define CFG_RV_DMEM_BYTES          (16*1024)
#define CFG_RV_SNAP_BASE           0x30000000U
#define CFG_RV_SYS_BASE            0x30000080U
#define CFG_LCD_BASE               0x20000000U
#define CFG_LCD_REG_CMD            0x00U
#define CFG_LCD_REG_DATA           0x04U
#define CFG_LCD_REG_CTRL           0x08U
#define CFG_LCD_REG_STATUS         0x0CU
#define CFG_LCD_REG_T_AS           0x10U
#define CFG_LCD_REG_T_DS           0x14U
#define CFG_LCD_REG_T_PW           0x18U
#define CFG_LCD_REG_T_DH           0x1CU
#define CFG_LCD_REG_T_IDLE         0x20U
#define CFG_LCD_REG_T_TURN         0x24U
#define CFG_LCD_REG_FIFO_STAT      0x28U
#define CFG_LCD_REG_ERR_CLR        0x2CU
#define CFG_LCD_REG_ID             0x30U
#define CFG_LCD_REG_WR_CNT         0x34U
#define CFG_LCD_REG_LAST_CYC       0x38U
#define CFG_LCD_REG_VER            0x3CU
#define CFG_RV_ENABLE_CMD          (1)

#endif /* LCD_REGS_H */
