#include "lcd.h"
#include "touch.h"
#define DEBUG (*(volatile uint32_t *)(CFG_RV_SYS_BASE+4u))
#define CYC (*(volatile uint32_t *)(CFG_RV_SYS_BASE+0x28u))
static const touch_point targets[5]={{24,42},{296,42},{24,214},{296,214},{160,128}};


static int absval(int n) { return n<0?-n:n; }
static void draw_hex(uint16_t x,uint16_t y,uint16_t value)
{
    static const char digits[]="0123456789ABCDEF";
    char text[5];
    for (unsigned i=0;i<4;i++) text[i]=digits[(value>>(12-4*i))&15u];
    text[4]=0;
    lcd_draw_text(x,y,text,C_CYAN,C_PANEL);
}
static void cross(touch_point p, uint16_t color)
{
    lcd_hline(p.x-10,p.y,21,color); lcd_vline(p.x,p.y-10,21,color);
    lcd_rect(p.x-6,p.y-6,13,13,color);
}
static void release(void)
{
    /* Require a continuous 20 ms release to avoid contact bounce. */
    uint32_t t=CYC;
    while ((uint32_t)(CYC-t)<1000000u) if (touch_pen()) t=CYC;
}
void calibrate(touch_cal *cal)
{
    touch_point raw[5], prev;
    for (;;) {
        lcd_fill_rect(0,0,320,240,C_PANEL);
        lcd_draw_text(24,6,"TOUCH CAL: TAP THE CROSS",C_WHITE,C_PANEL);
        release();
        for (unsigned i=0;i<5;i++) {
            char step[]="POINT 1/5 - TAP AND RELEASE"; step[6]+=(char)i;
            lcd_draw_text(24,65,step,C_YELLOW,C_PANEL);
            lcd_draw_text(16,150,"PEN: WAITING",C_WHITE,C_PANEL);
            lcd_draw_text(16,168,"RAW X: ----  Y: ----",C_WHITE,C_PANEL);
            lcd_draw_text(16,186,"FILTER: WAITING   ",C_WHITE,C_PANEL);
            cross(targets[i],C_WHITE);
            DEBUG=0xca100000u+i;
            int stable=0;
            uint32_t last_diag=CYC;
            do {
                int pen=touch_pen();
                touch_point filtered;
                int valid=touch_read(&filtered);
                if (pen) {
                    touch_read_raw(&raw[i]);
                    if (valid) {
                        raw[i]=filtered;
                        if (stable && absval(raw[i].x-prev.x)<35 && absval(raw[i].y-prev.y)<35) break;
                        prev=raw[i]; stable=1;
                    } else stable=0;
                } else stable=0;
                if ((uint32_t)(CYC-last_diag)>=5000000u) {
                    lcd_draw_text(16,150,pen?"PEN: DOWN   ":"PEN: UP     ",C_WHITE,C_PANEL);
                    if (pen) {
                        lcd_draw_text(16,168,"RAW X:",C_WHITE,C_PANEL); draw_hex(72,168,(uint16_t)raw[i].x);
                        lcd_draw_text(120,168,"Y:",C_WHITE,C_PANEL); draw_hex(144,168,(uint16_t)raw[i].y);
                    } else lcd_draw_text(16,168,"RAW X: ----  Y: ----",C_WHITE,C_PANEL);
                    lcd_draw_text(16,186,valid?"FILTER: OK       ":pen?"FILTER: NOISY/RAIL":"FILTER: WAITING  ",C_WHITE,C_PANEL);
                    last_diag=CYC;
                }
                delay_ms(5);
            } while (1);
            cross(targets[i],C_GREEN);
            DEBUG=0xca108000u+i;
            release(); cross(targets[i],C_PANEL);
        }
        int ok=touch_calculate(cal,raw,targets);
        if (ok) for (unsigned i=3;i<5;i++) {
            touch_point v=touch_map(cal,raw[i]);
            if (absval(v.x-targets[i].x)>14 || absval(v.y-targets[i].y)>14) ok=0;
        }
        if (ok) return;
        DEBUG=0xca1f0000u;
        lcd_draw_text(8,100,"CAL FAILED - PLEASE TRY AGAIN",C_RED,C_PANEL);
        delay_ms(1500);
    }
}
