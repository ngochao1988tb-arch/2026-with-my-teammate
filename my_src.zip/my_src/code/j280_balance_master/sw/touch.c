/* HR2046 resistive touch, based on ATK-MD0280 command/clock sequence.
 * GPIO output: bit0 CS_n, bit1 CLK, bit2 MOSI. Input: bit0 MISO, bit1 PEN_n.
 * Delays remain enabled in simulation; only LCD power-on waits are skipped.
 */
#include "touch.h"
#include "lcd.h"
#define GPIO_OUT (*(volatile uint32_t *)(CFG_RV_SYS_BASE + 0x2cu))
#define GPIO_IN  (*(volatile uint32_t *)(CFG_RV_SYS_BASE + 0x30u))
int touch_pen(void) { return !(GPIO_IN & 2u); }
static uint16_t adc(uint8_t cmd)
{
    uint16_t v=0;
    uint32_t bit;
    GPIO_OUT=1; GPIO_OUT=0;
    for (unsigned i=0;i<8;i++) {
        bit=(cmd & 0x80u) ? 4u:0u;
        GPIO_OUT=bit; delay_us(1); GPIO_OUT=bit|2u;
        delay_us(1); cmd<<=1;
    }
    delay_us(6);
    GPIO_OUT=0; delay_us(1); GPIO_OUT=2; delay_us(1); GPIO_OUT=0;
    for (unsigned i=0;i<16;i++) {
        GPIO_OUT=0; delay_us(1); GPIO_OUT=2; delay_us(1);
        v=(uint16_t)((v<<1) | (GPIO_IN & 1u));
    }
    GPIO_OUT=1;
    return v>>4;
}
void touch_init(void) { GPIO_OUT=1; (void)adc(0xd0); }
void touch_read_raw(touch_point *raw)
{
    raw->x=adc(0xd0);
    raw->y=adc(0x90);
}
/* Five samples per axis, remove the two extremes; reject wide middle spread. */
static int filtered(uint8_t cmd)
{
    uint16_t a[5];
    for (unsigned i=0;i<5;i++) {
        a[i]=adc(cmd);
        for (unsigned j=i;j>0 && a[j]<a[j-1];j--) {
            uint16_t t=a[j]; a[j]=a[j-1]; a[j-1]=t;
        }
    }
    if (a[1]<80 || a[3]>4015 || a[3]-a[1]>70) return -1;
    return (a[1]+a[2]+a[3])/3;
}
int touch_read(touch_point *raw)
{
    if (!touch_pen()) return 0;
    int x=filtered(0xd0), y=filtered(0x90);
    if (!touch_pen() || x<0 || y<0) return 0;
    raw->x=x; raw->y=y; return 1;
}
static int32_t absv(int32_t n) { return n<0?-n:n; }
/* Affine transform supports swapped/inverted axes without a wiring assumption. */
int touch_calculate(touch_cal *c, const touch_point r[3], const touch_point s[3])
{
    int32_t dx1=r[1].x-r[0].x, dy1=r[1].y-r[0].y;
    int32_t dx2=r[2].x-r[0].x, dy2=r[2].y-r[0].y;
    int32_t det=dx1*dy2-dx2*dy1;
    if (absv(det)<150000) return 0;
    c->ax=(int32_t)(((int64_t)(s[1].x-s[0].x)*dy2-(int64_t)(s[2].x-s[0].x)*dy1)*4096/det);
    c->bx=(int32_t)(((int64_t)dx1*(s[2].x-s[0].x)-(int64_t)dx2*(s[1].x-s[0].x))*4096/det);
    c->ay=(int32_t)(((int64_t)(s[1].y-s[0].y)*dy2-(int64_t)(s[2].y-s[0].y)*dy1)*4096/det);
    c->by=(int32_t)(((int64_t)dx1*(s[2].y-s[0].y)-(int64_t)dx2*(s[1].y-s[0].y))*4096/det);
    if (absv(c->ax)>32768 || absv(c->bx)>32768 || absv(c->ay)>32768 || absv(c->by)>32768) return 0;
    c->cx=s[0].x*4096-c->ax*r[0].x-c->bx*r[0].y;
    c->cy=s[0].y*4096-c->ay*r[0].x-c->by*r[0].y;
    return 1;
}
touch_point touch_map(const touch_cal *c, touch_point r)
{
    touch_point p={(c->ax*r.x+c->bx*r.y+c->cx+2048)>>12,
                   (c->ay*r.x+c->by*r.y+c->cy+2048)>>12};
    return p;
}
