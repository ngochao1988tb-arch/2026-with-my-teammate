/* =========================================================================
 * lcd.h  --  8080 并口 LCD 驱动接口（存储器映射，见 rv32_soc.v / lcd8080.v）
 *
 * 所有函数都是**阻塞式**的：函数返回时该次访问已经在 8080 总线上完成。
 * 因此不存在"忙等 FIFO"的问题；总线带宽即吞吐上限（见 docs 第 7 节）。
 * ========================================================================= */
#ifndef LCD_DRIVER_H
#define LCD_DRIVER_H

#include <stdint.h>
#include "lcd_regs.h"

#define LCD_W   ((uint16_t)CFG_LCD_PANEL_W)
#define LCD_PANEL_H ((uint16_t)CFG_LCD_PANEL_H)

#define RGB565(r, g, b) ((uint16_t)((((uint16_t)(r) & 0xF8u) << 8) | \
                                    (((uint16_t)(g) & 0xFCu) << 3) | \
                                    (((uint16_t)(b)) >> 3)))

#define C_BLACK   0x0000
#define C_WHITE   0xFFFF
#define C_RED     RGB565(255, 0, 0)
#define C_GREEN   RGB565(0, 200, 0)
#define C_BLUE    RGB565(0, 80, 255)
#define C_YELLOW  RGB565(255, 210, 0)
#define C_CYAN    RGB565(0, 220, 220)
#define C_GRAY    RGB565(120, 120, 120)
#define C_DGRAY   RGB565(40, 44, 52)
#define C_ORANGE  RGB565(255, 140, 0)
#define C_PANEL   RGB565(16, 18, 24)

/* 基于 SYS 周期计数器的忙等延时（不依赖中断） */
void     delay_us(uint32_t us);
void     delay_ms(uint32_t ms);

/* 硬件层：只碰寄存器，不做任何面板相关动作 */
void     lcd_hw_init(void);          /* 写时序参数 + 使能 */
int      lcd_selftest(void);         /* 读 ID/状态，返回 0 表示正常 */
uint32_t lcd_status(void);
void     lcd_clear_errors(void);
uint32_t lcd_access_count(void);     /* 已完成的 8080 访问次数 */
uint32_t lcd_last_cycles(void);      /* 上一次访问占用的时钟数 */
uint32_t lcd_self_measure(uint32_t n); /* 测 n 次数据写耗时（周期） */

/* 总线层 */
void     lcd_write_command(uint16_t cmd);
void     lcd_write_data(uint16_t data);
uint16_t lcd_read_data(void);

/* 面板层 */
void lcd_panel_init(void);

/* 绘图层 */
void lcd_set_window(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1);
void lcd_fill_rect(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint16_t color);
void lcd_draw_pixel(uint16_t x, uint16_t y, uint16_t color);
void lcd_hline(uint16_t x, uint16_t y, uint16_t w, uint16_t color);
void lcd_vline(uint16_t x, uint16_t y, uint16_t h, uint16_t color);
void lcd_rect(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint16_t color);
void lcd_draw_char(uint16_t x, uint16_t y, char c, uint16_t fg, uint16_t bg);
void lcd_draw_text(uint16_t x, uint16_t y, const char *s, uint16_t fg, uint16_t bg);

#endif /* LCD_DRIVER_H */
