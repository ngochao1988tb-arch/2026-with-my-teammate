/* ST7789 local HMI. Real snapshot MMIO, no UART parsing and no synthetic data.
 * UI and target scheduling share one monotonic clock; motion always uses the
 * hardware command mailbox and existing RUN/feedback/fault/slew guards. */
#include "lcd.h"
#include "touch.h"
#include "status.h"
#include <stdint.h>
#include "hmi_config.h"
#include "hmi_ui.h"

#define SYS(off) (*(volatile uint32_t *)(CFG_RV_SYS_BASE+(off)))
#define PX 80
#define PY 48
#define PW 232
#define PH 132
#define N 232
#define PADY 48
#define PADH 112
enum {MONITOR,PAD,WAVE,CONTROL};
/* enabled = which curves are on the scope. Boot shows the selected channel
 * alone; tapping another card switches the single curve, tapping the same card
 * twice brings all four back for an overview. */
static unsigned page, selected, paused, enabled=1, dirty=1;
static unsigned window_idx=3, range_auto=15, range_idx[4]={4,4,6,6};
/* Vertical pan of the trace in pixels; 0 keeps the zero line centred. UP/DN
 * step it, the grid scrolls with it so a value keeps its grid row. */
static int pan_px;
static const int ranges[]={10,20,50,100,300,600,1000,2000,3600}; /* 0.1 engineering units */
/* Whole-screen time span, selectable in both directions with T-/T+.
 * One plot column is PW pixels wide overall, so the per-column time resolution
 * is span/PW (e.g. 10 s -> 43 ms, 1 s -> 4 ms). */
static const unsigned windows[]={1000,2000,5000,10000,15000,20000,30000,45000,60000,90000,120000};
#define NWIN ((unsigned)(sizeof(windows)/sizeof(windows[0])))
static int lo[4]={-300,-300,-1000,-1000},hi[4]={300,300,1000,1000};
static int values[4], history[4][N], trace_x[4]={-1,-1,-1,-1}, trace_y[4];
static unsigned cursor, count;
static unsigned plot_start, plot_slot, plot_has_slot, pause_started;
static uint8_t history_valid[N];
static int16_t pad_points[N], pad_saved[N];
static unsigned pad_draw_col=N;
static unsigned pad_has, pad_undo, pad_last, pad_duration=5000, pad_range=300, interval=20, loop_play;
/* 周期默认 6 s：步进改成 3 s 后，5000 不在网格上（3/6/9/.../30 s）。 */
static unsigned wave_kind, wave_period=6000, wave_amp=100;
static unsigned playing, play_origin, play_next, play_duration, play_interval, play_amp, play_kind;
static int16_t play_points[N];
static unsigned ticks_ms, command_inflight, command_started, last_result, snapshot_ok, fresh_ms;
static lqr_status_t st;
static const uint16_t colors[4]={U_ACCENT,U_AMBER,RGB565(172,155,255),RGB565(113,214,154)};
static const char *names[4]={"ARM","PEND","SPD","OUT"};
static const char *units[4]={"deg","deg","d/s","%"};
#ifdef HMI_HOST
unsigned host_ms;
int host_cmd(unsigned c,int a,unsigned s);
static unsigned now_ms(void){return host_ms;}
#else
static unsigned now_ms(void)
{
    static uint32_t previous, rem;
    uint32_t c=SYS(0x28),delta=c-previous; previous=c;
    rem+=delta; ticks_ms+=rem/50000u; rem%=50000u;
    return ticks_ms;
}
#endif
static int abs_i(int a){return a<0?-a:a;}
static int clip(int a,int a0,int a1){return a<a0?a0:a>a1?a1:a;}
static char *number(char *s,int v)
{
    char a[12];unsigned n=0;uint32_t u=v<0?0u-(uint32_t)v:(uint32_t)v;
    if(v<0)*s++='-';
    do{a[n++]=(char)('0'+u%10);u/=10;}while(u);
    while(n)*s++=a[--n];*s=0;return s;
}
static char *decimal(char *b,int v)
{
    char *s=b;unsigned a=(unsigned)abs_i(v);
    if(v<0)*s++='-';s=number(s,(int)(a/10));*s++='.';*s++=(char)('0'+a%10);*s=0;return b;
}
static void metric(int y,const char *tag,int v,const char *suffix)
{
    char b[24],*p=number(b,v);while(*suffix)*p++=*suffix++;*p=0;
    uint16_t bg=U_SURFACE;
    lcd_fill_rect(84,y,224,18,bg);ui_text(87,y+2,tag,U_MUTED,bg);
    unsigned n=ui_len(b);ui_text_fit(306-(int)(n>160?160:n),y+2,b,U_TEXT,bg,160);
}
static void button(int x,int y,int w,int h,const char *s,int active)
{
    int danger=s[0]=='E'&&s[1]=='-';
    int stop=s[0]=='S'&&s[1]=='T'&&s[2]=='O';
    int primary=(page==CONTROL&&s[0]=='S'&&s[1]=='T'&&s[2]=='A') ||
        ((page==PAD||page==WAVE)&&y>=216&&x==78);
    int pressed=ui_down&&ui_x>=x&&ui_x<x+w&&ui_y>=y&&ui_y<y+h;
    uint16_t bg=danger?U_DANGER:active||primary?U_PRIMARY:U_RAISED;
    uint16_t fg=danger?U_TEXT:stop?U_RED:active||primary?U_ACCENT:U_TEXT;
    if(pressed){bg=danger?RGB565(207,61,81):U_PRESS;fg=U_TEXT;}
    ui_round(x,y,w,h,bg);
    ui_center(x+2,y+(h-13)/2+(pressed?1:0),w-4,s,fg,bg);
}
static void line(int x,int y,int xx,int yy,uint16_t c)
{
    int dx=abs_i(xx-x),sx=x<xx?1:-1,dy=-abs_i(yy-y),sy=y<yy?1:-1,err=dx+dy;
    for(;;){lcd_draw_pixel(x,y,c);if(x==xx&&y==yy)break;int e=2*err;if(e>=dy){err+=dy;x+=sx;}if(e<=dx){err+=dx;y+=sy;}}
}
/* Live read-out pinned to the top-right corner of a canvas. It is redrawn after
 * every new sample (and every status tick) so the newest trace column can never
 * cut through it. */
static void hud_panel(int x,int y,int w,int h)
{
    ui_round(x,y,w,h,U_SURFACE);
    lcd_rect((uint16_t)x,(uint16_t)y,(uint16_t)w,(uint16_t)h,U_AXIS);
}
/* Only the selected channel's value and unit, nothing else. */
static void plot_hud(void)
{
    if(page!=MONITOR)return;
    int x=PX+PW-96,y=PY+6;
    char b[20],*p=b;
    const char *u=units[selected];
    decimal(b,values[selected]);
    while(*p)p++;
    *p++=' ';
    while(*u)*p++=*u++;
    *p=0;
    hud_panel(x,y,92,21);
    ui_text_fit(x+4,y+4,b,colors[selected],U_SURFACE,84);
}
/* Single-line chip: only the vertical range, so as little drawing area as
 * possible is covered. */
static void pad_hud(void)
{
    if(page!=PAD)return;
    int x=75+PW+6-96,y=PADY+4;
    char b[20],*p=b;
    hud_panel(x,y,94,20);
    *p++='-';p=number(p,pad_range/10);*p++='.';*p++='.';p=number(p,pad_range/10);
    *p++=' ';*p++='d';*p++='e';*p++='g';*p=0;
    ui_text_fit(x+5,y+4,b,U_ACCENT,U_SURFACE,84);
}
static int cmd(unsigned c,int a,unsigned speed)
{
#ifdef HMI_HOST
    return host_cmd(c,a,speed);
#else
    if(command_inflight || (SYS(0x20)&1u))return 0;
    SYS(0x10)=c;SYS(0x14)=(uint32_t)a;SYS(0x18)=speed;SYS(0x1c)=1;
    command_started=now_ms();command_inflight=1;last_result=0xffffffffu;
    return 1;
#endif
}
static int can_play(void)
{
    return snapshot_ok && now_ms()-fresh_ms<200 && st.state==3 && !st.fault && (st.mode&0x12)==0x12;
}
static void command_poll(void)
{
#ifndef HMI_HOST
    if(command_inflight){
        unsigned s=SYS(0x20);
        if((s&14u) && !(s&1u)) {last_result=(s&12u)?9u:SYS(0x24);command_inflight=0;}
        else if(now_ms()-command_started>150u){last_result=9;command_inflight=0;}
        if(!command_inflight && last_result)playing=0;
    }
#endif
}
/* Hardware takes the same absolute point command for handwriting and waves.
 * A delayed UI iteration skips to the current time; it never replays a burst. */
static int wave_at(unsigned t,unsigned kind,unsigned period,unsigned amplitude)
{
    unsigned phase=(t%period)*1024u/period;int v;
    if(kind==1)v=phase<512?1024:-1024;
    else if(kind==2)v=phase<256?(int)phase*4:phase<768?2048-(int)phase*4:(int)phase*4-4096;
    else {
        /* Bhaskara sine approximation on [0,pi], max error <0.2 percent. */
        unsigned p=phase&511u,prod=p*(512u-p);
        v=(int)(16u*prod*1024u/(5u*512u*512u-4u*prod));if(phase>=512)v=-v;
    }
    return v*(int)amplitude/1024;
}
static int pad_at(unsigned t)
{
    unsigned scaled=t*(N-1u),i=scaled/play_duration,rem=scaled%play_duration;
    if(i>=N-1)return play_points[N-1];
    return play_points[i]+(play_points[i+1]-play_points[i])*(int)rem/(int)play_duration;
}
static unsigned stop_pending;
static void stop_motion(unsigned c)
{
    playing=0;stop_pending=c;
}
static void playback_tick(void)
{
    unsigned now=now_ms();
    if(stop_pending){if(cmd(stop_pending,0,0))stop_pending=0;return;}
    if(!playing)return;
    if(!can_play()){playing=0;stop_pending=0x23;return;}
    if((int32_t)(now-play_next)<0)return;
    unsigned elapsed=now-play_origin;
    if(playing==1 && elapsed>=play_duration){
        if(loop_play){play_origin+=elapsed/play_duration*play_duration;elapsed=now-play_origin;}
        else {if(cmd(0x24,play_points[N-1],100)){playing=0;}return;}
    }
    int target=playing==1?pad_at(elapsed):wave_at(elapsed,play_kind,play_duration,play_amp);
    if(cmd(0x24,target,100))play_next=now+play_interval;
}
static void begin_play(unsigned mode)
{
    if(!can_play() || stop_pending || command_inflight){last_result=2;return;}
    playing=mode;play_origin=now_ms();play_next=play_origin;last_result=0;
    play_duration=mode==1?pad_duration:wave_period;play_interval=interval;
    play_kind=wave_kind;play_amp=wave_amp;
    for(unsigned i=0;i<N;i++)play_points[i]=pad_points[i];
}
static void navigation(void)
{
    const char *nav[]={"SCOPE","PAD","WAVE","RUN"};
    for(unsigned i=0;i<4;i++){
        int pressed=ui_down&&ui_y<24&&(unsigned)ui_x/80==i;
        uint16_t bg=pressed?U_PRESS:page==i?U_SELECTED:U_BG;
        uint16_t fg=page==i?U_ACCENT:U_MUTED;
        lcd_fill_rect(i*80,0,80,24,U_BG);ui_round(i*80+2,2,76,21,bg);
        ui_icon(i,i*80+10,6,fg);ui_text(i*80+27,6,nav[i],fg,bg);
        if(page==i)lcd_hline(i*80+28,22,28,U_ACCENT);
    }
}
static void shell(void)
{
    lcd_fill_rect(0,0,320,240,U_BG);navigation();
    button(2,202,72,36,"E-STOP",1);
}
/* PAN_MAX keeps the zero line inside the canvas at the extremes. */
#define PAN_MAX 60
#define PAN_STEP 6
static int plot_y(unsigned k,int v)
{
    /* The value is clamped into the range first so a wild sample lands on the
       edge row instead of wrapping; the row itself may fall outside the canvas
       and the trace is clipped there, never drawn over the frame. */
    return PY+PH-1-(clip(v,lo[k],hi[k])-lo[k])*(PH-1)/(hi[k]-lo[k])-pan_px;
}
static void plot_column(unsigned i)
{
    /* The zero line follows the pan so the offset stays readable; the grid
       itself is a fixed backdrop, drawn from the same rows in both the full
       redraw and the per-column erase so the two never drift apart. */
    int zero=PY+PH/2-pan_px;
    lcd_vline(PX+i,PY,PH,(i%29)==0?U_GRID:U_PLOT);
    for(unsigned y=0;y<PH;y+=25)lcd_draw_pixel(PX+i,PY+y,U_GRID);
    if(zero>=PY&&zero<PY+PH)lcd_draw_pixel(PX+i,zero,U_AXIS);
}
static void plot_grid(void)
{
    int zero=PY+PH/2-pan_px;
    ui_round(PX-3,PY-3,PW+6,PH+6,U_SURFACE);
    lcd_fill_rect(PX,PY,PW,PH,U_PLOT);
    for(unsigned x=0;x<PW;x+=29)lcd_vline(PX+x,PY,PH,U_GRID);
    for(unsigned y=0;y<PH;y+=25)lcd_hline(PX,PY+y,PW,U_GRID);
    if(zero>=PY&&zero<PY+PH)lcd_hline(PX,zero,PW,U_AXIS);
}
static void draw_history(void)
{
    plot_grid();
    for(unsigned k=0;k<4;k++)trace_x[k]=-1;
    for(unsigned k=0;k<4;k++)if(enabled&(1u<<k))
        for(unsigned i=1;i<N;i++)if(history_valid[i]&&history_valid[i-1]){
            int a=plot_y(k,history[k][i-1]),b=plot_y(k,history[k][i]);
            if(a>=PY&&a<PY+PH&&b>=PY&&b<PY+PH)line(PX+i-1,a,PX+i,b,colors[k]);
            else{
                /* A sample beside an off-scale one keeps its dot, so the trace
                   fades out at the edge instead of vanishing a column early. */
                if(a>=PY&&a<PY+PH)lcd_draw_pixel((unsigned)(PX+i-1),a,colors[k]);
                if(b>=PY&&b<PY+PH)lcd_draw_pixel((unsigned)(PX+i),b,colors[k]);
            }
        }
}
static void channel_cards(void)
{
    static int old_values[4];static unsigned old_selected=99,old_enabled=99;
    static unsigned old_page=99;
    for(unsigned k=0;k<4;k++){
        if(!dirty&&old_page==page&&old_values[k]==values[k]&&old_selected==selected&&old_enabled==enabled)continue;
        unsigned y=28+k*42;int on=(enabled&(1u<<k))!=0;
        uint16_t c=on?colors[k]:U_DIM,bg=selected==k?U_SELECTED:U_SURFACE;
        lcd_fill_rect(2,y,72,39,U_BG);ui_round(2,y,72,39,bg);
        lcd_vline(2,y+9,21,c);ui_text(9,y+3,names[k],c,bg);
        unsigned uw=ui_len(units[k]);ui_text(68-(int)uw,y+3,units[k],U_MUTED,bg);
        char b[20];decimal(b,values[k]);ui_number(8,y+17,b,on?U_TEXT:U_DIM,bg,63);
        old_values[k]=values[k];
    }
    old_selected=selected;old_enabled=enabled;old_page=page;
}
static void monitor_controls(void)
{
    button(78,184,30,28,"Y-",0);button(111,184,40,28,"Y+",0);
    button(154,184,56,28,(range_auto&(1u<<selected))?"AUTO":"FIX",(range_auto&(1u<<selected))!=0);
    button(214,184,48,28,paused?"GO":"HOLD",paused);button(266,184,50,28,"CLR",0);
    /* Time base: T- / T+ step the span finer/coarser. The current span and the
       resulting per-column resolution (span/PW) are shown in the status line,
       so both buttons keep a finger-sized target. */
    button(78,216,44,22,"T-",0);button(124,216,44,22,"T+",0);
    /* Trace position: UP/DN slide the curve (and its grid) up or down, MID
       snaps it back to the centred zero line. */
    button(174,216,44,22,"UP",0);button(222,216,44,22,"DN",0);button(270,216,46,22,"MID",0);
}
static void pad_canvas(void)
{
    ui_round(75,PADY-3,PW+6,PADH+6,U_SURFACE);pad_draw_col=0;
}
/* Eight columns per iteration bounds drawing latency while sending targets. */
static void pad_render_tick(void)
{
    if(page!=PAD)return;
    for(unsigned n=0;n<8 && pad_draw_col<N;n++,pad_draw_col++){
        unsigned i=pad_draw_col;
        int y=clip(PADH/2-pad_points[i]*(PADH/2)/(int)pad_range,0,PADH-1);
        int prev=clip(PADH/2-pad_points[i?i-1:0]*(PADH/2)/(int)pad_range,0,PADH-1);
        lcd_set_window(78+i,PADY,78+i,PADY+PADH-1);
        for(int row=0;row<PADH;row++)lcd_write_data(row>=(y<prev?y:prev) && row<=(y>prev?y:prev)?U_ACCENT:row==PADH/2?U_AXIS:(i%29==0||row%28==0)?U_GRID:U_PLOT);
    }
    pad_hud();
}
static void wave_canvas(void)
{
    ui_round(75,51,PW+6,103,U_SURFACE);lcd_fill_rect(78,54,PW,96,U_PLOT);
    for(unsigned i=0;i<PW;i+=29)lcd_vline(78+i,54,96,U_GRID);
    lcd_hline(78,102,PW,U_AXIS);
    for(unsigned i=1;i<PW;i++)line(78+i-1,102-wave_at((i-1)*wave_period/PW,wave_kind,wave_period,43),
        78+i,102-wave_at(i*wave_period/PW,wave_kind,wave_period,43),U_ACCENT);
}
static void page_controls(void)
{
    navigation();button(2,202,72,36,"E-STOP",1);
    if(page==MONITOR)monitor_controls();
    if(page==PAD){
        button(78,164,54,25,"UNDO",0);button(138,164,58,25,"CLEAR",0);button(198,164,58,25,"SMOOTH",0);button(258,164,60,25,"FLIP",0);
        button(78,192,54,22,"T+",0);button(138,192,58,22,"Y+",0);button(198,192,58,22,"dt+",0);button(258,192,60,22,loop_play?"LOOP":"ONCE",loop_play);
        button(78,216,114,22,playing==1?"PLAYING":"PLAY PAD",playing==1);button(198,216,120,22,"STOP",0);
    }
    if(page==WAVE){
        const char *k[]={"SINE","SQUARE","TRIANGLE"};
        for(unsigned i=0;i<3;i++)button(78+i*80,26,76,24,k[i],i==wave_kind);
        button(78,192,54,22,"T-",0);button(138,192,58,22,"T+",0);button(198,192,58,22,"A-",0);button(258,192,58,22,"A+",0);
        button(78,216,114,22,playing==2?"PLAYING":"APPLY WAVE",playing==2);button(198,216,120,22,"STOP",0);
    }
    if(page==CONTROL){
        button(76,30,112,34,"START",st.state==3);button(198,30,112,34,"STOP",0);
        button(76,72,112,34,"RESET",0);button(198,72,112,34,"ZERO",0);
    }
}
static void status_ui(void);
static void draw_page(void)
{
    shell();channel_cards();page_controls();
    if(page==MONITOR)draw_history();
    if(page==PAD)pad_canvas();
    if(page==WAVE){
        wave_canvas();char b[24],*p;
        ui_round(78,157,114,31,U_SURFACE);ui_round(198,157,118,31,U_SURFACE);
        ui_text(85,158,"PERIOD",U_MUTED,U_SURFACE);p=number(b,wave_period);*p++='m';*p++='s';*p=0;ui_text(85,173,b,U_TEXT,U_SURFACE);
        ui_text(205,158,"AMPLITUDE",U_MUTED,U_SURFACE);p=number(b,wave_amp/10);*p++=' ';*p++='d';*p++='e';*p++='g';*p=0;ui_text(205,173,b,U_ACCENT,U_SURFACE);
    }
    if(page==CONTROL)ui_round(78,112,238,97,U_SURFACE);
    dirty=0;status_ui();
}
static void read_snapshot(void)
{
    if(lqr_read_status(&st)!=0){snapshot_ok=0;return;}
    static unsigned epoch;
    if(!snapshot_ok || epoch!=st.epoch){fresh_ms=now_ms();epoch=st.epoch;}
    snapshot_ok=1;
    values[0]=q16_to_deg10(st.alpha_q16)-q16_to_deg10(st.arm_ref_q16);
    values[1]=q16_to_deg10(st.theta_q16); /* supervisor upright reference is zero */
    values[2]=q16_to_deg10(st.alpha_dot);
    /* Same signed normalized motor-command output as debug_app goutput. */
    values[3]=(int)((int64_t)st.freq_q8*1000/(CFG_CONTROL_MAX_FREQUENCY_HZ*256));
}
static void clear_history(void)
{
    cursor=count=plot_slot=plot_has_slot=0;plot_start=now_ms();
    for(unsigned i=0;i<N;i++)history_valid[i]=0;
    for(unsigned k=0;k<4;k++)trace_x[k]=-1;
}
static void sample_plot(void)
{
    if(paused || !snapshot_ok || now_ms()-fresh_ms>200)return;
    /* X is determined by actual elapsed time, not UI loop count. */
    unsigned elapsed=now_ms()-plot_start;
    unsigned slot=(elapsed/windows[window_idx])*PW+(elapsed%windows[window_idx])*PW/windows[window_idx];
    if(plot_has_slot && slot==plot_slot)return;
    unsigned gap=plot_has_slot?slot-plot_slot:1;
    if(gap>N)gap=N;
    for(unsigned j=0;j<gap;j++){
        unsigned clear=(slot-j)%N;history_valid[clear]=0;
        if(page==MONITOR){plot_column(clear);}
    }
    unsigned i=slot%N;plot_slot=slot;plot_has_slot=1;
    history_valid[i]=1;
    for(unsigned k=0;k<4;k++)history[k][i]=values[k];
    if(count<N)count++;
    int changed=0;
    for(unsigned k=0;k<4;k++)if(range_auto&(1u<<k)){
        int max=10;for(unsigned j=0;j<N;j++)if(history_valid[j]&&abs_i(history[k][j])>max)max=abs_i(history[k][j]);
        int r=10;while(r<max && r<100000)r*=2;
        if(hi[k]!=r){lo[k]=-r;hi[k]=r;changed=1;}
    }
    if(page==MONITOR){
        if(changed)draw_history();
        plot_column(i);
        for(unsigned k=0;k<4;k++)if(enabled&(1u<<k)){
            int y=plot_y(k,values[k]),x=PX+(int)i;
            /* Off-scale samples are clipped, so the trace leaves and re-enters
               through the canvas edge instead of riding along it. */
            if(y<PY||y>=PY+PH){trace_x[k]=-1;continue;}
            /* Join to the previous drawn sample so a slow UI iteration leaves a
               short straight segment instead of a dotted trace. The x must grow:
               a wrap back to the left edge starts a new point, never a line. */
            if(trace_x[k]>=0 && x>trace_x[k])line(trace_x[k],trace_y[k],x,y,colors[k]);
            else lcd_draw_pixel((unsigned)x,y,colors[k]);
            trace_x[k]=x;trace_y[k]=y;
        }
        if(changed)monitor_controls();
        plot_hud();
    }
    cursor=(cursor+1)%N;
}
static void status_ui(void)
{
    char b[48],*s=b;int fresh=snapshot_ok&&now_ms()-fresh_ms<200;
    const char *v=fresh?lqr_state_name(st.state):"STALE";
    while(*v&&*v!=' ')*s++=*v++;*s++=' ';*s++=' ';*s++='F';s=number(s,st.fault);
    *s++=' ';*s++='R';if(command_inflight){*s++='.';*s++='.';}else s=number(s,(int)last_result);*s=0;
    uint16_t c=st.fault?U_RED:!fresh?U_AMBER:U_ACCENT;
    if(page==MONITOR||page==CONTROL){
        int y=page==MONITOR?27:220;lcd_fill_rect(78,y-1,240,17,U_BG);
        ui_round(80,y+3,8,8,c);ui_text_fit(94,y,b,c,U_BG,page==MONITOR?146u:220u);
        if(page==MONITOR){
            /* Time-base read-out stays on the status line, out of the value box. */
            char t[16],*q=t;
            q=number(q,(int)(windows[window_idx]/1000));*q++='s';*q++=' ';
            q=number(q,(int)(windows[window_idx]/PW));*q++='m';*q++='s';*q=0;
            unsigned n=ui_len(t);ui_text_fit(316-(int)n,y,t,U_MUTED,U_BG,n+2);
            if(pan_px){
                /* Offset read-out, only while the trace is off centre. */
                char o[8],*r=o;*r++=pan_px>0?'^':'v';r=number(r,abs_i(pan_px));*r=0;
                ui_text_fit(226,y,o,U_MUTED,U_BG,30);
            }
        }
    }
    channel_cards();plot_hud();pad_hud();
    if(page==PAD){
        char t[48],*p=number(t,pad_duration/1000);*p++='s';*p++=' ';*p++='/';*p++=' ';*p++='-';p=number(p,pad_range/10);*p++='.';*p++='.';p=number(p,pad_range/10);
        *p++='d';*p++='e';*p++='g';*p++=' ';*p++='/';*p++=' ';p=number(p,interval);*p++='m';*p++='s';*p=0;
        lcd_fill_rect(78,26,240,18,U_BG);ui_text_fit(81,29,t,U_MUTED,U_BG,234);
    }
    if(page==CONTROL){
        metric(115,"ENCODER",st.enc_raw,"");metric(133,"ADC",st.ad_value,"");
        char t[20];decimal(t,q16_to_deg10(st.arm_ref_q16));
        lcd_fill_rect(84,151,224,18,U_SURFACE);ui_text(87,153,"TARGET",U_MUTED,U_SURFACE);unsigned n=ui_len(t);ui_text(281-(int)n,153,t,U_ACCENT,U_SURFACE);ui_text(286,153,"deg",U_MUTED,U_SURFACE);
        metric(169,"OUTPUT",st.freq_q8/256," Hz");metric(187,"REG #",st.epoch,"");
    }
    static unsigned old_play=99,old_state=99;
    if(old_play!=playing||old_state!=st.state){page_controls();old_play=playing;old_state=st.state;}
}
static void range_change(int direction)
{
    range_auto&=~(1u<<selected);
    int i=clip((int)range_idx[selected]+direction,0,8);range_idx[selected]=(unsigned)i;
    lo[selected]=-ranges[i];hi[selected]=ranges[i];dirty=1;
}
static void save_pad(void){for(unsigned i=0;i<N;i++)pad_saved[i]=pad_points[i];pad_undo=1;}
static void action(int x,int y)
{
    if(y<24){page=(unsigned)x/80;dirty=1;return;}
    if(x<76){
        if(y>=202){stop_motion(0x0f);dirty=1;return;}
        for(unsigned k=0;k<4;k++)if(y>=28+(int)k*42 && y<67+(int)k*42){
            /* Single-channel view: tapping a card shows only that channel, so
               four different units never share the plot at once. Tapping the
               card that is already soloed restores the four-curve overview. */
            int solo=(selected==k && page==MONITOR && enabled==(1u<<k));
            selected=k;page=MONITOR;enabled=solo?15u:(1u<<k);dirty=1;return;
        }
        return;
    }
    if(page==MONITOR){
        if(y>=184 && y<212){if(x<111)range_change(-1);else if(x<154)range_change(1);else if(x<214){range_auto^=1u<<selected;dirty=1;}else if(x<266){paused=!paused;if(paused)pause_started=now_ms();else plot_start+=now_ms()-pause_started;dirty=1;}else{clear_history();dirty=1;}}
        else if(y>=216){
            if(x<170){
                /* T- (finer) / T+ (coarser); clamping at both ends keeps the span
                   inside 1 s..120 s so the column resolution stays meaningful. */
                if(x<123){if(window_idx)window_idx--;}
                else if(window_idx<NWIN-1)window_idx++;
                clear_history();dirty=1;
            }else if(x<270){
                /* UP raises the trace, DN lowers it; the grid scrolls along so
                   the read-out keeps the same rows. Values are untouched, so
                   the history buffer survives a pan. */
                if(x<220){if(pan_px<PAN_MAX)pan_px+=PAN_STEP;}
                else if(pan_px>-PAN_MAX)pan_px-=PAN_STEP;
                dirty=1;
            }else{pan_px=0;dirty=1;}
        }
    }else if(page==PAD){
        if(y>=164 && y<189){
            unsigned k=(x-78)/60;
            if(k==0 && pad_undo){for(unsigned i=0;i<N;i++)pad_points[i]=pad_saved[i];pad_undo=0;}
            else if(k==1){save_pad();for(unsigned i=0;i<N;i++)pad_points[i]=0;pad_has=0;}
            else if(k==2){save_pad();for(unsigned i=1;i<N-1;i++)pad_points[i]=(pad_saved[i-1]+pad_saved[i]+pad_saved[i+1])/3;}
            else if(k==3){save_pad();for(unsigned i=0;i<N;i++)pad_points[i]=-pad_points[i];}dirty=1;
        }else if(y>=192 && y<214){
            unsigned k=(x-78)/60;
            if(k==0)pad_duration=pad_duration>=30000?2000:pad_duration+1000;
            if(k==1){pad_range=pad_range>=1800?10:pad_range<100?pad_range+10:pad_range<600?pad_range+100:pad_range+300;for(unsigned i=0;i<N;i++)pad_points[i]=clip(pad_points[i],-(int)pad_range,pad_range);}
            if(k==2)interval=interval>=100?20:interval+20;
            if(k==3)loop_play=!loop_play;dirty=1;
        }else if(y>=216){if(x<194){if(pad_has)begin_play(1);else last_result=1;}else stop_motion(0x23);dirty=1;}
    }else if(page==WAVE){
        if(y>=26 && y<50){wave_kind=(x-78)/80;if(wave_kind>2)wave_kind=2;dirty=1;}
        /* 步进改粗：周期一次 3 s（3~30 s 共 10 档），幅值一次 5°（5~180°）。 */
        if(y>=192 && y<214){unsigned k=(x-78)/60;if(k==0)wave_period=wave_period>6000?wave_period-3000:3000;if(k==1)wave_period=wave_period<30000?wave_period+3000:30000;if(k==2)wave_amp=wave_amp>50?wave_amp-50:50;if(k==3)wave_amp=wave_amp<1800?wave_amp+50:1800;dirty=1;}
        if(y>=216){if(x<194)begin_play(2);else stop_motion(0x23);dirty=1;}
    }else if(page==CONTROL){
        unsigned c=0;
        if(y>=30 && y<64)c=x<194?1:2;
        if(y>=72 && y<106)c=x<194?4:0x12;
        if(c){if(c==2 || c==4)stop_motion(c);else if(!playing)cmd(c,0,c==0x12?30:0);dirty=1;}
    }
}
static void stroke(int x,int y,int first)
{
    unsigned k=(unsigned)clip(x-78,0,N-1);int v=clip((PADY+PADH/2-y)*(int)pad_range/(PADH/2),-(int)pad_range,(int)pad_range);
    unsigned first_col=first?k:(k<pad_last?k:pad_last);
    if(first){save_pad();pad_last=k;pad_points[k]=(int16_t)v;}
    else {int start=(int)pad_last,end=(int)k,old=pad_points[start];int d=end-start;
        if(d)for(int i=start;;i+=d>0?1:-1){pad_points[i]=(int16_t)(old+(v-old)*(i-start)/d);if(i==end)break;}}
    /* Hold the last drawn value over the undrawn tail, as in the desktop pad. */
    for(unsigned i=k+1;i<N;i++)pad_points[i]=(int16_t)v;
    pad_last=k;pad_has=1;
    if(first_col<pad_draw_col)pad_draw_col=first_col;
}
#ifndef HMI_HOST
void calibrate(touch_cal *cal);
#ifdef HMI_SIM_AUTOTEST
static void sim_assert(int ok,unsigned code){if(!ok){SYS(4)=0xdead0000u|code;for(;;){}}}
static void sim_send(unsigned c,int a,unsigned speed,unsigned expected)
{
    sim_assert(cmd(c,a,speed),10+c);
    while(command_inflight)command_poll();
    sim_assert(last_result==expected,100+c);
}
int main(void)
{
    delay_ms(2);read_snapshot();
    sim_assert(snapshot_ok && values[0]==287 && values[1]==-287 && values[2]==143 && values[3]==125,1);
    sim_send(0x24,-123,100,0);
    sim_send(0x24,1900,100,1);
    sim_send(0x23,0,0,0);
    sim_send(0x0f,0,0,0);
    sim_send(0x24,0,100,2);
    sim_send(0x04,0,0,0);
    SYS(4)=0x484d50ffu;
    for(;;){}
}
#else
int main(void)
{
    touch_cal cal;touch_point raw,p={0,0};
    lcd_hw_init();lcd_panel_init();touch_init();
#ifdef HMI_SIM_SKIP_CAL
    cal=(touch_cal){4096,0,0,0,4096,0};
#else
    calibrate(&cal);
#endif
    uint32_t sample_time=0,status_time=0;unsigned was_down=0,in_stroke=0,capture_page=0;int hit_x=0,hit_y=0;
    SYS(4)=0x484d4901u;
    for(;;){
        unsigned now=now_ms();command_poll();read_snapshot();playback_tick();
        unsigned down=touch_pen();
        if(down && touch_read(&raw)){
            p=touch_map(&cal,raw);p.x=clip(p.x,0,319);p.y=clip(p.y,0,239);
            if(!was_down){hit_x=p.x;hit_y=p.y;capture_page=page;
                in_stroke=page==PAD && p.x>=78 && p.x<310 && p.y>=PADY && p.y<PADY+PADH;
                if(in_stroke)stroke(p.x,p.y,1);
                /* E-stop acts on contact, other buttons commit on release. */
                if(p.x<76 && p.y>=202)stop_motion(0x0f);
                ui_down=1;ui_x=p.x;ui_y=p.y;if(!in_stroke)page_controls();
            }else if(in_stroke)stroke(p.x,p.y,0);
            if(ui_down&&!in_stroke&&(abs_i(p.x-ui_x)>5||abs_i(p.y-ui_y)>5)){ui_x=p.x;ui_y=p.y;page_controls();}
            was_down=1;
        }else if(!down && was_down){
            ui_down=0;if(!in_stroke)page_controls();
            if(!in_stroke && capture_page==page && abs_i(p.x-hit_x)<14 && abs_i(p.y-hit_y)<14)action(hit_x,hit_y);
            was_down=0;in_stroke=0;
        }
        if(dirty)draw_page();
        pad_render_tick();
        now=now_ms();
        if(now-sample_time>=windows[window_idx]/PW){sample_time=now;sample_plot();}
        if(now-status_time>=300){status_time=now;status_ui();}
        SYS(4)=0x484d0000u | (page<<8) | (playing<<4) | (command_inflight?1:0);
    }
}
#endif
#endif
