/* =========================================================================
 * status.h  --  控制域一致快照的读取（seqlock）
 *
 * 快照由 status_snapshot.v 每 1 ms 在同一时钟沿整体锁存一次，并让 SEQ+1。
 * 软件用 "读 SEQ -> 读字段 -> 再读 SEQ" 的方式确认读到的是一帧完整数据。
 * ========================================================================= */
#ifndef STATUS_H
#define STATUS_H

#include <stdint.h>
#include "lcd_regs.h"

#define SNAP_BASE ((uintptr_t)CFG_RV_SNAP_BASE)

typedef struct {
    uint32_t seq;
    uint32_t epoch;        /* 快照更新计数，用于判断数据是否刷新 */
    uint8_t  state;
    uint8_t  fault;
    uint8_t  flags;
    uint8_t  mode;         /* bit0 run, bit1 calibrated, bit2 saturated,
                              bit3 feedback_ready, bit4 swing_active */
    int32_t  alpha_q16;    /* 横臂角 rad<<16 */
    int32_t  theta_q16;    /* 摆杆角 rad<<16 */
    int32_t  arm_ref_q16;  /* 横臂目标 rad<<16 */
    int32_t  freq_q8;      /* 电机指令 Hz<<8 */
    int32_t  u_q16;
    int32_t  alpha_dot;
    int32_t  theta_dot;
    int32_t  alpha_c;
    uint32_t enc_raw;
    uint32_t enc_age_us;
    uint32_t enc_seq;
    uint32_t ctrl_count;
    uint32_t t_us;
    uint32_t ad_value;
    uint32_t build_tag;
} lqr_status_t;

/* 返回 0 表示读到一致快照；-1 表示重试 4 次仍失败（极少见） */
int  lqr_read_status(lqr_status_t *s);

/* rad<<16 -> 0.1 度（|角度| < 57 rad 时 32 位乘法不溢出） */
int32_t q16_to_deg10(int32_t q16);

const char *lqr_state_name(uint8_t state);

#endif /* STATUS_H */
