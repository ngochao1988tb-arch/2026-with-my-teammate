/* =========================================================================
 * status.c  --  一致快照读取
 * ========================================================================= */
#include "status.h"

#define R(off) (*(volatile uint32_t *)(SNAP_BASE + (off)))

int lqr_read_status(lqr_status_t *s)
{
    int tries;
    for (tries = 0; tries < 4; tries++) {
        uint32_t s1 = R(0x00);
        uint32_t st = R(0x04);
        int32_t  a  = (int32_t)R(0x08);
        int32_t  t  = (int32_t)R(0x0C);
        int32_t  ar = (int32_t)R(0x10);
        int32_t  f  = (int32_t)R(0x14);
        int32_t  u  = (int32_t)R(0x18);
        uint32_t er = R(0x1C);
        uint32_t ea = R(0x20);
        uint32_t cn = R(0x24);
        uint32_t tu = R(0x28);
        uint32_t es = R(0x2C);
        int32_t  ad_ = (int32_t)R(0x30);
        int32_t  td_ = (int32_t)R(0x34);
        int32_t  ac_ = (int32_t)R(0x38);
        uint32_t adv = R(0x3C);
        uint32_t bt = R(0x40);
        uint32_t epoch = R(0x4C);
        uint32_t s2 = R(0x00);
        if (s1 != s2) continue;
        s->seq       = s1;
        s->epoch     = epoch;
        s->state     = (uint8_t)(st >> 24);
        s->fault     = (uint8_t)(st >> 16);
        s->flags     = (uint8_t)(st >> 8);
        s->mode      = (uint8_t)(st & 0x1Fu);
        s->alpha_q16 = a;
        s->theta_q16 = t;
        s->arm_ref_q16 = ar;
        s->freq_q8   = f;
        s->u_q16     = u;
        s->enc_raw   = er;
        s->enc_age_us= ea;
        s->ctrl_count= cn;
        s->t_us      = tu;
        s->enc_seq   = es;
        s->alpha_dot = ad_;
        s->theta_dot = td_;
        s->alpha_c   = ac_;
        s->ad_value  = adv;
        s->build_tag = bt;
        return 0;
    }
    return -1;
}

int32_t q16_to_deg10(int32_t q16)
{
    /* deg*10 = q16 * 573 / 65536，误差 < 0.02% */
    if (q16 > 2000000)  q16 = 2000000;
    if (q16 < -2000000) q16 = -2000000;
    /* 限幅后 q16*573 <= 1.15e9，32 位有符号乘法不溢出 */
    return (q16 * 573) >> 16;
}

const char *lqr_state_name(uint8_t state)
{
    switch (state) {
    case 0:  return "IDLE ";
    case 1:  return "CAL  ";
    case 2:  return "READY";
    case 3:  return "RUN  ";
    case 4:  return "FAULT";
    case 5:  return "SWING";
    default: return "?    ";
    }
}
