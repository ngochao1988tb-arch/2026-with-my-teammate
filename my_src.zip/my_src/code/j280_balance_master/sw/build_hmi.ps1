param([string]$Zig='zig', [string]$Python='python')
$ErrorActionPreference='Stop'
function Run([string]$Program,[string[]]$CommandArgs) { & $Program @CommandArgs; if ($LASTEXITCODE -ne 0) { throw "Build failed: $Program" } }
Push-Location $PSScriptRoot
try {
 Run $Python @('../tools/gen_sw_header.py')
 Run $Python @('../tools/gen_hmi_header.py')
 $flags=@('cc','-target','riscv32-freestanding','-mcpu=generic_rv32','-mabi=ilp32','-DLCD_PANEL_ST7789','-Os','-g','-Wall','-Wextra','-Werror','-ffreestanding','-fno-builtin','-nostdlib','-Wl,-T,link.ld')
 $sources=@('start.S','hmi.c','calibrate.c','touch.c','lcd.c','status.c','font8x16.c','util.c')
 Run $Zig ($flags+@('-o','../fw.elf')+$sources)
 Run $Zig @('objcopy','-O','binary','../fw.elf','../fw.bin')
 Run $Python @('../tools/bin2hex.py','../fw.bin','../imem.hex','../dmem.hex','32768','16384')
 Run $Zig ($flags+@('-DSIM_FAST_INIT','-DHMI_SIM_SKIP_CAL','-o','../fw_sim.elf')+$sources)
 Run $Zig @('objcopy','-O','binary','../fw_sim.elf','../fw_sim.bin')
 Run $Python @('../tools/bin2hex.py','../fw_sim.bin','../imem_sim.hex','../dmem.hex','32768','16384')
 Run $Zig ($flags+@('-DSIM_FAST_INIT','-DHMI_SIM_AUTOTEST','-Wno-unused-function','-Wno-unused-variable','-o','../fw_bus_test.elf')+$sources)
 Run $Zig @('objcopy','-O','binary','../fw_bus_test.elf','../fw_bus_test.bin')
 Run $Python @('../tools/bin2hex.py','../fw_bus_test.bin','../imem_bus_test.hex','../dmem_bus_test.hex','32768','16384')
} finally { Pop-Location }
