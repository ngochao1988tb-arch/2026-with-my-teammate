/* Small immediate-mode dashboard renderer, RGB565, no framebuffer. */
#ifndef HMI_UI_H
#define HMI_UI_H
#include "ui_font.h"
#define U_BG       RGB565(10,17,29)
#define U_SURFACE  RGB565(20,31,47)
#define U_RAISED   RGB565(29,43,61)
#define U_SELECTED RGB565(27,53,71)
#define U_PLOT     RGB565(12,23,36)
#define U_GRID     RGB565(27,41,56)
#define U_AXIS     RGB565(47,66,83)
#define U_TEXT     RGB565(228,237,246)
#define U_MUTED    RGB565(132,155,178)
#define U_DIM      RGB565(75,95,116)
#define U_ACCENT   RGB565(68,211,204)
#define U_PRIMARY  RGB565(16,91,91)
#define U_PRESS    RGB565(47,114,128)
#define U_DANGER   RGB565(157,43,61)
#define U_RED      RGB565(255,132,145)
#define U_AMBER    RGB565(246,193,93)
static unsigned ui_down;
static int ui_x,ui_y;
static unsigned ui_len(const char *s)
{
    unsigned n=0;while(*s){unsigned c=(unsigned char)*s++;if(c<32||c>126)c='?';n+=ui_font_width[c-32]+1u;}return n?n-1u:0;
}
static void ui_text_fit(int x,int y,const char *s,uint16_t fg,uint16_t bg,unsigned maxw)
{
    int start=x;
    while(*s){
        unsigned c=(unsigned char)*s++;if(c<32||c>126)c='?';c-=32;
        unsigned w=ui_font_width[c];if((unsigned)(x-start)+w>maxw||x+(int)w>=320)return;
        lcd_set_window((uint16_t)x,(uint16_t)y,(uint16_t)(x+w),(uint16_t)(y+12));
        for(unsigned row=0;row<13;row++)for(unsigned col=0;col<=w;col++)lcd_write_data(col<w&&(ui_font[ui_font_offset[c]+col]&(1u<<row))?fg:bg);
        x+=(int)w+1;
    }
}
static void ui_text(int x,int y,const char *s,uint16_t fg,uint16_t bg)
{
    ui_text_fit(x,y,s,fg,bg,(unsigned)(320-x));
}
static void ui_center(int x,int y,int w,const char *s,uint16_t fg,uint16_t bg)
{
    unsigned n=ui_len(s);ui_text_fit(x+(n<(unsigned)w?(w-(int)n)/2:0),y,s,fg,bg,(unsigned)w);
}
static void ui_round(int x,int y,int w,int h,uint16_t bg)
{
    static const uint8_t insets[4]={3,1,1,0};
    lcd_fill_rect(x,y+4,w,h-8,bg);
    for(unsigned i=0;i<4;i++){
        unsigned d=insets[i];lcd_hline(x+d,y+i,w-2*d,bg);lcd_hline(x+d,y+h-1-i,w-2*d,bg);
    }
}
static void ui_number(int x,int y,const char *s,uint16_t fg,uint16_t bg,unsigned maxw)
{
    unsigned total=0;
    for(const char *p=s;*p;p++){unsigned k=*p=='-'?10:*p=='.'?11:(unsigned)(*p-'0');if(k>11)return;total+=ui_digit_width[k]+1;}
    if(total>maxw){ui_text_fit(x,y+4,s,fg,bg,maxw);return;}
    while(*s){
        unsigned k=*s=='-'?10:*s=='.'?11:(unsigned)(*s-'0');s++;
        unsigned w=ui_digit_width[k];lcd_set_window(x,y,x+w,y+19);
        for(unsigned row=0;row<20;row++)for(unsigned col=0;col<=w;col++)lcd_write_data(col<w&&(ui_digit[ui_digit_offset[k]+col]&(1u<<row))?fg:bg);
        x+=(int)w+1;
    }
}
/* 12px line icons keep navigation recognizable on a small display. */
static void ui_icon(unsigned kind,int x,int y,uint16_t c)
{
    static const uint16_t icons[4][12]={
        {0,0,0x108,0x108,0x108,0x18c,0x294,0x263,0x240,0,0,0},
        {0,0x100,0x280,0x140,0xa0,0x50,0x28,0x14,0x1c,0xe,0,0},
        {0,0,0x018,0x024,0x042,0x042,0x881,0x881,0x480,0x300,0,0},
        {0x020,0x020,0x020,0x020,0x124,0x222,0x222,0x202,0x104,0x088,0x070,0}
    };
    for(unsigned row=0;row<12;row++)for(unsigned col=0;col<12;col++)if(icons[kind][row]&(1u<<col))lcd_draw_pixel(x+col,y+row,c);
}
#endif
