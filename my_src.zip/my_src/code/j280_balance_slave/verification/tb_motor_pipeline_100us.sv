`timescale 1ns/1ps
`include "system_params.vh"
module tb_motor_pipeline_100us;
    reg clk=0,rst_n=0,safe=0;
    always #10 clk=~clk;
    reg [1:0] dir=0;
    reg [7:0] duty=0;
    reg swingup_mode=0;
    reg [12:0] phase=0;
    wire [15:0] applied_new,applied_old;
    wire n1,n2,np,o1,o2,op;
    integer i,j;
`ifdef DEADBAND_OFF_TEST
    localparam EXPECT_JOG=69, EXPECT_STRONG=240, EXPECT_STRONG_CMP=4687;
`elsif DEADBAND10_TEST
    localparam EXPECT_JOG=79, EXPECT_STRONG=250, EXPECT_STRONG_CMP=4882;
`else
    localparam EXPECT_JOG=84, EXPECT_STRONG=255, EXPECT_STRONG_CMP=4980;
`endif
    motor_tb6612 #(.SWINGUP_DUTY_LIMIT(8'd255)) current_motor(clk,rst_n,safe,dir,duty,
        `PWM_DEADBAND_POS,`PWM_DEADBAND_NEG,`PWM_DEADZONE_THRESH,swingup_mode,n1,n2,np,applied_new);
    motor_tb6612_before previous_motor(clk,rst_n,safe,dir,duty,
        `PWM_DEADBAND_POS,`PWM_DEADBAND_NEG,`PWM_DEADZONE_THRESH,o1,o2,op,applied_old);
    task compare;
        begin
            if(applied_new!==applied_old || current_motor.active_cmp!==previous_motor.active_cmp ||
               current_motor.active_dir!==previous_motor.active_dir || {n1,n2,np}!=={o1,o2,op})
                $fatal(1,"Motor compensation changed: dir=%0d duty=%0d new=%0d old=%0d",dir,duty,applied_new,applied_old);
        end
    endtask
    initial begin
        // Inject a common carrier boundary to compare all command values quickly.
        // Real free-running PWM/UART phase is covered by tb_uart_pwm_100us.
        force current_motor.pwm_cnt=phase;
        force previous_motor.pwm_cnt=phase;
        #101 rst_n=1; safe=1;
        for(j=0;j<4;j=j+1) for(i=0;i<256;i=i+1) begin
            @(negedge clk); phase=0; dir=j; duty=i;
            repeat(12) @(negedge clk);
            phase=4999;
            @(negedge clk); phase=0; compare;
            repeat(3) @(negedge clk); compare;
        end
        $display("PASS: all 1024 direction/duty combinations retain previous compensation, limit and PWM threshold");
        dir=2; duty=220;
        repeat(12) @(negedge clk);
        phase=4999; @(negedge clk); phase=0; compare;
        // Stop without a carrier boundary: every physical output must be zero
        // on the next clock, despite an extra command stage.
        safe=0; @(negedge clk);
        if({n1,n2,np}!=0 || applied_new!=0 || current_motor.excess_cmd || current_motor.ramp_cmd)
            $fatal(1,"Extra pipeline delayed emergency stop");
        compare;
        dir=1; duty=70; safe=1;
        repeat(12) @(negedge clk);
        phase=4999; @(negedge clk); phase=0; compare;
        if(applied_new!=EXPECT_JOG) $fatal(1,"Fresh command after stop used stale direction/duty");
        $display("PASS: stop bypasses carrier and all pipeline stages; reenable uses fresh command");
        swingup_mode=1; dir=1; duty=241;
        repeat(12) @(negedge clk);
        phase=4999; @(negedge clk); phase=0;
        if(applied_new!=EXPECT_STRONG || current_motor.active_cmp!=EXPECT_STRONG_CMP)
            $fatal(1,"Swing-up compensation is wrong for command 241");
        // Match the top-level capture flush before handing over to balance.
        safe=0; swingup_mode=0; @(negedge clk);
        if(applied_new!=0 || {n1,n2,np}!=0) $fatal(1,"Mode transition failed to stop high PWM");
        safe=1;
        repeat(12) @(negedge clk);
        phase=4999; @(negedge clk); phase=0;
        if(applied_new!=230) $fatal(1,"Balance mode reused the swing-up PWM limit");
        compare;
        $display("PASS: swing-up command 241 maps to %0d; capture flush clears it and balance stays capped at 230",EXPECT_STRONG);
        $finish;
    end
endmodule
