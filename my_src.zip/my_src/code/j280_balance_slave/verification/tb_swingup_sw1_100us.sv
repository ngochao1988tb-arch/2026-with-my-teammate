`timescale 1ns/1ps
`include "system_params.vh"
module tb_swingup_sw1_100us;
    reg clk=0, rst_n=0;
    always #10 clk=~clk;
    reg [9:0] adc_input=559;
    reg [3:0] keys=0, pulses=0;
    wire pa,a1,a2;
    integer i, lqr_results=0, entry_results;
`ifdef DEADBAND_OFF_TEST
    localparam EXPECT_KICK_PWM=240;
`elsif DEADBAND10_TEST
    localparam EXPECT_KICK_PWM=250;
`else
    localparam EXPECT_KICK_PWM=255;
`endif
    always @(posedge clk) if(dut.lqr_calc_done) lqr_results=lqr_results+1;
    always @(posedge clk) begin
        #1;
        if(rst_n && dut.fsm_state==2 && (dut.applied_pwm>230 || dut.applied_pwm< -230))
            $fatal(1,"High-duty swing-up command leaked into BALANCE");
    end
    j280_lqr_top dut(.clk_50m(clk),.rst_n(rst_n),.key_sw(4'hf),
        .uart_rx(1'b1),.adc_data_in(adc_input),.PWMA(pa),.AN1(a1),.AN2(a2),
        .enc1_a(1'b0),.enc1_b(1'b0),.enc2_a(1'b0),.enc2_b(1'b0));
    task frames(input integer n);
        begin repeat(n) @(posedge dut.control_tick); @(negedge clk); end
    endtask
    task pulse(input reg [3:0] p);
        begin @(negedge clk); pulses=p; @(negedge clk); pulses=0; end
    endtask
    task fresh(input integer a);
        begin
            @(negedge clk); rst_n=0; keys=0; pulses=0; adc_input=a;
            repeat(5) @(negedge clk); rst_n=1;
            // Let the existing sensor velocity window become valid; SW1 must
            // start on its own clock edge, without three calibration windows.
            frames(40);
            if(dut.fsm_state!=1 || dut.motor_safe_enable || dut.calibration_valid)
                $fatal(1,"Power-up started without SW1");
            pulse(1);
            if(dut.fsm_state!=((`SWINGUP_ENABLE && a==559) ? 5 : 1) || dut.calibrated_zero!=236)
                $fatal(1,"SW1 did not select the expected state on its press edge");
            if(dut.calibration_pending || dut.calibration_confirm_cnt || !dut.startup_velocity_valid)
                $fatal(1,"SW1 entered calibration or cleared the ready velocity window");
        end
    endtask
    task start;
        begin
            @(negedge clk); keys=0;
            repeat(5) @(negedge clk);
            if(dut.fsm_state!=5 || !dut.swingup_ctrl_enable) $fatal(1,"Fixed-zero SW1 failed to start real FSM without SW2/SW3");
            keys=0; frames(3);
            if(dut.swingup_duty!=241 || dut.applied_pwm!=EXPECT_KICK_PWM)
                $fatal(1,"Kick or current motor mapping incorrect: %0d/%0d",dut.swingup_duty,dut.applied_pwm);
        end
    endtask
    task stopped(input integer fault);
        begin
            repeat(4) @(negedge clk);
            if(dut.fsm_state!=4 || dut.fault_cause!=fault || dut.motor_safe_enable ||
               dut.applied_pwm!=0 || pa || a1 || a2)
                $fatal(1,"Fault %0d failed: state=%0d cause=%0d",fault,dut.fsm_state,dut.fault_cause);
            // Keep checking even when the sample clock has stopped.
            keys=6; repeat(15000) @(negedge clk);
            if(dut.fsm_state!=4) $fatal(1,"Latched fault restarted by trigger");
            keys=0;
        end
    endtask
    initial begin
        force dut.key_state=keys;
        force dut.key_pulse=pulses;
        // Press before any ADC/velocity history: consume without a delayed start.
        #101 rst_n=1;
        pulse(1); frames(40);
        if(dut.fsm_state!=1 || dut.motor_safe_enable || dut.calibration_pending || dut.calibration_valid)
            $fatal(1,"Early SW1 caused calibration or a delayed start");
        $display("PASS: SW1 before sensor readiness is consumed without calibration or deferred start");
        fresh(266); // raw=1064, upright distance=828: legacy DOWNWARD is not a start point.
        if(dut.swingup_start_condition) $fatal(1,"Legacy downward macro incorrectly mapped into start window");
        keys=6; repeat(5) @(negedge clk);
        keys=2; repeat(5) @(negedge clk);
        if(!dut.swingup_trigger_lockout || dut.jog_request || dut.fsm_state!=1 || dut.motor_safe_enable)
            $fatal(1,"Partial two-key release unexpectedly enables jog");
        keys=0; repeat(5) @(negedge clk);
        if(dut.swingup_trigger_lockout) $fatal(1,"Both-key release did not rearm");
        $display("PASS: invalid start is consumed until both keys release; raw 1064 stays outside start window");
        // Invalid SW1 start must not remain armed until the position later changes.
        adc_input=559; frames(65);
        if(dut.fsm_state!=1 || dut.calibration_pending || dut.motor_safe_enable)
            $fatal(1,"Invalid SW1 request caused a delayed start");
        $display("PASS: invalid SW1 request is consumed; no start when later moved into hanging window");
        fresh(559); // raw=2236, upright distance=2000; real ADC median + startup windows.
        if(!dut.swingup_start_condition || dut.fsm_state!=(`SWINGUP_ENABLE ? 5 : 1)) $fatal(1,"Hanging/start window mismatch");
`ifdef SWING_TEST_ENABLED
        start;
        keys=1; // Hold SW1, without additional debounced press pulses.
        frames(5);
        if(dut.fsm_state!=5 || dut.swingup_elapsed<7 || dut.calibration_pending)
            $fatal(1,"Held SW1 repeated or blocked the one-shot request");
        keys=0;
        @(negedge clk); adc_input=59;
        wait(dut.fsm_state==2); entry_results=lqr_results; @(negedge clk);
        if(dut.motor_safe_enable || dut.applied_pwm!=0 || !dut.swingup_handoff_flush)
            $fatal(1,"Capture did not flush the active high-duty swing-up command");
        if(dut.target_alpha!=dut.enc1_sampled_pos || dut.position_target_alpha!=dut.enc1_sampled_pos ||
           dut.swingup_ctrl_enable || !dut.lqr_ctrl_enable)
            $fatal(1,"Handoff did not select LQR and capture current arm target");
        // Entry tick must launch LQR immediately without waiting 100us.
        repeat(30) @(negedge clk);
        if(!dut.u_lqr.ctrl_enable || dut.swingup_duty!=0 || lqr_results<=entry_results)
            $fatal(1,"Handoff left swing command active or missed immediate LQR calculation");
        frames(2);
        $display("INFO: two frames after artificial 2000-count position jump: theta_dot=%0d PWM=%0d",dut.frame_theta_dot,dut.applied_pwm);
        // The artificial instantaneous ADC jump leaves a Kalman transient.
        // Retain damping during this transient; allow the observer to settle.
        frames(100);
        if(dut.fsm_state!=2 || dut.applied_pwm!=0) $fatal(1,"Steady upright handoff PWM not cleared");
        $display("PASS: SW1 press edge -> fixed zero 236 -> SWINGUP -> real ADC upright -> BALANCE, target capture and PWM change");
        fresh(559); start; pulse(8); stopped(4);
        $display("PASS: SW4 cuts drive and blocks retrigger");
        fresh(559); start;
        force dut.enc1_sampled_pos=16'd12151;
        stopped(1); release dut.enc1_sampled_pos;
        $display("PASS: swing-up travel protection cuts drive and latches");
        fresh(559); start;
        force dut.enc1_vel=16'sd501;
        stopped(2); release dut.enc1_vel;
        $display("PASS: swing-up overspeed protection cuts drive and latches");
        fresh(559); start;
        force dut.tick_3ms=0;
        wait(dut.sample_timeout); stopped(6); release dut.tick_3ms;
        $display("PASS: sampling watchdog cuts swing-up drive and latches");
        fresh(559); start;
        // Accelerate only the timeout counter; never force the FSM state.
        force dut.swingup_elapsed=17'd80009;
        frames(1); release dut.swingup_elapsed; stopped(7);
        pulse(1);
        if(dut.fsm_state!=5 || dut.fault_cause!=0 || dut.calibration_pending)
            $fatal(1,"SW1 did not restart immediately after timeout with fixed zero");
        start;
        $display("PASS: timeout latches fault 7; SW1 starts a fresh swing-up without calibration");
        fresh(559); start;
        // Keep capture pending until a stable real ADC input has reached the
        // catch window, then exercise coincident capture + timeout pulses.
        force dut.startup_tick=0;
        adc_input=59; frames(100);
        if(!dut.swingup_catch_condition) $fatal(1,"Boundary test never reached catch window");
        force dut.swingup_elapsed=17'd80009;
        force dut.control_tick=1;
        force dut.startup_tick=1;
        @(negedge clk);
        release dut.control_tick; release dut.startup_tick; release dut.swingup_elapsed;
        stopped(7);
        $display("PASS: coincident timeout and eligible capture select timeout fault, never drive BALANCE");
        force dut.enc1_sampled_pos=16'd10300;
        fresh(559); start;
        if(dut.calibrated_zero!=236 || dut.calibrated_alpha_center!=10000 ||
           dut.target_alpha!=10000 || dut.position_target_alpha!=10000)
            $fatal(1,"SW1 sampled an arm reference instead of using program defaults");
        release dut.enc1_sampled_pos;
        $display("PASS: arm sampled at 10300 does not replace fixed center/target 10000 on SW1");
`else
        keys=6; frames(4);
        if(dut.fsm_state!=1 || dut.swingup_ctrl_enable || dut.motor_safe_enable || dut.applied_pwm)
            $fatal(1,"Production swing-up flags are no longer disabled");
        $display("PASS: production manual and automatic swing-up remain disabled");
`endif
        $finish;
    end
    initial begin #250000000; $fatal(1,"FSM test timed out"); end
endmodule
