`timescale 1ns/1ps
`include "system_params.vh"
module tb_control_6ms;
    reg clk=0, rst_n=0;
    always #10 clk=~clk;
    wire tx, adc_clk, oe, stby, pa, a1, a2, pb, b1, b2;
    j280_lqr_top dut (
        .clk_50m(clk), .rst_n(rst_n), .key_sw(4'hf), .uart_rx(1'b1), .uart_tx(tx),
        .adc_data_in(10'd59), .adc_clk(adc_clk), .adc_oe_n(oe), .adc_stby_n(stby),
        .PWMA(pa), .AN1(a1), .AN2(a2), .PWMB(pb), .BN1(b1), .BN2(b2),
        .enc1_a(1'b0), .enc1_b(1'b0), .enc2_a(1'b0), .enc2_b(1'b0)
    );
    reg ea=0, eb=0, enc_tick=0;
    wire [15:0] pos, sampled_pos, illegal;
    wire signed [15:0] velocity;
    wire signed [19:0] velocity_q4;
    encoder_quad #(.INIT_POS(10000),.FILTER_MODE(0)) enc (
        .clk_50m(clk), .rst_n(rst_n), .tick_3ms(enc_tick), .enc_a(ea), .enc_b(eb),
        .pos(pos), .sampled_pos(sampled_pos), .vel(velocity), .vel_q4(velocity_q4),
        .illegal_trans_cnt(illegal)
    );
    reg pid_tick=0;
    wire signed [15:0] correction;
    wire pid_sat;
    arm_position_pid #(.KP(120),.KI(3),.KD(8000),.INTEGRAL_LIMIT(13107),.OUTPUT_LIMIT(100)) pid (
        .clk_50m(clk), .rst_n(rst_n), .tick_3ms(pid_tick), .enable(1'b1),
        .position(16'd10010), .target_position(16'd10000), .velocity_q4(20'sd0),
        .correction(correction), .saturated(pid_sat)
    );
    integer clock_count=0, last_report=0, reports=0;
    always @(posedge clk) begin
        clock_count=clock_count+1;
        #1;
        if (rst_n && dut.report_tick) begin
            if (reports!=0 && clock_count-last_report!=300000)
                $fatal(1,"Telemetry interval is not 6ms");
            last_report=clock_count; reports=reports+1;
        end
    end
    reg manual_tick=0;
    integer i;
    initial begin
        #101 rst_n=1;
        force dut.calibration_valid=1;
        force dut.calibration_pending=0;
        force dut.calibrated_zero=236;
        force dut.fsm_state=2;
        // Real ADC/control/telemetry cadence, not a synthetic tick generator.
        wait(reports==3);
        #2;
        if (dut.sample_timeout || dut.frame_theta!=236 || dut.cur_theta_dot!=0)
            $fatal(1,"Real ADC/control integration failed");
        // Exercise actual quadrature decoder: 2 counts per 6ms = 1 count/3ms.
        @(negedge clk); ea=1;
        repeat(20) @(negedge clk); eb=1;
        repeat(20) @(negedge clk); enc_tick=1;
        @(posedge clk); #1;
        if (sampled_pos!=10002 || velocity_q4!=16 || velocity!=1 || illegal!=0)
            $fatal(1,"Encoder velocity normalization failed");
        @(negedge clk); enc_tick=0; eb=0;
        repeat(20) @(negedge clk); ea=0;
        repeat(20) @(negedge clk); enc_tick=1;
        @(posedge clk); #1;
        if (sampled_pos!=10000 || velocity_q4!=-16 || velocity!=-1)
            $fatal(1,"Negative encoder normalization failed");
        @(negedge clk); enc_tick=0; pid_tick=1;
        @(negedge clk); pid_tick=0;
        repeat(8) @(posedge clk); #1;
        if (pid.integral_accum!=20 || correction!=4)
            $fatal(1,"Arm integral elapsed-time scaling failed");
        // Preserve 150-count target slew in 225 x 6ms frames (~1.35s).
        force dut.control_tick=manual_tick;
        force dut.position_target_alpha=10150;
        for (i=1;i<=225;i=i+1) begin
            @(negedge clk); manual_tick=1;
            @(posedge clk); #1;
            if (dut.target_alpha!=10000+(i*2)/3)
                $fatal(1,"Target slew mismatch at frame %0d: %0d",i,dut.target_alpha);
            @(negedge clk); manual_tick=0;
            repeat(8) @(posedge clk);
        end
        force dut.frame_theta=216; // 20-count angle error outside deadband
        @(negedge clk); manual_tick=1;
        @(posedge clk); #1;
        if (dut.theta_i_accum!=40) $fatal(1,"Theta integral elapsed-time scaling failed");
        @(negedge clk); manual_tick=0;
        // Sampling watchdog keeps three new frame periods and cuts the motor.
        force dut.sample_age=899999; #1;
        if (dut.sample_timeout) $fatal(1,"Watchdog too early");
        force dut.sample_age=900000; #1;
        if (!dut.sample_timeout || dut.motor_safe_enable) $fatal(1,"Watchdog failed to gate motor");
        @(posedge clk); #1;
        if (pa || a1 || a2) $fatal(1,"Motor not cut off");
        if (`SWINGUP_KICK_FRAMES*6!=90 || `SATURATION_TIMEOUT_CYCLES*6!=300)
            $fatal(1,"Real-time duration compensation failed");
        $display("PASS: actual 6ms control/telemetry, encoder sign/scale, integrals, 150-count slew and watchdog/motor gating");
        $finish;
    end
    initial begin
        #50000000;
        $fatal(1,"6ms integration timed out");
    end
endmodule
