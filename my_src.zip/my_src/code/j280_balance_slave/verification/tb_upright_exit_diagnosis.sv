`timescale 1ns/1ps
`include "system_params.vh"
module tb_upright_exit_diagnosis;
    reg clk=0, rst_n=0;
    always #10 clk=~clk;
    wire tx, adc_clk, oe, stby, pa, a1, a2, pb, b1, b2;
    j280_lqr_top dut (
        .clk_50m(clk), .rst_n(rst_n), .key_sw(4'hf), .uart_rx(1'b1), .uart_tx(tx),
        .adc_data_in(adc_input), .adc_clk(adc_clk), .adc_oe_n(oe), .adc_stby_n(stby),
        .PWMA(pa), .AN1(a1), .AN2(a2), .PWMB(pb), .BN1(b1), .BN2(b2),
        .enc1_a(1'b0), .enc1_b(1'b0), .enc2_a(1'b0), .enc2_b(1'b0)
    );
    reg [9:0] adc_input=59;
    reg injected_tick=0;
    reg signed [15:0] injected_velocity=0;
    integer i;
    initial begin
        #101 rst_n=1;
        force dut.calibration_valid=1;
        force dut.calibration_pending=0;
        force dut.sample_seen=1;
        force dut.sample_age=0;
        force dut.frame_theta=236;
        force dut.frame_theta_dot=injected_velocity;
        force dut.control_tick=injected_tick;
        force dut.fsm_state=2;
        repeat(20) @(negedge clk);
        release dut.fsm_state;
        // Accelerate ticks only: each represents a 100us control frame.
        // +/-120 is exactly the normalized difference of one raw ADC count.
        for(i=1;i<=3000;i=i+1) begin
            @(negedge clk); injected_velocity=(i%2) ? 120 : -120; injected_tick=1;
            @(negedge clk); injected_tick=0;
            repeat(14) @(negedge clk);
            if(i<3000 && dut.fsm_state!=2)
                $fatal(1,"Unexpected early exit at %0d: cause=%0d",i,dut.fault_cause);
        end
        if(dut.fsm_state!=4 || dut.fault_cause!=3 || dut.motor_safe_enable)
            $fatal(1,"Saturation exit not reproduced state=%0d cause=%0d",dut.fsm_state,dut.fault_cause);
        $display("REPRODUCED: zero angle error with +/-120 quantization velocity exits after 3000 control frames (300ms), cause=3 saturation_timeout");
        $finish;
    end
    initial begin #2000000; $fatal(1,"Exit diagnosis timed out"); end
endmodule
