`timescale 1ns/1ps
`include "system_params.vh"
module tb_measured_v1_lqr_wrap;
reg clk=0,rst=0,tick=0,enable=1;
always #10 clk=~clk;
reg [11:0] theta=0;
reg [15:0] zero=240;
wire [1:0] dir;
wire [7:0] duty;
wire signed [15:0] err,u;
wire done,sat;
lqr_controller dut(.clk_50m(clk),.rst_n(rst),.tick_3ms(tick),.ctrl_enable(enable),.flush_pipeline(!enable),
.calibrated_zero_val(zero),.theta_raw(theta),.theta_dot(16'sd0),.alpha_pos(16'd10000),.alpha_target_pos(16'd10000),.alpha_dot(20'sd0),
.k_theta(16'sd256),.k_theta_dot(16'sd0),.k_alpha(16'sd0),.k_alpha_dot(16'sd0),
.motor_dir(dir),.duty_out(duty),.calc_done_pulse(done),.saturated(sat),.theta_err_mon(err),.u_scaled_mon(u));
integer z,i,diff,expected_err,expected_u,mag,deadband,checks=0;
initial begin
#101 rst=1;deadband=`THETA_ERROR_DEADBAND;
for(z=0;z<3;z=z+1) begin
case(z) 0:zero=`DEFAULT_THETA_ZERO;1:zero=0;2:zero=4092;endcase
for(i=0;i<4096;i=i+1) begin
 @(negedge clk);theta=i;tick=1;
 @(negedge clk);tick=0;
 repeat(12) @(negedge clk);
 diff=i-zero;
 if(diff>2048)diff=diff-4096;
 if(diff< -2048)diff=diff+4096;
 expected_err=`THETA_DIR_INVERT ? -diff:diff;
 expected_u=(expected_err>=-deadband && expected_err<=deadband)?0:-expected_err;
 mag=expected_u<0?-expected_u:expected_u;
 if(mag>`MAX_PWM_DUTY_LIMIT)mag=`MAX_PWM_DUTY_LIMIT;
 if($signed(err)!==expected_err || $signed(u)!==expected_u || duty!==mag ||
    dir!==(expected_u>0?1:expected_u<0?2:0))
 $fatal(1,"ADC wrap zero=%0d theta=%0d err=%0d/%0d command=%0d/%0d duty=%0d/%0d",zero,theta,err,expected_err,u,expected_u,duty,mag);
 checks=checks+1;
end
end
enable=0;@(negedge clk);
if(dir!==0 || duty!==0 || u!==0) $fatal(1,"Disable failed to clear wrapped LQR pipeline");
$display("PASS: %0d ADC/zero combinations, direction, saturation, deadband and disable",checks);
$finish;
end
endmodule
