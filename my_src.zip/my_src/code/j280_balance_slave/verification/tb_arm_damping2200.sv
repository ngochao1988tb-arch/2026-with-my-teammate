`timescale 1ns/1ps
`include "system_params.vh"
module tb_arm_damping2200;
reg clk=0,rst=0,tick=0,enable=1;
always #10 clk=~clk;
reg [15:0] pos=10000;
reg signed [19:0] velocity=0;
wire signed [15:0] correction;
wire sat;
arm_position_pid #(.KP(`ARM_PID_KP),.KI(`ARM_PID_KI),.KD(`ARM_PID_KD),.OUTPUT_LIMIT(`ARM_PID_OUTPUT_LIMIT),.OUTPUT_INVERT(`ARM_PID_OUTPUT_INVERT)) dut
(.clk_50m(clk),.rst_n(rst),.tick_3ms(tick),.enable(enable),.position(pos),.target_position(16'd10000),.velocity_q4(velocity),.correction(correction),.saturated(sat));
integer e,v,p,d,want,checks=0;
task check;
 input integer error;
 input integer vel_q4;
 begin
 @(negedge clk);pos=10000+error;velocity=vel_q4;tick=1;
 @(negedge clk);tick=0;
 repeat(12)@(negedge clk);
 p=185*error/256;d=2200*vel_q4/4096;want=p+d;
 if(want>100)want=100;
 if(want< -100)want=-100;
 if($signed(correction)!==want || sat!==((p+d>100)||(p+d< -100)))
  $fatal(1,"Damping error=%0d vel_q4=%0d got=%0d expected=%0d",error,vel_q4,correction,want);
 checks=checks+1;
 end
endtask
initial begin
#101 rst=1;
if(`ARM_PID_KD!=2200 || `ARM_PID_KP!=185 || `ARM_PID_KI!=0) $fatal(1,"Wrong candidate gains");
for(e=-80;e<=80;e=e+5)for(v=-128;v<=128;v=v+8)check(e,v);
check(0,16);check(0,-16);check(0,1);check(0,-1);check(0,2048);check(0,-2048);
enable=0;@(negedge clk);
if(correction!==0 || sat!==0) $fatal(1,"Disable failed");
$display("PASS: %0d damping gain, Q4 scaling, symmetry, saturation and disable cases",checks);
$finish;
end
endmodule
