`timescale 1ns/1ps
`include "system_params.vh"
module tb_swingup_energy_100us;
    reg clk=0, rst_n=0, tick=0, enable=0;
    always #10 clk=~clk;
    reg [11:0] angle=2000;
    reg signed [15:0] velocity=0;
    wire [1:0] dir;
    wire [7:0] duty;
    wire done;
    wire signed [15:0] energy;
    integer i, boosts=0;
`ifdef SWINGUP_PWM255_TEST
    localparam EXPECT_KICK=241, EXPECT_BOOST=241, EXPECT_LIMIT=255;
`else
    localparam EXPECT_KICK=220, EXPECT_BOOST=230, EXPECT_LIMIT=230;
`endif
    swingup_energy_controller dut(clk,rst_n,tick,enable,angle,velocity,
        `SWINGUP_KICK_FRAMES,dir,duty,done,energy);
    // Accelerate idle clocks only. Each call represents one 100us frame;
    // arithmetic pipeline gets 12 clocks to finish before the next sample.
    task frame(input integer a, input integer v);
        begin
            @(negedge clk); angle=a; velocity=v; tick=1;
            @(negedge clk); tick=0;
            repeat(12) @(negedge clk);
            if(duty>EXPECT_LIMIT) $fatal(1,"Output exceeded swing-up duty limit");
        end
    endtask
    initial begin
        #101 rst_n=1; enable=1;
        for(i=0;i<900;i=i+1) begin
            frame(2000,0);
            if(dir!=1 || duty!=EXPECT_KICK || done) $fatal(1,"Kick duration/command changed at %0d",i);
        end
        frame(2000,0);
        if(!done || duty!=0) $fatal(1,"Kick did not end after exactly 900 frames");
        frame(2000,20);
        if(duty!=EXPECT_LIMIT || dir!=1)
            $fatal(1,"Between-peak energy drive did not use the configured ceiling");
        $display("PASS: between-peak energy drive uses duty ceiling %0d",EXPECT_LIMIT);
        frame(2000,0);
        for(i=1998;i>=1800;i=i-2) frame(i,-10);
        repeat(5) frame(1800,0);
        frame(1804,0);
        if(dir!=2 || duty!=EXPECT_BOOST) $fatal(1,"Peak did not reverse across zero-speed energy deadzone");
        boosts=1;
        repeat(269) begin
            frame(1804,0);
            if(dir!=2 || duty!=EXPECT_BOOST) $fatal(1,"Boost ended early");
            boosts=boosts+1;
        end
        frame(1804,0);
        if(duty!=0 || boosts!=270) $fatal(1,"Boost is not exactly 270 frames");
        $display("PASS: kick=900 frames (90ms), reversal=270 frames (27ms), zero-speed reversal and PWM limit");
        // Disable with a command in flight; no valid stage may restart drive.
        @(negedge clk); tick=1; velocity=10;
        @(negedge clk); tick=0; enable=0;
        repeat(20) @(negedge clk);
        if(dir!=0 || duty!=0 || done || dut.valid_pipe!=0 || dut.peak_pending)
            $fatal(1,"Disable failed to flush controller");
        enable=1; frame(2000,0);
        if(dir!=1 || duty!=EXPECT_KICK || done) $fatal(1,"Reenable did not restart clean kick");
        $display("PASS: disable flushes pending drive and reenable starts a fresh kick");
        $finish;
    end
    initial begin #10000000; $fatal(1,"Energy test timed out"); end
endmodule
