`timescale 1ns/1ps
`include "system_params.vh"
module tb_swingup_peak_100us;
    reg clk=0, rst_n=0, tick=0, enable=0;
    always #10 clk=~clk;
    reg [11:0] angle=2000;
    reg signed [15:0] velocity=0;
    wire peak;
    integer peaks=0, i, quantized_angle, analytic_velocity;
    real phase;
    swingup_peak_detector dut(clk,rst_n,tick,enable,angle,velocity,peak);
    task frame(input integer a, input integer v);
        begin
            @(negedge clk); angle=a; velocity=v; tick=1;
            @(negedge clk); tick=0;
            if(peak) peaks=peaks+1;
            @(negedge clk);
            if(peak) $fatal(1,"Peak is not a single-clock pulse");
        end
    endtask
    task restart;
        begin
            @(negedge clk); enable=0;
            repeat(2) @(negedge clk);
            enable=1; peaks=0;
        end
    endtask
    initial begin
        #101 rst_n=1; enable=1;
        frame(2000,0);
        for(i=1998;i>=1800;i=i-2) frame(i,-10);
        repeat(8) frame(1800,0);
        if(peaks!=0) $fatal(1,"Plateau triggered before angular departure");
        frame(1802,2);
        frame(1804,4);
        if(peaks!=1) $fatal(1,"Slow 2-count ascent missed: peaks=%0d",peaks);
        $display("PASS: 2-count/100us ascent and flat top produce one reversal after 4-count departure");
        repeat(20) begin frame(1800,-2); frame(1804,2); end
        if(peaks!=1) $fatal(1,"Cooldown allowed duplicate peaks");
        repeat(1200) frame(2000,0);
        for(i=1998;i>=1700;i=i-2) frame(i,10);
        frame(1704,-4);
        if(peaks!=2) $fatal(1,"Opposite-side second peak missed");
        $display("PASS: cooldown suppresses duplicates; opposite velocity sign still detects next peak");
        restart;
        repeat(1400) begin frame(1600,-2); frame(1604,2); end
        if(peaks!=0) $fatal(1,"Stationary jitter accumulated a false ascent");
        $display("PASS: repeated 4-count jitter cannot accumulate 64-count net ascent");
        restart; frame(2000,0);
        for(i=1998;i>=220;i=i-2) frame(i,-10);
        frame(224,4);
        if(peaks!=0) $fatal(1,"Capture exclusion failed");
        restart; frame(2048,0); frame(1984,-4); frame(1988,4);
        if(peaks!=0) $fatal(1,"Bottom exclusion failed");
        restart; frame(1900,0); frame(1800,-30); frame(1804,30);
        if(peaks!=0) $fatal(1,"Fast departure passed turn-speed limit");
        restart; frame(1900,0); frame(1840,-4); frame(1844,4);
        if(peaks!=0) $fatal(1,"Insufficient ascent triggered");
        $display("PASS: capture/bottom exclusions, speed limit and minimum net ascent");
        // A continuous synthetic half-swing sampled at 100us. Angle is
        // quantized to two counts, velocity is its analytic derivative in
        // counts/3ms. This exercises realistic sub-four-count motion.
        restart;
        for(i=0;i<=1400;i=i+1) begin
            phase=3.141592653589793*i/1000.0;
            quantized_angle=2*$rtoi((1650.0+350.0*$cos(phase))/2.0);
            analytic_velocity=$rtoi(-350.0*$sin(phase)*3.141592653589793*30.0/1000.0);
            frame(quantized_angle,analytic_velocity);
        end
        if(peaks!=1) $fatal(1,"Continuous 100us trajectory produced %0d peaks",peaks);
        $display("PASS: continuous quantized trajectory with derivative in counts/3ms produces one peak");
        $finish;
    end
    initial begin #10000000; $fatal(1,"Peak test timed out"); end
endmodule
