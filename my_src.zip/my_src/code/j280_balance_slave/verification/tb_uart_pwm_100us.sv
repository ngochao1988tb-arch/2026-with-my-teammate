`timescale 1ns/1ps
`include "system_params.vh"
module tb_uart_pwm_100us;
    reg clk=0, rst_n=0;
    always #10 clk=~clk;
    wire tx, adc_clk, oe, stby, pa, a1, a2, pb, b1, b2;
    j280_lqr_top dut (
        .clk_50m(clk), .rst_n(rst_n), .key_sw(4'hf), .uart_rx(1'b1), .uart_tx(tx),
        .adc_data_in(10'd59), .adc_clk(adc_clk), .adc_oe_n(oe), .adc_stby_n(stby),
        .PWMA(pa), .AN1(a1), .AN2(a2), .PWMB(pb), .BN1(b1), .BN2(b2),
        .enc1_a(1'b0), .enc1_b(1'b0), .enc2_a(1'b0), .enc2_b(1'b0)
    );
`ifndef LQR_ONLY_TEST
    reg ea=0, eb=0, enc_tick=0;
    wire [15:0] pos, sampled_pos, illegal;
    wire signed [15:0] velocity;
    wire signed [19:0] velocity_q4;
    encoder_quad #(.INIT_POS(10000),.FILTER_MODE(0)) enc (
        .clk_50m(clk), .rst_n(rst_n), .tick_3ms(enc_tick), .enc_a(ea), .enc_b(eb),
        .pos(pos), .sampled_pos(sampled_pos), .vel(velocity), .vel_q4(velocity_q4),
        .illegal_trans_cnt(illegal)
    );
    reg pid_tick=0;
    wire signed [15:0] correction;
    wire pid_sat;
    arm_position_pid #(.KP(120),.KI(3),.KD(8000),.INTEGRAL_LIMIT(13107),.OUTPUT_LIMIT(100)) pid (
        .clk_50m(clk), .rst_n(rst_n), .tick_3ms(pid_tick), .enable(1'b1),
        .position(16'd10010), .target_position(16'd10000), .velocity_q4(20'sd0),
        .correction(correction), .saturated(pid_sat)
    );
`endif
    integer clock_count=0, last_report=0, reports=0;
    integer last_control=0, controls=0, last_sequence=0;
    reg check_control_cadence=1;
    always @(posedge clk) begin
        clock_count=clock_count+1;
        #1;
        if (rst_n && dut.control_tick && check_control_cadence) begin
            if (controls!=0 && clock_count-last_control!=5000)
                $fatal(1,"Control interval is not 100us");
            last_control=clock_count; controls=controls+1;
        end
        if (rst_n && dut.report_tick) begin
            if (dut.u_telemetry.tx_busy)
                $fatal(1,"UART still busy at the next scheduled report");
            if (reports!=0 && dut.frame_number-last_sequence!=30)
                $fatal(1,"Telemetry frame stride is not 30");
            last_sequence=dut.frame_number;
            if (reports!=0 && clock_count-last_report!=150000)
                $fatal(1,"Telemetry interval is not 3ms");
            last_report=clock_count; reports=reports+1;
        end
    end
    reg [11:0] injected_angle=236;
    integer previous_request=0, current_request=0, magnitude, expected_applied, checked=0;
    always @(posedge clk) begin
        if (rst_n && dut.control_tick) begin
            #250;
            current_request=dut.requested_pwm;
        end
        if (rst_n && dut.report_tick) begin
            magnitude=current_request<0 ? -current_request : current_request;
            expected_applied=(magnitude<=`PWM_DEADZONE_THRESH) ? 0 :
                magnitude-`PWM_DEADZONE_THRESH +
                ((current_request<0 ? `PWM_DEADBAND_NEG : `PWM_DEADBAND_POS) *
                 ((magnitude-`PWM_DEADZONE_THRESH>=`PWM_COMP_RAMP_COUNTS) ? `PWM_COMP_RAMP_COUNTS : magnitude-`PWM_DEADZONE_THRESH))/(1<<`PWM_COMP_RAMP_SHIFT);
            if (expected_applied>`MAX_PWM_DUTY_LIMIT) expected_applied=`MAX_PWM_DUTY_LIMIT;
            if(current_request<0) expected_applied=-expected_applied;
            if (dut.applied_pwm!=expected_applied)
                $fatal(1,"UART/PWM frame alignment failed: request=%0d applied=%0d expected=%0d",current_request,dut.applied_pwm,expected_applied);
            checked=checked+1;
        end
    end
    integer i;
    initial begin
        #101 rst_n=1;
        force dut.calibration_valid=1;
        force dut.calibration_pending=0;
        force dut.calibrated_zero=236;
        force dut.fsm_state=2;
        force dut.frame_theta_dot=0;
        force dut.frame_theta=injected_angle;
        for (i=0;i<96;i=i+1) begin
            @(posedge dut.control_tick);
            // Every real ADC frame gets a different nonzero controller command.
            @(negedge clk); injected_angle=(i%2) ? 206 : 266;
        end
        wait(checked>=4);
        if(current_request==0) $fatal(1,"No nonzero command was tested");
        $display("PASS: changing signed commands, 10kHz PWM latching and same-frame UART snapshots (%0d reports)",checked);
        $finish;
    end
    initial begin #15000000; $fatal(1,"UART/PWM alignment timed out"); end
endmodule
