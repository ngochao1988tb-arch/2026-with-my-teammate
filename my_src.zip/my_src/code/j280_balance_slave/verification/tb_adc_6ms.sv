`timescale 1ns / 1ps

// Exercise the real ADC latch, sampler, sorting and frame-difference path.
module tb_adc_6ms;
    reg clk = 0;
    always #10 clk = ~clk;
    reg rst_n = 0;
    reg [9:0] adc_data = 58;
    reg [9:0] base_count = 58;
    reg split_samples = 1;
    wire valid;
    wire [11:0] theta;
    wire signed [15:0] delta;
    wire adc_clk, oe_n, stby_n;
    adc_3pa1030_sync dut (
        .clk_50m(clk), .rst_n(rst_n), .adc_clk(adc_clk),
        .adc_oe_n(oe_n), .adc_stby_n(stby_n), .adc_data_in(adc_data),
        .adc_valid_3ms(valid), .theta_raw_12b(theta), .theta_dot_raw(delta)
    );

    // Eight low and eight high samples make an odd sum of middle values.
    always @(negedge clk)
        adc_data = base_count + ((split_samples && dut.sample_index >= 8) ? 10'd1 : 10'd0);

    integer ticks = 0;
    integer last_frame_tick = 0;
    integer valid_frames = 0;
    always @(posedge clk) begin
        ticks = ticks + 1;
        #1;
        if (!rst_n) begin
            valid_frames = 0;
            last_frame_tick = 0;
        end else if (valid) begin
            if (valid_frames != 0 && ticks - last_frame_tick != 300000)
                $fatal(1, "Control frame period changed: %0d", ticks - last_frame_tick);
            last_frame_tick = ticks;
            valid_frames = valid_frames + 1;
        end
    end

    task check_frame;
        input [11:0] expected_theta;
        input signed [15:0] expected_delta;
        begin
            @(posedge valid);
            #2;
            if (theta !== expected_theta || delta !== expected_delta)
                $fatal(1, "theta=%0d delta=%0d; expected %0d %0d",
                       theta, delta, expected_theta, expected_delta);
        end
    endtask

    initial begin
        #101 rst_n = 1;
        // Initialization frame must not publish a false velocity.
        wait(dut.first_frame_done);
        #2;
        if (valid || theta !== 12'd234 || delta !== 16'sd0)
            $fatal(1, "Bad first-frame initialization");
        check_frame(234, 0); // median(58,59) = 58.5, in original x4 units
        base_count = 59;
        check_frame(238, 2); // median(59,60) = 59.5
        split_samples = 0;
        check_frame(236, -1); // integer median unchanged; negative half-step
        check_frame(236, 0); // no stale derivative after settling
        base_count = 60;
        check_frame(240, 2);

        // Approach extremes through accepted samples; the existing anti-glitch
        // guard deliberately rejects a large jump directly into either rail.
        base_count = 950;
        check_frame(3800, -268); // existing 4096-count velocity wrapping
        base_count = 1023;
        check_frame(4092, 146);
        check_frame(4092, 0);
        base_count = 50;
        check_frame(200, 102);
        base_count = 0;
        check_frame(0, -100);
        check_frame(0, 0);
        $display("PASS: half-count median, integer scale, signed velocity, bounds, initialization and 6ms cadence and 3ms-normalized velocity");
        $finish;
    end
    initial begin
        #120000000;
        $fatal(1, "ADC verification timed out");
    end
endmodule
