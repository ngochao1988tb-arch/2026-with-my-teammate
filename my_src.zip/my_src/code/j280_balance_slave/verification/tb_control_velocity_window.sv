`timescale 1ns/1ps
module tb_control_velocity_window;
    reg clk=0,rst_n=0,clear=0,tick=0;
    always #10 clk=~clk;
    reg [11:0] theta=236;
    reg [15:0] alpha=10000;
    wire signed [15:0] tv;
    wire signed [19:0] av;
    wire valid;
    control_velocity_window dut(.clk_50m(clk),.rst_n(rst_n),.clear_window(clear),.sample_tick(tick),
        .theta_position(theta),.alpha_position(alpha),.theta_velocity(tv),.alpha_velocity_q4(av),.velocity_valid(valid));
    integer i,n=0,delta,adelta;
    integer th[0:999],al[0:999];
    task sample;
        input [11:0] t;
        input [15:0] a;
        begin
            @(negedge clk); theta=t;alpha=a;tick=1;
            @(negedge clk); tick=0;
            @(posedge clk); #1;
            th[n]=t;al[n]=a;
            if(n<30) begin
                if(valid || tv!=0 || av!=0) $fatal(1,"Window published velocity before 30 intervals");
            end else begin
                delta=th[n]-th[n-30];
                if(delta>2048)delta=delta-4096;
                if(delta< -2048)delta=delta+4096;
                adelta=al[n]-al[n-30];
                if(adelta>32767)adelta=adelta-65536;
                if(adelta< -32768)adelta=adelta+65536;
                if(!valid || tv!=delta || av!=adelta*16)
                    $fatal(1,"Window mismatch n=%0d theta=%0d expected=%0d alpha=%0d expected=%0d",n,tv,delta,av,adelta*16);
            end
            n=n+1;
            repeat(2) @(posedge clk);
        end
    endtask
    task reset_window;
        begin
            @(negedge clk); clear=1;
            @(posedge clk);#1;
            if(valid || tv || av) $fatal(1,"Clear failed to flush velocities");
            @(negedge clk); clear=0;n=0;
        end
    endtask
    initial begin
        #101 rst_n=1;
        for(i=0;i<100;i=i+1)sample(236+2*i,10000+i);
        if(tv!=60 || av!=480) $fatal(1,"Uniform motion normalization failed");
        reset_window;
        for(i=0;i<100;i=i+1)sample(436-2*i,10100-i);
        if(tv!=-60 || av!=-480) $fatal(1,"Negative uniform motion failed");
        reset_window;
        for(i=0;i<100;i=i+1)sample(236+2*(i%2),10000);
        if(tv!=0 || av!=0) $fatal(1,"Alternating quantization was amplified");
        reset_window;
        for(i=0;i<60;i=i+1)sample(4092,65535);
        sample(0,0);
        if(tv!=4 || av!=16) $fatal(1,"Theta/encoder forward wrap failed");
        for(i=0;i<29;i=i+1)sample(0,0);
        if(tv!=4 || av!=16) $fatal(1,"Step did not occupy exactly 30 updates");
        sample(0,0);
        if(tv!=0 || av!=0) $fatal(1,"Step velocity did not expire at 3ms");
        for(i=0;i<40;i=i+1)sample(0,0);
        sample(4092,65535);
        if(tv!=-4 || av!=-16) $fatal(1,"Reverse wrap failed");
        reset_window;
        for(i=0;i<100;i=i+1)sample(234+2*((i*17+3)%3),10000+((i*7)%3));
        $display("PASS: 30-interval warmup, continuous rolling updates, signed normalization, quantization, step expiration, both wraps and clear");
        $finish;
    end
    initial begin #200000; $fatal(1,"Velocity window test timed out"); end
endmodule
