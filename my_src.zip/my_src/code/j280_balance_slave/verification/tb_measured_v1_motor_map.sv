`timescale 1ns/1ps
`include "system_params.vh"
module tb_measured_v1_motor_map;
reg clk=0,rst=0,safe=1;
always #10 clk=~clk;
reg [1:0] dir=0;
reg [7:0] duty=0;
reg [12:0] phase=0;
wire a,b,pwm;
wire signed [15:0] applied;
motor_tb6612 dut(.clk_50m(clk),.rst_n(rst),.safe_enable(safe),.motor_dir(dir),.duty_in(duty),
.deadband_pos(`PWM_DEADBAND_POS),.deadband_neg(`PWM_DEADBAND_NEG),.deadzone_thresh(`PWM_DEADZONE_THRESH),
.swingup_mode(1'b0),.in1(a),.in2(b),.pwm(pwm),.applied_pwm(applied));
integer i,j,e,r,c,want,cmp,checks=0;
initial begin
force dut.pwm_cnt=phase;
#101 rst=1;
if(`PWM_DEADBAND_POS!=12 || `PWM_DEADBAND_NEG!=13 || `DEFAULT_THETA_ZERO!=240 || `DEFAULT_THETA_DOWNWARD!=2336 || `MOTOR_IDENT_ENABLE || !`CLOSED_LOOP_ENABLE)
 $fatal(1,"Unexpected measured-v1 project configuration");
for(j=0;j<4;j=j+1)for(i=0;i<256;i=i+1)begin
 @(negedge clk);phase=0;dir=j;duty=i;
 repeat(12)@(negedge clk);
 phase=`PWM_CARRIER_PERIOD-1;
 @(negedge clk);phase=0;
 e=i>1?i-1:0;r=e<4?e:4;c=j==1?12:13;
 want=e+c*r/4;
 if(want>230)want=230;
 if(j==0 || j==3)want=0;
 cmp=want*`PWM_CARRIER_PERIOD/256;
 if(j==2)want=-want;
 if($signed(applied)!==want || dut.active_cmp!==cmp)
  $fatal(1,"Mapping dir=%0d request=%0d got=%0d want=%0d",j,i,applied,want);
 if(i==5 && j==1 && applied!==16) $fatal(1,"Positive full-ramp target mismatch");
 if(i==5 && j==2 && applied!==-17) $fatal(1,"Negative full-ramp target mismatch");
 checks=checks+1;
end
safe=0;@(negedge clk);
if({a,b,pwm}!==0 || applied!==0) $fatal(1,"Motor stop failed");
$display("PASS: %0d project-configured PWM mappings; full-ramp +16/-17 and immediate stop",checks);
$finish;
end
endmodule
