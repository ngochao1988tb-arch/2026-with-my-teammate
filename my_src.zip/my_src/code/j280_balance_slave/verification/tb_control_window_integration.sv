`timescale 1ns/1ps
`include "system_params.vh"
module tb_control_window_integration;
    reg clk=0, rst_n=0;
    always #10 clk=~clk;
    wire tx, adc_clk, oe, stby, pa, a1, a2, pb, b1, b2;
    j280_lqr_top dut (
        .clk_50m(clk), .rst_n(rst_n), .key_sw(4'hf), .uart_rx(1'b1), .uart_tx(tx),
        .adc_data_in(adc_input), .adc_clk(adc_clk), .adc_oe_n(oe), .adc_stby_n(stby),
        .PWMA(pa), .AN1(a1), .AN2(a2), .PWMB(pb), .BN1(b1), .BN2(b2),
        .enc1_a(1'b0), .enc1_b(1'b0), .enc2_a(1'b0), .enc2_b(1'b0)
    );
    reg [9:0] adc_input=59;
    reg [15:0] encoder_position=10000;
    initial begin
        force dut.calibration_valid=1;
        force dut.calibration_pending=0;
        force dut.fsm_state=2;
        force dut.u_encoder_1.pos=encoder_position;
        #101 rst_n=1;
        wait(dut.control_velocity_valid);
        repeat(2) @(posedge dut.control_tick);
        @(negedge clk); adc_input=60; encoder_position=10001;
        repeat(2) @(posedge dut.control_tick); #300;
        if(dut.frame_theta_dot!=4 || dut.control_alpha_velocity_q4!=16 ||
           dut.u_lqr.s0_theta_dot!=-4 || dut.u_lqr.s0_alpha_dot!=16 ||
           dut.u_arm_position_pid.velocity_q4!=16)
            $fatal(1,"Controller input alignment or 3ms units failed theta=%0d alpha=%0d LQR=%0d/%0d",dut.frame_theta_dot,dut.control_alpha_velocity_q4,dut.u_lqr.s0_theta_dot,dut.u_lqr.s0_alpha_dot);
        if(dut.combined_saturated || dut.sample_timeout)
            $fatal(1,"Single position count still caused saturation or sample fault");
        $display("PASS: real ADC/encoder step reaches LQR and PID as theta=4 alpha_Q4=16 without saturation");
        repeat(32) @(posedge dut.control_tick); #300;
        if(dut.frame_theta_dot!=0 || dut.control_alpha_velocity_q4!=0 ||
           dut.u_lqr.s0_theta_dot!=0 || dut.u_lqr.s0_alpha_dot!=0)
            $fatal(1,"Controller step velocities did not expire after 3ms");
        $display("PASS: window velocities and LQR inputs settle to zero with static position");
        $finish;
    end
    initial begin #15000000; $fatal(1,"Controller window integration timed out"); end
endmodule
