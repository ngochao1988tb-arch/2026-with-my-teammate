`timescale 1ns/1ps
`include "system_params.vh"
module tb_control_100us;
    reg clk=0, rst_n=0;
    always #10 clk=~clk;
    wire tx, adc_clk, oe, stby, pa, a1, a2, pb, b1, b2;
    j280_lqr_top dut (
        .clk_50m(clk), .rst_n(rst_n), .key_sw(4'hf), .uart_rx(1'b1), .uart_tx(tx),
        .adc_data_in(10'd59), .adc_clk(adc_clk), .adc_oe_n(oe), .adc_stby_n(stby),
        .PWMA(pa), .AN1(a1), .AN2(a2), .PWMB(pb), .BN1(b1), .BN2(b2),
        .enc1_a(1'b0), .enc1_b(1'b0), .enc2_a(1'b0), .enc2_b(1'b0)
    );
    reg ea=0, eb=0, enc_tick=0;
    wire [15:0] pos, sampled_pos, illegal;
    wire signed [15:0] velocity;
    wire signed [19:0] velocity_q4;
    encoder_quad #(.INIT_POS(10000),.FILTER_MODE(0)) enc (
        .clk_50m(clk), .rst_n(rst_n), .tick_3ms(enc_tick), .enc_a(ea), .enc_b(eb),
        .pos(pos), .sampled_pos(sampled_pos), .vel(velocity), .vel_q4(velocity_q4),
        .illegal_trans_cnt(illegal)
    );
    reg pid_tick=0;
    wire signed [15:0] correction;
    wire pid_sat;
    arm_position_pid #(.KP(120),.KI(3),.KD(8000),.INTEGRAL_LIMIT(13107),.OUTPUT_LIMIT(100)) pid (
        .clk_50m(clk), .rst_n(rst_n), .tick_3ms(pid_tick), .enable(1'b1),
        .position(16'd10010), .target_position(16'd10000), .velocity_q4(20'sd0),
        .correction(correction), .saturated(pid_sat)
    );
    integer clock_count=0, last_report=0, reports=0;
    integer last_control=0, controls=0, last_sequence=0;
    reg check_control_cadence=1;
    always @(posedge clk) begin
        clock_count=clock_count+1;
        #1;
        if (rst_n && dut.control_tick && check_control_cadence) begin
            if (controls!=0 && clock_count-last_control!=5000)
                $fatal(1,"Control interval is not 100us");
            last_control=clock_count; controls=controls+1;
        end
        if (rst_n && dut.report_tick) begin
            if (dut.u_telemetry.tx_busy)
                $fatal(1,"UART still busy at the next scheduled report");
            if (reports!=0 && dut.frame_number-last_sequence!=30)
                $fatal(1,"Telemetry frame stride is not 30");
            last_sequence=dut.frame_number;
            if (reports!=0 && clock_count-last_report!=150000)
                $fatal(1,"Telemetry interval is not 3ms");
            last_report=clock_count; reports=reports+1;
        end
    end
    reg manual_tick=0;
    integer i;
    reg signed [31:0] integral_seed;
    reg [11:0] integral_angle;
    task integral_case;
        input signed [31:0] seed;
        input signed [15:0] angle_error;
        input signed [31:0] expected_accum;
        input signed [15:0] expected_correction;
        input expected_sat;
        begin
            @(negedge clk); integral_seed=seed; integral_angle=236-angle_error;
            force dut.theta_i_accum=integral_seed;
            force dut.frame_theta=integral_angle;
            #1; release dut.theta_i_accum;
            manual_tick=1;
            @(posedge clk); #1;
            if (dut.theta_i_accum!=expected_accum || dut.theta_i_saturated!=expected_sat)
                $fatal(1,"Integral feedback mismatch seed=%0d error=%0d accum=%0d sat=%0d",seed,angle_error,dut.theta_i_accum,dut.theta_i_saturated);
            @(negedge clk); manual_tick=0;
            repeat(4) @(posedge clk); #1;
            if (dut.theta_i_correction!=expected_correction)
                $fatal(1,"Integral pipeline mismatch: got %0d expected %0d",dut.theta_i_correction,expected_correction);
        end
    endtask
    initial begin
        #101 rst_n=1;
        force dut.calibration_valid=1;
        force dut.calibration_pending=0;
        force dut.calibrated_zero=236;
        force dut.fsm_state=2;
        // Real ADC/control/telemetry cadence, not a synthetic tick generator.
        wait(reports==3);
        #2;
        if (dut.sample_timeout || dut.frame_theta!=236 || dut.cur_theta_dot!=0)
            $fatal(1,"Real ADC/control integration failed");
        // Real quadrature decoder: 2 counts per 100us = 60 counts/3ms.
        @(negedge clk); ea=1;
        repeat(20) @(negedge clk); eb=1;
        repeat(20) @(negedge clk); enc_tick=1;
        @(posedge clk);
        @(negedge clk); enc_tick=0;
        repeat(2) @(posedge clk); #1;
        if (sampled_pos!=10002 || velocity_q4!=960 || velocity!=60 || illegal!=0)
            $fatal(1,"Encoder velocity normalization failed");
        @(negedge clk); enc_tick=0; eb=0;
        repeat(20) @(negedge clk); ea=0;
        repeat(20) @(negedge clk); enc_tick=1;
        @(posedge clk);
        @(negedge clk); enc_tick=0;
        repeat(2) @(posedge clk); #1;
        if (sampled_pos!=10000 || velocity_q4!=-960 || velocity!=-60)
            $fatal(1,"Negative encoder normalization failed");
        @(negedge clk); enc_tick=0; pid_tick=1;
        @(negedge clk); pid_tick=0;
        repeat(8) @(posedge clk); #1;
        if (pid.integral_accum!=10 || correction!=4)
            $fatal(1,"Arm integral elapsed-time scaling failed");
        // Preserve 150-count target slew in 13500 x 100us frames (~1.35s).
        check_control_cadence=0;
        force dut.control_tick=manual_tick;
        force dut.position_target_alpha=10150;
        for (i=1;i<=13500;i=i+1) begin
            @(negedge clk); manual_tick=1;
            @(posedge clk); #1;
            if (dut.target_alpha!=10000+i/90)
                $fatal(1,"Target slew mismatch at frame %0d: %0d",i,dut.target_alpha);
            @(negedge clk); manual_tick=0;
            repeat(8) @(posedge clk);
        end
        force dut.frame_theta=216; // 20-count angle error outside deadband
        @(negedge clk); manual_tick=1;
        @(posedge clk); #1;
        if (dut.theta_i_accum!=20) $fatal(1,"Theta integral elapsed-time scaling failed");
        @(negedge clk); manual_tick=0;
        @(negedge clk); manual_tick=0;
        repeat(3) @(posedge clk);
        integral_case(180000,20,180020,-23,0);
        integral_case(-180000,-20,-180020,23,0);
        integral_case(191990,20,191990,-24,1);
        integral_case(-191990,-20,-191990,24,1);
        integral_case(192010,-20,191990,-24,0);
        integral_case(-192010,20,-191990,24,0);
        integral_case(1474560,-20,1474540,-24,1);
        integral_case(-1474560,20,-1474540,24,1);
        // Sampling watchdog keeps three new frame periods and cuts the motor.
        force dut.sample_age=14999; #1;
        if (dut.sample_timeout) $fatal(1,"Watchdog too early");
        force dut.sample_age=15000; #1;
        if (!dut.sample_timeout || dut.motor_safe_enable) $fatal(1,"Watchdog failed to gate motor");
        @(posedge clk); #1;
        if (pa || a1 || a2) $fatal(1,"Motor not cut off");
        if (`SWINGUP_KICK_FRAMES!=900 || `SATURATION_TIMEOUT_CYCLES!=3000)
            $fatal(1,"Real-time duration compensation failed");
        // Run past the former 12-bit counter range and verify the ~8s timeout.
        force dut.sample_age=0;
        force dut.frame_theta=2236; // downward window; never satisfy upright catch
        force dut.fsm_state=5;
        @(negedge clk); release dut.fsm_state;
        for (i=1;i<=80010;i=i+1) begin
            @(negedge clk); manual_tick=1;
            @(posedge clk); #1;
            if (i<80010 && dut.fsm_state!=5) $fatal(1,"Swing-up timeout too early at %0d",i);
            @(negedge clk); manual_tick=0;
            repeat(8) @(posedge clk);
        end
        if (dut.fsm_state!=4 || dut.fault_cause!=7)
            $fatal(1,"Swing-up counter wrapped or missed the 80010-frame timeout");
        $display("PASS: 100us control / 3ms UART, encoder scale, 1/30-frame integrals, target slew, watchdog and 80010-frame swing-up timeout");
        $finish;
    end
    initial begin
        #50000000;
        $fatal(1,"100us integration timed out");
    end
endmodule
