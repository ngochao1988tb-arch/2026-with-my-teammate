`timescale 1ns/1ps
module tb_kalman;
    reg clk=0, rst=0, clear=0, tick=0;
    always #10 clk=~clk;
    reg [11:0] theta;
    reg [15:0] alpha;
    wire signed [15:0] tv;
    wire signed [19:0] av;
    wire valid;
    control_kalman_velocity dut(clk,rst,clear,tick,theta,alpha,tv,av,valid);
    integer file_id, result, t, a, c, expected_t, expected_a, count=0;
    initial begin
        repeat(5) @(negedge clk); rst=1;
        file_id=$fopen("verification/kalman_vectors.txt","r");
        if(!file_id) $fatal(1,"Missing reference vectors");
        while(!$feof(file_id)) begin
            result=$fscanf(file_id,"%d %d %d %d %d\n",t,a,c,expected_t,expected_a);
            if(result==5) begin
                @(negedge clk); clear=c;
                @(negedge clk); clear=0; theta=t; alpha=a; tick=1;
                @(negedge clk); tick=0;
                repeat(8) @(negedge clk);
                if(tv!==expected_t || av!==expected_a)
                    $fatal(1,"Vector %0d: got %0d/%0d expected %0d/%0d",count,tv,av,expected_t,expected_a);
                if(c && valid) $fatal(1,"Clear did not invalidate initial frame");
                if(!c && !valid) $fatal(1,"Missing valid estimate");
                count=count+1;
                repeat(4990) @(negedge clk);
            end
        end
        // Cancel an update in flight; no stale result may become valid.
        @(negedge clk); tick=1;
        @(negedge clk); tick=0;
        @(negedge clk); clear=1;
        @(negedge clk); clear=0;
        repeat(8) @(negedge clk);
        if(valid || tv || av) $fatal(1,"In-flight clear failed");
        $display("PASS: %0d Kalman vectors and in-flight clear",count);
        $finish;
    end
endmodule
