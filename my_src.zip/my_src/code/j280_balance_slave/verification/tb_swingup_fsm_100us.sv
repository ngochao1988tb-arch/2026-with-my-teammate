`timescale 1ns/1ps
`include "system_params.vh"
module tb_swingup_fsm_100us;
    reg clk=0, rst_n=0;
    always #10 clk=~clk;
    reg [9:0] adc_input=559;
    reg [3:0] keys=0, pulses=0;
    wire pa,a1,a2;
    integer i, lqr_results=0, entry_results;
    always @(posedge clk) if(dut.lqr_calc_done) lqr_results=lqr_results+1;
    j280_lqr_top dut(.clk_50m(clk),.rst_n(rst_n),.key_sw(4'hf),
        .uart_rx(1'b1),.adc_data_in(adc_input),.PWMA(pa),.AN1(a1),.AN2(a2),
        .enc1_a(1'b0),.enc1_b(1'b0),.enc2_a(1'b0),.enc2_b(1'b0));
    task frames(input integer n);
        begin repeat(n) @(posedge dut.control_tick); @(negedge clk); end
    endtask
    task pulse(input reg [3:0] p);
        begin @(negedge clk); pulses=p; @(negedge clk); pulses=0; end
    endtask
    task fresh(input integer a);
        begin
            @(negedge clk); rst_n=0; keys=0; pulses=0; adc_input=a;
            repeat(5) @(negedge clk); rst_n=1;
            frames(3); pulse(1);
            wait(dut.calibration_valid); frames(2);
            if(dut.fsm_state!=1 || dut.calibrated_zero!=236)
                $fatal(1,"Calibration did not enter idle with original zero");
        end
    endtask
    task start;
        begin
            @(negedge clk); keys=6;
            repeat(5) @(negedge clk);
            if(dut.fsm_state!=5 || !dut.swingup_ctrl_enable) $fatal(1,"Real FSM failed to start");
            keys=0; frames(3);
            if(dut.swingup_duty!=220 || dut.applied_pwm!=230)
                $fatal(1,"Kick or current motor mapping incorrect: %0d/%0d",dut.swingup_duty,dut.applied_pwm);
        end
    endtask
    task stopped(input integer fault);
        begin
            repeat(4) @(negedge clk);
            if(dut.fsm_state!=4 || dut.fault_cause!=fault || dut.motor_safe_enable ||
               dut.applied_pwm!=0 || pa || a1 || a2)
                $fatal(1,"Fault %0d failed: state=%0d cause=%0d",fault,dut.fsm_state,dut.fault_cause);
            // Keep checking even when the sample clock has stopped.
            keys=6; repeat(15000) @(negedge clk);
            if(dut.fsm_state!=4) $fatal(1,"Latched fault restarted by trigger");
            keys=0;
        end
    endtask
    initial begin
        force dut.key_state=keys;
        force dut.key_pulse=pulses;
        fresh(266); // raw=1064, upright distance=828: legacy DOWNWARD is not a start point.
        if(dut.swingup_start_condition) $fatal(1,"Legacy downward macro incorrectly mapped into start window");
        keys=6; repeat(5) @(negedge clk);
        keys=2; repeat(5) @(negedge clk);
        if(!dut.swingup_trigger_lockout || dut.jog_request || dut.fsm_state!=1 || dut.motor_safe_enable)
            $fatal(1,"Partial two-key release unexpectedly enables jog");
        keys=0; repeat(5) @(negedge clk);
        if(dut.swingup_trigger_lockout) $fatal(1,"Both-key release did not rearm");
        $display("PASS: invalid start is consumed until both keys release; raw 1064 stays outside start window");
        fresh(559); // raw=2236, upright distance=2000; real ADC median + startup windows.
        if(!dut.swingup_start_condition || dut.fsm_state!=1) $fatal(1,"Hanging/start window mismatch");
`ifdef SWING_TEST_ENABLED
        start;
        @(negedge clk); adc_input=59;
        wait(dut.fsm_state==2); entry_results=lqr_results; @(negedge clk);
        if(dut.target_alpha!=dut.enc1_sampled_pos || dut.position_target_alpha!=dut.enc1_sampled_pos ||
           dut.swingup_ctrl_enable || !dut.lqr_ctrl_enable)
            $fatal(1,"Handoff did not select LQR and capture current arm target");
        // Entry tick must launch LQR immediately without waiting 100us.
        repeat(30) @(negedge clk);
        if(!dut.u_lqr.ctrl_enable || dut.swingup_duty!=0 || lqr_results<=entry_results)
            $fatal(1,"Handoff left swing command active or missed immediate LQR calculation");
        frames(2);
        $display("INFO: two frames after artificial 2000-count position jump: theta_dot=%0d PWM=%0d",dut.frame_theta_dot,dut.applied_pwm);
        // The artificial instantaneous ADC jump leaves a Kalman transient.
        // Retain damping during this transient; allow the observer to settle.
        frames(100);
        if(dut.fsm_state!=2 || dut.applied_pwm!=0) $fatal(1,"Steady upright handoff PWM not cleared");
        $display("PASS: SW1 -> SW2+SW3 -> SWINGUP -> real ADC upright -> BALANCE, target capture and PWM change");
        fresh(559); start; pulse(8); stopped(4);
        $display("PASS: SW4 cuts drive and blocks retrigger");
        fresh(559); start;
        force dut.enc1_sampled_pos=16'd12151;
        stopped(1); release dut.enc1_sampled_pos;
        $display("PASS: swing-up travel protection cuts drive and latches");
        fresh(559); start;
        force dut.enc1_vel=16'sd501;
        stopped(2); release dut.enc1_vel;
        $display("PASS: swing-up overspeed protection cuts drive and latches");
        fresh(559); start;
        force dut.tick_3ms=0;
        wait(dut.sample_timeout); stopped(6); release dut.tick_3ms;
        $display("PASS: sampling watchdog cuts swing-up drive and latches");
        fresh(559); start;
        // Accelerate only the timeout counter; never force the FSM state.
        force dut.swingup_elapsed=17'd80009;
        frames(1); release dut.swingup_elapsed; stopped(7);
        pulse(1); wait(dut.calibration_valid);
        if(dut.fsm_state!=1 || dut.fault_cause!=0) $fatal(1,"SW1 did not rearm after timeout");
        start;
        $display("PASS: timeout boundary latches fault 7; SW1 recalibration permits a fresh swing-up");
        fresh(559); start;
        // Keep capture pending until a stable real ADC input has reached the
        // catch window, then exercise coincident capture + timeout pulses.
        force dut.startup_tick=0;
        adc_input=59; frames(100);
        if(!dut.swingup_catch_condition) $fatal(1,"Boundary test never reached catch window");
        force dut.swingup_elapsed=17'd80009;
        force dut.control_tick=1;
        force dut.startup_tick=1;
        @(negedge clk);
        release dut.control_tick; release dut.startup_tick; release dut.swingup_elapsed;
        stopped(7);
        $display("PASS: coincident timeout and eligible capture select timeout fault, never drive BALANCE");
`else
        keys=6; frames(4);
        if(dut.fsm_state!=1 || dut.swingup_ctrl_enable || dut.motor_safe_enable || dut.applied_pwm)
            $fatal(1,"Production swing-up flags are no longer disabled");
        $display("PASS: production manual and automatic swing-up remain disabled");
`endif
        $finish;
    end
    initial begin #250000000; $fatal(1,"FSM test timed out"); end
endmodule
