`timescale 1ns/1ps
module tb_motor_ident_profile;
reg clk=0,rst=0,request=0;
reg [1:0] dir=1;
wire [7:0] duty;
always #10 clk=~clk;
motor_ident_profile #(.PULSE_TICKS(3),.GAP_TICKS(5)) dut(clk,rst,request,dir,duty);
integer i,j;
integer values[0:6];
initial begin
values[0]=8;values[1]=12;values[2]=16;values[3]=24;values[4]=32;values[5]=48;values[6]=64;
#21 rst=1;
@(negedge clk);request=1;dir=2;
@(negedge clk);
for(i=0;i<7;i=i+1) begin
for(j=0;j<8;j=j+1) begin
if(duty!==(j<5?0:values[i])) $fatal(1,"step=%0d tick=%0d duty=%0d",i,j,duty);
@(negedge clk);
end
end
repeat(15) begin if(duty!==0) $fatal(1,"Repeated after completion"); @(negedge clk); end
request=0;#1;if(duty!==0) $fatal(1,"Release did not stop");
@(negedge clk);request=1;
repeat(7) @(negedge clk);
if(duty!==8) $fatal(1,"Rearm failed");
dir=1;#1;if(duty!==0) $fatal(1,"Direction change retained pulse");
@(negedge clk);
if(duty!==0) $fatal(1,"No settling after direction change");
repeat(5) @(negedge clk);
if(duty!==8) $fatal(1,"Reverse restart failed");
request=0;#1;if(duty!==0) $fatal(1,"Release during pulse failed");
$display("PASS: pulse lengths, gaps, staircase values, completion latch, release and direction change");
$finish;
end
endmodule
