`timescale 1ns/1ps
module tb_theta_p_transition;
    reg clk = 0, rst_n = 0, tick = 0, enable = 1, flush = 0;
    reg [11:0] theta_raw = 2048;
    reg signed [15:0] theta_dot = 0;
    reg [15:0] alpha_pos = 10000;
    reg signed [19:0] alpha_dot = 0;
    reg signed [15:0] k_theta = 300, k_theta_dot = 1700, k_alpha = -5, k_alpha_dot = -2500;
    wire [1:0] dir;
    wire [7:0] duty;
    wire done, sat;
    wire signed [15:0] theta_mon, alpha_mon, u;
    always #10 clk = ~clk;
    lqr_controller dut (
        .clk_50m(clk), .rst_n(rst_n), .tick_3ms(tick),
        .ctrl_enable(enable), .flush_pipeline(flush),
        .calibrated_zero_val(16'd2048), .theta_raw(theta_raw), .theta_dot(theta_dot),
        .alpha_pos(alpha_pos), .alpha_target_pos(16'd10000), .alpha_dot(alpha_dot),
        .k_theta(k_theta), .k_theta_dot(k_theta_dot), .k_alpha(k_alpha), .k_alpha_dot(k_alpha_dot),
        .motor_dir(dir), .duty_out(duty), .calc_done_pulse(done), .saturated(sat),
        .theta_err_mon(theta_mon), .alpha_err_mon(alpha_mon), .u_scaled_mon(u)
    );
    integer checks = 0;
    task check(input integer raw_error, input integer mapped_error, input integer expected_u);
        integer j;
        begin
            @(negedge clk); theta_raw = 2048 - raw_error; tick = 1;
            @(posedge clk); #1;
            if (theta_mon !== raw_error || dut.s0_theta_err !== mapped_error || done)
                $fatal(1, "Sample mismatch: raw=%0d map=%0d (expected %0d/%0d)",
                    theta_mon, dut.s0_theta_err, raw_error, mapped_error);
            @(negedge clk); tick = 0;
            for (j=1; j<=5; j=j+1) begin
                @(posedge clk); #1;
                if (done !== (j==5)) $fatal(1, "Pipeline latency changed at clock %0d", j);
            end
            if (u !== expected_u) $fatal(1, "Command=%0d expected=%0d", u, expected_u);
            if (expected_u == 0 && (duty != 0 || dir != 0)) $fatal(1, "Zero still drives");
            if (expected_u > 0 && dir != 1) $fatal(1, "Positive direction mismatch");
            if (expected_u < 0 && dir != 2) $fatal(1, "Negative direction mismatch");
            if (expected_u < 230 && expected_u > -230 && sat) $fatal(1, "False saturation");
            checks = checks + 1;
            repeat (2) @(posedge clk);
        end
    endtask
    integer i, expected_map, expected_command;
    integer ramp_map [0:16];
    initial begin
        // Independent boundary table, including every integer transition input.
        ramp_map[0]=0; ramp_map[1]=1; ramp_map[2]=3; ramp_map[3]=4;
        ramp_map[4]=6; ramp_map[5]=7; ramp_map[6]=9; ramp_map[7]=11;
        ramp_map[8]=13; ramp_map[9]=15; ramp_map[10]=18; ramp_map[11]=20;
        ramp_map[12]=23; ramp_map[13]=25; ramp_map[14]=28; ramp_map[15]=31; ramp_map[16]=34;
        repeat (3) @(negedge clk); rst_n = 1;
        for (i=0; i<=350; i=i+1) begin
            if (i<=18) expected_map=0;
            else if (i<34) expected_map=ramp_map[i-18];
            else expected_map=i;
            expected_command=(300*expected_map+128)/256;
            check(i, expected_map, -expected_command);
            if (i!=0) check(-i, -expected_map, expected_command);
        end
        // Raw velocity must remain active inside the quiet band, with no history filter.
        theta_dot = 4; check(0, 0, 27);
        theta_dot = -4; check(0, 0, -27);
        theta_dot = 0;
        alpha_pos = 10064; alpha_dot = 16; check(0, 0, 11);
        alpha_pos = 10000; alpha_dot = 0;
        // Flush an in-flight nonzero result immediately.
        @(negedge clk); theta_raw = 2008; tick = 1;
        @(negedge clk); tick = 0; flush = 1;
        @(posedge clk); #1;
        if (u != 0 || duty != 0 || dir != 0 || done) $fatal(1, "Flush failed");
        @(negedge clk); flush = 0;
        check(20, 3, -4);
        @(negedge clk); enable = 0;
        @(posedge clk); #1;
        if (u != 0 || duty != 0 || dir != 0) $fatal(1, "Disable failed");
        $display("PASS: %0d signed P cases, raw telemetry/velocity, alpha path, 5-clock latency, flush and disable", checks);
        $finish;
    end
    initial begin
        #1000000;
        $fatal(1, "Transition verification timeout");
    end
endmodule
