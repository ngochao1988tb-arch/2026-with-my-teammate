`timescale 1ns/1ps
`include "system_params.vh"
module tb_upright_response;
    reg clk=0, rst_n=0, tick=0, safe=1, manual=1;
    always #10 clk=~clk;
    reg [11:0] theta=236;
    reg [7:0] manual_duty=0;
    reg [1:0] manual_dir=1;
    wire [7:0] duty;
    wire [1:0] direction;
    wire signed [15:0] command, applied;
    wire done, saturated, in1, in2, pwm;
    lqr_controller lqr(.clk_50m(clk),.rst_n(rst_n),.tick_3ms(tick),.ctrl_enable(safe),.flush_pipeline(!safe),
        .calibrated_zero_val(16'd236),.theta_raw(theta),.theta_dot(16'sd0),
        .alpha_pos(16'd10000),.alpha_target_pos(16'd10000),.alpha_dot(20'sd0),
        .k_theta(`PARAM_K_THETA),.k_theta_dot(`PARAM_K_THETA_DOT),.k_alpha(`PARAM_K_ALPHA),.k_alpha_dot(`PARAM_K_ALPHA_DOT),
        .motor_dir(direction),.duty_out(duty),.calc_done_pulse(done),.saturated(saturated),.u_scaled_mon(command));
    motor_tb6612 motor(.clk_50m(clk),.rst_n(rst_n),.safe_enable(safe),.swingup_mode(1'b0),
        .motor_dir(manual?manual_dir:direction),.duty_in(manual?manual_duty:duty),
        .deadband_pos(`PWM_DEADBAND_POS),.deadband_neg(`PWM_DEADBAND_NEG),.deadzone_thresh(`PWM_DEADZONE_THRESH),
        .in1(in1),.in2(in2),.pwm(pwm),.applied_pwm(applied));
    task boundary;
        begin
            repeat(15) @(posedge clk);
            @(posedge motor.cycle_boundary); @(posedge clk); #1;
        end
    endtask
    task drive_case;
        input [7:0] request;
        input signed [15:0] expected;
        begin
            @(negedge clk); manual=1; manual_duty=request; manual_dir=expected<0 ? 2 : 1;
            boundary;
            if(applied!==expected) $fatal(1,"Small drive mismatch request=%0d applied=%0d expected=%0d",request,applied,expected);
        end
    endtask
    task angle_case;
        input signed [15:0] error;
        input signed [15:0] expected_command;
        input signed [15:0] expected_drive;
        begin
            @(negedge clk); manual=0; theta=236+error; tick=1;
            @(negedge clk); tick=0;
            boundary;
            if(command!==expected_command || applied!==expected_drive)
                $fatal(1,"Upright response mismatch angle=%0d command=%0d drive=%0d",error,command,applied);
        end
    endtask
    initial begin
        #101 rst_n=1;
        drive_case(0,0); drive_case(1,0); drive_case(2,5); drive_case(3,11);
        drive_case(4,16); drive_case(5,22); drive_case(6,23); drive_case(17,34); drive_case(230,230);
        drive_case(2,-5); drive_case(3,-11); drive_case(4,-16); drive_case(5,-22);
        angle_case(0,0,0); angle_case(2,0,0); angle_case(4,0,0);
        angle_case(6,7,24); angle_case(8,9,26); angle_case(12,14,31); angle_case(20,23,40);
        angle_case(-2,0,0); angle_case(-4,0,0); angle_case(-6,-7,-24);
        angle_case(-8,-9,-26); angle_case(-12,-14,-31); angle_case(-20,-23,-40);
        @(negedge clk); safe=0;
        @(posedge clk); #1;
        if(applied!=0 || pwm || in1 || in2) $fatal(1,"Stop did not immediately bypass compensation");
        $display("PASS: small-command breakaway, +/-4 angle deadband, signed upright restoring drive, clamp and immediate stop");
        $finish;
    end
    initial begin #5000000; $fatal(1,"Upright response test timed out"); end
endmodule
