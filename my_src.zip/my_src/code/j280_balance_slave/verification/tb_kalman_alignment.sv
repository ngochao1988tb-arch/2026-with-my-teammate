`timescale 1ns/1ps
module tb_kalman_alignment;
    reg clk=0, rst_n=0;
    always #10 clk=~clk;
    reg [9:0] adc_input=59;
    reg [15:0] encoder_position=10000;
    j280_lqr_top dut (
        .clk_50m(clk), .rst_n(rst_n), .key_sw(4'hf), .uart_rx(1'b1),
        .adc_data_in(adc_input), .enc1_a(1'b0), .enc1_b(1'b0),
        .enc2_a(1'b0), .enc2_b(1'b0)
    );
    integer i, checked=0;
    initial begin
        force dut.calibration_valid=1;
        force dut.calibration_pending=0;
        force dut.fsm_state=2;
        force dut.u_encoder_1.pos=encoder_position;
        #101 rst_n=1;
        for(i=0;i<100;i=i+1) begin
            @(posedge dut.control_tick); #300;
            if(dut.frame_theta_dot!==dut.control_theta_velocity ||
               dut.u_lqr.s0_theta_dot!==-dut.control_theta_velocity ||
               dut.u_lqr.s0_alpha_dot!==dut.control_alpha_velocity_q4
`ifndef LQR_ONLY_TEST
               || dut.u_arm_position_pid.velocity_s1!==dut.control_alpha_velocity_q4
`endif
               )
                $fatal(1,"Kalman/LQR/PID frame mismatch at %0d",i);
            if(dut.sample_timeout) $fatal(1,"Pipeline caused sampling fault");
            checked=checked+1;
            @(negedge clk);
            if(i<40) begin
                adc_input=59+(i%2);
                encoder_position=10000+(i%2);
            end else if(i<70) begin
                adc_input=adc_input+1;
                encoder_position=encoder_position+1;
            end else begin
                adc_input=adc_input-1;
                encoder_position=encoder_position-1;
            end
        end
        `ifdef LQR_ONLY_TEST
        $display("PASS: %0d real ADC frames align Kalman and LQR velocities; no arm PID instance",checked);
`else
        $display("PASS: %0d real ADC frames align Kalman, LQR and PID velocities",checked);
`endif
        $finish;
    end
    initial begin #15000000; $fatal(1,"Alignment timeout"); end
endmodule
