`timescale 1ns/1ps
`include "system_params.vh"
module tb_startup_10khz_diagnosis;
    reg clk=0, rst_n=0;
    always #10 clk=~clk;
    wire tx, adc_clk, oe, stby, pa, a1, a2, pb, b1, b2;
    j280_lqr_top dut (
        .clk_50m(clk), .rst_n(rst_n), .key_sw(4'hf), .uart_rx(1'b1), .uart_tx(tx),
        .adc_data_in(adc_input), .adc_clk(adc_clk), .adc_oe_n(oe), .adc_stby_n(stby),
        .PWMA(pa), .AN1(a1), .AN2(a2), .PWMB(pb), .BN1(b1), .BN2(b2),
        .enc1_a(1'b0), .enc1_b(1'b0), .enc2_a(1'b0), .enc2_b(1'b0)
    );
    reg calibration_pulse=0;
    reg noisy=0;
    reg [9:0] adc_input=59;
    integer controls=0, pending_frames=0, max_confirm=0;
    always @(posedge dut.control_tick) begin
        controls=controls+1;
        if (noisy) adc_input=(adc_input==59) ? 60 : 59;
        if (dut.calibration_pending) pending_frames=pending_frames+1;
        if (dut.calibration_confirm_cnt>max_confirm) max_confirm=dut.calibration_confirm_cnt;
    end
    task calibrate;
        begin
            @(negedge clk); calibration_pulse=1;
            @(negedge clk); calibration_pulse=0;
        end
    endtask
    initial begin
        force dut.sw_calib_pulse=calibration_pulse;
        #101 rst_n=1;
        wait(controls>=3);
        calibrate;
        wait(dut.calibration_valid);
        wait(dut.fsm_state==2);
        if (dut.calibration_pending) $fatal(1,"Stable ADC calibration failed");
        $display("PASS: unforced startup with steady ADC enters BALANCE after SW1");
        @(negedge clk); rst_n=0;
        repeat(5) @(negedge clk);
        controls=0; pending_frames=0; max_confirm=0; noisy=1; adc_input=59; rst_n=1;
        wait(controls>=3);
        calibrate;
        wait(pending_frames>=120);
        #2;
        if (!dut.calibration_pending || dut.calibration_valid || dut.motor_safe_enable)
            $fatal(1,"Noise calibration block not reproduced");
        $display("REPRODUCED: one ADC count jitter at 10kHz leaves SW1 pending, motor disabled, confirm maximum=%0d, theta_delta=%0d",max_confirm,dut.frame_theta_dot);
        $finish;
    end
    initial begin #30000000; $fatal(1,"Startup diagnosis timed out"); end
endmodule
