`timescale 1ns/1ps
module tb_motor_ident_interlock;
reg clk=0,rst=0;
always #10 clk=~clk;
wire pa,pb,a1,a2,b1,b2,tx,ac,ao,ast;
j280_lqr_top dut(.clk_50m(clk),.rst_n(rst),.key_sw(4'b1111),.uart_rx(1'b1),
.adc_data_in(10'd100),.enc1_a(1'b0),.enc1_b(1'b0),.enc2_a(1'b0),.enc2_b(1'b0),
.uart_tx(tx),.adc_clk(ac),.adc_oe_n(ao),.adc_stby_n(ast),
.PWMA(pa),.PWMB(pb),.AN1(a1),.AN2(a2),.BN1(b1),.BN2(b2));
initial begin
#101 rst=1;
force dut.motor_base_enable=1;
force dut.jog_request=1;
force dut.ident_duty=8'd64;
force dut.fsm_state=3'd2;
#1;if(dut.motor_safe_enable!==0) $fatal(1,"Balance energized diagnostic candidate");
force dut.fsm_state=3'd5;
#1;if(dut.motor_safe_enable!==0) $fatal(1,"Swingup energized diagnostic candidate");
force dut.fsm_state=3'd3;
#1;if(dut.motor_safe_enable!==1) $fatal(1,"Jog pulse rejected");
force dut.ident_duty=0;
#1;if(dut.motor_safe_enable!==0) $fatal(1,"Gap did not disable driver");
@(negedge clk);
if({pa,pb,a1,a2,b1,b2}!==0) $fatal(1,"Gap left driver pins active");
force dut.ident_duty=8'd64;force dut.jog_request=0;
#1;if(dut.motor_safe_enable!==0) $fatal(1,"Released key energized motor");
force dut.jog_request=1;force dut.motor_base_enable=0;
#1;if(dut.motor_safe_enable!==0) $fatal(1,"Bypassed base fault interlock");
$display("PASS: diagnostic mode forbids balance/swingup drive; gap, release and base interlocks stop motor");
$finish;
end
endmodule
