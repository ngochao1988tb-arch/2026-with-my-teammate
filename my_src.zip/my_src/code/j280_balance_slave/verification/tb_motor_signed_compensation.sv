`timescale 1ns/1ps
`include "system_params.vh"
module tb_motor_signed_compensation;
    reg clk=0, rst=0, safe=0, mode=0;
    always #10 clk=~clk;
    reg [1:0] dir=0;
    reg [7:0] duty=0, threshold=1;
    reg signed [8:0] cp=0, cn=0;
    reg [12:0] phase=0;
    wire [1:0] p1,p2,pwm;
    wire signed [15:0] applied0,applied1;
    motor_tb6612 #(.DEADBAND_POS_HALF(0),.DEADBAND_NEG_HALF(0)) m0
        (clk,rst,safe,dir,duty,cp,cn,threshold,mode,p1[0],p2[0],pwm[0],applied0);
    motor_tb6612 #(.DEADBAND_POS_HALF(1),.DEADBAND_NEG_HALF(1)) m1
        (clk,rst,safe,dir,duty,cp,cn,threshold,mode,p1[1],p2[1],pwm[1],applied1);
    integer vals[0:7];
    integer a,b,c,d,h,x,r,co,q,lim,want,cmp,checks=0;
    task check;
        begin
            x=(duty>threshold)? duty-threshold:0;
            r=(x<4)?x:4;
            co=(dir==1)?cp:cn;
            lim=mode ? `SWINGUP_PWM_DUTY_LIMIT : `MAX_PWM_DUTY_LIMIT;
            for(h=0;h<2;h=h+1) begin
                // Independent integer reference in eighth-count units.
                if(h==0) q=(x+((co*r) >>> 2))*8;
                else q=x*8+(2*co+1)*r;
                if(q<0 || x==0 || dir==0 || dir==3) q=0;
                if(q>lim*8) q=lim*8;
                want=q/8;
                if(dir==2) want=-want;
                cmp=q*`PWM_CARRIER_PERIOD/2048;
                if(h==0) begin
                    if(applied0!==want || m0.active_cmp!==cmp)
                        $fatal(1,"integer dir=%0d duty=%0d cp=%0d cn=%0d got=%0d cmp=%0d want=%0d cmp=%0d",dir,duty,cp,cn,applied0,m0.active_cmp,want,cmp);
                end else if(applied1!==want || m1.active_cmp!==cmp)
                    $fatal(1,"half dir=%0d duty=%0d cp=%0d cn=%0d got=%0d want=%0d",dir,duty,cp,cn,applied1,want);
                checks=checks+1;
            end
        end
    endtask
    initial begin
        vals[0]=-256; vals[1]=-17; vals[2]=-3; vals[3]=-1;
        vals[4]=0; vals[5]=17; vals[6]=127; vals[7]=255;
        force m0.pwm_cnt=phase;
        force m1.pwm_cnt=phase;
        #101 rst=1; safe=1;
        for(a=0;a<8;a=a+1) for(b=0;b<2;b=b+1)
        for(c=0;c<4;c=c+1) for(d=0;d<256;d=d+1) begin
            @(negedge clk); phase=0; cp=vals[a]; cn=vals[7-a]; mode=b; dir=c; duty=d;
            repeat(10) @(negedge clk);
            phase=`PWM_CARRIER_PERIOD-1;
            @(negedge clk); phase=0; check;
        end
        dir=1; duty=100; cp=-3;
        repeat(10) @(negedge clk);
        phase=`PWM_CARRIER_PERIOD-1;
        @(negedge clk); phase=0;
        safe=0;
        @(negedge clk);
        if({p1,p2,pwm}!==0 || applied0!==0 || applied1!==0)
            $fatal(1,"Emergency stop delayed");
        safe=1; dir=2; duty=70; cn=-3;
        repeat(10) @(negedge clk);
        phase=`PWM_CARRIER_PERIOD-1;
        @(negedge clk); phase=0; check;
        $display("PASS: %0d signed compensation, half-count, direction, saturation and stop checks",checks);
        $finish;
    end
endmodule
