`timescale 1ns/1ps
`include "system_params.vh"
module tb_upright_velocity_window1ms;
    reg clk=0, rst_n=0;
    always #10 clk=~clk;
    wire tx, adc_clk, oe, stby, pa, a1, a2, pb, b1, b2;
    j280_lqr_top dut (
        .clk_50m(clk), .rst_n(rst_n), .key_sw(4'hf), .uart_rx(1'b1), .uart_tx(tx),
        .adc_data_in(adc_input), .adc_clk(adc_clk), .adc_oe_n(oe), .adc_stby_n(stby),
        .PWMA(pa), .AN1(a1), .AN2(a2), .PWMB(pb), .BN1(b1), .BN2(b2),
        .enc1_a(1'b0), .enc1_b(1'b0), .enc2_a(1'b0), .enc2_b(1'b0)
    );
    reg calibration_pulse=0;
    reg noisy=0;
    reg moving=0;
    reg [9:0] noise_base=59;
    reg [9:0] adc_input=59;
    integer controls=0, pending_frames=0, max_confirm=0;
    always @(posedge dut.control_tick) begin
        controls=controls+1;
        if (noisy) adc_input=(adc_input==noise_base) ? noise_base+1'b1 : noise_base;
        else if (moving) adc_input=adc_input+1'b1;
        if (dut.calibration_pending) pending_frames=pending_frames+1;
        if (dut.calibration_confirm_cnt>max_confirm) max_confirm=dut.calibration_confirm_cnt;
    end
    task calibrate;
        begin
            @(negedge clk); calibration_pulse=1;
            @(negedge clk); calibration_pulse=0;
        end
    endtask
    initial begin
        force dut.sw_calib_pulse=calibration_pulse;
        #101 rst_n=1;
        wait(controls>=3);
        calibrate;
        wait(dut.calibration_valid);
        wait(dut.fsm_state==2);
        if (dut.calibration_pending) $fatal(1,"Stable ADC calibration failed");
        $display("PASS: unforced startup with steady ADC enters BALANCE after SW1");
        @(negedge clk); rst_n=0;
        repeat(5) @(negedge clk);
        controls=0; pending_frames=0; max_confirm=0; noisy=1; adc_input=59; rst_n=1;
        wait(controls>=3);
        calibrate;
        wait(dut.calibration_valid);
        wait(dut.fsm_state==2); #2;
        if (dut.calibration_pending || !dut.motor_safe_enable)
            $fatal(1,"Noisy ADC still blocks calibration or balance entry");
        repeat(40) @(posedge dut.control_tick); #2;
        if(dut.frame_theta_dot!=0 || dut.combined_saturated || dut.applied_pwm!=0)
            $fatal(1,"Quantization noise still saturates upright control");
        if(dut.u_lqr.s0_theta_dot!=0 || dut.u_lqr.s0_alpha_dot!=0)
            $fatal(1,"LQR did not receive window velocities");
        $display("PASS: ADC jitter stays balanced without saturation; controller and startup velocities=0");
        // A small static tilt must still produce sustained restoring drive.
        @(negedge clk); noisy=0; adc_input=61;
        repeat(40) @(posedge dut.control_tick); #2;
        if(dut.fsm_state!=2 || dut.frame_theta_dot!=0 || dut.requested_pwm!=9 || dut.applied_pwm!=23)
            $fatal(1,"Small static tilt lost restoring drive: state=%0d velocity=%0d request=%0d applied=%0d",dut.fsm_state,dut.frame_theta_dot,dut.requested_pwm,dut.applied_pwm);
        $display("PASS: 8-count static tilt retains restoring request=9 applied=23 after velocity settles");
        // Fresh start while truly moving: noise fix must not authorize calibration.
        @(negedge clk); rst_n=0;
        repeat(5) @(negedge clk);
        controls=0; pending_frames=0; max_confirm=0; noisy=0; moving=1; adc_input=59; rst_n=1;
        wait(controls>=3); calibrate;
        wait(pending_frames>=120); #2;
        if (!dut.calibration_pending || dut.calibration_valid || dut.motor_safe_enable || dut.abs_startup_theta_dot<=12)
            $fatal(1,"Moving pendulum was incorrectly calibrated");
        $display("PASS: true motion blocks calibration; 3ms velocity=%0d",dut.startup_theta_dot);
        // Calibrated hanging position must remain idle with all swing-up disabled.
        @(negedge clk); rst_n=0;
        repeat(5) @(negedge clk);
        controls=0; pending_frames=0; max_confirm=0; noisy=1; moving=0; noise_base=559; adc_input=559; rst_n=1;
        wait(controls>=3); calibrate;
        wait(dut.calibration_valid);
        repeat(40) @(posedge dut.control_tick);
        #2;
        if (dut.fsm_state!=1 || dut.swingup_ctrl_enable || dut.motor_safe_enable || dut.applied_pwm!=0)
            $fatal(1,"Automatic swing-up is still active");
        // Simulate the debounced SW2+SW3 combination, retaining the real FSM.
        force dut.key_state=4'b0110;
        repeat(40) @(posedge dut.control_tick); #2;
        if (dut.fsm_state!=1 || dut.swingup_ctrl_enable || dut.applied_pwm!=0)
            $fatal(1,"Manual swing-up is still active");
        release dut.key_state;
        $display("PASS: automatic and SW2+SW3 swing-up stay disabled; hanging PWM remains zero");
        // Manually bring the calibrated pendulum upright; still allow balance.
        @(negedge clk); noisy=0; adc_input=59;
        wait(dut.fsm_state==2); #2;
        if (!dut.motor_safe_enable || dut.calibration_pending)
            $fatal(1,"Manual upright balance entry failed");
        $display("PASS: manually upright pendulum enters BALANCE without swing-up");
        // A fall must cut power and latch tilt fault, never automatically restart.
        @(negedge clk); adc_input=559;
        wait(dut.fsm_state==4); #2;
        if (dut.fault_cause!=5 || dut.motor_safe_enable || dut.calibration_valid)
            $fatal(1,"Tilt fault did not disable and disarm balance");
        repeat(40) @(posedge dut.control_tick); #2;
        if (dut.fsm_state!=4 || dut.applied_pwm!=0 || pa || a1 || a2)
            $fatal(1,"Tilt fault restarted the motor");
        $display("PASS: tilt fault cuts motor and remains latched");
        // SW1 clears the fault while idle; then upright placement allows reentry.
        calibrate; wait(dut.calibration_valid);
        @(negedge clk); adc_input=59;
        wait(dut.fsm_state==2); #2;
        if (dut.fault_cause!=0 || !dut.motor_safe_enable)
            $fatal(1,"SW1 did not rearm upright balance");
        $display("PASS: SW1 calibration rearms upright balance after a fall");
        $finish;
    end
    initial begin #150000000; $fatal(1,"Startup diagnosis timed out"); end
endmodule
