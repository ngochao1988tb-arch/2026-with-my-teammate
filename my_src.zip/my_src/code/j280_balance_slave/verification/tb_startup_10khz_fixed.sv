`timescale 1ns/1ps
`include "system_params.vh"
module tb_startup_10khz_fixed;
    reg clk=0, rst_n=0;
    always #10 clk=~clk;
    wire tx, adc_clk, oe, stby, pa, a1, a2, pb, b1, b2;
    j280_lqr_top dut (
        .clk_50m(clk), .rst_n(rst_n), .key_sw(4'hf), .uart_rx(1'b1), .uart_tx(tx),
        .adc_data_in(adc_input), .adc_clk(adc_clk), .adc_oe_n(oe), .adc_stby_n(stby),
        .PWMA(pa), .AN1(a1), .AN2(a2), .PWMB(pb), .BN1(b1), .BN2(b2),
        .enc1_a(1'b0), .enc1_b(1'b0), .enc2_a(1'b0), .enc2_b(1'b0)
    );
    reg calibration_pulse=0;
    reg noisy=0;
    reg moving=0;
    reg [9:0] noise_base=59;
    reg [9:0] adc_input=59;
    integer controls=0, pending_frames=0, max_confirm=0;
    always @(posedge dut.control_tick) begin
        controls=controls+1;
        if (noisy) adc_input=(adc_input==noise_base) ? noise_base+1'b1 : noise_base;
        else if (moving) adc_input=adc_input+1'b1;
        if (dut.calibration_pending) pending_frames=pending_frames+1;
        if (dut.calibration_confirm_cnt>max_confirm) max_confirm=dut.calibration_confirm_cnt;
    end
    task calibrate;
        begin
            @(negedge clk); calibration_pulse=1;
            @(negedge clk); calibration_pulse=0;
        end
    endtask
    initial begin
        force dut.sw_calib_pulse=calibration_pulse;
        #101 rst_n=1;
        wait(controls>=3);
        calibrate;
        wait(dut.calibration_valid);
        wait(dut.fsm_state==2);
        if (dut.calibration_pending) $fatal(1,"Stable ADC calibration failed");
        $display("PASS: unforced startup with steady ADC enters BALANCE after SW1");
        @(negedge clk); rst_n=0;
        repeat(5) @(negedge clk);
        controls=0; pending_frames=0; max_confirm=0; noisy=1; adc_input=59; rst_n=1;
        wait(controls>=3);
        calibrate;
        wait(dut.calibration_valid);
        wait(dut.fsm_state==2); #2;
        if (dut.calibration_pending || !dut.motor_safe_enable)
            $fatal(1,"Noisy ADC still blocks calibration or balance entry");
        wait(dut.applied_pwm!=0);
        $display("PASS: 1-ADC-count jitter calibrates and enters BALANCE with real motor output; fast derivative=%0d startup derivative=%0d",dut.frame_theta_dot,dut.startup_theta_dot);
        // Fresh start while truly moving: noise fix must not authorize calibration.
        @(negedge clk); rst_n=0;
        repeat(5) @(negedge clk);
        controls=0; pending_frames=0; max_confirm=0; noisy=0; moving=1; adc_input=59; rst_n=1;
        wait(controls>=3); calibrate;
        wait(pending_frames>=120); #2;
        if (!dut.calibration_pending || dut.calibration_valid || dut.motor_safe_enable || dut.abs_startup_theta_dot<=12)
            $fatal(1,"Moving pendulum was incorrectly calibrated");
        $display("PASS: true motion blocks calibration; 3ms velocity=%0d",dut.startup_theta_dot);
        // Noisy hanging pendulum must calibrate, start automatically and catch upright.
        @(negedge clk); rst_n=0;
        repeat(5) @(negedge clk);
        controls=0; pending_frames=0; max_confirm=0; noisy=1; moving=0; noise_base=559; adc_input=559; rst_n=1;
        wait(controls>=3); calibrate;
        wait(dut.calibration_valid); wait(dut.fsm_state==5);
        wait(dut.applied_pwm!=0);
        $display("PASS: hanging jitter calibrates and automatically starts swing-up with motor output");
        @(negedge clk); noisy=0; adc_input=59;
        wait(dut.fsm_state==2); #2;
        if (!dut.motor_safe_enable || dut.calibration_pending)
            $fatal(1,"Upright swing-up capture failed");
        $display("PASS: swing-up catches upright using 3ms velocity window");
        $finish;
    end
    initial begin #100000000; $fatal(1,"Startup diagnosis timed out"); end
endmodule
