

# Existing ADC board timing assumptions retained (25ns/3ns).
# Board flight time, ADC data-valid bounds and pin loading are not measured here.
# Passing this SDC is not a verification of the analog sensor or board-level timing.
create_clock -name clk_50m -period 20.0 -waveform {0 10} [get_ports {clk_50m}]


# Global functional clock from the explicit toggle divider.
create_generated_clock -name clk_sys -source [get_ports {clk_50m}] -divide_by 2 [get_nets {clk_sys}]
# ADC output toggles once per system clock: 12.5MHz.
create_generated_clock -name adc_clk -source [get_ports {clk_50m}] -divide_by 4 [get_ports {adc_clk}]


set_input_delay -clock adc_clk -max 25.0 [get_ports {adc_data_in[*]}]
set_input_delay -clock adc_clk -min 3.0  [get_ports {adc_data_in[*]}]


set_multicycle_path 2 -setup -from [get_ports {adc_data_in[*]}]
set_multicycle_path 1 -hold  -from [get_ports {adc_data_in[*]}]
