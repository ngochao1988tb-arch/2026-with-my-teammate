

`timescale 1ns / 1ps
`include "system_params.vh"

module adc_3pa1030_sync (
    input                    clk_50m,
    input                    rst_n,

    // 3PA1030 硬件引脚物理接口
    output                   adc_clk,           // 12.5MHz 采样时钟输出至 3PA1030 Pin 15
    output                   adc_oe_n,          // 输出使能 (0: 正常输出, 1: 高阻)
    output                   adc_stby_n,        // 待机休眠 (0: 正常工作, 1: 待机功耗)
    input             [9:0]  adc_data_in,       // 3PA1030 10-bit 原始并行总线输入

    // 处理后输出至控制环接口 (100us 周期更新；保留原端口名)
    output reg               adc_valid_3ms,     // 100us 采样更新脉冲 (单周期有效)
    output reg        [11:0] theta_raw_12b,     // 16点中值，保持4倍ADC尺度并保留半个ADC计数
    output reg signed [15:0] theta_dot_raw      // 100us帧差分乘30，保持counts/3ms速度单位
);

    // 硬件使能固定配置: 始终使能芯片正常转换
    assign adc_oe_n   = 1'b0;
    assign adc_stby_n = 1'b0;

    // -----------------------------------------------------------------------------
    // 1. 产生严格对称的 12.5MHz ADC 时钟 (adc_clk)
    // -----------------------------------------------------------------------------
    // Keep the external generated-clock net out of internal data/enable paths.
    // These two registers have identical reset and phase, but separate fanout.
    reg adc_phase_reg /* synthesis syn_preserve=1 syn_keep=1 */;
    reg adc_clk_reg /* synthesis syn_preserve=1 syn_keep=1 */;
    always @(posedge clk_50m or negedge rst_n) begin
        if (!rst_n) begin
            adc_phase_reg <= 1'b0;
            adc_clk_reg <= 1'b0;
        end else begin
            adc_phase_reg <= ~adc_phase_reg;
            adc_clk_reg <= ~adc_phase_reg;
        end
    end
    assign adc_clk = adc_clk_reg;

    // -----------------------------------------------------------------------------
    // 2. ADC 输入总线同步相位锁存
    //    3PA1030 手册指标: tOD <= 25ns, tOH >= 3ns。在 12.5MHz (周期 80ns) 下，
    //    adc_clk 上升沿由 clk_50m 产生后，数据在 25ns 后稳定，直至下一个周期 83ns。
    //    在 adc_clk_reg == 1'b0 的 clk_50m 时钟沿（对应周期 80ns 节点）整组锁存输入总线，
    //    彻底消除多位并行总线独立异步打拍引起的位间偏斜与撕裂。
    // -----------------------------------------------------------------------------
    reg [9:0] adc_bus_latch;

    always @(posedge clk_50m or negedge rst_n) begin
        if (!rst_n) begin
            adc_bus_latch <= 10'd512;
        end else if (adc_phase_reg == 1'b0) begin
            adc_bus_latch <= adc_data_in;
        end
    end

    // -----------------------------------------------------------------------------
    // 3. 突变坏点 / 极值撕裂抑制滤波器 (Anti-Glitch / Slew-Rate Limiter)
    //    倒立摆在 187.5us 内因机械惯性不可能发生瞬时大阶跃。
    //    若采样值突跳（如电位器死区弹跳坏点），保持上一拍稳定值，防止污染累加器。
    // -----------------------------------------------------------------------------
    reg [9:0] sample_filtered;
    reg [9:0] sample_last;
    reg       filter_init;

    wire signed [10:0] sample_diff = $signed({1'b0, adc_bus_latch}) - $signed({1'b0, sample_last});
    wire signed [10:0] abs_diff    = (sample_diff < 0) ? -sample_diff : sample_diff;

    // 允许单次 187.5us 采样的最大物理合理跳变值 (约 100 LSB)
    localparam MAX_PHYSICAL_DELTA = 11'sd100;

    always @(posedge clk_50m or negedge rst_n) begin
        if (!rst_n) begin
            sample_filtered <= 10'd512;
            sample_last     <= 10'd512;
            filter_init     <= 1'b0;
        end else if (!filter_init) begin
            sample_filtered <= adc_bus_latch;
            sample_last     <= adc_bus_latch;
            filter_init     <= 1'b1;
        end else begin
            if (abs_diff > MAX_PHYSICAL_DELTA && (adc_bus_latch < 10'd30 || adc_bus_latch > 10'd990)) begin
                sample_filtered <= sample_last;
            end else begin
                sample_filtered <= adc_bus_latch;
                sample_last     <= adc_bus_latch;
            end
        end
    end

    // -----------------------------------------------------------------------------
    // 4. 定时收集 16 点并取中值
    //    156/157时钟按余数分配（平均6.25us），16点总耗时精确为100us。
    //    偶数点中值取排序后第 8、9 点的平均，既抑制单点毛刺，也避免中值偏向一侧。
    //    采满后用 16 个系统时钟执行奇偶换位排序，避免形成过长的组合排序路径。
    // -----------------------------------------------------------------------------
    reg [14:0] sample_timer;   // 0..155/156 at 25MHz
    reg [3:0] sample_fraction;
    wire [4:0] next_fraction = {1'b0, sample_fraction} + (`CONTROL_LOOP_PERIOD_TICKS % 16);
    wire [15:0] sample_slot_ticks = (`CONTROL_LOOP_PERIOD_TICKS / 16) + next_fraction[4];
    reg [3:0]  sample_index;   // 0 ~ 15 (16 个样本)
    reg [9:0]  sample_buffer [0:15]; // 当前100us帧的16个10-bit样本
    reg        sorting;
    reg [4:0]  sort_phase;
    reg [11:0] theta_raw_prev;
    reg        first_frame_done;
    integer sort_i;

    wire [10:0] median_pair_sum =
        {1'b0, sample_buffer[7]} + {1'b0, sample_buffer[8]};
    // 4 * ((a + b) / 2) = 2 * (a + b). Preserve the half-count
    // median instead of truncating to 10 bits before scaling. Angle units,
    // frame timing and controller gains remain unchanged; range is 0..4092.
    wire [11:0] calculated_theta = {median_pair_sum, 1'b0};
    wire signed [12:0] theta_delta_raw =
        $signed({1'b0,calculated_theta}) - $signed({1'b0,theta_raw_12b});
    wire signed [12:0] theta_delta_wrapped =
        (theta_delta_raw > 13'sd2048) ? theta_delta_raw - 13'sd4096 :
        (theta_delta_raw < -13'sd2048) ? theta_delta_raw + 13'sd4096 : theta_delta_raw;

    wire signed [31:0] theta_delta_normalized = $signed(theta_delta_wrapped) * `CONTROL_VELOCITY_MULTIPLIER;

    always @(posedge clk_50m or negedge rst_n) begin
        if (!rst_n) begin
            sample_timer     <= 15'd0;
            sample_index     <= 4'd0;
            sample_fraction  <= 4'd0;
            sorting          <= 1'b0;
            sort_phase       <= 5'd0;
            theta_raw_12b    <= `DEFAULT_THETA_ZERO;
            theta_raw_prev   <= `DEFAULT_THETA_ZERO;
            theta_dot_raw    <= 16'sd0;
            adc_valid_3ms    <= 1'b0;
            first_frame_done <= 1'b0;
        end else begin
            adc_valid_3ms <= 1'b0; // 默认拉低，仅在中值就绪拍产生单周期脉冲

            if (sorting) begin
                if (sort_phase < 5'd16) begin
                    // Even phases compare (0,1), (2,3), ...; odd phases compare
                    // (1,2), (3,4), ... . Sixteen phases fully sort 16 values.
                    if (!sort_phase[0]) begin
                        for (sort_i = 0; sort_i < 16; sort_i = sort_i + 2) begin
                            if (sample_buffer[sort_i] > sample_buffer[sort_i + 1]) begin
                                sample_buffer[sort_i] <= sample_buffer[sort_i + 1];
                                sample_buffer[sort_i + 1] <= sample_buffer[sort_i];
                            end
                        end
                    end else begin
                        for (sort_i = 1; sort_i < 15; sort_i = sort_i + 2) begin
                            if (sample_buffer[sort_i] > sample_buffer[sort_i + 1]) begin
                                sample_buffer[sort_i] <= sample_buffer[sort_i + 1];
                                sample_buffer[sort_i + 1] <= sample_buffer[sort_i];
                            end
                        end
                    end
                    sort_phase <= sort_phase + 1'b1;
                end else begin
                    sorting <= 1'b0;
                    theta_raw_12b <= calculated_theta;
                    theta_raw_prev <= theta_raw_12b;

                    if (first_frame_done) begin
                        // Preserve counts/3ms units for gains and velocity gates.
                        theta_dot_raw <= (theta_delta_normalized > 32'sd32767) ? 16'sd32767 :
                            (theta_delta_normalized < -32'sd32768) ? -16'sd32768 : theta_delta_normalized[15:0];
                        adc_valid_3ms <= 1'b1;
                    end else begin
                        theta_raw_prev <= calculated_theta;
                        theta_dot_raw <= 16'sd0;
                        first_frame_done <= 1'b1;
                    end
                end
            end

            // Fractional divider: 12 slots x156 + 4 slots x157 =2500 clocks.
            if (sample_timer >= sample_slot_ticks - 1'b1) begin
                sample_fraction <= next_fraction[3:0];
                sample_timer <= 15'd0;

                if (sample_index == 4'd15) begin
                    sorting <= 1'b1;
                    sort_phase <= 5'd0;
                    sample_index <= 4'd0;
                end else begin
                    sample_index <= sample_index + 1'b1;
                end
                sample_buffer[sample_index] <= sample_filtered;
            end else begin
                sample_timer <= sample_timer + 1'b1;
            end
        end
    end

endmodule
