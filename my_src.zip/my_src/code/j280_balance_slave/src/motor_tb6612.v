// =================================================================================
// 工程名称: J280 高云 FPGA 旋转倒立摆控制系统 (硬件现场验证版)
// 文件名称: motor_tb6612.v
// 功能说明: TB6612FNG 驱动模块，支持 10kHz PWM 周期边界一致性锁存、
//           正反向独立死区平滑补偿、小信号消抖死区与硬件瞬时断电切断
// =================================================================================

`timescale 1ns / 1ps
`include "system_params.vh"

module motor_tb6612 #(
    parameter [7:0] SWINGUP_DUTY_LIMIT = `SWINGUP_PWM_DUTY_LIMIT,
    parameter DEADBAND_POS_HALF = `PWM_DEADBAND_POS_HALF,
    parameter DEADBAND_NEG_HALF = `PWM_DEADBAND_NEG_HALF
) (
    input                    clk_50m,
    input                    rst_n,

    // 安全逻辑控制使能 (为 0 时硬件绝对切断电机所有信号，单周期即时生效)
    input                    safe_enable,         // 1: 允许运转; 0: 硬件断电闭锁

    // 控制指令输入 (来自 LQR 流水线或点动状态机)
    input             [1:0]  motor_dir,           // 00: 停止, 01: 正转(CW), 10: 反转(CCW), 11: 刹车
    input             [7:0]  duty_in,             // 期望占空比 (0 ~ 255)

    // 死区补偿独立配置
    input signed      [8:0]  deadband_pos,        // 正向补偿，可为负值
    input signed      [8:0]  deadband_neg,        // 反向补偿，可为负值
    input             [7:0]  deadzone_thresh,     // 微小输入死区消除阈值 (小于此值输出0)
    input                    swingup_mode,       // only this mode may use the swing-up PWM ceiling

    // TB6612 硬件物理引脚输出
    output reg               in1,                 // TB6612 AIN1 / BIN1
    output reg               in2,                 // TB6612 AIN2 / BIN2
    output reg               pwm,                 // TB6612 PWMA / PWMB
    output signed [15:0]     applied_pwm          // signed, post-compensation active command
);

    // -----------------------------------------------------------------------------
    // 1. 10kHz 载波计数器 (25MHz / 2500 = 10.0kHz, 周期 100us)
    // -----------------------------------------------------------------------------
    localparam PWM_PERIOD = `PWM_CARRIER_PERIOD; // 2500
    reg [12:0] pwm_cnt;
    wire cycle_boundary = (pwm_cnt >= PWM_PERIOD - 1'b1);

    always @(posedge clk_50m or negedge rst_n) begin
        if (!rst_n)
            pwm_cnt <= 13'd0;
        else if (cycle_boundary)
            pwm_cnt <= 13'd0;
        else
            pwm_cnt <= pwm_cnt + 1'b1;
    end

    // -----------------------------------------------------------------------------
    // 2. 正反向独立死区平滑补偿与限幅计算
    // -----------------------------------------------------------------------------
    // Register the incoming command before compensation and PWM multiplication.
    // This adds one 40ns clock while stop still bypasses every command stage.
    reg [7:0] command_duty;
    reg [1:0] command_dir;
    reg command_swingup_mode;
    always @(posedge clk_50m or negedge rst_n) begin
        if (!rst_n) begin command_duty <= 0; command_dir <= 0; command_swingup_mode <= 0; end
        else if (!safe_enable) begin command_duty <= 0; command_dir <= 0; command_swingup_mode <= 0; end
        else begin command_duty <= duty_in; command_dir <= motor_dir; command_swingup_mode <= swingup_mode; end
    end

    reg [7:0] pre_duty_compensated;
    reg [2:0] pre_duty_fraction;
    reg [1:0] pre_dir;

    wire [7:0] excess_next = (command_duty > deadzone_thresh) ? (command_duty - deadzone_thresh) : 8'd0;
    // Ramp the compensation over the configured small-command range.
    // Register subtraction/ramp selection before compensation multiplication.
    // Keep direction aligned. Emergency stop still bypasses every stage.
    reg [7:0] excess_cmd;
    reg [4:0] ramp_cmd;
    reg [1:0] compensation_dir;
    reg compensation_swingup_mode;
    always @(posedge clk_50m or negedge rst_n) begin
        if (!rst_n) begin excess_cmd <= 0; ramp_cmd <= 0; compensation_dir <= 0; compensation_swingup_mode <= 0; end
        else if (!safe_enable) begin excess_cmd <= 0; ramp_cmd <= 0; compensation_dir <= 0; compensation_swingup_mode <= 0; end
        else begin
            excess_cmd <= excess_next;
            ramp_cmd <= (excess_next >= `PWM_COMP_RAMP_COUNTS) ?
                         `PWM_COMP_RAMP_COUNTS : {1'b0,excess_next[3:0]};
            compensation_dir <= command_dir;
            compensation_swingup_mode <= command_swingup_mode;
        end
    end
    // Nine signed bits retain the old positive 0..255 range and allow subtraction.
    // Both multiplier operands are signed; ramp_cmd remains nonnegative.
    wire signed [14:0] ramp_pos = deadband_pos * $signed({1'b0, ramp_cmd});
    wire signed [14:0] ramp_neg = deadband_neg * $signed({1'b0, ramp_cmd});
    wire signed [14:0] compensation_pos = ramp_pos >>> `PWM_COMP_RAMP_SHIFT;
    wire signed [14:0] compensation_neg = ramp_neg >>> `PWM_COMP_RAMP_SHIFT;
    wire [7:0] command_limit = compensation_swingup_mode ? SWINGUP_DUTY_LIMIT : `MAX_PWM_DUTY_LIMIT;

    // Q3 retains half-count precision. The half option adds +0.5 to the
    // signed setting (e.g. -3 with HALF=1 means -2.5). Integer settings
    // keep the original floor rounding through the ramp, also for negatives.
    wire signed [18:0] ramp_pos_scaled =
        ($signed({deadband_pos, 1'b1}) * $signed({1'b0, ramp_cmd})) <<< 3;
    wire signed [18:0] ramp_neg_scaled =
        ($signed({deadband_neg, 1'b1}) * $signed({1'b0, ramp_cmd})) <<< 3;
    wire signed [18:0] ramp_pos_q3 = ramp_pos_scaled >>> (`PWM_COMP_RAMP_SHIFT + 1);
    wire signed [18:0] ramp_neg_q3 = ramp_neg_scaled >>> (`PWM_COMP_RAMP_SHIFT + 1);
    wire signed [18:0] duty_pos_q3 = $signed({1'b0, excess_cmd, 3'd0}) +
        (DEADBAND_POS_HALF ? ramp_pos_q3 : (compensation_pos <<< 3));
    wire signed [18:0] duty_neg_q3 = $signed({1'b0, excess_cmd, 3'd0}) +
        (DEADBAND_NEG_HALF ? ramp_neg_q3 : (compensation_neg <<< 3));
    wire signed [18:0] limit_q3 = $signed({1'b0, command_limit, 3'd0});

    always @(*) begin
        // safe_enable gates OUTPUT registers below, not this multiplier path.
        pre_duty_fraction = 3'd0;
        if (excess_cmd == 0 || compensation_dir == 2'b00) begin
            pre_duty_compensated = 8'd0;
            pre_dir              = 2'b00;
        end else begin
            case (compensation_dir)
                2'b01: begin // 正转 CW
                    pre_dir = 2'b01;
                    if (duty_pos_q3 <= 0) begin
                        pre_duty_compensated = 8'd0;
                        pre_dir = 2'b00;
                    end else if (duty_pos_q3 > limit_q3)
                        pre_duty_compensated = command_limit;
                    else begin
                        pre_duty_compensated = duty_pos_q3[10:3];
                        pre_duty_fraction = duty_pos_q3[2:0];
                    end
                end
                2'b10: begin // 反转 CCW
                    pre_dir = 2'b10;
                    if (duty_neg_q3 <= 0) begin
                        pre_duty_compensated = 8'd0;
                        pre_dir = 2'b00;
                    end else if (duty_neg_q3 > limit_q3)
                        pre_duty_compensated = command_limit;
                    else begin
                        pre_duty_compensated = duty_neg_q3[10:3];
                        pre_duty_fraction = duty_neg_q3[2:0];
                    end
                end
                2'b11: begin // 刹车 Brake
                    pre_dir              = 2'b11;
                    pre_duty_compensated = 8'd0;
                end
                default: begin
                    pre_dir              = 2'b00;
                    pre_duty_compensated = 8'd0;
                end
            endcase
        end
    end

    // -----------------------------------------------------------------------------
    // 3. PWM 周期边界一致性对齐锁存与即时急停旁路
    //    关键设计: 正常方向切换与占空比更新严格发生在 PWM 周期边界 (cycle_boundary)，
    //    防止周期中途换向引发 H 桥反电势冲击或死区穿通；
    //    但当 safe_enable == 0 (急停/故障) 时，立即单拍切断，绝不等待周期边界！
    // -----------------------------------------------------------------------------
    reg [7:0]  active_duty;
    reg [1:0]  active_dir;
    reg [12:0] active_cmp;
    // Telemetry reports the integer portion; pulse width retains Q3 precision.
    assign applied_pwm = !safe_enable ? 16'sd0 :
        active_dir == 2'b01 ? $signed({8'd0,active_duty}) :
        active_dir == 2'b10 ? -$signed({8'd0,active_duty}) : 16'sd0;

    wire [20:0] cmp_calc = {13'd0, pre_duty_compensated} * PWM_PERIOD;
    wire [12:0] next_cmp = cmp_calc[20:8]; // (duty * 2500) / 256

    // Separate command compensation from PWM threshold multiplication.
    // The asynchronous-to-frame stop path below still cuts off on the next clock.
    reg [7:0] duty_stage1, prepared_duty;
    reg [1:0] dir_stage1, prepared_dir;
    reg [2:0] fraction_stage1;
    reg [12:0] prepared_cmp;
    wire [23:0] stage1_cmp_product = {13'd0,duty_stage1,fraction_stage1} * PWM_PERIOD;
    always @(posedge clk_50m or negedge rst_n) begin
        if (!rst_n) begin
            duty_stage1 <= 0; dir_stage1 <= 0; fraction_stage1 <= 0;
            prepared_duty <= 0; prepared_dir <= 0; prepared_cmp <= 0;
        end else if (!safe_enable) begin
            duty_stage1 <= 0; dir_stage1 <= 0; fraction_stage1 <= 0;
            prepared_duty <= 0; prepared_dir <= 0; prepared_cmp <= 0;
        end else begin
            duty_stage1 <= pre_duty_compensated;
            fraction_stage1 <= pre_duty_fraction;
            dir_stage1 <= pre_dir;
            prepared_duty <= duty_stage1;
            prepared_dir <= dir_stage1;
            prepared_cmp <= stage1_cmp_product[23:11];
        end
    end

    always @(posedge clk_50m or negedge rst_n) begin
        if (!rst_n) begin
            active_duty <= 8'd0;
            active_dir  <= 2'b00;
            active_cmp  <= 13'd0;
            in1         <= 1'b0;
            in2         <= 1'b0;
            pwm         <= 1'b0;
        end else if (!safe_enable) begin
            // 立即断电急停旁路
            active_duty <= 8'd0;
            active_dir  <= 2'b00;
            active_cmp  <= 13'd0;
            in1         <= 1'b0;
            in2         <= 1'b0;
            pwm         <= 1'b0;
        end else begin
            // At a carrier boundary, update the command registers only when
            // signed direction or compensated duty changes. The carrier still
            // restarts normally when the command is unchanged.
            if (cycle_boundary) begin
                if (prepared_dir != active_dir || prepared_duty != active_duty || prepared_cmp != active_cmp) begin
                    active_duty <= prepared_duty;
                    active_dir  <= prepared_dir;
                    active_cmp  <= prepared_cmp;
                    in1 <= prepared_dir == 2'b01 || prepared_dir == 2'b11;
                    in2 <= prepared_dir == 2'b10 || prepared_dir == 2'b11;
                    // First tick of the NEW period uses the NEW command.
                    pwm <= (prepared_cmp != 0);
                end else begin
                    pwm <= (active_cmp != 0);
                end
            end else begin
                pwm <= ((pwm_cnt + 1'b1) < active_cmp);
            end
        end
    end

endmodule
