`timescale 1ns / 1ps
`include "system_params.vh"
`include "swingup_peak_detector.v"

// Energy-shaping controller for the J280 rotary pendulum.
// theta_abs_counts is the wrapped upright-angle distance (0..2048 counts).
// theta_dot is upright-coordinate velocity in counts/3ms; tick is every 100us.
module swingup_energy_controller #(parameter PEAK_MODE = `SWINGUP_PEAK_MODE) (
    input                    clk,
    input                    rst_n,
    input                    tick,
    input                    enable,
    input      [11:0]         theta_abs_counts,
    input      signed [15:0]  theta_dot,
    input      [15:0]         kick_frames,
    output reg        [1:0]   motor_dir,
    output reg        [7:0]   duty,
    output reg                kick_done,
    output reg signed [15:0]  energy_error_mon
);

    // cos(theta) lookup over 0..pi in 16 linear segments. 128 ADC counts
    // represent pi/16 using the measured ~2000 counts per half revolution.
    function signed [11:0] cos_sample;
        input [4:0] index;
        begin
            case (index)
                0: cos_sample= 12'sd1024; 1: cos_sample= 12'sd1004;
                2: cos_sample= 12'sd946;  3: cos_sample= 12'sd851;
                4: cos_sample= 12'sd724;  5: cos_sample= 12'sd569;
                6: cos_sample= 12'sd392;  7: cos_sample= 12'sd200;
                8: cos_sample= 12'sd0;    9: cos_sample=-12'sd200;
                10: cos_sample=-12'sd392; 11: cos_sample=-12'sd569;
                12: cos_sample=-12'sd724; 13: cos_sample=-12'sd851;
                14: cos_sample=-12'sd946; 15: cos_sample=-12'sd1004;
                default: cos_sample=-12'sd1024;
            endcase
        end
    endfunction

    // Eight registered arithmetic stages. A tick produces its matching command
    // eight 25 MHz clocks later (320 ns), while the control frame is 100us.
    reg [7:0] valid_pipe;
    reg [11:0] theta_s1;
    reg [7:0] dot_s1, dot_s2, dot_s3, dot_s4, dot_s5;
    reg signed [11:0] cos_a_s2, cos_a_s3, cos_s4, cos_s5, cos_s6;
    reg signed [12:0] cos_delta_s2;
    reg [6:0] fraction_s2;
    reg [15:0] dot_squared_s2, kinetic_s4;
    reg [23:0] kinetic_product_s3;
    reg signed [20:0] interpolation_s3, error_dot_s6;
    reg signed [17:0] error_s5, error_s6, error_s7, error_s8;
    reg signed [32:0] drive_s7;
    reg [32:0] magnitude_s8;
    reg negative_s8;
    reg dot_negative_s1, dot_negative_s2, dot_negative_s3, dot_negative_s4, dot_negative_s5;
    wire signed [8:0] signed_dot_s5 = dot_negative_s5 ?
        -$signed({1'b0,dot_s5}) : $signed({1'b0,dot_s5});

    wire [11:0] theta_clamped = theta_abs_counts > 12'd2048 ? 12'd2048 : theta_abs_counts;
    wire signed [15:0] dot_abs_wide = theta_dot < 0 ? -theta_dot : theta_dot;
    wire [7:0] dot_limited = dot_abs_wide > 16'd100 ? 8'd100 : dot_abs_wide[7:0];
    wire signed [11:0] lut_a = cos_sample(theta_s1[11:7]);
    wire signed [11:0] lut_b = cos_sample(theta_s1[11:7] + 1'b1);
    wire signed [20:0] interpolation_shifted = interpolation_s3 >>> 7;
    wire signed [12:0] potential_s4 = 13'sd1024 + $signed(cos_s4);
    wire [15:0] potential_nonnegative = potential_s4[12] ? 16'd0 : {4'd0,potential_s4[11:0]};
    wire [16:0] total_energy_s4 = {1'b0,potential_nonnegative} + {1'b0,kinetic_s4};

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            valid_pipe <= 0;
            theta_s1 <= 0;
            dot_negative_s1 <= 0; dot_negative_s2 <= 0; dot_negative_s3 <= 0;
            dot_negative_s4 <= 0; dot_negative_s5 <= 0;
            dot_s1 <= 0; dot_s2 <= 0; dot_s3 <= 0; dot_s4 <= 0; dot_s5 <= 0;
            cos_a_s2 <= 0; cos_a_s3 <= 0;
            cos_s4 <= 0; cos_s5 <= 0; cos_s6 <= 0;
            cos_delta_s2 <= 0; fraction_s2 <= 0;
            dot_squared_s2 <= 0; kinetic_s4 <= 0; kinetic_product_s3 <= 0;
            interpolation_s3 <= 0; error_dot_s6 <= 0;
            error_s5 <= 0; error_s6 <= 0; error_s7 <= 0; error_s8 <= 0;
            drive_s7 <= 0; magnitude_s8 <= 0; negative_s8 <= 0;
        end else begin
            valid_pipe <= enable ? {valid_pipe[6:0],tick} : 8'd0;
            theta_s1 <= theta_clamped;
            dot_s1 <= dot_limited;
            dot_negative_s1 <= theta_dot[15];

            cos_a_s2 <= lut_a;
            cos_delta_s2 <= $signed(lut_b) - $signed(lut_a);
            fraction_s2 <= theta_s1[6:0];
            dot_squared_s2 <= dot_s1 * dot_s1;
            dot_s2 <= dot_s1;
            dot_negative_s2 <= dot_negative_s1;

            interpolation_s3 <= cos_delta_s2 * $signed({1'b0,fraction_s2});
            cos_a_s3 <= cos_a_s2;
            kinetic_product_s3 <= dot_squared_s2 * 24'd329;
            dot_s3 <= dot_s2;
            dot_negative_s3 <= dot_negative_s2;

            cos_s4 <= cos_a_s3 + interpolation_shifted[11:0];
            kinetic_s4 <= kinetic_product_s3[23:8] > 16'd4095 ?
                          16'd4095 : kinetic_product_s3[23:8];
            dot_s4 <= dot_s3;
            dot_negative_s4 <= dot_negative_s3;

            error_s5 <= 18'sd2048 - $signed({1'b0,total_energy_s4});
            cos_s5 <= cos_s4;
            dot_s5 <= dot_s4;
            dot_negative_s5 <= dot_negative_s4;

            error_dot_s6 <= error_s5 * signed_dot_s5;
            cos_s6 <= cos_s5;
            error_s6 <= error_s5;

            drive_s7 <= error_dot_s6 * cos_s6;
            error_s7 <= error_s6;

            magnitude_s8 <= drive_s7[32] ? -drive_s7 : drive_s7;
            negative_s8 <= drive_s7[32];
            error_s8 <= error_s7;
        end
    end

    wire [32:0] scaled_drive = magnitude_s8 >> `SWINGUP_DUTY_SHIFT;
    wire [7:0] scaled_drive_limited =
        scaled_drive > `SWINGUP_PWM_DUTY_LIMIT ? `SWINGUP_PWM_DUTY_LIMIT : scaled_drive[7:0];

    wire peak_pulse;
    reg peak_pending;
    reg [1:0] peak_drive_dir;
    reg [15:0] peak_boost_remaining;
    wire [1:0] reversed_peak_dir = peak_drive_dir == 2'b01 ? 2'b10 : 2'b01;
    wire [7:0] peak_boost_duty = `SWINGUP_REVERSAL_DUTY > `SWINGUP_PWM_DUTY_LIMIT ?
                                `SWINGUP_PWM_DUTY_LIMIT : `SWINGUP_REVERSAL_DUTY;
    swingup_peak_detector u_peak_detector (
        .clk(clk), .rst_n(rst_n), .tick(tick),
        .enable(enable && kick_done && PEAK_MODE),
        .theta_abs_counts(theta_abs_counts), .theta_dot(theta_dot), .peak_pulse(peak_pulse));

    reg [15:0] kick_count;
    reg [1:0] last_drive_dir;
    wire kick_active = (kick_count < kick_frames);
    wire energy_drive_valid = (magnitude_s8 >= `SWINGUP_MIN_PRODUCT);
    wire [15:0] requested_duty = {8'd0,`SWINGUP_MIN_DUTY} + {8'd0,scaled_drive_limited};
    wire [1:0] energy_drive_dir = (negative_s8 ^ `SWINGUP_MOTOR_INVERT) ? 2'b10 : 2'b01;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            peak_pending <= 0;
            peak_drive_dir <= `SWINGUP_KICK_DIR;
            peak_boost_remaining <= 0;
            kick_count <= 16'd0;
            last_drive_dir <= 2'b00;
            kick_done <= 1'b0;
            motor_dir <= 2'b00;
            duty <= 8'd0;
            energy_error_mon <= 16'sd0;
        end else if (!enable) begin
            peak_pending <= 0;
            peak_drive_dir <= `SWINGUP_KICK_DIR;
            peak_boost_remaining <= 0;
            kick_count <= 16'd0;
            last_drive_dir <= 2'b00;
            kick_done <= 1'b0;
            motor_dir <= 2'b00;
            duty <= 8'd0;
            energy_error_mon <= 16'sd0;
        end else begin
          if (peak_pulse) peak_pending <= 1;
          if (valid_pipe[7]) begin
            energy_error_mon <= (error_s8 > 18'sd32767) ? 16'sd32767 :
                (error_s8 < -18'sd32768) ? -16'sd32768 : error_s8[15:0];
            if (!kick_done && kick_active) begin
                kick_count <= kick_count + 1'b1;
                motor_dir <= `SWINGUP_KICK_DIR;
                last_drive_dir <= `SWINGUP_KICK_DIR;
                duty <= `SWINGUP_KICK_DUTY;
            end else begin
                kick_done <= 1'b1;
                if (PEAK_MODE && peak_pending) begin
                    // Reverse ONLY at the detected elevation maximum.
                    // The event bypasses the zero-speed energy deadzone.
                    peak_pending <= 0;
                    peak_drive_dir <= reversed_peak_dir;
                    last_drive_dir <= reversed_peak_dir;
                    motor_dir <= reversed_peak_dir;
                    duty <= peak_boost_duty;
                    peak_boost_remaining <= `SWINGUP_PEAK_BOOST_FRAMES - 1'b1;
                end else if (PEAK_MODE && peak_boost_remaining != 0) begin
                    motor_dir <= peak_drive_dir;
                    duty <= peak_boost_duty;
                    peak_boost_remaining <= peak_boost_remaining - 1'b1;
                end else if (PEAK_MODE) begin
                    // Energy regulates magnitude between peaks; direction is
                    // held until the next peak, rather than flipping at horizontal.
                    if (energy_drive_valid && error_s8 > 0) begin
                        motor_dir <= peak_drive_dir;
                        last_drive_dir <= peak_drive_dir;
                        duty <= requested_duty > `SWINGUP_PWM_DUTY_LIMIT ?
                                `SWINGUP_PWM_DUTY_LIMIT : requested_duty[7:0];
                    end else begin
                        motor_dir <= 0;
                        duty <= 0;
                    end
                end else if (energy_drive_valid) begin
                    // alpha torque sign is a board/mechanics polarity; keep it
                    // explicit because it must be verified with the motor lifted.
                    motor_dir <= energy_drive_dir;
                    last_drive_dir <= energy_drive_dir;
                    if (last_drive_dir != 2'b00 && energy_drive_dir != last_drive_dir)
                        duty <= (`SWINGUP_REVERSAL_DUTY > `SWINGUP_PWM_DUTY_LIMIT) ?
                            `SWINGUP_PWM_DUTY_LIMIT : `SWINGUP_REVERSAL_DUTY;
                    else duty <= (requested_duty > `SWINGUP_PWM_DUTY_LIMIT) ?
                        `SWINGUP_PWM_DUTY_LIMIT : requested_duty[7:0];
                end else begin
                    motor_dir <= 2'b00;
                    duty <= 8'd0;
                end
            end
          end
        end
    end
endmodule
