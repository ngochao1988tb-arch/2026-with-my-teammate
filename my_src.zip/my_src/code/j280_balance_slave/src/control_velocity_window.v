`timescale 1ns/1ps
`include "system_params.vh"
// Position endpoint differences across exactly WINDOW_FRAMES sample intervals.
// Both positions are captured on the ADC sample tick; output is ready one clock later.
module control_velocity_window #(
    parameter WINDOW_FRAMES = `CONTROL_VELOCITY_WINDOW_FRAMES,
    parameter VELOCITY_MULTIPLIER = `CONTROL_VELOCITY_WINDOW_SCALE
)(
    input clk_50m, rst_n, clear_window, sample_tick,
    input [11:0] theta_position,
    input [15:0] alpha_position,
    output reg signed [15:0] theta_velocity,
    output reg signed [19:0] alpha_velocity_q4,
    output reg velocity_valid
);
    localparam INDEX_BITS = (WINDOW_FRAMES>1) ? $clog2(WINDOW_FRAMES) : 1;
    localparam COUNT_BITS = $clog2(WINDOW_FRAMES+1);
    reg [11:0] theta_history [0:WINDOW_FRAMES-1];
    reg [15:0] alpha_history [0:WINDOW_FRAMES-1];
    reg [INDEX_BITS-1:0] history_index;
    reg [COUNT_BITS-1:0] history_count;
    reg stage_tick, stage_valid;
    reg [11:0] theta_current, theta_previous;
    reg [15:0] alpha_current, alpha_previous;
    wire signed [12:0] theta_delta = $signed({1'b0,theta_current}) - $signed({1'b0,theta_previous});
    wire signed [12:0] theta_delta_wrapped =
        theta_delta > 13'sd2048 ? theta_delta-13'sd4096 :
        theta_delta < -13'sd2048 ? theta_delta+13'sd4096 : theta_delta;
    wire signed [15:0] alpha_delta = alpha_current-alpha_previous;
    // Normalize 1ms endpoint differences to the retained counts/3ms units.
    wire signed [15:0] theta_normalized = $signed(theta_delta_wrapped) * VELOCITY_MULTIPLIER;
    wire signed [35:0] alpha_normalized = $signed(alpha_delta) * (VELOCITY_MULTIPLIER * 36'sd16);
    wire signed [19:0] alpha_normalized_limited =
        alpha_normalized > 36'sd524287 ? 20'sd524287 :
        alpha_normalized < -36'sd524288 ? -20'sd524288 : alpha_normalized[19:0];
    always @(posedge clk_50m or negedge rst_n) begin
        if (!rst_n) begin
            history_index <= 0; history_count <= 0; stage_tick <= 0; stage_valid <= 0;
            theta_current <= 0; theta_previous <= 0; alpha_current <= 0; alpha_previous <= 0;
            theta_velocity <= 0; alpha_velocity_q4 <= 0; velocity_valid <= 0;
        end else if (clear_window) begin
            history_index <= 0; history_count <= 0; stage_tick <= 0; stage_valid <= 0;
            theta_velocity <= 0; alpha_velocity_q4 <= 0; velocity_valid <= 0;
        end else begin
            stage_tick <= sample_tick;
            if (sample_tick) begin
                theta_current <= theta_position; alpha_current <= alpha_position;
                theta_previous <= theta_history[history_index];
                alpha_previous <= alpha_history[history_index];
                theta_history[history_index] <= theta_position;
                alpha_history[history_index] <= alpha_position;
                stage_valid <= history_count == WINDOW_FRAMES;
                if (history_count < WINDOW_FRAMES) history_count <= history_count+1'b1;
                history_index <= history_index == WINDOW_FRAMES-1 ? 0 : history_index+1'b1;
            end
            if (stage_tick) begin
                velocity_valid <= stage_valid;
                theta_velocity <= stage_valid ? theta_normalized : 16'sd0;
                alpha_velocity_q4 <= stage_valid ? alpha_normalized_limited : 20'sd0;
            end
        end
    end
endmodule
