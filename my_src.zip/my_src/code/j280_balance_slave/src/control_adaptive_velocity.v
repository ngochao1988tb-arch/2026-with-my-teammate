`timescale 1ns/1ps
`include "system_params.vh"
// Second-order IIR: two cascaded adaptive first-order low-pass sections.
// Both sections use the same current-frame motion-dependent gain. Small displacements
// use stronger smoothing; larger motion selects a faster response.
// Q16 state retains sub-count velocity. Output commits at sample+6 clocks.
module control_adaptive_velocity #(
    parameter THETA_SLOW_LIMIT = `ADAPTIVE_THETA_SLOW_LIMIT,
    parameter THETA_FAST_LIMIT = `ADAPTIVE_THETA_FAST_LIMIT,
    parameter ALPHA_SLOW_LIMIT = `ADAPTIVE_ALPHA_SLOW_LIMIT,
    parameter ALPHA_FAST_LIMIT = `ADAPTIVE_ALPHA_FAST_LIMIT,
    parameter SLOW_SHIFT = `ADAPTIVE_SLOW_SHIFT,
    parameter MID_SHIFT = `ADAPTIVE_MID_SHIFT,
    parameter FAST_SHIFT = `ADAPTIVE_FAST_SHIFT
)(
    input clk_50m, rst_n, clear_filter, sample_tick,
    input [11:0] theta_position,
    input [15:0] alpha_position,
    output reg signed [15:0] theta_velocity,
    output reg signed [19:0] alpha_velocity_q4,
    output reg velocity_valid
);
    reg initialized;
    reg [5:0] pending;
    reg [11:0] theta_previous;
    reg [15:0] alpha_previous;
    // Width-limited subtraction gives shortest signed modular displacement.
    wire signed [11:0] theta_delta = theta_position - theta_previous;
    wire signed [15:0] alpha_delta = alpha_position - alpha_previous;
    reg signed [11:0] theta_delta_s0;
    reg signed [15:0] alpha_delta_s0;
    wire [11:0] theta_magnitude = theta_delta_s0 < 0 ? -theta_delta_s0 : theta_delta_s0;
    wire [15:0] alpha_magnitude = alpha_delta_s0 < 0 ? -alpha_delta_s0 : alpha_delta_s0;
    reg signed [31:0] theta_target, alpha_target;
    reg [4:0] theta_shift, alpha_shift;
    reg signed [31:0] theta_rate, alpha_rate; // first section
    reg signed [31:0] theta_rate2, alpha_rate2; // second section

    // Enough guard bits for the largest configured shift, including sign.
    localparam MAX_SHIFT_SM = SLOW_SHIFT > MID_SHIFT ? SLOW_SHIFT : MID_SHIFT;
    localparam MAX_SHIFT = MAX_SHIFT_SM > FAST_SHIFT ? MAX_SHIFT_SM : FAST_SHIFT;
    localparam SUM_WIDTH = 33 + MAX_SHIFT;
    reg signed [SUM_WIDTH-1:0] theta_sum, alpha_sum;
    reg signed [SUM_WIDTH-1:0] theta_sum2, alpha_sum2;
    // Split weighted addition and symmetric division across two clocks.
    function signed [SUM_WIDTH-1:0] weighted_sum;
        input signed [31:0] previous, target;
        input [4:0] shift;
        reg signed [SUM_WIDTH-1:0] wide_previous, wide_target;
        begin
            wide_previous = {{(SUM_WIDTH-32){previous[31]}}, previous};
            wide_target = {{(SUM_WIDTH-32){target[31]}}, target};
            weighted_sum = (wide_previous <<< shift) - wide_previous + wide_target;
        end
    endfunction
    // y = ((2^shift - 1)*y_previous + x) / 2^shift.
    // Truncate toward zero: stationary inputs decay without negative residue.
    function signed [31:0] divide_sum;
        input signed [SUM_WIDTH-1:0] numerator;
        input [4:0] shift;
        reg [SUM_WIDTH-1:0] magnitude, quotient;
        reg signed [SUM_WIDTH-1:0] signed_result;
        begin
            magnitude = numerator < 0 ? -numerator : numerator;
            quotient = magnitude >> shift;
            signed_result = numerator < 0 ? -$signed(quotient) : $signed(quotient);
            // A weighted mean of two signed 32-bit values fits signed 32 bits.
            divide_sum = signed_result[31:0];
        end
    endfunction
    function signed [41:0] truncate_q16;
        input signed [41:0] value;
        reg [41:0] magnitude;
        begin
            magnitude = value < 0 ? -value : value;
            truncate_q16 = value < 0 ? -$signed(magnitude >> 16) :
                                      $signed(magnitude >> 16);
        end
    endfunction
    wire signed [41:0] theta_scaled = $signed(theta_rate2) * (42'sd1 * `CONTROL_VELOCITY_MULTIPLIER);
    wire signed [41:0] alpha_scaled = $signed(alpha_rate2) * (42'sd16 * `CONTROL_VELOCITY_MULTIPLIER);
    wire signed [41:0] theta_output = truncate_q16(theta_scaled);
    wire signed [41:0] alpha_output = truncate_q16(alpha_scaled);
    always @(posedge clk_50m or negedge rst_n) begin
        if (!rst_n) begin
            initialized <= 0; pending <= 0; velocity_valid <= 0;
            theta_previous <= 0; alpha_previous <= 0;
            theta_delta_s0 <= 0; alpha_delta_s0 <= 0;
            theta_target <= 0; alpha_target <= 0;
            theta_sum <= 0; alpha_sum <= 0;
            theta_sum2 <= 0; alpha_sum2 <= 0;
            theta_shift <= SLOW_SHIFT; alpha_shift <= SLOW_SHIFT;
            theta_rate <= 0; alpha_rate <= 0;
            theta_rate2 <= 0; alpha_rate2 <= 0;
            theta_velocity <= 0; alpha_velocity_q4 <= 0;
        end else if (clear_filter) begin
            initialized <= 0; pending <= 0; velocity_valid <= 0;
            theta_rate <= 0; alpha_rate <= 0;
            theta_rate2 <= 0; alpha_rate2 <= 0;
            theta_velocity <= 0; alpha_velocity_q4 <= 0;
        end else begin
            pending <= {pending[4:0], sample_tick && initialized};
            if (sample_tick) begin
                theta_previous <= theta_position;
                alpha_previous <= alpha_position;
                if (!initialized) begin
                    initialized <= 1;
                    theta_rate <= 0; alpha_rate <= 0;
                    theta_rate2 <= 0; alpha_rate2 <= 0;
                end else begin
                    theta_delta_s0 <= theta_delta;
                    alpha_delta_s0 <= alpha_delta;
                end
            end
            if (pending[0]) begin
                theta_target <= {{4{theta_delta_s0[11]}}, theta_delta_s0, 16'd0};
                alpha_target <= {alpha_delta_s0, 16'd0};
                theta_shift <= theta_magnitude <= THETA_SLOW_LIMIT ? SLOW_SHIFT :
                               theta_magnitude >= THETA_FAST_LIMIT ? FAST_SHIFT : MID_SHIFT;
                alpha_shift <= alpha_magnitude <= ALPHA_SLOW_LIMIT ? SLOW_SHIFT :
                               alpha_magnitude >= ALPHA_FAST_LIMIT ? FAST_SHIFT : MID_SHIFT;
            end
            if (pending[1]) begin
                theta_sum <= weighted_sum(theta_rate, theta_target, theta_shift);
                alpha_sum <= weighted_sum(alpha_rate, alpha_target, alpha_shift);
            end
            if (pending[2]) begin
                theta_rate <= divide_sum(theta_sum, theta_shift);
                alpha_rate <= divide_sum(alpha_sum, alpha_shift);
            end
            if (pending[3]) begin
                // Use the newly committed first-section value from this frame.
                theta_sum2 <= weighted_sum(theta_rate2, theta_rate, theta_shift);
                alpha_sum2 <= weighted_sum(alpha_rate2, alpha_rate, alpha_shift);
            end
            if (pending[4]) begin
                theta_rate2 <= divide_sum(theta_sum2, theta_shift);
                alpha_rate2 <= divide_sum(alpha_sum2, alpha_shift);
            end
            if (pending[5]) begin
                theta_velocity <= theta_output > 32767 ? 16'sd32767 :
                    theta_output < -32768 ? -16'sd32768 : theta_output[15:0];
                alpha_velocity_q4 <= alpha_output > 524287 ? 20'sd524287 :
                    alpha_output < -524288 ? -20'sd524288 : alpha_output[19:0];
                // Ready flag stays asserted until clear, as in the old interface.
                velocity_valid <= 1;
            end
        end
    end
endmodule
