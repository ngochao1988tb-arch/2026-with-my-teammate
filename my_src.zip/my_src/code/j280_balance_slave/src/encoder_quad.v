

`timescale 1ns / 1ps
`include "system_params.vh"

module encoder_quad #(
    parameter INIT_POS    = `ENCODER_INIT_POS,
    parameter FILTER_MODE = 1                  // 0: 无滤波直出(延时100us); 1: 轻度平滑(alpha=0.5, 延时约0.2ms); 2: 强阻尼(alpha=0.75, 延时约0.4ms)
)(
    input                    clk_50m,
    input                    rst_n,
    input                    tick_3ms,             // 来自ADC的100us节拍（保留原端口名）

    input                    enc_a,                // 编码器 A 相物理输入
    input                    enc_b,                // 编码器 B 相物理输入

    output reg        [15:0] pos,                  // 16位绝对累计位置
    output reg signed [15:0] vel,                  // 16位对称舍入速度估计 (脉冲数 / 3ms)
    output reg        [15:0] illegal_trans_cnt,    // 非法正交跳变计数器
    output reg        [15:0] sampled_pos,          // 与本帧速度对应的位置
    output reg signed [19:0] vel_q4               // 控制反馈保留4位小数
);

    // -----------------------------------------------------------------------------
    // 1. A/B 相输入 2 级同步打拍防亚稳态 + 2 周期数字去毛刺滤波
    // -----------------------------------------------------------------------------
    reg [1:0] sync_a, sync_b;
    always @(posedge clk_50m or negedge rst_n) begin
        if (!rst_n) begin
            sync_a <= 2'b00;
            sync_b <= 2'b00;
        end else begin
            sync_a <= {sync_a[0], enc_a};
            sync_b <= {sync_b[0], enc_b};
        end
    end

    // 2 周期数字毛刺消除 (80ns 持续稳定电平判定)
    reg [2:0] filter_cnt_a, filter_cnt_b;
    reg       a_debounced, b_debounced;

    always @(posedge clk_50m or negedge rst_n) begin
        if (!rst_n) begin
            filter_cnt_a <= 3'd0;
            a_debounced  <= 1'b0;
        end else if (sync_a[1] != a_debounced) begin
            if (filter_cnt_a >= (`SYS_CLK_FREQ_HZ / 10_000_000 - 1)) begin
                a_debounced  <= sync_a[1];
                filter_cnt_a <= 3'd0;
            end else begin
                filter_cnt_a <= filter_cnt_a + 1'b1;
            end
        end else begin
            filter_cnt_a <= 3'd0;
        end
    end

    always @(posedge clk_50m or negedge rst_n) begin
        if (!rst_n) begin
            filter_cnt_b <= 3'd0;
            b_debounced  <= 1'b0;
        end else if (sync_b[1] != b_debounced) begin
            if (filter_cnt_b >= (`SYS_CLK_FREQ_HZ / 10_000_000 - 1)) begin
                b_debounced  <= sync_b[1];
                filter_cnt_b <= 3'd0;
            end else begin
                filter_cnt_b <= filter_cnt_b + 1'b1;
            end
        end else begin
            filter_cnt_b <= 3'd0;
        end
    end

    // -----------------------------------------------------------------------------
    // 2. 4 倍频正交状态机、方向判别与非法跳变统计
    // -----------------------------------------------------------------------------
    reg [1:0] state_now;
    reg [1:0] state_last;

    always @(posedge clk_50m or negedge rst_n) begin
        if (!rst_n) begin
            state_now         <= 2'b00;
            state_last        <= 2'b00;
            pos               <= INIT_POS;
            illegal_trans_cnt <= 16'd0;
        end else begin
            state_now  <= `ENCODER_DIR_INVERT ? {b_debounced, a_debounced} : {a_debounced, b_debounced};
            state_last <= state_now;

            case ({state_last, state_now})
                // 正转增加脉冲 (CW)
                4'b00_10,
                4'b10_11,
                4'b11_01,
                4'b01_00: pos <= pos + 1'b1;

                // 反转减少脉冲 (CCW)
                4'b00_01,
                4'b01_11,
                4'b11_10,
                4'b10_00: pos <= pos - 1'b1;

                // 保持不变
                4'b00_00,
                4'b01_01,
                4'b10_10,
                4'b11_11: pos <= pos;

                // 非法跨相跳变 (00<->11, 01<->10)，统计丢计数故障
                default: begin
                    pos               <= pos;
                    illegal_trans_cnt <= illegal_trans_cnt + 1'b1;
                end
            endcase
        end
    end

    // -----------------------------------------------------------------------------
    // 3. 3.0ms 速度差分计算 (16 位无损溢出回绕) 与 Q4 对称舍入滤波
    // -----------------------------------------------------------------------------
    reg [15:0] pos_prev;

    // 采用无符号模减法天然消除 0~65535 跨界翻转缺陷:
    // 例如: pos从 65535 变为 2 (正转3步): (2 - 65535) = 3;
    //       pos从 0 变为 65534 (反转2步): (65534 - 0) = 16'hFFFE = -2.
    wire [15:0]        diff_u = pos - pos_prev;
    wire signed [15:0] diff_s = diff_u;

    // 内部保留 4 位小数 (Q4 定点格式)，防止微小速度在定点截断时向负无穷单向漂移
    reg signed [23:0] vel_accum_q4;
    // Capture the exact frame difference, then normalize and filter in two stages.
    // Top-level control_tick waits until the matching position/velocity are ready.
    reg signed [15:0] diff_stage;
    reg [15:0] sampled_pos_stage;
    reg signed [23:0] diff_q4;
    reg [1:0] velocity_valid;
    wire signed [23:0] diff_q4_full = {{4{diff_stage[15]}}, diff_stage, 4'b0000};

    // Truncate the filter update toward zero: no permanent -1 fractional residue.
    wire signed [23:0] filter_sum = (FILTER_MODE == 2) ?
        (vel_accum_q4 * 24'sd3 + diff_q4) : (vel_accum_q4 + diff_q4);
    wire [23:0] filter_mag = (filter_sum < 0) ? -filter_sum : filter_sum;
    wire [23:0] filtered_mag = filter_mag >> ((FILTER_MODE == 2) ? 2 : 1);
    wire signed [23:0] next_q4 = (FILTER_MODE == 0) ? diff_q4 :
        ((filter_sum < 0) ? -$signed(filtered_mag) : $signed(filtered_mag));
    wire [23:0] next_mag = (next_q4 < 0) ? -next_q4 : next_q4;
    wire [23:0] rounded_mag = (next_mag + 24'd8) >> 4;
    wire signed [23:0] rounded_vel = (next_q4 < 0) ?
        -$signed(rounded_mag) : $signed(rounded_mag);

    always @(posedge clk_50m or negedge rst_n) begin
        if (!rst_n) begin
            diff_stage <= 0; sampled_pos_stage <= INIT_POS;
            diff_q4 <= 0; velocity_valid <= 0;
            pos_prev       <= INIT_POS;
            vel_accum_q4   <= 24'sd0;
            vel            <= 16'sd0;
            vel_q4         <= 20'sd0;
            sampled_pos    <= INIT_POS;
        end else begin
            velocity_valid <= {velocity_valid[0],tick_3ms};
            if (tick_3ms) begin
                pos_prev <= pos; sampled_pos_stage <= pos; diff_stage <= diff_s;
            end
            if (velocity_valid[0]) diff_q4 <= diff_q4_full * `CONTROL_VELOCITY_MULTIPLIER;
            if (velocity_valid[1]) begin
                sampled_pos <= sampled_pos_stage;
                vel_accum_q4 <= next_q4;
                vel_q4 <= next_q4[19:0];
                vel <= rounded_vel[15:0];
            end
        end
    end

endmodule
