// J280 balance-only configuration. Previous source is in backups/pre_codex_20260913_151817.
`ifndef _SYSTEM_PARAMS_VH_
`define _SYSTEM_PARAMS_VH_

// Enable / physical channel. XH1=A is the recorded motor connection.
`define MOTOR_HARDWARE_ENABLE         1'b1
`define CLOSED_LOOP_ENABLE            1'b1
`define MOTOR_CHANNEL_SELECT          1'b0

// 2026-11-02 response trial: theta restoring gain +7.7%; damping unchanged.
// Alpha signs provide arm centering and velocity damping for the recorded
// convention: CW jog increases encoder position.
`define LQR_GAIN_SHIFT                8
`define PARAM_K_THETA                 16'sd280
`define PARAM_K_THETA_DOT             16'sd1200
`define PARAM_K_ALPHA                 -16'sd5
`define PARAM_K_ALPHA_DOT             -16'sd2500
// Small upright-angle deadband applied only to theta proportional/integral
// terms. Theta velocity damping remains active inside this band.
`define THETA_ERROR_DEADBAND          16'd4

// Arm position PID. These are intentionally lower-authority than the
// upright controller and may be summed after the existing alpha LQR feedback.
// The default output polarity matches the previously tested -K_alpha signs.
// Response trial: both handoff and steady-state P increase 200 -> 220.
`define ARM_PID_KP                    16'sd220
`define ARM_PID_KP_HANDOFF            16'sd220
`define ARM_PID_HANDOFF_FRAMES        32'd30000 // 100us frames = 3.0s
`define ARM_PID_HANDOFF_SLEW_FRAMES   32'd8192  // 100us frames = 0.8192s bumpless ramp
// 2026-10-30 diagnostic: disable position integral to test whether it causes
// the wide left-right limit cycle. Position Kp and damping stay unchanged.
`define ARM_PID_KI                    16'sd0
// 2026-10-30: stronger arm velocity damping for the wide slow limit cycle.
// 2026-11-02: position Kp=220; retain this velocity damping.
`define ARM_PID_KD                    16'sd220

`define ARM_PID_INTEGRAL_LIMIT        32'sd393210 // accumulator in 1/30 of the 3ms reference interval
`define ARM_PID_I_GAIN_SHIFT          6'd20
`define ARM_PID_OUTPUT_LIMIT           8'd100
`define ARM_PID_OUTPUT_INVERT          1'b0
// Extension 1: in BALANCE, tap SW2/SW3 to shift the arm target by 150 counts.
// One target count per 150 100us frames: 15ms/count, 2.25s per 150 counts.
`define ARM_POSITION_STEP_PULSES       16'd150
`define ARM_TARGET_SLEW_STEP           16'd1
`define ARM_TARGET_SLEW_INTERVAL       8'd150
`define ARM_POSITION_ERROR_DEADBAND   16'd8

// Slow theta integral trim. This removes long-term pendulum angle bias without
// changing the tuned LQR gains or the arm feedback terms.
// 2026-10-27 test: restore theta integral output authority.
`define THETA_I_KI                    16'sd2
`define THETA_I_GAIN_SHIFT             6'd9 // divide by INTEGRAL_TIME_SCALE after shift
`define THETA_I_ACCUM_LIMIT           32'sd1474560
`define THETA_I_OUTPUT_LIMIT           8'd60
`define THETA_I_ERROR_DEADBAND        16'sd2
// Leak stale theta bias while the upright angle is quiet but the arm still has a position error.
`define THETA_I_LEAK_SHIFT             6'd12 // 409.6ms leak constant (previous 384ms)
`define THETA_I_OUTPUT_INVERT          1'b0

// Original user-tuned capture and protection settings.
`define THETA_ENTRY_LIMIT             16'sd180
`define THETA_DOT_ENTRY_LIMIT         16'sd60
`define ARM_DOT_ENTRY_LIMIT           16'd10
// Two 3ms windows = 6ms; three calibration windows = 9ms.
`define STARTUP_WINDOW_FRAMES         5'd30
`define ENTRY_CONFIRM_CYCLES          8'd2
// SW1 calibration must observe stable sensor data before committing a new
// zero/target pair. Startup confirmation counts below are evaluated on 3ms velocity windows.
`define CALIBRATION_CONFIRM_CYCLES     8'd3
`define CALIBRATION_THETA_DOT_LIMIT    16'd25
`define CALIBRATION_ARM_DOT_LIMIT      16'd4
`define THETA_EXIT_LIMIT              16'sd350
`define MAX_ARM_TRAVEL_PULSES         16'd2150
`define MAX_ARM_VEL_PULSES            16'd500
`define SATURATION_TIMEOUT_CYCLES     12'd3000

// Manual swing-up tuning: SW1 starts from the ready hanging position.
// Initial start remains manual. After a balance fall, recover only at a settled hanging pose.
`define SWINGUP_ENABLE                1'b1
`define AUTO_SWINGUP_ENABLE           1'b0
// Fall-only restart: wait at least 500ms and 10 consecutive 3ms ready windows.
`ifndef AUTO_RESTART_ENABLE
`define AUTO_RESTART_ENABLE           1'b1
`endif
`define AUTO_RESTART_WAIT_FRAMES      16'd5000
`define AUTO_RESTART_CONFIRM_WINDOWS  8'd10
`define SWINGUP_PWM_DUTY_LIMIT        8'd253
`define SWINGUP_START_MIN             12'd1400
`define SWINGUP_START_MAX             12'd2048
`define SWINGUP_START_THETA_DOT_MAX   16'd12
`define SWINGUP_START_ARM_DOT_MAX     16'd4
// Swing-up capture only; standby entry retains THETA_DOT_ENTRY_LIMIT.
`define SWINGUP_CATCH_THETA_DOT_LIMIT 16'd75
`define SWINGUP_CATCH_CONFIRM_CYCLES  8'd1
`define SWINGUP_CATCH_ARM_DOT_LIMIT   16'd30
`define SWINGUP_TIMEOUT_FRAMES        17'd80010
`define SWINGUP_KICK_FRAMES           16'd1223
`define SWINGUP_KICK_DUTY             8'd242
`define SWINGUP_KICK_DIR              2'b01
`define SWINGUP_REVERSAL_DUTY          8'd253
`define SWINGUP_MOTOR_INVERT          1'b0
`define SWINGUP_MIN_DUTY              8'd182
`define SWINGUP_DUTY_SHIFT            18
`define SWINGUP_MIN_PRODUCT           33'd262144

// Peak-triggered reversal: one event per swing, then a 36.7 ms reverse pulse.
`define SWINGUP_PEAK_MODE             1'b1
`define SWINGUP_PEAK_BOOST_FRAMES     16'd367
`define SWINGUP_PEAK_COOLDOWN_FRAMES  16'd1200
`define SWINGUP_PEAK_MIN_RISE         13'd64
`define SWINGUP_PEAK_ANGLE_STEP       12'd4
`define SWINGUP_PEAK_ZERO_DOT         16'd4
`define SWINGUP_PEAK_TURN_DOT_MAX     16'd20
`define SWINGUP_PEAK_CAPTURE_GUARD    12'd240
`define SWINGUP_PEAK_BOTTOM_GUARD     12'd1984


// Data-informed candidate 2026-10-23. Fixed-arm decay informed the mechanical
// model; PWM startup observations set this motor mapping, not a torque conversion.
// At request magnitude 5: excess=4, ramp is full, applied POS=16 / NEG=17.
// Signed compensation: negative values reduce PWM magnitude; clamp at zero.
`define MAX_PWM_DUTY_LIMIT            8'd230
`define PWM_DEADBAND_POS              9'sd12
`define PWM_DEADBAND_NEG              9'sd13
// Optional half-count compensation, applied directly to PWM pulse width.
`define PWM_DEADBAND_POS_HALF         1'b0
`define PWM_DEADBAND_NEG_HALF         1'b0
`define PWM_DEADZONE_THRESH           8'd1
// Reach the measured deadband compensation over four command counts.
`define PWM_COMP_RAMP_COUNTS          5'd4
`define PWM_COMP_RAMP_SHIFT           2
`define JOG_PWM_DUTY                  8'd70
// Opt-in diagnostic candidate only; normal project keeps this disabled.
`define MOTOR_IDENT_ENABLE            1'b0

// Measured upright on 2026-10-27: 17s stable capture, theta_raw mean 227.6,
// median 228. ADC arithmetic wrap remains 4096, independent of the manual scale.
`define DEFAULT_THETA_ZERO            16'd228
`define DEFAULT_THETA_DOWNWARD        16'd2336
`define ENCODER_CPR_PULSES            16'd1075
`define ENCODER_INIT_POS              16'd10000
`define ENCODER_VEL_FILTER_MODE       1
`define ENCODER_DIR_INVERT            1'b0
`define THETA_DIR_INVERT              1'b1

// Legacy=9600bps, 10 bytes at20Hz (stream0),50Hz(stream1),2Hz(stream2).
// Debug UART stays 115200bps; transmit every 30 control frames (~333Hz).
// Fractional 156/157-clock slots: 16 samples =2500 clocks =100us.
// Velocity stays in counts/3ms; integral accumulators use 1/30 reference-frame elapsed-time units.
// Board input=50MHz, internal clock=25MHz; PWM=25MHz/2500=10kHz.
`define SYS_CLK_FREQ_HZ               32'd25_000_000
`define UART_BPS_DIV                  16'd2604
`define UART_DEBUG_BPS_DIV            ((`SYS_CLK_FREQ_HZ + 57600) / 115200)
`define TELEMETRY_DEBUG_ENABLE 1'b1
`define TELEMETRY_STREAM_MODE         0
`define ADC_SAMPLE_SUB_CNT            16'd157
`define CONTROL_LOOP_PERIOD_TICKS     32'd2_500
`define CONTROL_VELOCITY_MULTIPLIER   30
// Controller velocities: rolling 1ms endpoints x3, refreshed every 100us.
`define CONTROL_VELOCITY_WINDOW_FRAMES 10
`define CONTROL_VELOCITY_WINDOW_SCALE  3
// Historical adaptive IIR settings; inactive in the current Kalman top.
// Limits are absolute displacement counts/frame, before velocity scaling.
// Each section: a=1/(2^SHIFT), y=(1-a)*y_previous+a*x.
`define ADAPTIVE_THETA_SLOW_LIMIT    2
`define ADAPTIVE_THETA_FAST_LIMIT    8
`define ADAPTIVE_ALPHA_SLOW_LIMIT    1
`define ADAPTIVE_ALPHA_FAST_LIMIT    4
`define ADAPTIVE_SLOW_SHIFT          4
`define ADAPTIVE_MID_SHIFT           3
`define ADAPTIVE_FAST_SHIFT          1
// Active control estimator: independent steady-state Kalman gains per channel.
// Legacy shared defaults below are retained for old module instantiations.
// Steady-state Kalman gains (Q16), updated every 100us; output counts/3ms.
`define KALMAN_POSITION_GAIN_Q16      17'sd14564
`define KALMAN_VELOCITY_GAIN_Q16      17'sd1828
// Response-priority candidate: Q/R theta=0.0016, alpha=0.0006.
// A=[1 1;0 1], H=[1 0], Q=q*[.25 .5;.5 1], R=1.
// See verification/kalman_fastreturn_25mhz_20261102/candidate_evaluation.json.
`define KALMAN_THETA_POSITION_GAIN_Q16 17'sd16134
`define KALMAN_THETA_VELOCITY_GAIN_Q16 17'sd2276
`define KALMAN_ALPHA_POSITION_GAIN_Q16 17'sd13006
`define KALMAN_ALPHA_VELOCITY_GAIN_Q16 17'sd1437
// Nominal trial scales for dual-board angular telemetry/commands. Recalibrate on hardware.
`define SLAVE_THETA_COUNTS_PER_TURN   32'd4096
`define SLAVE_ARM_COUNTS_PER_TURN     32'd1000
// Signed command magnitude: 6000 units maps to 180 degrees (half a turn).
`define SLAVE_ARM_MAX_RELATIVE_ARG    16'd6000
`define INTEGRAL_TIME_SCALE           30
`define PWM_CARRIER_PERIOD            16'd2500
`endif
