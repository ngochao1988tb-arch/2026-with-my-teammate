`ifndef NN_SAFETY_FILTER_V
`define NN_SAFETY_FILTER_V
`timescale 1ns/1ps
module nn_safety_filter #(parameter ALLOW_LIVE=1, WARMUP_TICKS=50)(
 input clk,rst_n,control_tick,feature_tick,control_enable,hard_safe,authority_safe,
 input prediction_done,input [7:0] ood_mask,input signed [31:0] delta_q12,
 input mode_write,input [7:0] requested_mode,input invert,
 output reg [1:0] mode,output reg trip_latch,output arm_ready,request_ok,fresh,
 output signed [15:0] correction,output reg signed [15:0] filtered_q8,
 output reg [15:0] warmup_ticks,age_frames
);
 reg have_prediction;
 reg signed [2:0] output_pwm;
 reg signed [10:0] target_q8;
 wire value_valid=delta_q12>=-32'sd131072 && delta_q12<=32'sd131072;
 assign fresh=have_prediction && age_frames<600 && mode!=0;
 wire operational=control_enable && hard_safe && fresh && ood_mask==0 && value_valid;
 assign arm_ready=operational && warmup_ticks>=WARMUP_TICKS && !trip_latch && ALLOW_LIVE;
 assign request_ok=requested_mode<=1 || (requested_mode==2 && arm_ready);
 assign correction=(mode==2 && authority_safe) ? $signed({{13{output_pwm[2]}},output_pwm}) : 16'sd0;
 reg signed [31:0] raw_q8;
 reg signed [11:0] difference,quarter,next_filtered,rounded;
 always @* begin
  // Experimental lead gain: -1/8 PWM per predicted count, not a learned PWM label.
  raw_q8=delta_q12<0 ? ((-delta_q12) >>> 7) : -(delta_q12 >>> 7);
  if(invert) raw_q8=-raw_q8;
  if(raw_q8>512) raw_q8=512;else if(raw_q8< -512) raw_q8=-512;
  difference=$signed({target_q8[10],target_q8})-$signed({filtered_q8[10],filtered_q8[10:0]});
  quarter=difference<0 ? -((-difference) >>> 2) : difference >>> 2;
  next_filtered=$signed({filtered_q8[10],filtered_q8[10:0]})+quarter;
  rounded=next_filtered<0 ? -(((-next_filtered)+128) >>> 8) : (next_filtered+128) >>> 8;
 end
 always @(posedge clk or negedge rst_n) begin
  if(!rst_n) begin
   mode<=1;trip_latch<=0;have_prediction<=0;age_frames<=1000;
   warmup_ticks<=0;filtered_q8<=0;output_pwm<=0;target_q8<=0;
  end else begin
   if(prediction_done && value_valid) target_q8<=raw_q8[10:0];
   if(!control_enable || mode==0) begin have_prediction<=0;age_frames<=1000;end
   else if(prediction_done) begin have_prediction<=1;age_frames<=0;end
   else if(control_tick && age_frames<1000) age_frames<=age_frames+1'b1;
   if(!operational) warmup_ticks<=0;
   else if(feature_tick && warmup_ticks<WARMUP_TICKS) warmup_ticks<=warmup_ticks+1'b1;
   if(mode_write && requested_mode<=1) begin mode<=requested_mode[1:0];trip_latch<=0;end
   else if(mode==2 && !operational) begin mode<=1;trip_latch<=1;end
   else if(mode_write && requested_mode==2 && request_ok) mode<=2;
   if(mode!=2 || !operational || !authority_safe || (mode_write && requested_mode<=1)) begin
    filtered_q8<=0;output_pwm<=0;
   end else if(feature_tick) begin
    filtered_q8<={{4{next_filtered[11]}},next_filtered};
    if(rounded>$signed(output_pwm)+1) output_pwm<=output_pwm+1'b1;
    else if(rounded<$signed(output_pwm)-1) output_pwm<=output_pwm-1'b1;
    else output_pwm<=rounded[2:0];
   end
  end
 end
endmodule
`endif
