// =================================================================================
// 工程名称: J280 高云 FPGA 旋转倒立摆控制系统 (硬件现场验证版)
// 文件名称: lqr_controller.v
// 功能说明: 25MHz 连续同步流水线 LQR 控制器，5周期(200ns)极速计算，
//           采用绝对值对称舍入缩放消除正负偏置与低速死区，含单拍快速清空与饱和监控
// =================================================================================

`timescale 1ns / 1ps
`include "system_params.vh"

module lqr_controller (
    input                    clk_50m,
    input                    rst_n,
    input                    tick_3ms,             // 3.0ms 采样与控制节拍脉冲 (单周期触发)

    // 控制使能与保护门控
    input                    ctrl_enable,          // 控制总使能 (来自顶层 FSM: 仅在 BALANCE 状态有效)
    input                    flush_pipeline,       // 流水线紧急清空 (急停、退出平衡或零点标定时置1)

    // 状态观测输入 (在 tick_3ms 拍严格对齐采样)
    input             [15:0] calibrated_zero_val,  // 标定后的直立零点参考值
    input             [11:0] theta_raw,            // 实时 ADC 测量角度值 (12-bit)
    input      signed [15:0] theta_dot,            // 摆杆角速度 (LSB/3ms)
    input             [15:0] alpha_pos,            // 电机横臂当前脉冲位置
    input             [15:0] alpha_target_pos,     // 电机横臂期望平衡目标位置
    input      signed [19:0] alpha_dot,            // Q4: 16 * 脉冲/3ms

    // 可配置增益输入 (从系统参数传入)
    input      signed [15:0] k_theta,              // K1
    input      signed [15:0] k_theta_dot,          // K2
    input      signed [15:0] k_alpha,              // K3
    input      signed [15:0] k_alpha_dot,          // K4

    // 控制量输出至 TB6612 驱动
    output reg        [1:0]  motor_dir,            // 电机转向 (00:停, 01:CW, 10:CCW)
    output reg        [7:0]  duty_out,             // 输出 PWM 占空比 (0~255)
    output reg               calc_done_pulse,      // 本次控制计算就绪单周期指示
    output reg               saturated,            // 控制量达到硬限幅标志

    // 状态监控输出至遥测与安全检测
    output reg signed [15:0] theta_err_mon,        // 角度偏差监控 (对齐输入拍)
    output reg signed [15:0] alpha_err_mon,        // 位置偏差监控 (对齐输入拍)
    output reg signed [15:0] u_scaled_mon          // 饱和前定点控制量 (用于遥测分析)
);

    // -----------------------------------------------------------------------------
    // 状态误差提取 (考虑极性反转配置)
    // -----------------------------------------------------------------------------
    wire signed [16:0] raw_theta_diff = $signed({1'b0, 4'b0000, theta_raw}) - $signed({1'b0, calibrated_zero_val});
    // Match the top-level safety/entry error across the ADC 4096-count boundary.
    // The physical angle calibration does not change the ADC arithmetic period.
    wire signed [16:0] wrapped_theta_diff =
        (raw_theta_diff > 17'sd2048) ? raw_theta_diff - 17'sd4096 :
        (raw_theta_diff < -17'sd2048) ? raw_theta_diff + 17'sd4096 : raw_theta_diff;
    wire signed [15:0] theta_err_raw = `THETA_DIR_INVERT ?
        -wrapped_theta_diff[15:0] : wrapped_theta_diff[15:0];
    wire [15:0] theta_err_abs = (theta_err_raw < 0) ? -theta_err_raw : theta_err_raw;
    // Suppress only the upright-angle proportional term. The theta velocity
    // path remains live so the controller still damps motion through zero.
    wire signed [15:0] theta_err_in =
        (theta_err_abs <= `THETA_ERROR_DEADBAND) ? 16'sd0 : theta_err_raw;
    wire signed [15:0] theta_dot_in   = `THETA_DIR_INVERT ? -theta_dot : theta_dot;

    wire signed [16:0] raw_alpha_diff = $signed({1'b0, alpha_pos}) - $signed({1'b0, alpha_target_pos});
    wire signed [15:0] alpha_err_in   = raw_alpha_diff[15:0];
    wire signed [19:0] alpha_dot_in   = alpha_dot;

    // -----------------------------------------------------------------------------
    // 25MHz 5 级同步流水线 (Pipeline Latency = 5 Clocks = 200ns)
    // -----------------------------------------------------------------------------
    reg [4:0] pipe_vld;

    // Stage 0 寄存器: 状态锁存
    reg signed [15:0] s0_theta_err;
    reg signed [15:0] s0_theta_dot;
    reg signed [15:0] s0_alpha_err;
    reg signed [19:0] s0_alpha_dot;

    // Stage 1 寄存器: 4 路有符号乘法乘积
    reg signed [31:0] s1_prod_theta;
    reg signed [31:0] s1_prod_theta_dot;
    reg signed [31:0] s1_prod_alpha;
    reg signed [35:0] s1_prod_alpha_dot;

    // Separate gain magnitude multiplication from sign application. This avoids
    // Gowin's long constant-negative-multiply carry chain (e.g. -16*x).
    wire [15:0] km1 = k_theta < 0 ? -k_theta : k_theta;
    wire [15:0] km2 = k_theta_dot < 0 ? -k_theta_dot : k_theta_dot;
    wire [15:0] km3 = k_alpha < 0 ? -k_alpha : k_alpha;
    wire [15:0] km4 = k_alpha_dot < 0 ? -k_alpha_dot : k_alpha_dot;
    reg [3:0] gain_negative;
    reg signed [31:0] signed_p1,signed_p2,signed_p3;
    reg signed [35:0] signed_p4;

    // Stage 2 寄存器: 求和累加与反号
    reg signed [37:0] s2_sum_terms;

    // Stage 3 寄存器: Q8 对称定点舍入与 16 位饱和
    reg signed [15:0] s3_u_scaled;
    wire [15:0] s3_magnitude = s3_u_scaled < 0 ? -s3_u_scaled : s3_u_scaled;

    // All sum terms have four fractional state bits; gain scaling is separate.
    localparam TOTAL_SHIFT = `LQR_GAIN_SHIFT + 4;
    wire is_neg_sum = (s2_sum_terms < 0);
    wire [37:0] abs_sum_terms = is_neg_sum ? -s2_sum_terms : s2_sum_terms;
    wire [37:0] abs_sum_rounded = abs_sum_terms + (38'd1 << (TOTAL_SHIFT-1));
    wire [37:0] abs_scaled = abs_sum_rounded >> TOTAL_SHIFT;
    wire signed [37:0] term_theta = $signed({{6{signed_p1[31]}},signed_p1}) <<< 4;
    wire signed [37:0] term_theta_dot = $signed({{6{signed_p2[31]}},signed_p2}) <<< 4;
    wire signed [37:0] term_alpha = $signed({{6{signed_p3[31]}},signed_p3}) <<< 4;
    wire signed [37:0] term_alpha_dot = $signed({{2{signed_p4[35]}},signed_p4});

    always @(posedge clk_50m or negedge rst_n) begin
        if (!rst_n) begin
            pipe_vld           <= 5'b00000;
            gain_negative <= 0; signed_p1 <= 0; signed_p2 <= 0; signed_p3 <= 0; signed_p4 <= 0;
            s0_theta_err       <= 16'sd0;
            s0_theta_dot       <= 16'sd0;
            s0_alpha_err       <= 16'sd0;
            s0_alpha_dot       <= 20'sd0;
            s1_prod_theta      <= 32'sd0;
            s1_prod_theta_dot  <= 32'sd0;
            s1_prod_alpha      <= 32'sd0;
            s1_prod_alpha_dot  <= 36'sd0;
            s2_sum_terms       <= 38'sd0;
            s3_u_scaled        <= 16'sd0;
            motor_dir          <= 2'b00;
            duty_out           <= 8'd0;
            calc_done_pulse    <= 1'b0;
            saturated          <= 1'b0;
            theta_err_mon      <= 16'sd0;
            alpha_err_mon      <= 16'sd0;
            u_scaled_mon       <= 16'sd0;
        end else if (flush_pipeline || !ctrl_enable) begin
            // 关键安全门控: 故障、急停或非使能时立即单拍清空流水线并切断输出
            pipe_vld        <= 5'b00000;
            motor_dir       <= 2'b00;
            duty_out        <= 8'd0;
            calc_done_pulse <= 1'b0;
            saturated       <= 1'b0;
            u_scaled_mon    <= 16'sd0;
        end else begin
            // -------------------------------------------------------------------------
            // Stage 0: 在 tick_3ms 脉冲到来时同步锁存状态向量 (对齐全部4个状态)
            // -------------------------------------------------------------------------
            if (tick_3ms) begin
                s0_theta_err  <= theta_err_in;
                s0_theta_dot  <= theta_dot_in;
                s0_alpha_err  <= alpha_err_in;
                s0_alpha_dot  <= alpha_dot_in;
                theta_err_mon <= theta_err_raw;
                alpha_err_mon <= alpha_err_in;
                pipe_vld[0]   <= 1'b1;
            end else begin
                pipe_vld[0]   <= 1'b0;
            end

            // -------------------------------------------------------------------------
            // Stage 1 (Cycle 1): 4 路并行 16x16 有符号定点乘法
            // -------------------------------------------------------------------------
            pipe_vld[1] <= pipe_vld[0];
            if (pipe_vld[0]) begin
                s1_prod_theta     <= $signed({1'b0,km1}) * s0_theta_err;
                s1_prod_theta_dot <= $signed({1'b0,km2}) * s0_theta_dot;
                s1_prod_alpha     <= $signed({1'b0,km3}) * s0_alpha_err;
                s1_prod_alpha_dot <= $signed({1'b0,km4}) * s0_alpha_dot;
                gain_negative <= {k_alpha_dot[15],k_alpha[15],k_theta_dot[15],k_theta[15]};
            end

            // -------------------------------------------------------------------------
            // Extra system-clock stage for sign application; gain sign travels with data.
            pipe_vld[2] <= pipe_vld[1];
            if (pipe_vld[1]) begin
                signed_p1 <= gain_negative[0] ? -s1_prod_theta : s1_prod_theta;
                signed_p2 <= gain_negative[1] ? -s1_prod_theta_dot : s1_prod_theta_dot;
                signed_p3 <= gain_negative[2] ? -s1_prod_alpha : s1_prod_alpha;
                signed_p4 <= gain_negative[3] ? -s1_prod_alpha_dot : s1_prod_alpha_dot;
            end

            // Stage 3 (Cycle 3): 加法树汇总并取反: u_raw = -(P1 + P2 + P3 + P4)
            // -------------------------------------------------------------------------
            pipe_vld[3] <= pipe_vld[2];
            if (pipe_vld[2]) begin
                s2_sum_terms <= -(term_theta + term_theta_dot + term_alpha + term_alpha_dot);
            end

            // -------------------------------------------------------------------------
            // Stage 4 (Cycle 4): Q8 绝对值对称舍入缩放与 16 位饱和截断
            // -------------------------------------------------------------------------
            pipe_vld[4] <= pipe_vld[3];
            if (pipe_vld[3]) begin
                if (abs_scaled > 26'd32767) begin
                    s3_u_scaled <= is_neg_sum ? -16'sd32768 : 16'sd32767;
                end else begin
                    s3_u_scaled <= is_neg_sum ? (-abs_scaled[15:0]) : abs_scaled[15:0];
                end
            end

            // -------------------------------------------------------------------------
            // Stage 5 (Cycle 5): 转向判别、占空比硬限幅与输出寄存
            // -------------------------------------------------------------------------
            calc_done_pulse <= pipe_vld[4];
            if (pipe_vld[4]) begin
                u_scaled_mon <= s3_u_scaled;

                if (s3_u_scaled > 16'sd0) begin
                    motor_dir <= 2'b01; // CW 正转
                    if (s3_u_scaled >= $signed({8'd0, `MAX_PWM_DUTY_LIMIT})) begin
                        duty_out  <= `MAX_PWM_DUTY_LIMIT;
                        saturated <= 1'b1;
                    end else begin
                        duty_out  <= s3_u_scaled[7:0];
                        saturated <= 1'b0;
                    end
                end else if (s3_u_scaled < 16'sd0) begin
                    motor_dir <= 2'b10; // CCW 反转
                    // 对 -32768 边界做防溢出保护
                    if (s3_u_scaled == -16'sd32768 || (-s3_u_scaled) >= $signed({8'd0, `MAX_PWM_DUTY_LIMIT})) begin
                        duty_out  <= `MAX_PWM_DUTY_LIMIT;
                        saturated <= 1'b1;
                    end else begin
                        duty_out  <= s3_magnitude[7:0];
                        saturated <= 1'b0;
                    end
                end else begin
                    motor_dir <= 2'b00;
                    duty_out  <= 8'd0;
                    saturated <= 1'b0;
                end
            end
        end
    end

endmodule
