`ifndef NN_PREDICTOR_TRIAL_V
`define NN_PREDICTOR_TRIAL_V
`include "nn_core_q12.v"
`include "nn_safety_filter.v"
`timescale 1ns/1ps
module nn_predictor_trial(
 input clk,rst_n,control_tick,sample_tick,control_enable,hard_safe,authority_safe,
 input [15:0] position,active_target,final_target,
 input signed [15:0] theta_error,theta_dot,base_command,applied_pwm,
 input signed [19:0] arm_velocity_q4,
 input mode_write,input [7:0] requested_mode,input invert,
 input [31:0] frame_number,
 output signed [15:0] correction,output request_ok,
 output [1:0] mode,output trip_latch,output [255:0] debug_bank
);
 reg [3:0] history_count;
 reg signed [31:0] error_history[0:9];
 reg [15:0] held_target;
 reg filter_phase;
 wire signed [31:0] error_now=$signed({1'b0,active_target})-$signed({1'b0,position});
 wire target_fixed=active_target==final_target && active_target==held_target;
 // Exactly the 100 Hz capture edge used by training; old values provide causal lags.
 wire feature_tick=sample_tick && filter_phase;
 wire [255:0] features={
  ($signed({{16{applied_pwm[15]}},applied_pwm}) <<< 12),
  ($signed({{16{base_command[15]}},base_command}) <<< 12),
  ($signed({{16{theta_dot[15]}},theta_dot}) <<< 12),
  ($signed({{16{theta_error[15]}},theta_error}) <<< 12),
  ($signed({{12{arm_velocity_q4[19]}},arm_velocity_q4}) <<< 8),
  ((error_now-error_history[9]) <<< 12),
  ((error_now-error_history[3]) <<< 12),
  (error_now <<< 12)
 };
 wire busy,done,fresh,arm_ready;
 wire signed [31:0] delta_q12,future_q12;
 wire [7:0] ood_mask;
 wire signed [15:0] filtered_q8;
 wire [15:0] warmup_ticks,age_frames;
 reg [31:0] inference_count;
 reg signed [15:0] sample_error;
 wire start=sample_tick && control_enable && target_fixed && history_count>=10 && mode!=0 && !busy;
 integer k;
 always @(posedge clk or negedge rst_n) begin
  if(!rst_n) begin
   history_count<=0;held_target<=0;filter_phase<=0;inference_count<=0;sample_error<=0;
   for(k=0;k<10;k=k+1) error_history[k]<=0;
  end else begin
   if(!control_enable || !target_fixed) begin
    history_count<=0;held_target<=active_target;filter_phase<=0;
    for(k=0;k<10;k=k+1) error_history[k]<=0;
   end else if(sample_tick) begin
    filter_phase<=!filter_phase;
    for(k=9;k>0;k=k-1) error_history[k]<=error_history[k-1];
    error_history[0]<=error_now;
    if(history_count<10) history_count<=history_count+1'b1;
   end
   if(start) sample_error<=error_now[15:0];
   if(done) inference_count<=inference_count+1'b1;
  end
 end
 nn_core_q12 core(.clk(clk),.rst_n(rst_n),.enable(control_enable && target_fixed && mode!=0),.start(start),
  .features_q12(features),.busy(busy),.done(done),.delta_q12(delta_q12),
  .future_error_q12(future_q12),.ood_mask(ood_mask));
 nn_safety_filter filter(.clk(clk),.rst_n(rst_n),.control_tick(control_tick),.feature_tick(feature_tick),
  .control_enable(control_enable),.hard_safe(hard_safe && target_fixed && history_count>=10),.authority_safe(authority_safe),
  .prediction_done(done),.ood_mask(ood_mask),.delta_q12(delta_q12),
  .mode_write(mode_write),.requested_mode(requested_mode),.invert(invert),
  .mode(mode),.trip_latch(trip_latch),.arm_ready(arm_ready),.request_ok(request_ok),.fresh(fresh),
  .correction(correction),.filtered_q8(filtered_q8),.warmup_ticks(warmup_ticks),.age_frames(age_frames));
 wire [7:0] flags={1'b0,busy,trip_latch,(mode==2 && correction!=0),1'b1,arm_ready,(ood_mask!=0),fresh};
 assign debug_bank={ood_mask,4'd0,history_count,frame_number,inference_count,age_frames,warmup_ticks,
  filtered_q8,sample_error,future_q12,delta_q12,correction,flags,6'd0,mode,8'h02,8'h4e};
endmodule
`endif
