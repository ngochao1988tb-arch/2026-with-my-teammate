`timescale 1ns/1ps
`include "system_params.vh"
// Legacy mode preserves the existing display. Debug mode transmits every state and fault.
module uart_telemetry #(
    parameter DEBUG_MODE = `TELEMETRY_DEBUG_ENABLE,
    parameter BAUD_DIV = DEBUG_MODE ? `UART_DEBUG_BPS_DIV : `UART_BPS_DIV
)(
    input clk_50m, rst_n, tick_3ms, manual_trig,
    input [15:0] theta_raw_in, enc1_pos_in,
    input signed [15:0] theta_err_in, pwm_duty_signed_in,
    input [7:0] status_byte_in,
    input [31:0] frame_number_in,
    input signed [15:0] theta_dot_in, alpha_err_in,
    input signed [19:0] alpha_dot_q4_in,
    input signed [15:0] u_unclamped_in, requested_pwm_in,
    input [2:0] fault_cause_in,
    input [15:0] illegal_count_in,
    output uart_tx,
    input uart_rx
);
    localparam LENGTH = DEBUG_MODE ? 32 : 10;
    localparam LEGACY_PERIOD = (`TELEMETRY_STREAM_MODE==0) ? (`SYS_CLK_FREQ_HZ / 20) :
        (`TELEMETRY_STREAM_MODE==1) ? (`SYS_CLK_FREQ_HZ / 50) : (`SYS_CLK_FREQ_HZ / 2);
    reg [31:0] rate_count;
    reg legacy_pending;
    reg [7:0] packet[0:31];
    reg [7:0] live[0:31];
    integer n;
    reg [7:0] checksum;
    wire [23:0] aq4 = {{4{alpha_dot_q4_in[19]}},alpha_dot_q4_in};
    always @* begin
        for(n=0;n<32;n=n+1) live[n]=0;
        if(DEBUG_MODE) begin
            live[0]=8'ha5;live[1]=8'h5a;live[2]=1;live[3]=32;
            {live[4],live[5],live[6],live[7]}=frame_number_in;
            {live[8],live[9]}=theta_raw_in;
            {live[10],live[11]}=theta_err_in;
            {live[12],live[13]}=theta_dot_in;
            {live[14],live[15]}=enc1_pos_in;
            {live[16],live[17]}=alpha_err_in;
            {live[18],live[19],live[20]}=aq4;
            {live[21],live[22]}=u_unclamped_in;
            {live[23],live[24]}=requested_pwm_in;
            {live[25],live[26]}=pwm_duty_signed_in;
            live[27]=status_byte_in;live[28]={5'd0,fault_cause_in};
            {live[29],live[30]}=illegal_count_in;
            checksum=0;
            for(n=2;n<31;n=n+1) checksum=checksum ^ live[n];
            live[31]=checksum;
        end else begin
            live[0]=8'haa;live[1]=8'h55;
            {live[2],live[3]}=theta_raw_in;
            {live[4],live[5]}=enc1_pos_in;
            {live[6],live[7]}=theta_err_in;
            live[8]=8'h0d;live[9]=8'h0a;
            checksum=0;
        end
    end
    reg tx_busy;
    reg [5:0] byte_index;
    reg [3:0] bit_index;
    reg [15:0] baud_count;
    reg [9:0] shift_reg;
    assign uart_tx=tx_busy ? shift_reg[0] : 1'b1;
    wire send_now = tick_3ms && !tx_busy && (DEBUG_MODE || legacy_pending);
    integer j;
    always @(posedge clk_50m or negedge rst_n) begin
        if(!rst_n) begin
            rate_count<=0;legacy_pending<=0;tx_busy<=0;byte_index<=0;bit_index<=0;
            baud_count<=0;shift_reg<=10'h3ff;
            for(j=0;j<32;j=j+1) packet[j]<=0;
        end else begin
            if(rate_count>=LEGACY_PERIOD-1) begin
                rate_count<=0;legacy_pending<=1;
            end else rate_count<=rate_count+1'b1;
            if(manual_trig) legacy_pending<=1;
            if(send_now) begin
                for(j=0;j<32;j=j+1) packet[j]<=live[j];
                legacy_pending<=0;
                tx_busy<=1;byte_index<=0;bit_index<=0;baud_count<=BAUD_DIV-1;
                shift_reg<={1'b1,live[0],1'b0};
            end else if(tx_busy) begin
                if(baud_count==0) begin
                    baud_count<=BAUD_DIV-1;
                    if(bit_index==9) begin
                        if(byte_index==LENGTH-1) begin tx_busy<=0;shift_reg<=10'h3ff;end
                        else begin
                            byte_index<=byte_index+1'b1;bit_index<=0;
                            shift_reg<={1'b1,packet[byte_index+1'b1],1'b0};
                        end
                    end else begin
                        bit_index<=bit_index+1'b1;shift_reg<={1'b1,shift_reg[9:1]};
                    end
                end else baud_count<=baud_count-1'b1;
            end
        end
    end
endmodule
