`timescale 1ns/1ps
`include "system_params.vh"
// One bounded staircase per key hold. Release/repress starts a new staircase.
module motor_ident_profile #(
    parameter PULSE_TICKS=(`SYS_CLK_FREQ_HZ / 10), // 100 ms
    parameter GAP_TICKS=(`SYS_CLK_FREQ_HZ * 2 / 5) // 400 ms, including initial settling
)(input clk, rst_n, request, input [1:0] direction,
  output reg [7:0] duty);
    reg [31:0] elapsed;
    reg [2:0] step;
    reg done;
    reg [1:0] last_direction;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin elapsed<=0; step<=0; done<=0; last_direction<=0; end
        else if (!request || direction!=last_direction) begin
            elapsed<=0; step<=0; done<=0; last_direction<=direction;
        end else if (!done) begin
            if (elapsed==GAP_TICKS+PULSE_TICKS-1) begin
                elapsed<=0;
                if (step==6) done<=1;
                else step<=step+1'b1;
            end else elapsed<=elapsed+1'b1;
        end
    end
    always @* begin
        duty=0;
        if (request && direction==last_direction && !done && elapsed>=GAP_TICKS) begin
            case(step)
                0: duty=8; 1: duty=12; 2: duty=16; 3: duty=24;
                4: duty=32; 5: duty=48; 6: duty=64;
                default: duty=0;
            endcase
        end
    end
endmodule
