// =================================================================================
// 工程名称: J280 高云 FPGA 旋转倒立摆控制系统 (硬件现场验证版)
// 文件名称: j280_lqr_top.v
// 功能说明: 顶层系统集成模块，实现 ADC 同步采集、正交编码器解算、25MHz 同步流水线
//           四状态 LQR、TB6612 双通道并联驱动、原厂 9600bps 遥测与平滑接管状态机
// =================================================================================

`timescale 1ns / 1ps
`include "system_params.vh"
`include "arm_position_pid.v"
`include "control_kalman_velocity.v"
`include "motor_ident_profile.v"
`include "uart_remote.v"
`include "slave_hmi_adapter.v"
`include "nn_predictor_trial.v"

module j280_lqr_top (
    input             clk_50m,             // 50MHz 晶振输入 (管脚 M19, 3.3V)
    input             rst_n,               // 全局硬件复位 (管脚 AB3, SW5, 低有效)

    // 4路轻触按键开关 (SW1~SW4, 1.5V 弱上拉)
    input      [3:0]  key_sw,              // SW1:T18, SW2:R18, SW3:U20, SW4:T20

    // USB-UART Type-C 接口 (CH340N)
    output            uart_tx,             // 串口发送 (管脚 K20, 3.3V)
    input             uart_rx,             // 串口接收 (管脚 L20, 3.3V)

    // 3PA1030 10-Bit ADC 接口
    output            adc_clk,             // ADC 采样时钟 12.5MHz (管脚 G18, 3.3V)
    output            adc_oe_n,            // 输出使能低有效 (管脚 H20, 3.3V)
    output            adc_stby_n,          // 休眠控制 (管脚未引出，顶层置0)
    input      [9:0]  adc_data_in,         // 10-bit 并行数据输入 (E19~L21)

    // TB6612FNG 电机通道 A (XH1 接口)
    output            PWMA,                // 电机 A PWM 输出 (管脚 Y18, 3.3V)
    output            AN1,                 // 电机 A 转向 1 (管脚 Y17, 3.3V)
    output            AN2,                 // 电机 A 转向 2 (管脚 Y19, 3.3V)

    // TB6612FNG 电机通道 B (XH2 接口)
    output            PWMB,                // 电机 B PWM 输出 (管脚 V14, 3.3V)
    output            BN1,                 // 电机 B 转向 1 (管脚 V15, 3.3V)
    output            BN2,                 // 电机 B 转向 2 (管脚 AA17, 3.3V)

    // 编码器接口
    input             enc1_a,              // 编码器 1 A相 (管脚 Y20, 3.3V)
    input             enc1_b,              // 编码器 1 B相 (管脚 AA20, 3.3V)
    input             remote_uart_rx,              // Remote UART RX, W7, 3.3V
    output            remote_uart_tx               // Remote UART TX, W8, 3.3V
);

    // Board oscillator remains 50 MHz. Every functional block below uses
    // the divided 25 MHz clock; legacy child port names clk_50m are retained.
    reg clk_sys /* synthesis syn_preserve=1 syn_keep=1 */;
    always @(posedge clk_50m or negedge rst_n) begin
        if (!rst_n) clk_sys <= 1'b0;
        else clk_sys <= ~clk_sys;
    end

    // -----------------------------------------------------------------------------
    // 1. 按键消抖模块 (SW1~SW4)
    // -----------------------------------------------------------------------------
    wire [3:0] key_pulse, key_state;
    key_debouncer #(.DEBOUNCE_TICKS(`SYS_CLK_FREQ_HZ / 100)) u_debouncer (
        .clk(clk_sys), .rst_n(rst_n), .key_raw(key_sw),
        .key_pressed_pulse(key_pulse), .key_state(key_state));

    wire remote_start, remote_stop, remote_hold_target, remote_plus, remote_minus;
    reg remote_stop_latch;
    wire sw_calib_pulse = key_pulse[0] || remote_start;
    wire sw_estop_pulse = key_pulse[3];
    wire jog_cw_active  = key_state[1] && !key_state[2];
    wire jog_ccw_active = key_state[2] && !key_state[1];
    wire raw_jog_request = jog_cw_active || jog_ccw_active;
    wire jog_conflict   = key_state[1] && key_state[2];
    reg swingup_trigger_lockout;
    wire jog_request = raw_jog_request && !swingup_trigger_lockout;
    wire swingup_request = !`MOTOR_IDENT_ENABLE && jog_conflict && !swingup_trigger_lockout;

    // -----------------------------------------------------------------------------
    // 2. ADC 3PA1030 采样模块 (16点中值，100us帧，速度保持counts/3ms单位)
    // -----------------------------------------------------------------------------
    wire tick_3ms;
    wire [11:0] theta_raw_12b;
    wire signed [15:0] theta_dot_raw;
    adc_3pa1030_sync u_adc (
        .clk_50m(clk_sys), .rst_n(rst_n), .adc_clk(adc_clk),
        .adc_oe_n(adc_oe_n), .adc_stby_n(adc_stby_n), .adc_data_in(adc_data_in),
        .adc_valid_3ms(tick_3ms), .theta_raw_12b(theta_raw_12b), .theta_dot_raw(theta_dot_raw));

    // -----------------------------------------------------------------------------
    // 3. 编码器解算模块
    // -----------------------------------------------------------------------------
    wire [15:0] enc1_pos, enc1_sampled_pos, enc1_illegal_trans;
    wire signed [15:0] enc1_vel;
    wire signed [19:0] enc1_vel_q4;
    encoder_quad #(.INIT_POS(`ENCODER_INIT_POS), .FILTER_MODE(`ENCODER_VEL_FILTER_MODE)) u_encoder_1 (
        .clk_50m(clk_sys), .rst_n(rst_n), .tick_3ms(tick_3ms),
        .enc_a(enc1_a), .enc_b(enc1_b), .pos(enc1_pos), .vel(enc1_vel),
        .sampled_pos(enc1_sampled_pos), .vel_q4(enc1_vel_q4), .illegal_trans_cnt(enc1_illegal_trans));

    wire signed [15:0] control_theta_velocity;
    wire signed [19:0] control_alpha_velocity_q4;
    wire control_velocity_valid;
    wire sample_timeout;
    control_kalman_velocity #(
        .THETA_POSITION_GAIN(`KALMAN_THETA_POSITION_GAIN_Q16),
        .THETA_VELOCITY_GAIN(`KALMAN_THETA_VELOCITY_GAIN_Q16),
        .ALPHA_POSITION_GAIN(`KALMAN_ALPHA_POSITION_GAIN_Q16),
        .ALPHA_VELOCITY_GAIN(`KALMAN_ALPHA_VELOCITY_GAIN_Q16)
    ) u_control_kalman (
        .clk_50m(clk_sys), .rst_n(rst_n),
        .clear_filter((sw_calib_pulse && !`SWINGUP_ENABLE) || sample_timeout),
        .sample_tick(tick_3ms), .theta_position(theta_raw_12b), .alpha_position(enc1_pos),
        .theta_velocity(control_theta_velocity), .alpha_velocity_q4(control_alpha_velocity_q4),
        .velocity_valid(control_velocity_valid));

    // -----------------------------------------------------------------------------
    // 4. 同步状态锁存
    // -----------------------------------------------------------------------------
    reg control_tick;
    reg [4:0] sample_tick_pipe;
    reg [11:0] frame_theta;
    reg signed [15:0] frame_theta_dot;
    reg [31:0] frame_number, sample_age;
    reg sample_seen;
    always @(posedge clk_sys or negedge rst_n) begin
        if (!rst_n) begin
            control_tick <= 0;
            sample_tick_pipe <= 0;
            frame_theta <= `DEFAULT_THETA_ZERO;
            frame_theta_dot <= 0;
            frame_number <= 0;
            sample_age <= 0;
            sample_seen <= 0;
        end else begin
            // Kalman output commits at sample+4 clocks; consume at +5.
            sample_tick_pipe <= {sample_tick_pipe[3:0], tick_3ms};
            control_tick <= sample_tick_pipe[4];
            if (sample_tick_pipe[4]) frame_theta_dot <= control_theta_velocity;
            if (tick_3ms) begin
                frame_theta <= theta_raw_12b;

                frame_number <= frame_number + 1'b1;
                sample_seen <= 1;
                sample_age <= 0;
            end else if (sample_age != 32'hffffffff)
                sample_age <= sample_age + 1'b1;
        end
    end

    // -----------------------------------------------------------------------------
    // 5. 状态机与安全互锁
    // -----------------------------------------------------------------------------
    localparam FSM_DISABLED=3'd0, FSM_STANDBY=3'd1, FSM_BALANCE=3'd2,
               FSM_JOG=3'd3, FSM_FAULT=3'd4, FSM_SWINGUP=3'd5;
    localparam signed [15:0] ARM_TRAVEL_LIMIT_S = `MAX_ARM_TRAVEL_PULSES;
    localparam signed [15:0] ARM_TARGET_STEP_S = `ARM_POSITION_STEP_PULSES;
    reg [2:0] fsm_state, fault_cause;
    // Issue a frame immediately on balance entry, after the new arm target
    // has committed. Otherwise LQR stays flushed until the next 3 ms tick.
    reg [2:0] previous_fsm_state;
    always @(posedge clk_sys or negedge rst_n) begin
        if (!rst_n) previous_fsm_state <= FSM_STANDBY;
        else previous_fsm_state <= fsm_state;
    end
    wire balance_entry_tick = fsm_state == FSM_BALANCE && previous_fsm_state != FSM_BALANCE;
    wire balance_control_tick = control_tick || balance_entry_tick;
    reg estop_latch, calibration_pending, calibration_valid;
    reg [15:0] calibrated_zero, calibrated_alpha_center;
    reg [15:0] target_alpha, position_target_alpha, entry_alpha_candidate;
    wire signed [15:0] cur_theta_err;
    reg [7:0] entry_confirm_cnt, calibration_confirm_cnt;
    reg [11:0] sat_duration_cnt;
    wire [7:0] hmi_speed_percent;
    wire hmi_move_pulse,hmi_result_pulse,hmi_result_usb,hmi_sync_enabled;
    wire [15:0] hmi_move_target;
    wire signed [15:0] hmi_theta_reference_counts,hmi_theta_reference_cd;
    // Only the LQR reference moves. Physical upright/tilt protections keep
    // using calibrated_zero and the original raw angle independently.
    wire signed [17:0] lqr_reference_unwrapped=$signed({2'b0,calibrated_zero})+
        (`THETA_DIR_INVERT ? -$signed({{2{hmi_theta_reference_counts[15]}},hmi_theta_reference_counts}) :
                              $signed({{2{hmi_theta_reference_counts[15]}},hmi_theta_reference_counts}));
    wire [15:0] lqr_reference_zero={4'd0,lqr_reference_unwrapped[11:0]};
    wire signed [15:0] theta_tracking_error=cur_theta_err-hmi_theta_reference_counts;
    wire [15:0] abs_theta_tracking_error=theta_tracking_error<0 ? -theta_tracking_error : theta_tracking_error;
    reg queued_arm_valid;
    reg [15:0] queued_arm_target;
    wire [15:0] accepted_arm_target=queued_arm_valid ? queued_arm_target : position_target_alpha;
    wire [7:0] hmi_command_result;
    wire [255:0] hmi_telemetry_bank;
    reg hmi_stopped;
    reg [15:0] arm_target_slew_count;
    localparam [16:0] ARM_SLEW_CREDIT_LIMIT = `ARM_TARGET_SLEW_INTERVAL * 100;
    // Target slew interval is configured in system_params.vh.
    wire [16:0] arm_target_slew_elapsed = {1'b0,arm_target_slew_count} + {9'd0,hmi_speed_percent};
    reg auto_restart_pending;
    reg [15:0] auto_restart_wait_frames;
    reg [7:0] auto_restart_confirm_windows;
    reg [16:0] swingup_elapsed; // 80010 frames need 17 bits
    reg entry_candidate_valid;

    wire signed [16:0] theta_diff_raw = $signed({1'b0,frame_theta}) - $signed({1'b0,calibrated_zero});
    wire signed [16:0] theta_diff_wrapped =
        (theta_diff_raw > 17'sd2048) ? theta_diff_raw - 17'sd4096 :
        (theta_diff_raw < -17'sd2048) ? theta_diff_raw + 17'sd4096 : theta_diff_raw;
    wire signed [15:0] raw_theta_error = theta_diff_wrapped[15:0];
    assign cur_theta_err = `THETA_DIR_INVERT ? -raw_theta_error : raw_theta_error;
    wire signed [15:0] cur_theta_dot = `THETA_DIR_INVERT ? -frame_theta_dot : frame_theta_dot;
    wire signed [15:0] cur_alpha_err = enc1_sampled_pos - target_alpha;
    wire signed [15:0] cur_alpha_center_err = enc1_sampled_pos - calibrated_alpha_center;
    wire signed [15:0] position_target_center_err = position_target_alpha - calibrated_alpha_center;

    wire [15:0] abs_theta_err = (cur_theta_err < 0) ? -cur_theta_err : cur_theta_err;
    wire [15:0] abs_theta_dot = (cur_theta_dot < 0) ? -cur_theta_dot : cur_theta_dot;
    wire [15:0] abs_alpha_err = (cur_alpha_err < 0) ? -cur_alpha_err : cur_alpha_err;
    wire [15:0] abs_alpha_center_err = (cur_alpha_center_err < 0) ? -cur_alpha_center_err : cur_alpha_center_err;
    wire [15:0] abs_alpha_dot = (enc1_vel < 0) ? -enc1_vel : enc1_vel;

    assign sample_timeout = sample_age >= (3 * `CONTROL_LOOP_PERIOD_TICKS);
    // Startup/capture velocities use independent 3ms endpoint differences.
    // The 10kHz feedback velocity and all live motor protections stay unchanged.
    reg [4:0] startup_window_count;
    reg startup_initialized, startup_velocity_valid, startup_tick;
    reg [11:0] startup_theta_previous;
    reg [15:0] startup_alpha_previous;
    reg signed [15:0] startup_theta_dot, startup_alpha_dot;
    wire signed [12:0] startup_theta_delta =
        $signed({1'b0,frame_theta}) - $signed({1'b0,startup_theta_previous});
    wire signed [12:0] startup_theta_delta_wrapped =
        (startup_theta_delta > 13'sd2048) ? startup_theta_delta - 13'sd4096 :
        (startup_theta_delta < -13'sd2048) ? startup_theta_delta + 13'sd4096 : startup_theta_delta;
    wire signed [15:0] startup_alpha_delta = enc1_sampled_pos - startup_alpha_previous;
    wire [15:0] abs_startup_theta_dot = startup_theta_dot < 0 ? -startup_theta_dot : startup_theta_dot;
    wire [15:0] abs_startup_alpha_dot = startup_alpha_dot < 0 ? -startup_alpha_dot : startup_alpha_dot;
    always @(posedge clk_sys or negedge rst_n) begin
        if (!rst_n) begin
            startup_window_count <= 0; startup_initialized <= 0;
            startup_velocity_valid <= 0; startup_tick <= 0;
            startup_theta_previous <= `DEFAULT_THETA_ZERO;
            startup_alpha_previous <= `ENCODER_INIT_POS;
            startup_theta_dot <= 0; startup_alpha_dot <= 0;
        end else begin
            startup_tick <= 0;
            if ((sw_calib_pulse && !`SWINGUP_ENABLE) || sample_timeout) begin
                startup_window_count <= 0; startup_initialized <= 0;
                startup_velocity_valid <= 0;
            end else if (control_tick) begin
                if (!startup_initialized) begin
                    startup_theta_previous <= frame_theta;
                    startup_alpha_previous <= enc1_sampled_pos;
                    startup_window_count <= 0;
                    startup_initialized <= 1;
                end else if (startup_window_count == `STARTUP_WINDOW_FRAMES-1'b1) begin
                    startup_theta_dot <= {{3{startup_theta_delta_wrapped[12]}},startup_theta_delta_wrapped};
                    startup_alpha_dot <= startup_alpha_delta;
                    startup_theta_previous <= frame_theta;
                    startup_alpha_previous <= enc1_sampled_pos;
                    startup_window_count <= 0;
                    startup_velocity_valid <= 1;
                    startup_tick <= 1;
                end else startup_window_count <= startup_window_count + 1'b1;
            end
        end
    end

    wire enter_condition = calibration_valid && sample_seen && startup_velocity_valid && !sample_timeout &&
        abs_theta_err <= `THETA_ENTRY_LIMIT && abs_startup_theta_dot <= `THETA_DOT_ENTRY_LIMIT &&
        abs_startup_alpha_dot <= `ARM_DOT_ENTRY_LIMIT;
    wire swingup_catch_condition = calibration_valid && sample_seen && startup_velocity_valid && !sample_timeout &&
        abs_theta_err <= `THETA_ENTRY_LIMIT && abs_startup_theta_dot <= `SWINGUP_CATCH_THETA_DOT_LIMIT &&
        abs_startup_alpha_dot <= `SWINGUP_CATCH_ARM_DOT_LIMIT;
    wire exit_condition = abs_theta_err > `THETA_EXIT_LIMIT;
    wire over_travel_fault = abs_alpha_center_err > `MAX_ARM_TRAVEL_PULSES;
    wire over_speed_fault = abs_alpha_dot > `MAX_ARM_VEL_PULSES;
    wire swingup_start_condition = startup_velocity_valid &&
        abs_theta_err >= `SWINGUP_START_MIN && abs_theta_err <= `SWINGUP_START_MAX &&
        abs_startup_theta_dot <= `SWINGUP_START_THETA_DOT_MAX &&
        abs_startup_alpha_dot <= `SWINGUP_START_ARM_DOT_MAX &&
        abs_alpha_center_err < (`MAX_ARM_TRAVEL_PULSES - 16'd300);

    // An automatic request exists only after leaving a valid BALANCE state
    // due to tilt. Manual keys cancel it, including on the ready edge.
    wire auto_restart_ready = `AUTO_RESTART_ENABLE && `SWINGUP_ENABLE &&
        auto_restart_pending && fsm_state == FSM_STANDBY && calibration_valid &&
        sample_seen && !sample_timeout && !over_travel_fault && !over_speed_fault &&
        !key_state[1] && !key_state[2] && swingup_start_condition &&
        auto_restart_wait_frames >= `AUTO_RESTART_WAIT_FRAMES &&
        auto_restart_confirm_windows >= `AUTO_RESTART_CONFIRM_WINDOWS;

    wire [1:0] lqr_motor_dir;
    wire [7:0] lqr_duty;
    wire lqr_calc_done, lqr_saturated, combined_saturated;
    wire signed [15:0] theta_err_mon, alpha_err_mon, u_scaled_mon;
    wire immediate_stop = estop_latch || remote_stop_latch || remote_stop || sw_estop_pulse || sw_calib_pulse ||
        !calibration_valid || calibration_pending || sample_timeout ||
        (jog_conflict && (fsm_state == FSM_STANDBY) && !swingup_trigger_lockout) ||
        ((fsm_state == FSM_BALANCE) && (exit_condition || over_travel_fault || over_speed_fault));
    wire lqr_ctrl_enable = (`CLOSED_LOOP_ENABLE) && (fsm_state == FSM_BALANCE) &&
        !immediate_stop && (!jog_request || (fsm_state == FSM_BALANCE));
    wire lqr_flush = !lqr_ctrl_enable;

    always @(posedge clk_sys or negedge rst_n) begin
        if (!rst_n) begin
            fsm_state <= FSM_STANDBY;
            fault_cause <= 0;
            estop_latch <= 0;
            calibration_pending <= 0;
            calibration_valid <= 0;
            entry_confirm_cnt <= 0;
            sat_duration_cnt <= 0;
            calibration_confirm_cnt <= 0;
            calibrated_zero <= `DEFAULT_THETA_ZERO;
            calibrated_alpha_center <= `ENCODER_INIT_POS;
            target_alpha <= `ENCODER_INIT_POS;
            position_target_alpha <= `ENCODER_INIT_POS;
            arm_target_slew_count <= 16'd0;
            entry_alpha_candidate <= `ENCODER_INIT_POS;
            entry_candidate_valid <= 0;
            swingup_elapsed <= 0;
            swingup_trigger_lockout <= 0;
            auto_restart_pending <= 0;
            auto_restart_wait_frames <= 0;
            auto_restart_confirm_windows <= 0;
        end else begin
            if(remote_hold_target) position_target_alpha<=target_alpha;
            if (`AUTO_RESTART_ENABLE && auto_restart_pending && fsm_state == FSM_STANDBY) begin
                if (control_tick && auto_restart_wait_frames < `AUTO_RESTART_WAIT_FRAMES)
                    auto_restart_wait_frames <= auto_restart_wait_frames + 1'b1;
                if (!swingup_start_condition || sample_timeout || over_travel_fault || over_speed_fault)
                    auto_restart_confirm_windows <= 0;
                else if (startup_tick && auto_restart_confirm_windows < `AUTO_RESTART_CONFIRM_WINDOWS)
                    auto_restart_confirm_windows <= auto_restart_confirm_windows + 1'b1;
            end else begin
                auto_restart_wait_frames <= 0;
                auto_restart_confirm_windows <= 0;
            end
            if (!`AUTO_RESTART_ENABLE || !`SWINGUP_ENABLE || !`MOTOR_HARDWARE_ENABLE ||
                !calibration_valid || estop_latch || sw_estop_pulse || remote_stop_latch || remote_stop ||
                sw_calib_pulse || key_state[1] || key_state[2] ||
                fsm_state == FSM_FAULT || fsm_state == FSM_BALANCE)
                auto_restart_pending <= 0;

            // Keep a two-key request consumed until BOTH keys are released.
            // Releasing one must not turn a rejected request into a jog.
            if (!key_state[1] && !key_state[2]) swingup_trigger_lockout <= 0;
            if (sw_estop_pulse) estop_latch <= !estop_latch;
            if (!`MOTOR_HARDWARE_ENABLE) begin
                fsm_state <= FSM_DISABLED;
                entry_confirm_cnt <= 0;
                sat_duration_cnt <= 0;
            end else if (estop_latch || sw_estop_pulse || remote_stop_latch || remote_stop) begin
                // Releasing remote stop must not leave standby armed to balance.
                if(remote_stop_latch || remote_stop) calibration_valid <= 0;
                fsm_state <= FSM_FAULT;
                // STOP must not turn a latched hardware/control fault into a
                // restartable command stop. Only cause 4 can be rearmed by START.
                if(fsm_state != FSM_FAULT || fault_cause == 4) fault_cause <= 4;
                entry_confirm_cnt <= 0;
                calibration_pending <= 0;
            end else if (sw_calib_pulse) begin
                calibration_confirm_cnt <= 0;
                fault_cause <= 0;
                entry_confirm_cnt <= 0;
                sat_duration_cnt <= 0;
                entry_candidate_valid <= 0;
                if (`SWINGUP_ENABLE) begin
                    // SW1 starts with fixed program references. No stationary
                    // calibration, arm-center capture, or deferred request.
                    calibrated_zero <= `DEFAULT_THETA_ZERO;
                    calibrated_alpha_center <= `ENCODER_INIT_POS;
                    target_alpha <= `ENCODER_INIT_POS;
                    position_target_alpha <= `ENCODER_INIT_POS;
                    arm_target_slew_count <= 0;
                    calibration_pending <= 0;
                    calibration_valid <= sample_seen && startup_velocity_valid && !sample_timeout;
                    swingup_elapsed <= 0;
                    if (sample_timeout || over_travel_fault || over_speed_fault) begin
                        fsm_state <= FSM_FAULT;
                        fault_cause <= sample_timeout ? 6 : over_travel_fault ? 1 : 2;
                    end else if (sample_seen && swingup_start_condition) begin
                        fsm_state <= FSM_SWINGUP;
                    end else begin
                        fsm_state <= FSM_STANDBY;
                    end
                end else begin
                    // Preserve the upright-only project's original SW1 calibration.
                    calibration_pending <= 1;
                    calibration_valid <= 0;
                    fsm_state <= FSM_STANDBY;
                end
            end else if (calibration_pending) begin
                if (sample_timeout) calibration_confirm_cnt <= 0;
                else if (startup_tick) begin
                    // Keep the fixed pendulum zero; SW1 validates that the
                    // mechanism is stationary and captures the arm reference.
                    if (abs_startup_theta_dot <= `CALIBRATION_THETA_DOT_LIMIT &&
                        abs_startup_alpha_dot <= `CALIBRATION_ARM_DOT_LIMIT) begin
                        if (calibration_confirm_cnt >= `CALIBRATION_CONFIRM_CYCLES - 1'b1) begin
                            calibrated_zero <= `DEFAULT_THETA_ZERO;
                            calibrated_alpha_center <= enc1_sampled_pos;
                            target_alpha <= enc1_sampled_pos;
                            position_target_alpha <= enc1_sampled_pos;
                            arm_target_slew_count <= 16'd0;
                            calibration_pending <= 0;
                            calibration_valid <= 1;
                            calibration_confirm_cnt <= 0;
                            fault_cause <= 0;
                        end else begin
                            calibration_confirm_cnt <= calibration_confirm_cnt + 1'b1;
                        end
                    end else begin
                        calibration_confirm_cnt <= 0;
                    end
                end
            end else if (auto_restart_pending && fsm_state == FSM_STANDBY &&
                         (sample_timeout || over_travel_fault || over_speed_fault)) begin
                // A new live fault during the waiting interval must latch;
                // returning to a good reading alone must never rearm it.
                fsm_state <= FSM_FAULT;
                fault_cause <= sample_timeout ? 6 : over_travel_fault ? 1 : 2;
                auto_restart_pending <= 0;
                entry_confirm_cnt <= 0;
                entry_candidate_valid <= 0;
            end else if (auto_restart_ready) begin
                fsm_state <= FSM_SWINGUP;
                fault_cause <= 0;
                swingup_elapsed <= 0;
                entry_confirm_cnt <= 0;
                entry_candidate_valid <= 0;
                auto_restart_pending <= 0;
                auto_restart_wait_frames <= 0;
                auto_restart_confirm_windows <= 0;
            end else if (`AUTO_SWINGUP_ENABLE && `SWINGUP_ENABLE &&
                         fsm_state == FSM_STANDBY && calibration_valid &&
                         swingup_start_condition) begin
                // Automatically begin swing-up once the calibrated pendulum
                // settles inside the hanging/start window; no SW2+SW3 needed.
                fsm_state <= FSM_SWINGUP;
                swingup_elapsed <= 0;
                entry_confirm_cnt <= 0;
                entry_candidate_valid <= 0;
            end else if (swingup_request && fsm_state == FSM_STANDBY) begin
                swingup_trigger_lockout <= 1;
                entry_confirm_cnt <= 0;
                entry_candidate_valid <= 0;
                if (`SWINGUP_ENABLE && fsm_state == FSM_STANDBY &&
                    calibration_valid && swingup_start_condition) begin
                    fsm_state <= FSM_SWINGUP;
                    swingup_elapsed <= 0;
                    swingup_trigger_lockout <= 1;
                end else begin
                    fsm_state <= FSM_STANDBY;
                end
            end else if (jog_request && fsm_state != FSM_SWINGUP &&
                         fsm_state != FSM_BALANCE && fsm_state != FSM_FAULT && !sample_timeout &&
                         !over_travel_fault && !over_speed_fault) begin
                // Manual jog is permitted only outside latched and live faults.
                fsm_state <= FSM_JOG;
                entry_confirm_cnt <= 0;
                sat_duration_cnt <= 0;
                entry_candidate_valid <= 0;
            end else if (fsm_state == FSM_FAULT) begin
                // Latch fault for real hazards (travel, speed, timeout, saturation). SW1 clears and rearms.
                entry_confirm_cnt <= 0;
                sat_duration_cnt <= 0;
                if (fault_cause == 4 && !estop_latch) begin
                    fsm_state <= FSM_STANDBY;
                    fault_cause <= 0;
                end
            end else if (fsm_state == FSM_BALANCE &&
                         (sample_timeout || over_travel_fault || over_speed_fault)) begin
                fsm_state <= FSM_FAULT;
                fault_cause <= sample_timeout ? 6 : over_travel_fault ? 1 : 2;
            end else if (fsm_state == FSM_BALANCE && exit_condition) begin
                // Tilt alone can schedule a new attempt. All higher-priority
                // fault branches remain latched and never create a retry.
                if ((`AUTO_RESTART_ENABLE || `AUTO_SWINGUP_ENABLE) &&
                    `SWINGUP_ENABLE && calibration_valid) begin
                    fsm_state <= FSM_STANDBY;
                    fault_cause <= 0;
                    auto_restart_pending <= `AUTO_RESTART_ENABLE;
                    auto_restart_wait_frames <= 0;
                    auto_restart_confirm_windows <= 0;
                end else begin
                    fsm_state <= FSM_FAULT;
                    fault_cause <= 5;
                    calibration_valid <= 0;
                end
                entry_confirm_cnt <= 0;
                sat_duration_cnt <= 0;
                entry_candidate_valid <= 0;
            end else if (fsm_state == FSM_SWINGUP &&
                         (sample_timeout || over_travel_fault || over_speed_fault)) begin
                fsm_state <= FSM_FAULT;
                fault_cause <= sample_timeout ? 6 : over_travel_fault ? 1 : 2;
                entry_confirm_cnt <= 0;
                entry_candidate_valid <= 0;
            end else begin
                case (fsm_state)
                    FSM_DISABLED: fsm_state <= FSM_STANDBY;
                    FSM_JOG: begin
                        if (sample_timeout || over_travel_fault || over_speed_fault) begin
                            fsm_state <= FSM_FAULT;
                            fault_cause <= sample_timeout ? 6 : over_travel_fault ? 1 : 2;
                        end else begin
                            fsm_state <= FSM_STANDBY;
                            target_alpha <= enc1_sampled_pos;
                            position_target_alpha <= enc1_sampled_pos;
                            arm_target_slew_count <= 16'd0;
                        end
                        entry_confirm_cnt <= 0;
                        entry_candidate_valid <= 0;
                    end
                    FSM_STANDBY: begin
                        sat_duration_cnt <= 0;
                        if (startup_tick) begin
                            if (`CLOSED_LOOP_ENABLE && enter_condition) begin
                                // Capture the first frame that enters the
                                // upright window. The later confirmation
                                // frames only validate the handoff; they do
                                // not move the arm target.
                                if (!entry_candidate_valid) begin
                                    entry_alpha_candidate <= enc1_sampled_pos;
                                    entry_candidate_valid <= 1;
                                end
                                if (entry_confirm_cnt >= `ENTRY_CONFIRM_CYCLES-1) begin
                                    fsm_state <= FSM_BALANCE;
                                    target_alpha <= entry_candidate_valid ?
                                        entry_alpha_candidate : enc1_sampled_pos;
                                    position_target_alpha <= entry_candidate_valid ?
                                        entry_alpha_candidate : enc1_sampled_pos;
                                    arm_target_slew_count <= 16'd0;
                                    entry_confirm_cnt <= 0;
                                    entry_candidate_valid <= 0;
                                end else entry_confirm_cnt <= entry_confirm_cnt + 1'b1;
                            end else begin
                                entry_confirm_cnt <= 0;
                                entry_candidate_valid <= 0;
                            end
                        end
                    end
                    FSM_BALANCE: begin
                        // In BALANCE, SW2 advances and SW3 retreats the position command.
                        // Simultaneous presses remain a no-op here.
                        if (remote_hold_target) begin
                            position_target_alpha <= target_alpha;
                            arm_target_slew_count <= 0;
                        end else if (queued_arm_valid) begin
                            position_target_alpha <= queued_arm_target;
                        end else if ((key_pulse[1] || remote_plus) && !(key_pulse[2] || remote_minus) &&
                            position_target_center_err <= (ARM_TRAVEL_LIMIT_S - ARM_TARGET_STEP_S)) begin
                            position_target_alpha <= position_target_alpha + `ARM_POSITION_STEP_PULSES;
                        end else if ((key_pulse[2] || remote_minus) && !(key_pulse[1] || remote_plus) &&
                            position_target_center_err >= (-ARM_TRAVEL_LIMIT_S + ARM_TARGET_STEP_S)) begin
                            position_target_alpha <= position_target_alpha - `ARM_POSITION_STEP_PULSES;
                        end
                        // Absolute updates retain the same slew limiter; hold must not step toward an old goal.
                        if (control_tick && !queued_arm_valid && !remote_hold_target) begin
                            if (target_alpha == position_target_alpha) begin
                                arm_target_slew_count <= 16'd0;
                            end else if (arm_target_slew_elapsed >= ARM_SLEW_CREDIT_LIMIT) begin
                                arm_target_slew_count <= arm_target_slew_elapsed - ARM_SLEW_CREDIT_LIMIT;
                                if (target_alpha < position_target_alpha)
                                    target_alpha <= target_alpha + `ARM_TARGET_SLEW_STEP;
                                else target_alpha <= target_alpha - `ARM_TARGET_SLEW_STEP;
                            end else arm_target_slew_count <= arm_target_slew_elapsed[15:0];
                        end
                        if (sample_timeout || over_travel_fault || over_speed_fault) begin
                            fsm_state <= FSM_FAULT;
                            fault_cause <= sample_timeout ? 6 : over_travel_fault ? 1 : 2;
                        end else if (lqr_calc_done) begin
                            if (combined_saturated) begin
                                if (sat_duration_cnt >= `SATURATION_TIMEOUT_CYCLES-1) begin
                                    fsm_state <= FSM_FAULT;
                                    fault_cause <= 3;
                                end else sat_duration_cnt <= sat_duration_cnt + 1'b1;
                            end else sat_duration_cnt <= 0;
                        end
                    end
                    FSM_SWINGUP: begin
                        if (startup_tick) begin
                            if (`CLOSED_LOOP_ENABLE && swingup_catch_condition) begin
                                if (!entry_candidate_valid) begin
                                    entry_alpha_candidate <= enc1_sampled_pos;
                                    entry_candidate_valid <= 1;
                                end
                                if (entry_confirm_cnt >= `SWINGUP_CATCH_CONFIRM_CYCLES-1) begin
                                    fsm_state <= FSM_BALANCE;
                                    target_alpha <= entry_candidate_valid ?
                                        entry_alpha_candidate : enc1_sampled_pos;
                                    position_target_alpha <= entry_candidate_valid ?
                                        entry_alpha_candidate : enc1_sampled_pos;
                                    arm_target_slew_count <= 16'd0;
                                    entry_confirm_cnt <= 0;
                                    entry_candidate_valid <= 0;
                                    swingup_elapsed <= 0;
                                end else entry_confirm_cnt <= entry_confirm_cnt + 1'b1;
                            end else begin
                                entry_confirm_cnt <= 0;
                                entry_candidate_valid <= 0;
                            end
                        end
                        if (control_tick) begin
                            if (swingup_elapsed >= `SWINGUP_TIMEOUT_FRAMES-1) begin
                                fsm_state <= FSM_FAULT;
                                fault_cause <= 7;
                                entry_confirm_cnt <= 0;
                                entry_candidate_valid <= 0;
                            end else swingup_elapsed <= swingup_elapsed + 1'b1;
                        end
                    end
                    default: fsm_state <= FSM_STANDBY;
                endcase
            end
        end
    end

    // -----------------------------------------------------------------------------
    // 6. LQR 控制核心 (25MHz 同步流水线)
    // -----------------------------------------------------------------------------
    lqr_controller u_lqr (
        .clk_50m(clk_sys), .rst_n(rst_n), .tick_3ms(balance_control_tick),
        .ctrl_enable(lqr_ctrl_enable), .flush_pipeline(lqr_flush),
        .calibrated_zero_val(lqr_reference_zero), .theta_raw(frame_theta), .theta_dot(frame_theta_dot),
        .alpha_pos(enc1_sampled_pos), .alpha_target_pos(target_alpha), .alpha_dot(control_alpha_velocity_q4),
        .k_theta(`PARAM_K_THETA), .k_theta_dot(`PARAM_K_THETA_DOT),
        .k_alpha(`PARAM_K_ALPHA), .k_alpha_dot(`PARAM_K_ALPHA_DOT),
        .motor_dir(lqr_motor_dir), .duty_out(lqr_duty), .calc_done_pulse(lqr_calc_done),
        .saturated(lqr_saturated), .theta_err_mon(theta_err_mon), .alpha_err_mon(alpha_err_mon),
        .u_scaled_mon(u_scaled_mon));

    wire [1:0] swingup_motor_dir;
    wire [7:0] swingup_duty;
    wire swingup_kick_done;
    wire signed [15:0] swingup_energy_error;
    wire swingup_ctrl_enable = `SWINGUP_ENABLE && `MOTOR_HARDWARE_ENABLE &&
        (fsm_state == FSM_SWINGUP) && !immediate_stop;
    swingup_energy_controller u_swingup_energy (
        .clk(clk_sys), .rst_n(rst_n), .tick(control_tick),
        .enable(swingup_ctrl_enable), .theta_abs_counts(abs_theta_err[11:0]),
        .theta_dot(cur_theta_dot), .kick_frames(`SWINGUP_KICK_FRAMES),
        .motor_dir(swingup_motor_dir), .duty(swingup_duty),
        .kick_done(swingup_kick_done), .energy_error_mon(swingup_energy_error));

    // The arm PID is summed after the existing LQR output. Keep its authority
    // low and reset it outside BALANCE so the upright controller stays dominant.
    // Handoff schedule: use a stronger P for the first three seconds after
    // entering BALANCE, then ramp to the steady-state low P. Both pipelines
    // stay live so the gain transition does not insert a zero-output bubble.
    localparam [15:0] ARM_PID_HOLD_FRAMES = `ARM_PID_HANDOFF_FRAMES;
    localparam [15:0] ARM_PID_SLEW_FRAMES = `ARM_PID_HANDOFF_SLEW_FRAMES;
    localparam [15:0] ARM_PID_TOTAL_FRAMES = ARM_PID_HOLD_FRAMES + ARM_PID_SLEW_FRAMES;
    reg [15:0] arm_pid_handoff_age;
    always @(posedge clk_sys or negedge rst_n) begin
        if (!rst_n) arm_pid_handoff_age <= 16'd0;
        else if (!lqr_ctrl_enable || balance_entry_tick) arm_pid_handoff_age <= 16'd0;
        else if (control_tick && arm_pid_handoff_age < ARM_PID_TOTAL_FRAMES)
            arm_pid_handoff_age <= arm_pid_handoff_age + 1'b1;
    end
    wire arm_pid_hold_active = lqr_ctrl_enable && (arm_pid_handoff_age < ARM_PID_HOLD_FRAMES);
    wire [15:0] arm_pid_ramp_index =
        (arm_pid_handoff_age <= ARM_PID_HOLD_FRAMES) ? 16'd0 :
        (arm_pid_handoff_age >= ARM_PID_TOTAL_FRAMES) ? ARM_PID_SLEW_FRAMES :
        (arm_pid_handoff_age - ARM_PID_HOLD_FRAMES);
    wire [15:0] arm_pid_ramp_remain = ARM_PID_SLEW_FRAMES - arm_pid_ramp_index;
    wire arm_pid_ramp_active = lqr_ctrl_enable &&
        (arm_pid_ramp_index != 16'd0) && (arm_pid_ramp_index < ARM_PID_SLEW_FRAMES);
    wire signed [15:0] arm_pid_correction;
    wire signed [15:0] arm_pid_correction_handoff, arm_pid_correction_steady;
    wire arm_pid_saturated;
    wire arm_pid_saturated_handoff, arm_pid_saturated_steady;
    wire signed [23:0] arm_pid_handoff_ext =
        {{8{arm_pid_correction_handoff[15]}}, arm_pid_correction_handoff};
    wire signed [23:0] arm_pid_steady_ext =
        {{8{arm_pid_correction_steady[15]}}, arm_pid_correction_steady};
    wire signed [23:0] arm_pid_remain_ext = {8'd0, arm_pid_ramp_remain};
    wire signed [23:0] arm_pid_index_ext = {8'd0, arm_pid_ramp_index};
    wire signed [47:0] arm_pid_blend_num =
        arm_pid_handoff_ext * arm_pid_remain_ext +
        arm_pid_steady_ext * arm_pid_index_ext;
    arm_position_pid #(
        .KP(`ARM_PID_KP_HANDOFF), .KI(`ARM_PID_KI), .KD(`ARM_PID_KD),
        .INTEGRAL_LIMIT(`ARM_PID_INTEGRAL_LIMIT),
        .OUTPUT_LIMIT(`ARM_PID_OUTPUT_LIMIT), .OUTPUT_INVERT(`ARM_PID_OUTPUT_INVERT)
    ) u_arm_position_pid_handoff (
        .clk_50m(clk_sys), .rst_n(rst_n), .tick_3ms(balance_control_tick),
        .enable(lqr_ctrl_enable), .position(enc1_sampled_pos),
        .target_position(target_alpha), .velocity_q4(control_alpha_velocity_q4),
        .correction(arm_pid_correction_handoff), .saturated(arm_pid_saturated_handoff));
    arm_position_pid #(
        .KP(`ARM_PID_KP), .KI(`ARM_PID_KI), .KD(`ARM_PID_KD),
        .INTEGRAL_LIMIT(`ARM_PID_INTEGRAL_LIMIT),
        .OUTPUT_LIMIT(`ARM_PID_OUTPUT_LIMIT), .OUTPUT_INVERT(`ARM_PID_OUTPUT_INVERT)
    ) u_arm_position_pid (
        .clk_50m(clk_sys), .rst_n(rst_n), .tick_3ms(balance_control_tick),
        .enable(lqr_ctrl_enable), .position(enc1_sampled_pos),
        .target_position(target_alpha), .velocity_q4(control_alpha_velocity_q4),
        .correction(arm_pid_correction_steady), .saturated(arm_pid_saturated_steady));
    assign arm_pid_correction = arm_pid_hold_active ?
        arm_pid_correction_handoff :
        $signed(arm_pid_blend_num[28:13]);
    assign arm_pid_saturated = arm_pid_hold_active ?
        arm_pid_saturated_handoff :
        arm_pid_ramp_active ? (arm_pid_saturated_handoff || arm_pid_saturated_steady) :
        arm_pid_saturated_steady;

    function signed [47:0] theta_i_shift_toward_zero;
        input signed [47:0] value;
        input [5:0] shift_count;
        reg [47:0] magnitude;
        begin
            magnitude = (value < 0) ? -value : value;
            theta_i_shift_toward_zero = (value < 0) ?
                -$signed(magnitude >> shift_count) : $signed(magnitude >> shift_count);
        end
    endfunction

    reg signed [31:0] theta_i_accum;
    reg signed [15:0] theta_i_correction;
    reg theta_i_saturated;
    // Use the same angle deadband as the LQR theta proportional term. Inside
    // the band theta_i_candidate equals the accumulator, so integration pauses
    // while the theta velocity term remains active in lqr_controller.
    wire signed [15:0] theta_i_error = (abs_theta_tracking_error <= `THETA_ERROR_DEADBAND) ?
        16'sd0 : theta_tracking_error;
    wire signed [32:0] theta_i_candidate_wide =
        $signed({theta_i_accum[31], theta_i_accum}) +
        $signed({{17{theta_i_error[15]}}, theta_i_error}); // integral in 1/30 reference-frame units
    wire signed [31:0] theta_i_candidate =
        (theta_i_candidate_wide > `THETA_I_ACCUM_LIMIT) ? `THETA_I_ACCUM_LIMIT :
        (theta_i_candidate_wide < -`THETA_I_ACCUM_LIMIT) ? -`THETA_I_ACCUM_LIMIT :
        theta_i_candidate_wide[31:0];
    reg signed [31:0] theta_i_candidate_stage;
    wire signed [47:0] theta_i_product =
        $signed(`THETA_I_KI) * $signed(theta_i_candidate_stage);
    // Four clocks of integral pipeline are negligible versus a 2500-clock frame.
    // Separate constant division from accumulator feedback to close system-clock timing.
    wire signed [47:0] theta_i_shifted =
        theta_i_shift_toward_zero(theta_i_product, `THETA_I_GAIN_SHIFT);
    reg signed [13:0] theta_i_shifted_stage; // bounded to +/-5760 by accumulator limit
    reg signed [13:0] theta_i_term;
    reg [2:0] theta_i_valid;
    wire signed [47:0] theta_i_directed =
        `THETA_I_OUTPUT_INVERT ? -theta_i_term : theta_i_term;
    wire signed [47:0] theta_i_positive_limit =
        $signed({40'd0, `THETA_I_OUTPUT_LIMIT});
    wire signed [47:0] theta_i_negative_limit = -theta_i_positive_limit;
    wire signed [15:0] theta_i_limited =
        (theta_i_directed > theta_i_positive_limit) ?
            $signed({8'd0, `THETA_I_OUTPUT_LIMIT}) :
        (theta_i_directed < theta_i_negative_limit) ?
            -$signed({8'd0, `THETA_I_OUTPUT_LIMIT}) :
        theta_i_directed[15:0];
    // floor(abs(product)/2^shift/scale) exceeds output limit at this threshold.
    localparam signed [47:0] THETA_I_SAT_PRODUCT =
        ((48'sd1 + `THETA_I_OUTPUT_LIMIT) * `INTEGRAL_TIME_SCALE) << `THETA_I_GAIN_SHIFT;
    // The configured accumulator limit is beyond the output-saturation threshold.
    // Compare before the clamp muxes so feedback does not pass through division.
    wire signed [48:0] theta_i_feedback_product =
        $signed(`THETA_I_KI) * $signed(theta_i_candidate_wide);
    wire theta_i_would_saturate =
        theta_i_feedback_product >= THETA_I_SAT_PRODUCT || theta_i_feedback_product <= -THETA_I_SAT_PRODUCT;
    wire theta_i_correction_negative = `THETA_I_OUTPUT_INVERT ?
        theta_i_feedback_product < 0 : theta_i_feedback_product > 0;
    wire theta_i_drives_deeper = theta_i_would_saturate &&
        ((theta_i_correction_negative && theta_i_error > 0) ||
         (!theta_i_correction_negative && theta_i_error < 0));
    always @(posedge clk_sys or negedge rst_n) begin
        if (!rst_n) begin
            theta_i_candidate_stage <= 0; theta_i_shifted_stage <= 0; theta_i_term <= 0; theta_i_valid <= 0;
        end else if (!lqr_ctrl_enable) begin
            theta_i_candidate_stage <= 0; theta_i_shifted_stage <= 0; theta_i_term <= 0; theta_i_valid <= 0;
        end else begin
            theta_i_valid <= {theta_i_valid[1:0], control_tick};
            if (control_tick) theta_i_candidate_stage <= theta_i_candidate;
            if (theta_i_valid[0]) theta_i_shifted_stage <= theta_i_shifted[13:0];
            if (theta_i_valid[1]) theta_i_term <= -theta_i_shifted_stage / 14'sd30;
        end
    end

    always @(posedge clk_sys or negedge rst_n) begin
        if (!rst_n) begin
            theta_i_accum <= 32'sd0;
            theta_i_correction <= 16'sd0;
            theta_i_saturated <= 1'b0;
        end else if (!lqr_ctrl_enable) begin
            theta_i_accum <= 32'sd0;
            theta_i_correction <= 16'sd0;
            theta_i_saturated <= 1'b0;
        end else if (control_tick) begin
            // Do not let a stale balance-angle integral permanently cancel the
            // arm position loop after a commanded move has reached its target.
            if ((abs_theta_err <= `THETA_ERROR_DEADBAND) &&
                (abs_alpha_err > `ARM_POSITION_ERROR_DEADBAND)) begin
                theta_i_accum <= theta_i_accum - (theta_i_accum >>> `THETA_I_LEAK_SHIFT);
            end else if (!theta_i_would_saturate || !theta_i_drives_deeper) begin
                theta_i_accum <= theta_i_candidate;
            end
            theta_i_saturated <= theta_i_would_saturate;
        end
        else if (theta_i_valid[2]) theta_i_correction <= theta_i_limited;
    end

    wire signed [17:0] base_motor_command_sum =
        $signed({u_scaled_mon[15], u_scaled_mon}) +
        $signed({arm_pid_correction[15], arm_pid_correction}) +
        $signed({theta_i_correction[15], theta_i_correction});
    wire signed [15:0] nn_correction;
    wire [1:0] nn_mode;
    wire nn_trip,nn_request_ok;
    wire [255:0] nn_debug_bank;
    wire signed [15:0] applied_pwm;
    wire capture_valid;
    wire signed [15:0] base_combined_u_mon=base_motor_command_sum>18'sd32767 ? 16'sd32767 : base_motor_command_sum< -18'sd32768 ? -16'sd32768 : base_motor_command_sum[15:0];
    wire command_write;
    wire [7:0] bus_data,bus_operation;
    wire [15:0] bus_target;
    localparam signed [17:0] NN_MIN_BASE = `PWM_DEADZONE_THRESH + `PWM_COMP_RAMP_COUNTS + 3;
    wire nn_authority_safe=(base_motor_command_sum>=NN_MIN_BASE && base_motor_command_sum<=180) ||
        (base_motor_command_sum<=-NN_MIN_BASE && base_motor_command_sum>=-180);
    wire nn_hard_safe=lqr_ctrl_enable && cur_theta_err<=16'sd80 && cur_theta_err>=-16'sd80 &&
        cur_theta_dot<=16'sd16 && cur_theta_dot>=-16'sd16 && cur_alpha_err<=16'sd80 && cur_alpha_err>=-16'sd80 &&
        control_alpha_velocity_q4<=20'sd64 && control_alpha_velocity_q4>=-20'sd64;
    nn_predictor_trial u_nn_trial(.clk(clk_sys),.rst_n(rst_n),.control_tick(control_tick),
        .sample_tick(capture_valid),.control_enable(lqr_ctrl_enable),.hard_safe(nn_hard_safe),.authority_safe(nn_authority_safe),
        .position(enc1_sampled_pos),.active_target(target_alpha),.final_target(position_target_alpha),
        .theta_error(cur_theta_err),.theta_dot(cur_theta_dot),.base_command(base_combined_u_mon),.applied_pwm(applied_pwm),
        .arm_velocity_q4(control_alpha_velocity_q4),
        .mode_write(command_write && bus_operation==8'h40 && bus_target[15:8]==0),.requested_mode(bus_data),.invert(`ARM_PID_OUTPUT_INVERT),
        .frame_number(frame_number),.correction(nn_correction),.request_ok(nn_request_ok),
        .mode(nn_mode),.trip_latch(nn_trip),.debug_bank(nn_debug_bank));
    // Pair the base command and its gated residual in one 25MHz register stage.
    // Authority is checked against the exact base sample that reaches the driver.
    reg signed [17:0] paired_base_sum;
    reg signed [15:0] paired_nn_correction;
    always @(posedge clk_sys or negedge rst_n) begin
        if(!rst_n) begin paired_base_sum<=0;paired_nn_correction<=0;end
        else begin paired_base_sum<=base_motor_command_sum;paired_nn_correction<=nn_correction;end
    end
    wire signed [17:0] motor_command_sum=paired_base_sum+$signed({{2{paired_nn_correction[15]}},paired_nn_correction});
    wire signed [17:0] pwm_positive_limit = $signed({10'd0, `MAX_PWM_DUTY_LIMIT});
    wire signed [17:0] pwm_negative_limit = -pwm_positive_limit;
    wire [17:0] motor_command_magnitude = motor_command_sum < 0 ?
        -motor_command_sum : motor_command_sum;
    // NN only acts at |base|<=180, so it cannot create saturation. Preserve
    // the original undelayed saturation monitor for the fault counter.
    assign combined_saturated = (base_motor_command_sum >= pwm_positive_limit) ||
        (base_motor_command_sum <= pwm_negative_limit);
    wire motor_sum_saturated = (motor_command_sum >= pwm_positive_limit) ||
        (motor_command_sum <= pwm_negative_limit);
    wire [1:0] balance_motor_dir = motor_command_sum > 0 ? 2'b01 :
        motor_command_sum < 0 ? 2'b10 : 2'b00;
    wire [7:0] balance_motor_duty = motor_sum_saturated ? `MAX_PWM_DUTY_LIMIT :
        motor_command_magnitude[7:0];
    wire signed [15:0] combined_u_mon = motor_command_sum > 18'sd32767 ?
        16'sd32767 : motor_command_sum < -18'sd32768 ? -16'sd32768 :
        motor_command_sum[15:0];

    // -----------------------------------------------------------------------------
    // 7. 电机驱动与仲裁 (A/B 双通道并联镜像输出)
    // -----------------------------------------------------------------------------
    // Flush the high-duty swing-up command on capture before enabling BALANCE.
    // No prepared/active 255 command may carry into the upright controller.
    wire swingup_handoff_flush = balance_entry_tick && previous_fsm_state == FSM_SWINGUP;
    wire motor_base_enable = `MOTOR_HARDWARE_ENABLE && !immediate_stop && !swingup_handoff_flush &&
        !over_travel_fault && !over_speed_fault &&
        (lqr_ctrl_enable || swingup_ctrl_enable || ((fsm_state == FSM_JOG) && jog_request));
    wire [7:0] ident_duty;
    wire [1:0] ident_direction = jog_cw_active ? 2'b01 : jog_ccw_active ? 2'b10 : 2'b00;
    motor_ident_profile u_ident_profile (
        .clk(clk_sys), .rst_n(rst_n),
        .request(`MOTOR_IDENT_ENABLE && motor_base_enable && fsm_state == FSM_JOG && jog_request),
        .direction(ident_direction), .duty(ident_duty));
    // In the candidate, only held-key diagnostic pulses may energize the motor.
    // Zero gaps flush the driver pipeline instead of leaving a previous pulse active.
    wire motor_safe_enable = motor_base_enable && (!`MOTOR_IDENT_ENABLE ||
        ((fsm_state == FSM_JOG) && jog_request && ident_duty != 0));
    wire [1:0] arb_motor_dir = (fsm_state == FSM_JOG) ?
        (jog_cw_active ? 2'b01 : jog_ccw_active ? 2'b10 : 2'b00) :
        (fsm_state == FSM_SWINGUP) ? swingup_motor_dir : balance_motor_dir;
    wire [7:0] arb_duty = (fsm_state == FSM_JOG) ? (`MOTOR_IDENT_ENABLE ? ident_duty : `JOG_PWM_DUTY) :
        (fsm_state == FSM_SWINGUP) ? swingup_duty : balance_motor_duty;
    wire pwm_out_wire, in1_out_wire, in2_out_wire;
    motor_tb6612 u_motor (
        .clk_50m(clk_sys), .rst_n(rst_n), .safe_enable(motor_safe_enable),
        .motor_dir(arb_motor_dir), .duty_in(arb_duty),
        .deadband_pos(`PWM_DEADBAND_POS), .deadband_neg(`PWM_DEADBAND_NEG),
        .deadzone_thresh(`PWM_DEADZONE_THRESH),
        .swingup_mode(fsm_state == FSM_SWINGUP),
        .in1(in1_out_wire), .in2(in2_out_wire), .pwm(pwm_out_wire), .applied_pwm(applied_pwm));

    // 双通道同步并联驱动: 无论插 XH1(A) 还是 XH2(B) 均能完美工作
    assign PWMA = pwm_out_wire;
    assign AN1  = in1_out_wire;
    assign AN2  = in2_out_wire;
    assign PWMB = pwm_out_wire;
    assign BN1  = in1_out_wire;
    assign BN2  = in2_out_wire;

    // Remote UART on W7 (RX), W8 (TX): 115200 8N1.
    wire external_write,usb_write;
    wire [7:0] external_data,usb_data,external_operation,usb_operation;
    wire [15:0] external_target,usb_target;
    wire usb_stop_request = usb_write && usb_operation == 8'h20 && usb_data == 8'h02 && usb_target[15:8]==0;
    wire external_stop_request = external_write && external_operation == 8'h20 && external_data == 8'h02 && external_target[15:8]==0;
    // Stop wins across ports; target low byte 02 must never be mistaken for stop.
    wire usb_grant = usb_write && (!external_write || usb_stop_request || !external_stop_request);
    wire external_grant = external_write && !usb_grant;
    assign command_write = usb_write || external_write;
    assign bus_data = usb_grant ? usb_data : external_data;
    assign bus_operation = usb_grant ? usb_operation : external_operation;
    assign bus_target = usb_grant ? usb_target : external_target;
    wire legacy_command_write = command_write && bus_operation == 8'h20 && bus_target[15:8]==0;
    reg [7:0] usb_last_command,usb_result,external_last_command,external_result;
    reg [7:0] last_remote_command,remote_result;
    assign remote_stop = legacy_command_write && bus_data == 8'h02;
    wire remote_start_blocked = estop_latch || sw_estop_pulse || sample_timeout ||
        over_travel_fault || over_speed_fault || (fsm_state == FSM_FAULT && fault_cause != 4);
    wire remote_start_request=legacy_command_write && bus_data==8'h01;
    wire remote_start_accepted=remote_start_request && !remote_start_blocked;
    wire remote_start_allowed = !remote_stop_latch && !remote_start_blocked &&
        sample_seen && swingup_start_condition &&
        fsm_state != FSM_BALANCE && fsm_state != FSM_SWINGUP && fsm_state != FSM_FAULT;
    reg remote_start_pending;
    assign remote_start=(remote_start_request || remote_start_pending) && remote_start_allowed;
    always @(posedge clk_sys or negedge rst_n) begin
        if(!rst_n) remote_start_pending<=0;
        else if(remote_stop || remote_start_blocked || key_pulse[0]) remote_start_pending<=0;
        else if(remote_start || fsm_state==FSM_BALANCE || fsm_state==FSM_SWINGUP) remote_start_pending<=0;
        // Retain this request while STOP clears and cause 4 returns to STANDBY,
        // then enter the existing start path once the physical window is ready.
        else if(remote_start_accepted) remote_start_pending<=1;
        else if(remote_stop_latch) remote_start_pending<=0;
    end
    wire remote_move_allowed = fsm_state == FSM_BALANCE && !immediate_stop;
    assign remote_plus = legacy_command_write && bus_data == 8'h03 && remote_move_allowed;
    assign remote_minus = legacy_command_write && bus_data == 8'h04 && remote_move_allowed;
    wire signed [16:0] absolute_target_error = $signed({1'b0,bus_target}) - $signed({1'b0,calibrated_alpha_center});
    wire absolute_target_allowed =
        absolute_target_error <= ARM_TRAVEL_LIMIT_S && absolute_target_error >= -ARM_TRAVEL_LIMIT_S;
    wire hold_target_allowed = 1'b1;
    wire remote_set_target = command_write && bus_operation == 8'h30 && absolute_target_allowed;
    assign remote_hold_target = command_write && bus_operation == 8'h31 && bus_target == 0 && hold_target_allowed;
    wire [7:0] bus_history_code = bus_operation == 8'h20 ? bus_data : bus_operation;
    reg [7:0] selected_command_result;
    always @* begin
        case(bus_operation)
            8'h40: selected_command_result = bus_target>2 ? 2 : nn_request_ok ? 0 : 1;
            8'h30: selected_command_result = absolute_target_allowed ? 0 : 2;
            8'h31: selected_command_result = bus_target != 0 ? 2 : hold_target_allowed ? 0 : 1;
            8'h20: begin
                if(bus_target[15:8]!=0) selected_command_result=2;
                else case(bus_data)
                    8'h01: selected_command_result = remote_start_blocked ? 1 : 0;
                    8'h02,8'h05: selected_command_result = 0;
                    8'h03: selected_command_result = (remote_move_allowed &&
                        position_target_center_err <= ARM_TRAVEL_LIMIT_S-ARM_TARGET_STEP_S && !key_pulse[2]) ? 0 : 1;
                    8'h04: selected_command_result = (remote_move_allowed &&
                        position_target_center_err >= -ARM_TRAVEL_LIMIT_S+ARM_TARGET_STEP_S && !key_pulse[1]) ? 0 : 1;
                    default: selected_command_result = 2;
                endcase
            end
            default: selected_command_result = 3;
        endcase
    end
    always @(posedge clk_sys or negedge rst_n) begin
        if(!rst_n) begin
            remote_stop_latch <= 0; last_remote_command <= 0; remote_result <= 0;
            usb_last_command <= 0;usb_result <= 0;external_last_command <= 0;external_result <= 0;
        end else begin
            if(command_write) begin
                last_remote_command <= bus_history_code;remote_result <= selected_command_result;
                if(legacy_command_write && bus_data == 8'h02) remote_stop_latch <= 1;
                else if(remote_start_accepted || (legacy_command_write && bus_data == 8'h05)) remote_stop_latch <= 0;
            end
            if(usb_write) begin
                usb_last_command <= usb_operation == 8'h20 ? usb_data : usb_operation;
                usb_result <= (usb_grant || usb_stop_request) ? selected_command_result : 1;
            end
            if(external_write) begin
                external_last_command <= external_operation == 8'h20 ? external_data : external_operation;
                external_result <= (external_grant || external_stop_request) ? selected_command_result : 1;
            end
            if(hmi_result_pulse) begin
                if(hmi_result_usb) usb_result <= hmi_command_result;
                else external_result <= hmi_command_result;
            end
        end
    end
    // Commands update a latest-target mailbox even outside BALANCE.
    // Applying the target still requires the original motor safety gates.
    always @(posedge clk_sys or negedge rst_n) begin
        if(!rst_n) begin queued_arm_valid<=0;queued_arm_target<=`ENCODER_INIT_POS;end
        else if(remote_stop || sw_estop_pulse || remote_hold_target ||
                (fsm_state==FSM_FAULT && previous_fsm_state!=FSM_FAULT)) queued_arm_valid<=0;
        else begin
            if(fsm_state==FSM_BALANCE && !immediate_stop) queued_arm_valid<=0;
            if(remote_set_target) begin queued_arm_valid<=1;queued_arm_target<=bus_target;end
            if(hmi_move_pulse) begin queued_arm_valid<=1;queued_arm_target<=hmi_move_target;end
        end
    end
    // OP32/33 are relative arm moves: -6000..6000 maps to -180..180 deg.
    always @(posedge clk_sys or negedge rst_n) begin
        if(!rst_n) hmi_stopped<=0;
        else if(remote_stop || sw_estop_pulse) hmi_stopped<=1;
        else if(sw_calib_pulse) hmi_stopped<=0;
    end
    slave_hmi_adapter u_slave_hmi (
        .clk(clk_sys),.rst_n(rst_n),.control_tick(control_tick),
        .command_write(command_write),.command_usb(usb_grant),.command_op(bus_operation),.command_arg(bus_target),
        .manual_allowed(!remote_stop_latch && !estop_latch && !sample_timeout && !over_travel_fault && !over_speed_fault && fsm_state!=FSM_FAULT),
        .data_valid(sample_seen && startup_velocity_valid && calibration_valid && !sample_timeout &&
                    !over_travel_fault && !over_speed_fault && fsm_state!=FSM_FAULT),
        .remote_estop(remote_stop_latch || remote_stop),.local_estop(estop_latch || sw_estop_pulse),
        .stopped(hmi_stopped),.state(fsm_state),.restart_pending(auto_restart_pending || remote_start_pending),
        .theta_counts(cur_theta_err),.theta_velocity(cur_theta_dot),.arm_error_counts(cur_alpha_err),
        .arm_position(enc1_sampled_pos),.arm_center(calibrated_alpha_center),
        .final_target(accepted_arm_target),.active_target(target_alpha),
        .move_pulse(hmi_move_pulse),.move_target(hmi_move_target),
        .result_pulse(hmi_result_pulse),.result_usb(hmi_result_usb),.command_result(hmi_command_result),
        .theta_reference_counts(hmi_theta_reference_counts),.theta_reference_cd(hmi_theta_reference_cd),
        .speed_percent(hmi_speed_percent),.sync_enabled(hmi_sync_enabled),.telemetry_bank(hmi_telemetry_bank));

    // Remote protocol uses a signed 16-bit Q4 field; observer output is 20-bit.
    wire signed [15:0] remote_arm_velocity_q4 =
        control_alpha_velocity_q4 > 20'sd32767 ? 16'sd32767 :
        control_alpha_velocity_q4 < -20'sd32768 ? -16'sd32768 : control_alpha_velocity_q4[15:0];
    // Voice legacy state domain is distinct from OP60 HMI state numbering.
    wire [2:0] voice_state=(fsm_state==FSM_FAULT || remote_stop_latch || estop_latch) ? 3'd4 :
        fsm_state==FSM_BALANCE ? 3'd3 :
        (fsm_state==FSM_SWINGUP || remote_start_pending || auto_restart_pending) ? 3'd1 : 3'd0;
    wire [255:0] remote_read_bank = {
        `MAX_ARM_TRAVEL_PULSES,calibrated_alpha_center,frame_number,applied_pwm,target_alpha,accepted_arm_target,
        remote_arm_velocity_q4,enc1_sampled_pos,cur_theta_dot,cur_theta_err,
        4'd0,frame_theta,
        8'h1f,remote_result,last_remote_command,
        nn_trip,(nn_correction!=0),(nn_mode==2),sample_timeout,calibration_valid,remote_stop_latch,estop_latch,motor_safe_enable,
        5'd0,fault_cause,5'd0,fsm_state,8'h02,8'h4a
    };
    // Per-port command history/result: each reply belongs to its own request.
    wire [255:0] usb_read_bank = {remote_read_bank[255:56],usb_result,usb_last_command,remote_read_bank[39:0]};
    wire [255:0] external_read_bank = {remote_read_bank[255:56],external_result,external_last_command,
        remote_read_bank[39:24],5'd0,voice_state,remote_read_bank[15:0]};
    // 100 Hz fixed-rate acquisition, sampled 32 clocks after control tick.
    // No command injection or backpressure into the control path.
    reg [6:0] capture_div;
    reg [5:0] capture_delay;
    reg [31:0] capture_frame;
    assign capture_valid=capture_delay==1;
    always @(posedge clk_sys or negedge rst_n) begin
        if(!rst_n) begin capture_div<=0;capture_delay<=0;capture_frame<=0;end
        else begin
            if(capture_delay!=0) capture_delay<=capture_delay-1'b1;
            if(control_tick) begin
                if(capture_div==99) begin capture_div<=0;capture_delay<=32;capture_frame<=frame_number;end
                else capture_div<=capture_div+1'b1;
            end
        end
    end
    wire [255:0] capture_bank={4'd0,frame_theta,applied_pwm,base_combined_u_mon,
        target_alpha,position_target_alpha,remote_arm_velocity_q4,enc1_sampled_pos,
        cur_theta_dot,cur_theta_err,capture_frame,32'd0,8'd0,
        nn_trip,(nn_correction!=0),(nn_mode==2),sample_timeout,calibration_valid,remote_stop_latch,estop_latch,motor_safe_enable,
        5'd0,fault_cause,5'd0,fsm_state,8'h01,8'hd1};
    uart_remote #(.CAPTURE_ENABLE(1),.UNIFORM_REQUESTS(1),.LEGACY_COMPAT(1)) u_remote_uart (
        .clk(clk_sys),.rst_n(rst_n),.rx(remote_uart_rx),.tx(remote_uart_tx),
        .telemetry_bank(hmi_telemetry_bank),.capture_valid(capture_valid),.capture_bank(capture_bank),.read_bank(external_read_bank),.debug_bank(nn_debug_bank),.write_pulse(external_write),.write_data(external_data),
        .write_operation(external_operation),.write_target(external_target));
    uart_remote #(.CAPTURE_ENABLE(1)) u_usb_uart (
        .clk(clk_sys),.rst_n(rst_n),.rx(uart_rx),.tx(uart_tx),
        .telemetry_bank(hmi_telemetry_bank),.capture_valid(capture_valid),.capture_bank(capture_bank),.read_bank(usb_read_bank),.debug_bank(nn_debug_bank),.write_pulse(usb_write),.write_data(usb_data),
        .write_operation(usb_operation),.write_target(usb_target));

    // -----------------------------------------------------------------------------
    // 8. 串口遥测
    // -----------------------------------------------------------------------------
    wire [7:0] status_byte = {fsm_state, (fault_cause != 0), combined_saturated,
        estop_latch, motor_safe_enable, (enc1_illegal_trans != 0)};
    reg [12:0] report_delay;
    reg [4:0] report_frame_count;
    wire report_tick = report_delay == 13'd1;
    always @(posedge clk_sys or negedge rst_n) begin
        if (!rst_n) begin report_delay <= 0; report_frame_count <= 0; end
        else if (control_tick) begin
            // 32-byte frames at 115200bps need ~2.78ms; send every 30th
            // 100us control frame. Snapshot after its command reaches the PWM boundary.
            report_frame_count <= (report_frame_count == 5'd29) ? 5'd0 : report_frame_count + 5'd1;
            if (report_frame_count == 0) report_delay <= `CONTROL_LOOP_PERIOD_TICKS - 17;
            else if (report_delay != 0) report_delay <= report_delay - 1'b1;
        end
        else if (report_delay != 0) report_delay <= report_delay - 1'b1;
    end
    wire signed [15:0] requested_pwm = !motor_safe_enable ? 16'sd0 :
        arb_motor_dir == 1 ? $signed({8'd0,arb_duty}) :
        arb_motor_dir == 2 ? -$signed({8'd0,arb_duty}) : 16'sd0;
    // Historical telemetry generator is disconnected from USB TX to avoid mixing protocols.
    wire unused_usb_telemetry;
    uart_telemetry u_telemetry (
        .clk_50m(clk_sys), .rst_n(rst_n), .tick_3ms(report_tick),
        .manual_trig(|key_pulse), .theta_raw_in({4'd0,frame_theta}),
        .enc1_pos_in(enc1_sampled_pos), .theta_err_in(cur_theta_err),
        .pwm_duty_signed_in(applied_pwm), .status_byte_in(status_byte),
        .frame_number_in(frame_number), .theta_dot_in(cur_theta_dot),
        .alpha_err_in(cur_alpha_err), .alpha_dot_q4_in(control_alpha_velocity_q4),
        .u_unclamped_in(combined_u_mon), .requested_pwm_in(requested_pwm),
        .fault_cause_in(fault_cause), .illegal_count_in(enc1_illegal_trans),
        .uart_tx(unused_usb_telemetry), .uart_rx(uart_rx));

endmodule
