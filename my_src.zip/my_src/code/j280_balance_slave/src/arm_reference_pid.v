`ifndef ARM_REFERENCE_PID_V
`define ARM_REFERENCE_PID_V
`timescale 1ns/1ps
// Position outer loop: output is Q8 logical angle, never PWM.
module arm_reference_pid #(
 parameter signed [15:0] KP_Q8=185,KD_Q8=1600,I_STEP_Q24=0,
 parameter signed [31:0] I_LIMIT_Q24=268435456,
 parameter signed [15:0] REF_LIMIT_Q8=6144,SLEW_Q8=32,
 parameter OUTPUT_INVERT=0
)(input clk,rst_n,tick,enable,input [15:0] position,target,
 input signed [19:0] velocity_q4,input inner_saturated,
 output reg signed [15:0] reference_q8,output reg saturated,output reg done);
 reg [3:0] state;
 reg signed [16:0] error_sample;
 reg signed [19:0] velocity_sample;
 reg signed [32:0] p_product,i_candidate,i_step;
 reg signed [35:0] d_product;
 reg signed [31:0] i_accum;
 reg signed [37:0] pd_sum,raw_sum;
 reg signed [15:0] desired;
 reg freeze_sample;
 wire signed [16:0] error_now=$signed({1'b0,position})-$signed({1'b0,target});
 function signed [35:0] shr_zero;
  input signed [35:0] value;input [5:0] shift;
  begin shr_zero=value<0 ? -((-value) >>> shift) : value >>> shift;end
 endfunction
 wire signed [31:0] i_clamped=i_candidate>I_LIMIT_Q24 ? I_LIMIT_Q24 :
  i_candidate< -$signed(I_LIMIT_Q24) ? -$signed(I_LIMIT_Q24) : i_candidate[31:0];
 wire signed [37:0] directed=OUTPUT_INVERT ? -raw_sum : raw_sum;
 wire signed [37:0] limit=$signed(REF_LIMIT_Q8);
 wire limited=directed>limit || directed< -limit;
 wire signed [16:0] step_difference=$signed({desired[15],desired})-$signed({reference_q8[15],reference_q8});
 wire drives_deeper=(raw_sum>0 && i_step>0) || (raw_sum<0 && i_step<0);
 always @(posedge clk or negedge rst_n) begin
  if(!rst_n) begin
   state<=0;reference_q8<=0;saturated<=0;done<=0;i_accum<=0;
   error_sample<=0;velocity_sample<=0;p_product<=0;d_product<=0;i_step<=0;
   i_candidate<=0;pd_sum<=0;raw_sum<=0;desired<=0;freeze_sample<=0;
  end else if(!enable) begin state<=0;reference_q8<=0;saturated<=0;done<=0;i_accum<=0;end
  else begin
   done<=0;
   case(state)
    0:if(tick) begin error_sample<=error_now;velocity_sample<=velocity_q4;freeze_sample<=inner_saturated;state<=1;end
    1:begin p_product<=error_sample*$signed(KP_Q8);d_product<=velocity_sample*$signed(KD_Q8);i_step<=error_sample*$signed(I_STEP_Q24);state<=2;end
    2:begin pd_sum<=$signed(p_product)+$signed(shr_zero(d_product,4));i_candidate<=$signed(i_accum)+$signed(i_step);state<=3;end
    3:begin raw_sum<=pd_sum+$signed(shr_zero({{4{i_clamped[31]}},i_clamped},16));state<=4;end
    4:begin
     desired<=directed>limit ? REF_LIMIT_Q8 : directed< -limit ? -REF_LIMIT_Q8 : directed[15:0];
     saturated<=limited;
     if(!freeze_sample && !(drives_deeper && (limited || directed>$signed(reference_q8)+SLEW_Q8 || directed<$signed(reference_q8)-SLEW_Q8))) i_accum<=i_clamped;
     state<=5;
    end
    5:begin
     if(step_difference>SLEW_Q8) reference_q8<=reference_q8+SLEW_Q8;
     else if(step_difference< -$signed(SLEW_Q8)) reference_q8<=reference_q8-SLEW_Q8;
     else reference_q8<=desired;
     done<=1;state<=0;
    end
    default:state<=0;
   endcase
  end
 end
endmodule
`endif
