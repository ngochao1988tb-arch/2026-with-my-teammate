`timescale 1ns/1ps
`include "system_params.vh"
// Steady-state Kalman observer, x=[position, counts per 100us frame].
// A=[1 1;0 1], H=[1 0]. Gains are independent for the two channels.
// Legacy shared gain defaults remain compatible; top overrides each channel.
// Independent observers use modular positions and Q16 fractional states.
// The raw positions still feed controller P terms and all safety checks.
module control_kalman_velocity #(
    parameter signed [16:0] POSITION_GAIN = `KALMAN_POSITION_GAIN_Q16,
    parameter signed [16:0] VELOCITY_GAIN = `KALMAN_VELOCITY_GAIN_Q16,
    parameter signed [16:0] THETA_POSITION_GAIN = POSITION_GAIN,
    parameter signed [16:0] THETA_VELOCITY_GAIN = VELOCITY_GAIN,
    parameter signed [16:0] ALPHA_POSITION_GAIN = POSITION_GAIN,
    parameter signed [16:0] ALPHA_VELOCITY_GAIN = VELOCITY_GAIN
)(
    input clk_50m, rst_n, clear_filter, sample_tick,
    input [11:0] theta_position,
    input [15:0] alpha_position,
    output reg signed [15:0] theta_velocity,
    output reg signed [19:0] alpha_velocity_q4,
    output reg velocity_valid
);
    reg initialized;
    reg [3:0] pending;
    reg [27:0] theta_estimate, theta_prediction, theta_measurement;
    reg [31:0] alpha_estimate, alpha_prediction, alpha_measurement;
    reg signed [31:0] theta_rate, alpha_rate;
    reg signed [27:0] theta_innovation;
    reg signed [31:0] alpha_innovation;
    reg signed [44:0] theta_p_product, theta_v_product;
    reg signed [48:0] alpha_p_product, alpha_v_product;
    wire signed [49:0] theta_rate_next =
        $signed(theta_rate) + ($signed(theta_v_product) >>> 16);
    wire signed [49:0] alpha_rate_next =
        $signed(alpha_rate) + ($signed(alpha_v_product) >>> 16);
    // Bound internal velocity before modular prediction, ~1092 counts/frame.
    function signed [31:0] clamp_rate;
        input signed [49:0] value;
        begin
            clamp_rate = value > 50'sd71582788 ? 32'sd71582788 :
                         value < -50'sd71582788 ? -32'sd71582788 : value[31:0];
        end
    endfunction
    // Truncate symmetrically: negative rounding must not create a drive bias.
    function signed [41:0] truncate_q16;
        input signed [41:0] value;
        reg [41:0] magnitude;
        begin
            magnitude = value < 0 ? -value : value;
            truncate_q16 = value < 0 ? -$signed(magnitude >> 16) :
                                                   $signed(magnitude >> 16);
        end
    endfunction
    wire signed [41:0] theta_scaled = $signed(theta_rate) * 42'sd30;
    wire signed [41:0] alpha_scaled = $signed(alpha_rate) * 42'sd480;
    wire signed [41:0] theta_output = truncate_q16(theta_scaled);
    wire signed [41:0] alpha_output = truncate_q16(alpha_scaled);
    always @(posedge clk_50m or negedge rst_n) begin
        if (!rst_n) begin
            initialized <= 0; pending <= 0; velocity_valid <= 0;
            theta_estimate <= 0; alpha_estimate <= 0;
            theta_prediction <= 0; alpha_prediction <= 0;
            theta_measurement <= 0; alpha_measurement <= 0;
            theta_innovation <= 0; alpha_innovation <= 0;
            theta_p_product <= 0; theta_v_product <= 0;
            alpha_p_product <= 0; alpha_v_product <= 0;
            theta_rate <= 0; alpha_rate <= 0;
            theta_velocity <= 0; alpha_velocity_q4 <= 0;
        end else if (clear_filter) begin
            initialized <= 0; pending <= 0; velocity_valid <= 0;
            theta_rate <= 0; alpha_rate <= 0;
            theta_velocity <= 0; alpha_velocity_q4 <= 0;
        end else begin
            pending <= {pending[2:0], sample_tick && initialized};
            if (sample_tick) begin
                if (!initialized) begin
                    initialized <= 1;
                    theta_estimate <= {theta_position,16'd0};
                    alpha_estimate <= {alpha_position,16'd0};
                    theta_rate <= 0; alpha_rate <= 0;
                end else begin
                    theta_prediction <= theta_estimate + theta_rate;
                    alpha_prediction <= alpha_estimate + alpha_rate;
                    theta_measurement <= {theta_position,16'd0};
                    alpha_measurement <= {alpha_position,16'd0};
                end
            end
            if (pending[0]) begin
                // Width-limited subtraction wraps at 4096/65536 counts.
                theta_innovation <= theta_measurement - theta_prediction;
                alpha_innovation <= alpha_measurement - alpha_prediction;
            end
            if (pending[1]) begin
                theta_p_product <= theta_innovation * THETA_POSITION_GAIN;
                theta_v_product <= theta_innovation * THETA_VELOCITY_GAIN;
                alpha_p_product <= alpha_innovation * ALPHA_POSITION_GAIN;
                alpha_v_product <= alpha_innovation * ALPHA_VELOCITY_GAIN;
            end
            if (pending[2]) begin
                theta_estimate <= theta_prediction + (theta_p_product >>> 16);
                alpha_estimate <= alpha_prediction + (alpha_p_product >>> 16);
                theta_rate <= clamp_rate(theta_rate_next);
                alpha_rate <= clamp_rate(alpha_rate_next);
            end
            if (pending[3]) begin
                theta_velocity <= theta_output > 32767 ? 16'sd32767 :
                    theta_output < -32768 ? -16'sd32768 : theta_output[15:0];
                alpha_velocity_q4 <= alpha_output > 524287 ? 20'sd524287 :
                    alpha_output < -524288 ? -20'sd524288 : alpha_output[19:0];
                velocity_valid <= 1;
            end
        end
    end
endmodule
