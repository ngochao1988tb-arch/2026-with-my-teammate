// =================================================================================
// 工程名称: J280 高云 FPGA 旋转倒立摆控制系统 (硬件现场验证版)
// 文件名称: key_debouncer.v
// 功能说明: 4路轻触按键硬件消抖模块 (SW1~SW4)，输出单周期按键脉冲与稳定电平
// =================================================================================

`timescale 1ns / 1ps
`include "system_params.vh"

module key_debouncer #(
    parameter DEBOUNCE_TICKS = (`SYS_CLK_FREQ_HZ / 100) // 25MHz 下 10ms 消抖时间 (快速点按灵敏捕捉)
)(
    input             clk,
    input             rst_n,
    input      [3:0]  key_raw,              // 原始按键输入 (按键按下为低电平 0)
    
    output reg [3:0]  key_pressed_pulse,    // 按下瞬间输出单周期高电平脉冲
    output reg [3:0]  key_state             // 稳定消抖状态 (1: 按下, 0: 松开)
);

    // 2级寄存器打拍消除亚稳态
    reg [3:0] key_sync_0;
    reg [3:0] key_sync_1;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            key_sync_0 <= 4'b1111;
            key_sync_1 <= 4'b1111;
        end else begin
            key_sync_0 <= key_raw;
            key_sync_1 <= key_sync_0;
        end
    end

    // -----------------------------------------------------------------------------
    // 上电防误触发静默计数器 (25MHz 下 50ms = 1,250,000 个时钟周期)
    // 确保 FPGA 上电或复位释放瞬间，弱上拉未稳定前的引脚毛刺绝不误产生脉冲
    // -----------------------------------------------------------------------------
    reg [21:0] startup_cnt;
    reg        startup_ready;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            startup_cnt   <= 22'd0;
            startup_ready <= 1'b0;
        end else if (!startup_ready) begin
            if (startup_cnt >= (`SYS_CLK_FREQ_HZ / 20) - 1'b1) begin
                startup_ready <= 1'b1;
            end else begin
                startup_cnt <= startup_cnt + 1'b1;
            end
        end
    end

    // 对每一路按键独立消抖计数
    genvar i;
    generate
        for (i = 0; i < 4; i = i + 1) begin : gen_debouncers
            reg [19:0] cnt;
            reg        sample_last;
            reg        state_reg;

            always @(posedge clk or negedge rst_n) begin
                if (!rst_n) begin
                    cnt         <= 20'd0;
                    sample_last <= 1'b1;
                    state_reg   <= 1'b0;
                    key_pressed_pulse[i] <= 1'b0;
                    key_state[i]         <= 1'b0;
                end else begin
                    key_pressed_pulse[i] <= 1'b0; // 默认清零单拍脉冲
                    
                    if (key_sync_1[i] != sample_last) begin
                        // 电平发生变动，重置消抖计时
                        cnt         <= 20'd0;
                        sample_last <= key_sync_1[i];
                    end else if (cnt < DEBOUNCE_TICKS) begin
                        cnt <= cnt + 1'b1;
                    end else begin
                        // 计数已满 10ms，确认稳定电平
                        // 注意: 原始输入按下为 0，此处转换为 1 表示按下
                        if (state_reg != (~sample_last)) begin
                            state_reg <= ~sample_last;
                            if (~sample_last == 1'b1 && startup_ready) begin
                                key_pressed_pulse[i] <= 1'b1; // 仅在上电稳定后且由松开变为按下时输出单脉冲
                            end
                        end
                        key_state[i] <= state_reg;
                    end
                end
            end
        end
    endgenerate

endmodule
