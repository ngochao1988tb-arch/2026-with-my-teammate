`ifndef J280_UART_REMOTE_V
`define J280_UART_REMOTE_V
`timescale 1ns/1ps
`include "system_params.vh"
`include "capture_fifo.v"
// External port also accepts legacy 6-byte OP00/20/31 used by the master voice path.
// Legacy request (6 bytes): A5 5A 01 OP DATA XOR.
// Absolute target (OP30, 7 bytes): A5 5A 01 30 LO HI XOR(01,30,LO,HI).
// Response: 5A A5 01 OP RESULT BANK[0..31] XOR(bytes 2..36).
module uart_remote #(parameter CAPTURE_ENABLE=0, parameter UNIFORM_REQUESTS=0, parameter LEGACY_COMPAT=0, parameter SETTLE_CYCLES=64, parameter BAUD_DIV=`UART_DEBUG_BPS_DIV, parameter TIMEOUT_CLOCKS=(`SYS_CLK_FREQ_HZ / 100))(
 input clk,input rst_n,input rx,output tx,input [255:0] read_bank,input [255:0] debug_bank,
 input capture_valid,input [255:0] capture_bank,
 output reg write_pulse,output reg [7:0] write_data,
 output reg [7:0] write_operation,output reg [15:0] write_target,
 input [255:0] telemetry_bank
);
 reg [2:0] rx_sync;
 reg [1:0] rx_state;
 reg [15:0] rx_count;
 reg [2:0] rx_bit;
 reg [7:0] rx_shift,rx_byte;
 reg rx_valid,rx_error;
 always @(posedge clk or negedge rst_n) begin
  if(!rst_n) begin
   rx_sync<=7;rx_state<=0;rx_count<=0;rx_bit<=0;rx_shift<=0;
   rx_byte<=0;rx_valid<=0;rx_error<=0;
  end else begin
   rx_sync<={rx_sync[1:0],rx};rx_valid<=0;rx_error<=0;
   case(rx_state)
    0: if(!rx_sync[2]) begin rx_count<=BAUD_DIV/2-1;rx_state<=1;end
    1: if(rx_count!=0) rx_count<=rx_count-1'b1;
       else if(rx_sync[2]) rx_state<=0;
       else begin rx_state<=2;rx_count<=BAUD_DIV-1;rx_bit<=0;end
    2: if(rx_count!=0) rx_count<=rx_count-1'b1;
       else begin
        rx_shift[rx_bit]<=rx_sync[2];rx_count<=BAUD_DIV-1;
        if(rx_bit==7) rx_state<=3;else rx_bit<=rx_bit+1'b1;
       end
    3: if(rx_count!=0) rx_count<=rx_count-1'b1;
       else begin
        rx_state<=0;
        if(rx_sync[2]) begin rx_byte<=rx_shift;rx_valid<=1;end
        else rx_error<=1;
       end
   endcase
  end
 end
 reg [2:0] parse_state;
 reg [7:0] address,operation,data_byte,target_high;
 reg [19:0] timeout_count;
 reg pending;
 reg [6:0] settle;
 reg [7:0] pending_operation,pending_data;
 reg [15:0] pending_target;
 wire wide_request=UNIFORM_REQUESTS || operation==8'h30 || operation==8'h32 || operation==8'h33 ||
  operation==8'h34 || operation==8'h35 || operation==8'h38 || operation==8'h60;
 // These master commands have unambiguous zero-high-byte 7-byte forms:
 // sixth byte is either the legacy checksum or the parameter high byte.
 wire short_compat=LEGACY_COMPAT && UNIFORM_REQUESTS &&
  (operation==8'h00 || operation==8'h20 || operation==8'h31);
 wire short_complete=parse_state==5 && short_compat &&
  rx_byte==(address^operation^data_byte);
 wire frame_complete=rx_valid && address==8'h01 &&
  (short_complete || (parse_state==6 &&
   rx_byte==(address^operation^data_byte^(wide_request ? target_high : 8'd0))));
 wire [7:0] completed_high=short_complete ? 8'd0 : target_high;
 wire hmi_control= pending_operation==8'h32 || pending_operation==8'h33 || pending_operation==8'h34 ||
  pending_operation==8'h35 || pending_operation==8'h38;
 reg capture_enabled;
 reg tx_busy;
 wire capture_empty;
 wire capture_config=pending && !tx_busy && settle==1 && pending_operation==8'h50 && pending_data<=1 && CAPTURE_ENABLE;
 wire capture_clear=capture_config && pending_data==1;
 wire capture_pop=pending && !tx_busy && settle==0 && pending_operation==8'h51 && pending_data==0 && CAPTURE_ENABLE && !capture_empty;
 wire [255:0] capture_head;
 wire [5:0] capture_count;
 wire [31:0] capture_generated,capture_dropped;
 capture_fifo u_capture(.clk(clk),.rst_n(rst_n),.clear(capture_clear),
  .enable(capture_enabled),.sample_valid(capture_valid),.sample_bank(capture_bank),
  .pop(capture_pop),.head(capture_head),.empty(capture_empty),.count(capture_count),
  .generated(capture_generated),.dropped(capture_dropped));
 wire [255:0] capture_info={112'd0,16'd32,16'd100,16'd100,2'd0,capture_count,
  7'd0,capture_enabled,capture_dropped,capture_generated,8'h01,8'hd2};
 wire capture_op=CAPTURE_ENABLE && (pending_operation==8'h50 || pending_operation==8'h51 || pending_operation==8'h52);
 wire [255:0] reply_bank=capture_op ?
  ((pending_operation==8'h51 && !capture_empty) ? capture_head : capture_info) : (pending_operation==8'h60 ? telemetry_bank : pending_operation==8'h11 ? debug_bank : read_bank);
 wire [7:0] reply_result=capture_op ?
  ((pending_operation==8'h50 ? pending_data>1 : pending_data!=0) ? 8'd2 :
   (pending_operation==8'h51 && capture_empty) ? 8'd1 : 8'd0) :
  (hmi_control || pending_operation==8'h20 || pending_operation==8'h30 || pending_operation==8'h31 || pending_operation==8'h40) ? read_bank[55:48] :
  (pending_operation==8'h60 || (UNIFORM_REQUESTS && pending_operation==8'h00)) ?
   (pending_target==0 ? 8'd0 : 8'd2) :
  (pending_operation==8'h00 || pending_operation==8'h10 || pending_operation==8'h11) ? 8'd0 : 8'd3;
 always @(posedge clk or negedge rst_n) begin
  if(!rst_n) capture_enabled<=0;
  else if(capture_config) capture_enabled<=pending_data[0];
 end
 reg [7:0] packet[0:37];
 reg [5:0] tx_index;
 reg [3:0] tx_bit;
 reg [15:0] tx_count;
 reg [9:0] tx_shift;
 reg [7:0] checksum;
 integer i;
 assign tx=tx_busy ? tx_shift[0] : 1'b1;
 always @(posedge clk or negedge rst_n) begin
  if(!rst_n) begin
   parse_state<=0;address<=0;operation<=0;data_byte<=0;target_high<=0;timeout_count<=0;
   pending<=0;settle<=0;pending_operation<=0;pending_data<=0;pending_target<=0;write_pulse<=0;write_data<=0;write_operation<=0;write_target<=0;
   tx_busy<=0;tx_index<=0;tx_bit<=0;tx_count<=0;tx_shift<=10'h3ff;checksum=0;
   for(i=0;i<38;i=i+1) packet[i]<=0;
  end else begin
   write_pulse<=0;
   if(parse_state!=0 && !rx_valid) begin
    if(timeout_count>=TIMEOUT_CLOCKS-1) begin parse_state<=0;timeout_count<=0;end
    else timeout_count<=timeout_count+1'b1;
   end
   if(rx_error) begin parse_state<=0;timeout_count<=0;end
   if(rx_valid) begin
    timeout_count<=0;
    case(parse_state)
     0: if(rx_byte==8'ha5) parse_state<=1;
     1: if(rx_byte==8'h5a) parse_state<=2;else parse_state<=rx_byte==8'ha5 ? 1 : 0;
     2: begin address<=rx_byte;parse_state<=3;end
     3: begin operation<=rx_byte;target_high<=0;parse_state<=4;end
     4: begin data_byte<=rx_byte;parse_state<=wide_request ? 5 : 6;end
     5: begin target_high<=rx_byte;parse_state<=short_complete ? 0 : 6;end
     6: parse_state<=0;
     default: parse_state<=0;
    endcase
   end
   if(frame_complete) begin
       if(!pending && !tx_busy) begin
        pending<=1;settle<=SETTLE_CYCLES;pending_operation<=operation;pending_data<=data_byte;pending_target<={completed_high,data_byte};
        if(operation==8'h20 || operation==8'h30 || operation==8'h31 || operation==8'h40 ||
           operation==8'h32 || operation==8'h33 || operation==8'h34 || operation==8'h35 || operation==8'h38) begin
         write_pulse<=1;write_data<=data_byte;write_operation<=operation;write_target<={completed_high,data_byte};
        end
       end else if(operation==8'h20 && (data_byte==8'h01 || data_byte==8'h02) && completed_high==0) begin
        // Execute START/STOP even while a previous response is being sent.
        // Application interlocks still decide whether START is allowed.
        // No second response is queued while busy; poll status after the reply.
        write_pulse<=1;write_data<=data_byte;write_operation<=8'h20;write_target<={8'd0,data_byte};
       end
   end
   if(pending && !tx_busy) begin
    if(settle!=0) settle<=settle-1'b1;
    else begin
     packet[0]<=8'h5a;packet[1]<=8'ha5;packet[2]<=8'h01;packet[3]<=pending_operation;
     packet[4]<=reply_result;
     checksum=8'h01 ^ pending_operation ^ reply_result;
     for(i=0;i<32;i=i+1) begin
      packet[5+i]<=reply_bank[i*8+:8];checksum=checksum ^ reply_bank[i*8+:8];
     end
     packet[37]<=checksum;pending<=0;tx_busy<=1;tx_index<=0;tx_bit<=0;
     tx_count<=BAUD_DIV-1;tx_shift<={1'b1,8'h5a,1'b0};
    end
   end else if(tx_busy) begin
    if(tx_count!=0) tx_count<=tx_count-1'b1;
    else begin
     tx_count<=BAUD_DIV-1;
     if(tx_bit==9) begin
      if(tx_index==37) begin tx_busy<=0;tx_shift<=10'h3ff;end
      else begin tx_index<=tx_index+1'b1;tx_bit<=0;tx_shift<={1'b1,packet[tx_index+1'b1],1'b0};end
     end else begin tx_bit<=tx_bit+1'b1;tx_shift<={1'b1,tx_shift[9:1]};end
    end
   end
  end
 end
endmodule
`endif
