`ifndef NN_CORE_Q12_V
`define NN_CORE_Q12_V
`timescale 1ns/1ps
module nn_core_q12(input clk,rst_n,enable,start,input [255:0] features_q12,
 output reg busy,done,output reg signed [31:0] delta_q12,future_error_q12,
 output reg [7:0] ood_mask);
 `include "nn_weights_q12.vh"
 reg [4:0] state;
 reg [2:0] i,h;
 reg signed [31:0] raw[0:7];
 reg signed [15:0] normalized[0:7],hidden[0:7];
 reg signed [31:0] ma,mb,sample_error;
 reg signed [63:0] product,acc;
 reg [7:0] working_ood;
 wire signed [63:0] norm_value=product >>> 20;
 wire signed [63:0] delta_value=$signed(NN_DELTA_MEAN)+(product >>> 12);
 integer k;
 function signed [15:0] tanh_q12;
  input signed [63:0] a;
  reg signed [63:0] pre;
  reg [31:0] magnitude;
  reg [6:0] index;
  reg signed [31:0] base,next,interp;
  begin
   pre=a >>> 12;
   magnitude=pre<0 ? -pre : pre;
   if(magnitude>=16384) interp=4093;
   else begin
    index=magnitude[14:8];base=nn_tanh_lut(index);next=nn_tanh_lut(index+1'b1);
    interp=base+(((next-base)*$signed({1'b0,magnitude[7:0]})) >>> 8);
   end
   tanh_q12=pre<0 ? -interp : interp;
  end
 endfunction
 always @(posedge clk) product<=ma*mb;
 always @(posedge clk or negedge rst_n) begin
  if(!rst_n) begin
   state<=0;i<=0;h<=0;ma<=0;mb<=0;acc<=0;sample_error<=0;
   busy<=0;done<=0;delta_q12<=0;future_error_q12<=0;ood_mask<=0;working_ood<=0;
   for(k=0;k<8;k=k+1) begin raw[k]<=0;normalized[k]<=0;hidden[k]<=0;end
  end else if(!enable) begin
   state<=0;busy<=0;done<=0;delta_q12<=0;future_error_q12<=0;ood_mask<=0;
  end else begin
   done<=0;
   case(state)
    0: if(start) begin
     for(k=0;k<8;k=k+1) raw[k]<=$signed(features_q12[k*32+:32]);
     sample_error<=$signed(features_q12[31:0]);working_ood<=0;i<=0;busy<=1;state<=1;
    end
    1: begin ma<=raw[i]-nn_mean(i);mb<=nn_inv_std(i);state<=2;end
    2: state<=3;
    3: begin
     normalized[i]<=norm_value>24576 ? 16'sd24576 : norm_value< -24576 ? -16'sd24576 : norm_value[15:0];
     if(norm_value>24576 || norm_value< -24576) working_ood[i]<=1;
     if(i==7) begin i<=0;h<=0;acc<=$signed(nn_b1(0))*64'sd4096;state<=4;end
     else begin i<=i+1'b1;state<=1;end
    end
    4: begin ma<=normalized[i];mb<=nn_w1({h,i});state<=5;end
    5: state<=6;
    6: begin acc<=acc+product;if(i==7) state<=7;else begin i<=i+1'b1;state<=4;end end
    7: begin
     hidden[h]<=tanh_q12(acc);i<=0;
     if(h==7) begin acc<=$signed(NN_B2)*64'sd4096;state<=8;end
     else begin h<=h+1'b1;acc<=$signed(nn_b1(h+1'b1))*64'sd4096;state<=4;end
    end
    8: begin ma<=hidden[i];mb<=nn_w2(i);state<=9;end
    9: state<=10;
    10: begin acc<=acc+product;if(i==7) state<=11;else begin i<=i+1'b1;state<=8;end end
    11: begin ma<=acc >>> 12;mb<=NN_DELTA_STD;state<=12;end
    12: state<=13;
    13: begin
     delta_q12<=delta_value[31:0];future_error_q12<=sample_error+delta_value;
     ood_mask<=working_ood;done<=1;busy<=0;state<=0;
    end
    default: begin state<=0;busy<=0;end
   endcase
  end
 end
endmodule
`endif
