`ifndef J280_I2C_REGISTER_SLAVE_V
`define J280_I2C_REGISTER_SLAVE_V
`timescale 1ns/1ps
// 25MHz sampled I2C target, 100/400kHz. SDA is strictly open drain.
// First write byte selects a register; subsequent bytes write and increment.
// Read snapshot is frozen at START (including repeated START).
module i2c_register_slave #(parameter [6:0] ADDRESS=7'h01)(
 input clk,input rst_n,input scl,inout sda,
 input [255:0] read_bank,
 output reg write_pulse,output reg [7:0] write_address,write_data
);
 reg [2:0] scl_sync,sda_sync;
 reg scl_last,sda_last;
 reg drive_low;
 assign sda=drive_low ? 1'b0 : 1'bz;
 wire rise=scl_sync[2] && !scl_last;
 wire fall=!scl_sync[2] && scl_last;
 wire start=scl_sync[2] && scl_last && sda_last && !sda_sync[2];
 wire stop=scl_sync[2] && scl_last && !sda_last && sda_sync[2];
 localparam IDLE=0,ADDRESS_RX=1,POINTER_RX=2,DATA_RX=3,ACK=4,DATA_TX=5,MASTER_ACK=6;
 reg [2:0] state,next_state;
 reg [2:0] bits;
 reg [7:0] shift,pointer,tx_byte;
 reg ack_low,ack_started,ack_released,ack_sampled,master_continue;
 reg [255:0] snapshot;
 wire [7:0] received={shift[6:0],sda_sync[2]};
 wire [7:0] selected=pointer<32 ? snapshot[pointer[4:0]*8 +: 8] : 8'h00;
 always @(posedge clk or negedge rst_n) begin
  if(!rst_n) begin
   scl_sync<=7;sda_sync<=7;scl_last<=1;sda_last<=1;
  end else begin
   scl_sync<={scl_sync[1:0],scl};sda_sync<={sda_sync[1:0],sda};
   scl_last<=scl_sync[2];sda_last<=sda_sync[2];
  end
 end
 always @(posedge clk or negedge rst_n) begin
  if(!rst_n) begin
   state<=IDLE;next_state<=IDLE;bits<=0;shift<=0;pointer<=0;tx_byte<=0;
   drive_low<=0;ack_low<=0;ack_started<=0;ack_released<=0;ack_sampled<=0;
   master_continue<=0;snapshot<=0;write_pulse<=0;write_address<=0;write_data<=0;
  end else begin
   write_pulse<=0;
   if(start) begin
    state<=ADDRESS_RX;bits<=0;shift<=0;drive_low<=0;snapshot<=read_bank;
   end else if(stop) begin state<=IDLE;drive_low<=0;end
   else case(state)
    ADDRESS_RX,POINTER_RX,DATA_RX: if(rise) begin
     shift<=received;
     if(bits==7) begin
      bits<=0;state<=ACK;ack_started<=0;ack_low<=1;
      if(state==ADDRESS_RX) begin
       if(received[7:1]!=ADDRESS) begin ack_low<=0;next_state<=IDLE;end
       else next_state<=received[0] ? DATA_TX : POINTER_RX;
      end else if(state==POINTER_RX) begin pointer<=received;next_state<=DATA_RX;end
      else begin
       write_address<=pointer;write_data<=received;write_pulse<=1;
       pointer<=pointer+1'b1;next_state<=DATA_RX;
      end
     end else bits<=bits+1'b1;
    end
    ACK: if(fall) begin
     if(!ack_started) begin drive_low<=ack_low;ack_started<=1;end
     else begin
      state<=next_state;bits<=0;drive_low<=0;
      if(next_state==DATA_TX) begin tx_byte<=selected;drive_low<=!selected[7];end
     end
    end
    DATA_TX: begin
     if(rise) begin
      if(bits==7) begin
       state<=MASTER_ACK;ack_released<=0;ack_sampled<=0;bits<=0;
      end else bits<=bits+1'b1;
     end
     if(fall) begin tx_byte<={tx_byte[6:0],1'b0};drive_low<=!tx_byte[6];end
    end
    MASTER_ACK: begin
     if(fall && !ack_released) begin drive_low<=0;ack_released<=1;pointer<=pointer+1'b1;end
     if(rise && ack_released) begin master_continue<=!sda_sync[2];ack_sampled<=1;end
     if(fall && ack_sampled) begin
      if(master_continue) begin state<=DATA_TX;tx_byte<=selected;drive_low<=!selected[7];end
      else begin state<=IDLE;drive_low<=0;end
     end
    end
    default: drive_low<=0;
   endcase
  end
 end
endmodule

`endif
