`timescale 1ns / 1ps
`include "system_params.vh"

// Low-authority arm position loop. Its sign convention deliberately matches
// the former negative alpha LQR gains: a positive encoder error requests a
// positive motor command. The polarity can be flipped from system_params.vh
// after a low-duty bench check without touching the upright controller.
module arm_position_pid #(
    parameter signed [15:0] KP = 16'sd6,
    parameter signed [15:0] KI = 16'sd64,
    parameter signed [15:0] KD = 16'sd768,
    parameter signed [31:0] INTEGRAL_LIMIT = 32'sd131072,
    parameter [7:0] OUTPUT_LIMIT = 8'd48,
    parameter OUTPUT_INVERT = 1'b0
)(
    input clk_50m,
    input rst_n,
    input tick_3ms,
    input enable,
    input [15:0] position,
    input [15:0] target_position,
    input signed [19:0] velocity_q4,
    output reg signed [15:0] correction,
    output reg saturated
);
    wire signed [16:0] error_wide = $signed({1'b0, position}) -
                                    $signed({1'b0, target_position});
    wire signed [15:0] position_error = error_wide[15:0];
    reg signed [31:0] integral_accum;
    reg [4:0] valid_pipe;
    reg signed [15:0] error_s1;
    reg signed [19:0] velocity_s1;
    reg signed [31:0] integral_s2, p_product_s2;
    reg signed [35:0] d_product_s2;
    reg signed [47:0] i_product_s3, p_term_s3, d_term_s3, i_term_s4;
    reg signed [48:0] pd_sum_s4, raw_sum_s5;

    wire signed [32:0] integral_candidate_wide =
        $signed({integral_accum[31], integral_accum}) +
        $signed({{17{error_s1[15]}}, error_s1}); // integral: one thirtieth-reference frame
    wire signed [31:0] integral_candidate =
        (integral_candidate_wide > INTEGRAL_LIMIT) ? INTEGRAL_LIMIT :
        (integral_candidate_wide < -INTEGRAL_LIMIT) ? -INTEGRAL_LIMIT :
        integral_candidate_wide[31:0];

    // Arithmetic right shifts round negative values toward -infinity. The
    // position loop must instead truncate toward zero to avoid a permanent
    // one-count drive bias around the target position.
    function signed [47:0] shift_toward_zero;
        input signed [47:0] value;
        input [5:0] shift_count;
        reg [47:0] magnitude;
        begin
            magnitude = (value < 0) ? -value : value;
            shift_toward_zero = (value < 0) ?
                -$signed(magnitude >> shift_count) : $signed(magnitude >> shift_count);
        end
    endfunction

    // The shared Kalman observer already estimates velocity for LQR and PID.
    // Use that estimate directly to avoid another derivative-path filter delay.

    wire signed [48:0] directed_sum = OUTPUT_INVERT ? -raw_sum_s5 : raw_sum_s5;
    wire signed [48:0] positive_limit = $signed({41'd0, OUTPUT_LIMIT});
    wire signed [48:0] negative_limit = -positive_limit;
    wire signed [15:0] limited_correction =
        (directed_sum > positive_limit) ? $signed({8'd0, OUTPUT_LIMIT}) :
        (directed_sum < negative_limit) ? -$signed({8'd0, OUTPUT_LIMIT}) :
        directed_sum[15:0];
    wire output_limited = (directed_sum > positive_limit) ||
                          (directed_sum < negative_limit);

    // Sample on the same frame as LQR and finish five clocks later.
    // Register the products and sums separately to meet the 20 ns clock period.
    always @(posedge clk_50m or negedge rst_n) begin
        if (!rst_n) begin
            integral_accum <= 0;
            correction <= 0;
            saturated <= 0;
            valid_pipe <= 0;
            error_s1 <= 0; velocity_s1 <= 0;
            integral_s2 <= 0; p_product_s2 <= 0; d_product_s2 <= 0;
            i_product_s3 <= 0; p_term_s3 <= 0; d_term_s3 <= 0;
            i_term_s4 <= 0; pd_sum_s4 <= 0; raw_sum_s5 <= 0;
        end else if (!enable) begin
            integral_accum <= 0;
            correction <= 0;
            saturated <= 0;
            valid_pipe <= 0;
        end else begin
            valid_pipe <= {valid_pipe[3:0],tick_3ms};
            error_s1 <= position_error;
            velocity_s1 <= velocity_q4;

            integral_s2 <= integral_candidate;
            if (valid_pipe[0]) integral_accum <= integral_candidate;
            p_product_s2 <= $signed(KP) * error_s1;
            d_product_s2 <= $signed(KD) * velocity_s1;

            i_product_s3 <= $signed(KI) * integral_s2;
            p_term_s3 <= shift_toward_zero({{16{p_product_s2[31]}},p_product_s2},6'd8);
            d_term_s3 <= shift_toward_zero({{12{d_product_s2[35]}},d_product_s2},6'd12);

            pd_sum_s4 <= $signed({p_term_s3[47],p_term_s3}) +
                         $signed({d_term_s3[47],d_term_s3});
            i_term_s4 <= shift_toward_zero(i_product_s3,`ARM_PID_I_GAIN_SHIFT) / `INTEGRAL_TIME_SCALE;

            raw_sum_s5 <= pd_sum_s4 + $signed({i_term_s4[47],i_term_s4});
            if (valid_pipe[4]) begin
                correction <= limited_correction;
                saturated <= output_limited;
            end
        end
    end
endmodule
