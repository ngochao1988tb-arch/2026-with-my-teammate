`timescale 1ns/1ps
`ifndef SLAVE_HMI_ADAPTER_V
`define SLAVE_HMI_ADAPTER_V
`include "system_params.vh"
// Bounded iterative division avoids a combinational divide in the 25MHz path.
module slave_unsigned_divider(input clk,rst_n,start,input [39:0] numerator,
 input [31:0] denominator,output reg busy,done,output reg [39:0] quotient);
 reg [32:0] remainder;
 reg [31:0] divisor;
 reg [5:0] remaining;
 wire [32:0] trial={remainder[31:0],quotient[39]};
 wire subtract=trial>={1'b0,divisor};
 always @(posedge clk or negedge rst_n) begin
  if(!rst_n) begin busy<=0;done<=0;quotient<=0;remainder<=0;divisor<=1;remaining<=0;end
  else begin
   done<=0;
   if(start && !busy) begin
    quotient<=numerator;divisor<=denominator;remainder<=0;remaining<=40;busy<=1;
   end else if(busy) begin
    remainder<=subtract ? trial-{1'b0,divisor} : trial;
    quotient<={quotient[38:0],subtract};remaining<=remaining-1'b1;
    if(remaining==1) begin busy<=0;done<=1;end
   end
  end
 end
endmodule

module slave_hmi_adapter(input clk,rst_n,control_tick,
 input command_write,command_usb,input [7:0] command_op,input [15:0] command_arg,
 input manual_allowed,data_valid,remote_estop,local_estop,stopped,
 input [2:0] state,input restart_pending,
 input signed [15:0] theta_counts,theta_velocity,arm_error_counts,
 input [15:0] arm_position,arm_center,final_target,active_target,
 output reg move_pulse,output reg [15:0] move_target,
 output reg result_pulse,result_usb,output reg [7:0] command_result,
 output reg signed [15:0] theta_reference_counts,theta_reference_cd,
 output reg [7:0] speed_percent,output reg sync_enabled,
 output reg [255:0] telemetry_bank);
 wire cmd_busy,cmd_done;
 wire is_target=command_op==8'h32 || command_op==8'h33;
 wire is_hmi=is_target || command_op==8'h34 || command_op==8'h35 || command_op==8'h38;
 wire [15:0] arg_magnitude=command_arg[15] ? -command_arg : command_arg;
 // OP32/33 are signed relative ARM moves: -6000..6000 => -180..180 deg.
 // Each received request uses the latest accepted arm target, including a
 // queued target. Repeated requests intentionally accumulate (not idempotent).
 reg target_pending,target_negative,target_usb;
 reg deferred_valid,deferred_usb;
 reg [7:0] deferred_result;
 wire [7:0] immediate_result=is_target ?
     (arg_magnitude>`SLAVE_ARM_MAX_RELATIVE_ARG ? 2 : target_pending || cmd_busy ? 1 : 0) :
     command_op==8'h34 ? (command_arg<=100 ? 0 : 2) :
     command_op==8'h38 ? (command_arg<=1 ? 0 : 2) :
     command_arg!=0 ? 2 : 0;
 reg [15:0] target_base,target_origin;
 reg cmd_start;
 reg [39:0] cmd_numerator;
 wire [39:0] cmd_quotient;
 // 6000 command units = half a turn; round the unsigned magnitude, then
 // apply the sign so positive and negative motion round symmetrically.
 slave_unsigned_divider command_divider(clk,rst_n,cmd_start,cmd_numerator,32'd12000,cmd_busy,cmd_done,cmd_quotient);
 wire signed [40:0] converted_target=$signed({25'd0,target_base})+
  (target_negative ? -$signed({1'b0,cmd_quotient}) : $signed({1'b0,cmd_quotient}));
 wire signed [40:0] converted_center_error=converted_target-$signed({25'd0,target_origin});
 wire target_within=converted_target>=0 && converted_target<=65535 &&
  converted_center_error<=$signed({25'd0,`MAX_ARM_TRAVEL_PULSES}) &&
  converted_center_error>=-$signed({25'd0,`MAX_ARM_TRAVEL_PULSES});
 always @(posedge clk or negedge rst_n) begin
  if(!rst_n) begin
   move_pulse<=0;move_target<=0;result_pulse<=0;result_usb<=0;command_result<=0;
   speed_percent<=100;sync_enabled<=0;target_pending<=0;target_negative<=0;
   target_usb<=0;theta_reference_counts<=0;theta_reference_cd<=0;target_base<=0;target_origin<=0;cmd_start<=0;cmd_numerator<=0;
   deferred_valid<=0;deferred_usb<=0;deferred_result<=0;
  end else begin
   move_pulse<=0;result_pulse<=0;cmd_start<=0;
   deferred_valid<=0;
   if(deferred_valid) begin result_pulse<=1;result_usb<=deferred_usb;command_result<=deferred_result;end
   if(cmd_done && target_pending) begin
    target_pending<=0;result_pulse<=1;result_usb<=target_usb;
    command_result<=target_within ? 0 : 2;
    if(target_within) begin
     move_pulse<=1;move_target<=converted_target[15:0];
    end
   end
   if(command_write && is_hmi) begin
    if(is_target && immediate_result==0) begin
     target_pending<=1;target_negative<=command_arg[15];target_usb<=command_usb;
     target_base<=final_target;target_origin<=arm_center;
     cmd_numerator<=arg_magnitude*`SLAVE_ARM_COUNTS_PER_TURN+40'd6000;cmd_start<=1;
    end else begin
     // Two UARTs may complete different requests on the divider-done edge.
     // Preserve both results instead of overwriting the earlier port's ack.
     if(cmd_done && target_pending) begin
      deferred_valid<=1;deferred_usb<=command_usb;deferred_result<=immediate_result;
     end else begin
      result_pulse<=1;result_usb<=command_usb;command_result<=immediate_result;
     end
     if(immediate_result==0) begin
      if(command_op==8'h34) speed_percent<=command_arg[7:0];
      else if(command_op==8'h38) sync_enabled<=command_arg[0];
      else if(command_op==8'h35) begin move_pulse<=1;move_target<=arm_center;end
     end
    end
   end
  end
 end

 // Snapshot every control frame. Four time-shared 40-clock conversions
 // publish one atomic telemetry bank in <8us, well below the 100us frame.
 reg [2:0] phase;
 reg tele_start,negative;
 reg [39:0] tele_numerator;
 reg [31:0] tele_denominator;
 wire tele_busy,tele_done;
 wire [39:0] tele_quotient;
 reg signed [15:0] snap_theta,snap_velocity,snap_arm_error,snap_reference;
 reg signed [16:0] snap_target_offset;
 reg [15:0] snap_position,snap_final,snap_active;
 reg [7:0] snap_state,snap_flags;
 reg signed [15:0] theta_cd,omega_d10,arm_error_cd,target_cd;
 wire signed [16:0] theta_error_wide=$signed({theta_cd[15],theta_cd})-$signed({snap_reference[15],snap_reference});
 wire signed [15:0] theta_error_cd=theta_error_wide>32767 ? 16'sd32767 :
  theta_error_wide < -32768 ? -16'sd32768 : theta_error_wide[15:0];
 wire signed [15:0] converted_value=negative ?
  (tele_quotient>=32768 ? -16'sd32768 : -$signed(tele_quotient[15:0])) :
  (tele_quotient>32767 ? 16'sd32767 : $signed(tele_quotient[15:0]));
 wire [16:0] target_magnitude=snap_target_offset<0 ? -snap_target_offset : snap_target_offset;
 function [15:0] magnitude16;
  input signed [15:0] value;
  begin magnitude16=value<0 ? -value : value;end
 endfunction
 slave_unsigned_divider telemetry_divider(clk,rst_n,tele_start,tele_numerator,tele_denominator,tele_busy,tele_done,tele_quotient);
 always @(posedge clk or negedge rst_n) begin
  if(!rst_n) begin
   phase<=0;tele_start<=0;negative<=0;tele_numerator<=0;tele_denominator<=1;
   snap_reference<=0;snap_theta<=0;snap_velocity<=0;snap_arm_error<=0;snap_target_offset<=0;
   snap_position<=0;snap_final<=0;snap_active<=0;snap_state<=0;snap_flags<=0;
   theta_cd<=0;omega_d10<=0;arm_error_cd<=0;target_cd<=0;telemetry_bank<=0;
  end else begin
   tele_start<=0;
   case(phase)
    0: if(control_tick) begin
     snap_reference<=theta_reference_cd;snap_theta<=theta_counts;snap_velocity<=theta_velocity;snap_arm_error<=arm_error_counts;
     snap_target_offset<=$signed({1'b0,final_target})-$signed({1'b0,arm_center});
     snap_position<=arm_position;snap_final<=final_target;snap_active<=active_target;
     snap_flags<={5'd0,remote_estop,manual_allowed,data_valid};
     snap_state<=remote_estop || local_estop ? 4 : state==4 ? 5 : state==2 ? 2 :
                 state==5 || state==3 || restart_pending ? 1 : stopped ? 3 : 0;
     phase<=1;
    end
    1: begin
     tele_numerator<=magnitude16(snap_theta)*40'd36000;
     tele_denominator<=`SLAVE_THETA_COUNTS_PER_TURN;negative<=snap_theta<0;
     tele_start<=1;phase<=2;
    end
    2: if(tele_done) begin
     theta_cd<=converted_value;
     tele_numerator<=magnitude16(snap_velocity)*40'd1200000;
     tele_denominator<=`SLAVE_THETA_COUNTS_PER_TURN;negative<=snap_velocity<0;
     tele_start<=1;phase<=3;
    end
    3: if(tele_done) begin
     omega_d10<=converted_value;
     tele_numerator<=magnitude16(snap_arm_error)*40'd36000;
     tele_denominator<=`SLAVE_ARM_COUNTS_PER_TURN;negative<=snap_arm_error<0;
     tele_start<=1;phase<=4;
    end
    4: if(tele_done) begin
     arm_error_cd<=converted_value;
     tele_numerator<=target_magnitude*40'd36000;
     tele_denominator<=`SLAVE_ARM_COUNTS_PER_TURN;negative<=snap_target_offset<0;
     tele_start<=1;phase<=5;
    end
    5: if(tele_done) begin target_cd<=converted_value;phase<=6;end
    6: begin
     // Bank byte zero becomes response byte five. All fields are little endian.
     telemetry_bank<={80'd0,snap_active,snap_final,16'd0,snap_position,16'd0,
                     snap_reference,theta_error_cd,arm_error_cd,target_cd,omega_d10,theta_cd,snap_flags,snap_state};
     phase<=0;
    end
    default: phase<=0;
   endcase
  end
 end
endmodule
`endif
