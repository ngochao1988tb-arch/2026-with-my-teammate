`ifndef J280_CAPTURE_FIFO_V
`define J280_CAPTURE_FIFO_V
module capture_fifo #(parameter ADDR_BITS=5)(
 input clk,rst_n,input clear,input enable,input sample_valid,
 input [255:0] sample_bank,input pop,
 output [255:0] head,output empty,
 output reg [ADDR_BITS:0] count,
 output reg [31:0] generated,dropped
);
 localparam DEPTH=1<<ADDR_BITS;
 reg [255:0] memory[0:DEPTH-1];
 reg [ADDR_BITS-1:0] wp,rp;
 reg [255:0] read_data;
 wire take=pop && !empty;
 wire offer=enable && sample_valid;
 wire put=offer && (count<DEPTH || take);
 assign empty=count==0;
 assign head=read_data;
 wire [255:0] stored_sample={sample_bank[255:80],generated,sample_bank[47:0]};
 // Synchronous RAM read. Protocol waits three clocks before consuming head.
 always @(posedge clk) begin
  if(put && !clear) memory[wp]<=stored_sample;
  // Forward first enqueue: a fetch may settle immediately after an empty write.
  read_data<=(put && !clear && wp==rp) ? stored_sample : memory[rp];
 end
 always @(posedge clk or negedge rst_n) begin
  if(!rst_n) begin wp<=0;rp<=0;count<=0;generated<=0;dropped<=0;end
  else if(clear) begin wp<=0;rp<=0;count<=0;generated<=0;dropped<=0;end
  else begin
   if(offer) generated<=generated+1'b1;
   if(offer && !put) dropped<=dropped+1'b1;
   if(put) wp<=wp+1'b1;
   if(take) rp<=rp+1'b1;
   case({put,take})
    2'b10:count<=count+1'b1;
    2'b01:count<=count-1'b1;
   endcase
  end
 end
endmodule
`endif
