// Fixed-target 2026-10-26 trained 8-8-1; Q12/Q20.
function signed [31:0] nn_mean;
 input [2:0] index;
 begin case(index)
 0: nn_mean=-32'sd182737;
 1: nn_mean=-32'sd19;
 2: nn_mean=-32'sd33;
 3: nn_mean=32'sd23;
 4: nn_mean=32'sd51960;
 5: nn_mean=32'sd26;
 6: nn_mean=-32'sd1826;
 7: nn_mean=-32'sd3622;
 default: nn_mean=0;
 endcase end
endfunction
function signed [31:0] nn_inv_std;
 input [2:0] index;
 begin case(index)
 0: nn_inv_std=32'sd84822;
 1: nn_inv_std=32'sd485830;
 2: nn_inv_std=32'sd229491;
 3: nn_inv_std=32'sd2173966;
 4: nn_inv_std=32'sd85805;
 5: nn_inv_std=32'sd348871;
 6: nn_inv_std=32'sd52079;
 7: nn_inv_std=32'sd35778;
 default: nn_inv_std=0;
 endcase end
endfunction
function signed [31:0] nn_w1;
 input [5:0] index;
 begin case(index)
 0: nn_w1=32'sd507;
 1: nn_w1=32'sd352;
 2: nn_w1=-32'sd67;
 3: nn_w1=-32'sd651;
 4: nn_w1=-32'sd796;
 5: nn_w1=32'sd585;
 6: nn_w1=32'sd980;
 7: nn_w1=32'sd94;
 8: nn_w1=-32'sd876;
 9: nn_w1=32'sd198;
 10: nn_w1=-32'sd2582;
 11: nn_w1=-32'sd1025;
 12: nn_w1=32'sd1124;
 13: nn_w1=32'sd1674;
 14: nn_w1=32'sd2226;
 15: nn_w1=32'sd463;
 16: nn_w1=-32'sd913;
 17: nn_w1=-32'sd91;
 18: nn_w1=32'sd426;
 19: nn_w1=32'sd177;
 20: nn_w1=32'sd1486;
 21: nn_w1=-32'sd280;
 22: nn_w1=32'sd149;
 23: nn_w1=-32'sd256;
 24: nn_w1=32'sd984;
 25: nn_w1=-32'sd1776;
 26: nn_w1=32'sd2832;
 27: nn_w1=-32'sd631;
 28: nn_w1=-32'sd4334;
 29: nn_w1=32'sd821;
 30: nn_w1=32'sd92;
 31: nn_w1=32'sd657;
 32: nn_w1=-32'sd581;
 33: nn_w1=32'sd301;
 34: nn_w1=-32'sd2226;
 35: nn_w1=32'sd197;
 36: nn_w1=-32'sd880;
 37: nn_w1=32'sd1040;
 38: nn_w1=32'sd525;
 39: nn_w1=-32'sd172;
 40: nn_w1=32'sd1200;
 41: nn_w1=-32'sd492;
 42: nn_w1=32'sd2676;
 43: nn_w1=32'sd453;
 44: nn_w1=32'sd436;
 45: nn_w1=-32'sd516;
 46: nn_w1=-32'sd758;
 47: nn_w1=-32'sd168;
 48: nn_w1=32'sd937;
 49: nn_w1=-32'sd142;
 50: nn_w1=-32'sd282;
 51: nn_w1=-32'sd760;
 52: nn_w1=32'sd240;
 53: nn_w1=32'sd1069;
 54: nn_w1=32'sd667;
 55: nn_w1=32'sd1167;
 56: nn_w1=-32'sd1030;
 57: nn_w1=-32'sd1424;
 58: nn_w1=32'sd895;
 59: nn_w1=-32'sd414;
 60: nn_w1=32'sd1518;
 61: nn_w1=32'sd414;
 62: nn_w1=32'sd413;
 63: nn_w1=32'sd532;
 default: nn_w1=0;
 endcase end
endfunction
function signed [31:0] nn_b1;
 input [2:0] index;
 begin case(index)
 0: nn_b1=32'sd71;
 1: nn_b1=-32'sd1145;
 2: nn_b1=32'sd1488;
 3: nn_b1=-32'sd1140;
 4: nn_b1=32'sd876;
 5: nn_b1=-32'sd1450;
 6: nn_b1=-32'sd120;
 7: nn_b1=-32'sd881;
 default: nn_b1=0;
 endcase end
endfunction
function signed [31:0] nn_w2;
 input [2:0] index;
 begin case(index)
 0: nn_w2=-32'sd2190;
 1: nn_w2=-32'sd2511;
 2: nn_w2=32'sd3302;
 3: nn_w2=32'sd1980;
 4: nn_w2=-32'sd2115;
 5: nn_w2=32'sd2635;
 6: nn_w2=-32'sd2353;
 7: nn_w2=32'sd2781;
 default: nn_w2=0;
 endcase end
endfunction
function signed [31:0] nn_tanh_lut;
 input [6:0] index;
 begin case(index)
 0: nn_tanh_lut=32'sd0;
 1: nn_tanh_lut=32'sd256;
 2: nn_tanh_lut=32'sd509;
 3: nn_tanh_lut=32'sd759;
 4: nn_tanh_lut=32'sd1003;
 5: nn_tanh_lut=32'sd1240;
 6: nn_tanh_lut=32'sd1468;
 7: nn_tanh_lut=32'sd1686;
 8: nn_tanh_lut=32'sd1893;
 9: nn_tanh_lut=32'sd2088;
 10: nn_tanh_lut=32'sd2272;
 11: nn_tanh_lut=32'sd2443;
 12: nn_tanh_lut=32'sd2602;
 13: nn_tanh_lut=32'sd2748;
 14: nn_tanh_lut=32'sd2883;
 15: nn_tanh_lut=32'sd3007;
 16: nn_tanh_lut=32'sd3119;
 17: nn_tanh_lut=32'sd3222;
 18: nn_tanh_lut=32'sd3315;
 19: nn_tanh_lut=32'sd3399;
 20: nn_tanh_lut=32'sd3475;
 21: nn_tanh_lut=32'sd3543;
 22: nn_tanh_lut=32'sd3604;
 23: nn_tanh_lut=32'sd3659;
 24: nn_tanh_lut=32'sd3707;
 25: nn_tanh_lut=32'sd3751;
 26: nn_tanh_lut=32'sd3790;
 27: nn_tanh_lut=32'sd3825;
 28: nn_tanh_lut=32'sd3856;
 29: nn_tanh_lut=32'sd3883;
 30: nn_tanh_lut=32'sd3908;
 31: nn_tanh_lut=32'sd3929;
 32: nn_tanh_lut=32'sd3949;
 33: nn_tanh_lut=32'sd3966;
 34: nn_tanh_lut=32'sd3981;
 35: nn_tanh_lut=32'sd3994;
 36: nn_tanh_lut=32'sd4006;
 37: nn_tanh_lut=32'sd4016;
 38: nn_tanh_lut=32'sd4026;
 39: nn_tanh_lut=32'sd4034;
 40: nn_tanh_lut=32'sd4041;
 41: nn_tanh_lut=32'sd4048;
 42: nn_tanh_lut=32'sd4053;
 43: nn_tanh_lut=32'sd4058;
 44: nn_tanh_lut=32'sd4063;
 45: nn_tanh_lut=32'sd4067;
 46: nn_tanh_lut=32'sd4070;
 47: nn_tanh_lut=32'sd4073;
 48: nn_tanh_lut=32'sd4076;
 49: nn_tanh_lut=32'sd4078;
 50: nn_tanh_lut=32'sd4080;
 51: nn_tanh_lut=32'sd4082;
 52: nn_tanh_lut=32'sd4084;
 53: nn_tanh_lut=32'sd4085;
 54: nn_tanh_lut=32'sd4086;
 55: nn_tanh_lut=32'sd4088;
 56: nn_tanh_lut=32'sd4089;
 57: nn_tanh_lut=32'sd4089;
 58: nn_tanh_lut=32'sd4090;
 59: nn_tanh_lut=32'sd4091;
 60: nn_tanh_lut=32'sd4091;
 61: nn_tanh_lut=32'sd4092;
 62: nn_tanh_lut=32'sd4092;
 63: nn_tanh_lut=32'sd4093;
 64: nn_tanh_lut=32'sd4093;
 default: nn_tanh_lut=0;
 endcase end
endfunction
localparam signed [31:0] NN_B2=32'sd407, NN_DELTA_MEAN=-32'sd61, NN_DELTA_STD=32'sd18733;
