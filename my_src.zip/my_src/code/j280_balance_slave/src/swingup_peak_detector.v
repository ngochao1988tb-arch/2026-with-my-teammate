`timescale 1ns/1ps
`include "system_params.vh"

// Upright distance decreases on ascent. Track net ascent, rather than adding
// positive steps: 100us quantization steps can be smaller than four counts,
// and summing jitter can incorrectly arm a stationary pendulum.
module swingup_peak_detector (
    input clk, input rst_n, input tick, input enable,
    input [11:0] theta_abs_counts,
    input signed [15:0] theta_dot,
    output reg peak_pulse
);
    reg initialized;
    reg [11:0] descent_maximum, ascent_minimum;
    reg [15:0] cooldown;
    wire [11:0] net_ascent = descent_maximum - ascent_minimum;
    wire [11:0] departure = theta_abs_counts >= ascent_minimum ?
                            theta_abs_counts - ascent_minimum : 12'd0;
    wire [15:0] speed_abs = theta_dot[15] ? -theta_dot : theta_dot;
    // ANGLE_STEP is departure hysteresis, not a per-frame rise filter.
    // A flat plateau or a velocity sign change alone is insufficient.
    wire peak_candidate = initialized && cooldown == 0 &&
        net_ascent >= `SWINGUP_PEAK_MIN_RISE &&
        ascent_minimum > `SWINGUP_PEAK_CAPTURE_GUARD &&
        ascent_minimum < `SWINGUP_PEAK_BOTTOM_GUARD &&
        theta_abs_counts < `SWINGUP_PEAK_BOTTOM_GUARD &&
        departure >= `SWINGUP_PEAK_ANGLE_STEP &&
        speed_abs <= `SWINGUP_PEAK_TURN_DOT_MAX;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            peak_pulse <= 0; initialized <= 0;
            descent_maximum <= 0; ascent_minimum <= 0; cooldown <= 0;
        end else if (!enable) begin
            peak_pulse <= 0; initialized <= 0;
            descent_maximum <= 0; ascent_minimum <= 0; cooldown <= 0;
        end else begin
            peak_pulse <= 0;
            if (tick) begin
                if (cooldown != 0) cooldown <= cooldown - 1'b1;
                if (!initialized || theta_abs_counts > descent_maximum) begin
                    initialized <= 1;
                    descent_maximum <= theta_abs_counts;
                    ascent_minimum <= theta_abs_counts;
                end else if (theta_abs_counts < ascent_minimum) begin
                    ascent_minimum <= theta_abs_counts;
                end
                if (peak_candidate) begin
                    peak_pulse <= 1;
                    cooldown <= `SWINGUP_PEAK_COOLDOWN_FRAMES;
                    // A fresh descent tracks the maximum for the next ascent.
                    descent_maximum <= theta_abs_counts;
                    ascent_minimum <= theta_abs_counts;
                end
            end
        end
    end
endmodule
